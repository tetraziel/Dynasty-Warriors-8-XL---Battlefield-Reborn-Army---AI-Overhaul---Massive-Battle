"""Identify executable variants that can use the shipped native patch profile."""

import hashlib
import json
import os
from pathlib import Path
import struct
import tempfile


REFERENCE = json.loads(Path(__file__).with_name('compatibility_reference.json').read_text(encoding='utf-8'))
VERSION = 1


def mismatch(image):
    """Return the first file region that prevents reusing the verified RVAs."""
    core_size = REFERENCE['core_size']
    if len(image) < core_size:
        return 'executable size'
    certificate, certificate_size = struct.unpack_from('<II', image, REFERENCE['security_directory'])
    if (certificate, certificate_size) == (0, 0):
        if len(image) != core_size:
            return 'executable overlay'
    elif certificate != core_size or certificate_size < 8 or certificate + certificate_size != len(image):
        return 'executable signature layout'

    for region in REFERENCE['regions']:
        start, end = region['range']
        data = image[start:end]
        if region.get('ignore'):
            data = bytearray(data)
            for offset, size in region['ignore']:
                data[offset - start:offset - start + size] = bytes(size)
        if hashlib.sha256(data).hexdigest() != region['sha256']:
            return region['name']
    return None


class ProfileStore:
    """Record explicit acceptance of a variant for this exact shipped profile."""

    def __init__(self, directory):
        self.directory = Path(directory) / 'compatibility'

    def record(self, sha256):
        return {'version': VERSION, 'exe_sha256': sha256, 'base_profile_sha256': REFERENCE['source_sha256']}

    def installed(self, sha256):
        path = self.directory / (sha256 + '.json')
        try:
            with path.open(encoding='utf-8') as file:
                return json.loads(file.read(2048)) == self.record(sha256)
        except (OSError, ValueError):
            return False

    def install(self, sha256):
        self.directory.mkdir(parents=True, exist_ok=True)
        target = self.directory / (sha256 + '.json')
        pending = None
        try:
            with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=self.directory,
                                             prefix='profile-', suffix='.pending', delete=False) as file:
                pending = Path(file.name)
                json.dump(self.record(sha256), file, indent=2)
                file.write('\n')
                file.flush()
                os.fsync(file.fileno())
            os.replace(pending, target)
        finally:
            if pending is not None:
                pending.unlink(missing_ok=True)
