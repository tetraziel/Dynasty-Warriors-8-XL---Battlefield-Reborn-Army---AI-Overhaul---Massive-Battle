DW8 XL - Army & AI
Public interface preview, based on v5-ambition-guard-refresh-41

QUICK START
1. Extract the entire folder to a location on your PC.
2. Start Dynasty Warriors 8 Xtreme Legends Complete Edition yourself.
3. Open the included .cmd launcher. A private Python runtime is included; no Python install
   or developer tools are needed. The packaged runtime is for 64-bit Windows.
4. If necessary, Browse for the .exe that actually runs the game. The
   selected executable path is saved immediately, including Unicode paths.
5. Click Check Compatibility. If it offers a profile, click Install Compatibility.
6. Choose the options, press Save Settings to remember them, and press Start.
   Features that prepare a battle need a new battle.
   A green indicator means the tool connected. If it turns red, read the
   error at the bottom of the window. Game PID shows the detected process ID.
7. Use the ? button beside each section for the option explanations.
8. Press Stop before switching to another version of this tool.

SAVE IS DIFFERENT FROM APPLY
Save Settings remembers preferences. Apply Settings updates a running
session. Neither saving nor opening the window starts the game or enables
mods automatically. Preferences are stored at:
%LOCALAPPDATA%\DW8XLArmyAI\settings.json

COMPATIBILITY
Intended for 64-bit Windows 10/11 and the original verified PC build or
an executable variant that passes the compatibility comparison.

With the game open, use Check Compatibility. The status shows the current
step and elapsed seconds. A green dot means the tool is compatible. A red
dot means the profile needs installation or the check found a mismatch.
Copy Result copies the result, executable name and SHA-256 for support.

The check compares a different executable against the verified code, data
and layout. Variants that differ only in file signatures or supported
cosmetic resources can reuse the profile. Click Install Compatibility to
save it locally for that executable, then press Start to activate the mod.
If the executable's code or layout differs, send the copied result to the
mod author. Filename and path matching support Unicode.

WHAT CHANGED IN THIS COPY
- No debug/JSON panel or developer scans.
- Pool diagnostics and NPC allocation balance test are not available.
  The allocation-balance feature is always requested OFF by this interface.
- Fog Distance 100000 has no "test" suffix in its visible label.
- A saved executable chooser, Save Settings and section-help windows.
- Clear status text and error messages instead of continuous debug dumps.

RECOVERY AND GAME DATA
The original game files and save files are not edited by the tool.
Code modifications are applied to the running game memory. Internal
recovery journals are kept under the local application-data directory;
continuous battle, AI and damage-report files are not produced by this copy.
Do not run the development tool and this copy together on the same game.

Some population/display features remain experimental. Large request
numbers are not a count of simultaneously rendered NPCs and do not expand
the native engine pools. Read the ? descriptions before interpreting them.
Fresh bodyguards each battle still needs live validation after defeat.

RUNTIME LICENSES
Python and bundled Tcl/Tk notices are included inside runtime. This package
does not include any game executable or assets. Keep runtime and the .py/.json
resources together with the .cmd launcher.
