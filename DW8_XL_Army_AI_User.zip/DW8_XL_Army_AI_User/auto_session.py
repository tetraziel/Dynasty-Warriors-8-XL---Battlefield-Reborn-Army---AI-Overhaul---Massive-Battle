"""Startup, agent recall and scoped native-target filter bundle."""
import ctypes as C
from ctypes import wintypes as W
import datetime
import hashlib
import json
import struct
from pathlib import Path
from auto_bridge import (AUTO_DATA_SIZE,build_auto_bridge,initial_auto_data,
                         decode_header,read_events)
from bridge import relative_jump
from recall_bridge import (DATA_SIZE as RECALL_DATA_SIZE, initial_recall_data,
                           build_recall_bridge, relative_call, decode_recall,
                           HEADER_SIZE,FOLLOW_FLAG,MODE_EPOCH,FOLLOW_VIEW)
from target_bridge import build_target_bridge
from follow_bridge import build_follow_bridge
from reinforcement_bridge import build_reinforcement_bridge
from morale_limit_bridge import build_morale_limit_bridge
from morale_policy import BASE as POLICY_BASE,initialize as initialize_policy,validate_thresholds
from gate_scan import read_gates
import aggression
import offensive_ai
import ambition_timer
import tactical_balance
import manual_morale
import bundle_support
import ambition_bonus
import guard_army
import zone_balance
import guard_orders
import story_guards
import population
import visibility
import npc_many
import npc_render_request
import npc_allocation_balance
import fog_distance
import ambition_guards
import damage_audit
import guard_damage
import officer_crowd
import officer_hit_audit
import officer_pursuit
import reinforcement_delay
import map_markers
import detachment
import native_hud
import personal_movement
import ambition_duel
import duel_officer_drops
import pool_expansion
import pool_lifecycle
from reinforcement_state import inspect_native_state,summarize_army
from battle_morale import read_balance,HOST_DIAGNOSTICS_BUILD
from core import (BUILD,PROFILE,require,journal_write,validate_profile,audit_player,
                  pointer,uint,player_snapshot)
from transport import Transport
from windows_memory import k,check

LEGACY_BUILD='v5-experimental-player-recall-1'
ASSIST_BUILD='v5-experimental-player-assist-2'
FOLLOW_V3_BUILD='v5-experimental-native-follow-toggle-3'
TRACKING_V4_BUILD='v5-experimental-follow-tracking-4'
INTEGRATED_V5_BUILD='v5-integrated-follow-120-5'
NATIVE01_BUILD='v5-integrated-follow-120-5-native01'
NATIVE_GATES_BUILD='v5-integrated-follow-120-5-native-gates'
RANGE6_BUILD='v5-gates-morale-instant-follow-6'
RANGE7_BUILD='v5-follow-1800-900-7'
AI8_BUILD='v5-npc-decision-frequency-8'
TIMER9_BUILD='v5-ambition-30min-9'
EXTRA_MODULES={'ambition_bonus':ambition_bonus,'guard_army':guard_army,'zone_balance':zone_balance,'guard_orders':guard_orders,'population':population,'visibility':visibility,'story_guards':story_guards,'map_markers':map_markers,'detachment':detachment,'native_hud':native_hud,'personal_movement':personal_movement,'ambition_duel':ambition_duel,'duel_officer_drops':duel_officer_drops,'npc_many':npc_many,'npc_render_request':npc_render_request,'damage_audit':damage_audit,'guard_damage':guard_damage,'officer_crowd':officer_crowd,'officer_hit_audit':officer_hit_audit,'officer_pursuit':officer_pursuit,'reinforcement_delay':reinforcement_delay,'npc_allocation_balance':npc_allocation_balance,'fog_distance':fog_distance,'ambition_guards':ambition_guards}

def stamp():return datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')

def validate_all(memory,patches=()):
    owned={p['mode']:bytes.fromhex(p['replacement_hex']) for p in patches if p['installed']}
    for mode in PROFILE['modes']:
        validate_profile(memory,mode,installed=owned.get(mode),owned_sites=owned)
    for mode,spec in PROFILE['recall']['sites'].items():
        expected=owned.get(mode,bytes.fromhex(spec['original']))
        require(memory.read(memory.base+spec['site_rva'],len(expected))==expected,
                'E_RECALL_SITE_CHANGED_'+mode)
    for rva,sig in PROFILE['recall']['code_checks'].items():
        expected=bytes.fromhex(sig)
        require(memory.read(memory.base+int(rva),len(expected))==expected,
                'E_RECALL_NATIVE_CODE_'+hex(int(rva)))

def specs():
    return {**PROFILE['modes'],**PROFILE['recall']['sites']}

def make_replacement(site,code,original,mode):
    spec=specs()[mode]
    return (relative_call(site,code) if mode in PROFILE['recall']['sites'] and
            spec.get('kind')!='entry' else relative_jump(site,code,len(original)))

def payload_for(mode,base,recall,data,code,*,legacy=False,assist_v2=False,follow_v3=False,tracking_v4=False,integrated_v5=False,native_gates_v5=False,native01_v5=False,detachment_support=False):
    count=1 if legacy or assist_v2 or follow_v3 or tracking_v4 else PROFILE['player_squad_count']
    native_zero=not(tracking_v4 or integrated_v5)
    delay=10 if any((legacy,assist_v2,follow_v3,tracking_v4,integrated_v5,native_gates_v5,native01_v5)) else 0
    if mode=='MORALE_LIMIT_SITE':return build_morale_limit_bridge(base,recall,data,code)
    if mode=='GATE_DEPLETION_SITE':return build_reinforcement_bridge(base,recall,data,code)
    if mode=='AGENT_OBSERVE_LOOP':return build_recall_bridge(base,recall,data,code,observe=True,squad_count=count,native_template_zero=native_zero,delay_seconds=delay,detachment_support=detachment_support)
    if mode=='FOLLOW_ANCHOR_SITE':return build_follow_bridge(base,recall,data,code,follow_v3=follow_v3,squad_count=count,native_template_zero=native_zero,detachment_support=detachment_support)
    if mode=='TARGET_FILTER_ENTRY':return build_target_bridge(base,recall,data,code,assist_v2=assist_v2,follow_v3=follow_v3,squad_count=count,native_template_zero=native_zero)
    if mode in PROFILE['recall']['sites']:
        return build_recall_bridge(base,recall,data,code,legacy=legacy,assist_v2=assist_v2,follow_v3=follow_v3,squad_count=count,native_template_zero=native_zero,delay_seconds=delay,detachment_support=detachment_support)
    return build_auto_bridge(base,data,code,mode,squad_count=count)

class AutoSession(Transport):
    def __init__(self,pid,root):
        super().__init__(pid);self.root=Path(root)

    def installed(self):
        return bool(self.lease and (any(p['installed'] for p in self.lease.get('patches',[])) or
            any(p.get('installed') for p in self.lease.get('offensive_ai',{}).get('patches',[])) or
            any(p.get('installed') for p in self.lease.get('tactical_balance',{}).get('patches',[])) or
            self.lease.get('ambition_timer',{}).get('installed') or
            self.lease.get('ambition_timer',{}).get('secondary',{}).get('installed') or
            any(p.get('installed') for name in EXTRA_MODULES for p in self.lease.get(name,{}).get('patches',[]))))

    def log(self,status,**extra):
        self.lease.update(journal_status=status,installed=self.installed(),**extra)
        journal_write(self.log_path,self.lease)

    def status(self):
        require(self.lease is not None,'E_NO_AUTO_SESSION')
        result={'build':BUILD,'installed':self.installed(),'journal':str(self.log_path),
                'modes':{p['mode']:p['installed'] for p in self.lease['patches']}}
        if 'data_address' in self.lease:
            result.update(decode_header(self.read(self.lease['data_address'],0x20)))
        if 'recall_data_address' in self.lease:
            result['recall']=self.recall_status()
        return result

    def recover(self):
        for path in sorted((self.root/'logs').glob('auto_session_*.json'),reverse=True):
            try:record=json.loads(path.read_text(encoding='utf-8'))
            except (ValueError,OSError):continue
            if record.get('cookie')!=list(self.cookie) or not record.get('installed'):continue
            self.lease=record;self.log_path=path
            legacy=record.get('build')==LEGACY_BUILD
            assist_v2=record.get('build')==ASSIST_BUILD
            follow_v3=record.get('build')==FOLLOW_V3_BUILD
            tracking_v4=record.get('build')==TRACKING_V4_BUILD
            integrated_v5=record.get('build')==INTEGRATED_V5_BUILD
            native_gates_v5=record.get('build')==NATIVE_GATES_BUILD
            require(record.get('build') in (BUILD,TIMER9_BUILD,AI8_BUILD,LEGACY_BUILD,ASSIST_BUILD,FOLLOW_V3_BUILD,TRACKING_V4_BUILD,INTEGRATED_V5_BUILD,NATIVE01_BUILD,NATIVE_GATES_BUILD,RANGE6_BUILD,RANGE7_BUILD),
                    'E_RECOVERY_AUTO_BUILD')
            patches=record.get('patches',[])
            expected_modes=set(specs())-({'TARGET_FILTER_ENTRY','FOLLOW_ANCHOR_SITE'} if legacy
                                        else ({'FOLLOW_ANCHOR_SITE'} if assist_v2 else set()))
            if legacy or assist_v2 or follow_v3:expected_modes.discard('AGENT_OBSERVE_LOOP')
            if record.get('build') not in (BUILD,TIMER9_BUILD,AI8_BUILD,RANGE6_BUILD,RANGE7_BUILD):expected_modes.discard('MORALE_LIMIT_SITE')
            if record.get('build') not in (BUILD,TIMER9_BUILD,AI8_BUILD,RANGE6_BUILD,RANGE7_BUILD,NATIVE_GATES_BUILD):expected_modes.discard('GATE_DEPLETION_SITE')
            require(len(patches)==len(expected_modes) and
                    {p['mode'] for p in patches}==expected_modes,'E_RECOVERY_AUTO_MODES')
            data=record['data_address'];require(0x10000<=data<0xFFF00000,'E_RECOVERY_AUTO_DATA')
            decode_header(self.read(data,0x20))
            recall=record['recall_data_address']
            require(0x10000<=recall<0xFFF00000,'E_RECOVERY_RECALL_DATA')
            self.recall_status()
            if not(legacy or assist_v2):self.validate_follow_view()
            for p in patches:
                spec=specs()[p['mode']];original=bytes.fromhex(spec['original'])
                require(p['site']==self.base+spec['site_rva'] and p['original_hex']==original.hex(),
                        'E_RECOVERY_AUTO_PROFILE')
                code=p['code_address'];size=p['code_size']
                require(0x10000<=code<0xFFF00000 and 0<size<0x4000,'E_RECOVERY_AUTO_CODE_RANGE')
                patched=bytes.fromhex(p['replacement_hex'])
                require(make_replacement(p['site'],code,original,p['mode'])==patched,'E_RECOVERY_AUTO_JUMP')
                expected_code=payload_for(p['mode'],self.base,recall,data,code,legacy=legacy,assist_v2=assist_v2,follow_v3=follow_v3,tracking_v4=tracking_v4,integrated_v5=integrated_v5,native_gates_v5=native_gates_v5,native01_v5=record.get('build')==NATIVE01_BUILD,detachment_support=record.get('build')==BUILD and record.get('detachment_support',False))
                require(len(expected_code)==size and hashlib.sha256(expected_code).hexdigest()==p['code_sha256'],
                        'E_RECOVERY_AUTO_CODE_IDENTITY')
                actual=self.read(p['site'],len(original))
                require(actual in (original,patched),'E_RECOVERY_AUTO_SITE_CONFLICT')
                p['installed']=actual==patched
                require(hashlib.sha256(self.read(code,size)).hexdigest()==p['code_sha256'],
                        'E_RECOVERY_AUTO_CODE')
            self.lease=record;self.log_path=path
            validate_all(self,patches)
            if record.get('offensive_ai',{}).get('patches'):
                offensive_ai.validate(self,record['offensive_ai'])
            if record.get('tactical_balance'):
                require(record['tactical_balance'].get('auto_data_address')==data,'E_TACTICAL_AUTO_DATA_BINDING')
                tactical_balance.validate(self,record['tactical_balance'])
            if record.get('ambition_timer'):
                ambition_timer.validate(self,record['ambition_timer'])
            for name,module in EXTRA_MODULES.items():
                if record.get(name):
                    require(record[name].get('auto_data_address')==data and
                            record[name].get('recall_data_address')==recall,'E_EXTRA_MAIN_BINDING')
                    bundle_support.validate(module,self,record[name])
            return self.status()
        return None

    def start(self):
        self.claim_control()
        found=self.recover()
        if found and self.installed():
            optional=self.lease.get('offensive_ai') or {}
            complete=(all(p['installed'] for p in self.lease['patches']) and
                (not optional.get('patches') or
                 (optional.get('state')=='APPLIED' and all(p['installed'] for p in optional['patches'])) or
                 (optional.get('state') in ('PREPARED','RESTORED') and not any(p['installed'] for p in optional['patches']))))
            timer=self.lease.get('ambition_timer')
            complete=complete and (not timer or
                (timer.get('state')=='APPLIED' and all(p['installed'] for p in ambition_timer.patches(timer))) or
                (timer.get('state') in ('PREPARED','RESTORED') and not any(p['installed'] for p in ambition_timer.patches(timer))))
            tactical=self.lease.get('tactical_balance')
            complete=complete and (not tactical or
                (tactical.get('state')=='APPLIED' and all(p['installed'] for p in tactical['patches'])) or
                (tactical.get('state') in ('PREPARED','RESTORED') and not any(p['installed'] for p in tactical['patches'])))
            complete=complete and (not tactical or tactical.get('version')==tactical_balance.VERSION)
            for name in EXTRA_MODULES:
                extra=self.lease.get(name)
                complete=complete and (not extra or
                    (extra.get('state')=='APPLIED' and all(p['installed'] for p in extra['patches'])) or
                    (extra.get('state') in ('PREPARED','RESTORED') and not any(p['installed'] for p in extra['patches'])))
                complete=complete and (not extra or extra.get('version')==EXTRA_MODULES[name].VERSION)
            if (self.lease['build']==BUILD and complete and found['enabled'] and not found['cancel_requested'] and
                found['recall']['enabled'] and not found['recall']['cancel_requested'] and
                found['recall']['reinforcements']['enabled']):
                self.log('AUTO_RECOVERED_RUNNING');return self.status()
            self.remove()
        self.lease=None
        validate_all(self)
        patches=[]
        for mode,spec in specs().items():
            patches.append({'mode':mode,'site':self.base+spec['site_rva'],
                            'original_hex':spec['original'],'installed':False})
        self.log_path=self.root/'logs'/('auto_session_'+stamp()+'.json')
        self.lease={'build':BUILD,'cookie':list(self.cookie),'patches':patches,
                    'installed':False,'last_sequence_logged':0,'run_id':stamp(),
                    'live_validated':False,'game_files_modified':False,
                    'personal_squad_count':PROFILE['player_squad_count'],
                    'personal_soldiers':PROFILE['player_squad_count']*30,'follow_automatic':True,
                    'reinforcement_experimental':True,'morale_tiers_enabled':True,
                    'detachment_support':True,
                    'allocated_pages_retained_until_process_exit':True}
        self.log('BEFORE_ALLOCATION')
        if self.writer is None:self.open_writer()
        data=self.allocate(AUTO_DATA_SIZE);self.lease['data_address']=data
        self.write(data,initial_auto_data())
        require(self.read(data,AUTO_DATA_SIZE)==initial_auto_data(),'E_AUTO_DATA_VERIFY')
        recall=self.allocate(RECALL_DATA_SIZE);self.lease['recall_data_address']=recall
        # FOLLOW is initialized before publishing any entry point to the game.
        recall_initial=initial_recall_data(follow_enabled=True,gate_enabled=True,policy_enabled=True);self.write(recall,recall_initial)
        require(self.read(recall,RECALL_DATA_SIZE)==recall_initial,'E_RECALL_DATA_VERIFY')
        recall_code=None;prepared=set()
        for p in patches:
            if p['mode'] in ('TARGET_FILTER_ENTRY','FOLLOW_ANCHOR_SITE','AGENT_OBSERVE_LOOP','GATE_DEPLETION_SITE','MORALE_LIMIT_SITE'):
                code=self.allocate(0x4000);payload=payload_for(p['mode'],self.base,recall,data,code,detachment_support=True)
            elif p['mode'] in PROFILE['recall']['sites']:
                if recall_code is None:recall_code=self.allocate(0x4000)
                code=recall_code;payload=payload_for(p['mode'],self.base,recall,data,code,detachment_support=True)
            else:
                code=self.allocate(0x4000);payload=payload_for(p['mode'],self.base,recall,data,code,detachment_support=True)
            p.update(code_address=code,code_size=len(payload),code_sha256=hashlib.sha256(payload).hexdigest(),
                     replacement_hex=make_replacement(p['site'],code,bytes.fromhex(p['original_hex']),p['mode']).hex())
            self.log('BEFORE_CODE_WRITE')
            if code in prepared:
                require(self.read(code,len(payload))==payload,'E_AUTO_SHARED_CODE_VERIFY')
                continue
            self.write(code,payload);require(self.read(code,len(payload))==payload,'E_AUTO_CODE_VERIFY')
            previous=W.DWORD()
            check(k.VirtualProtectEx(self.writer,code,0x4000,0x20,C.byref(previous)))
            check(k.FlushInstructionCache(self.writer,code,len(payload)))
            prepared.add(code)
        forbidden=[(p['site'],p['site']+len(bytes.fromhex(p['original_hex']))) for p in patches]
        try:
            with self.quiesce(forbidden):
                validate_all(self)
                try:
                    for p in patches:
                        p['installed']=True;self.log('PATCH_PENDING')
                        self.patch_site(p['site'],bytes.fromhex(p['original_hex']),
                                        bytes.fromhex(p['replacement_hex']))
                except Exception:
                    # All threads are still held: restore every entry point installed so far.
                    for p in reversed(patches):
                        original=bytes.fromhex(p['original_hex']);actual=self.read(p['site'],len(original))
                        replacement=bytes.fromhex(p['replacement_hex'])
                        if actual==replacement:self.patch_site(p['site'],replacement,original)
                        p['installed']=self.read(p['site'],len(original))!=original
                    raise
            self.log('AUTO_INSTALLED_WAITING')
        except Exception:
            for p in patches:
                try:p['installed']=self.read(p['site'],len(bytes.fromhex(p['original_hex'])))!=bytes.fromhex(p['original_hex'])
                except Exception:p['installed']=True
            self.log('AUTO_INSTALL_ERROR');raise
        return self.status()

    def events(self,after):
        require(self.lease and 'data_address' in self.lease,'E_NO_AUTO_DATA')
        return read_events(self,self.lease['data_address'],after)

    def persist_capture(self,event):
        path=self.root/'logs'/('auto_configuration_'+self.lease['run_id']+'_'+str(event['sequence'])+'.json')
        record={'build':BUILD,'cookie':list(self.cookie),'capture':event,
                'run_id':self.lease['run_id'],'live_behavior_verified':False}
        journal_write(path,record)
        extra={'last_successful_capture':event} if event['state']==3 else {}
        self.log('AUTO_CAPTURE_LOGGED',last_sequence_logged=event['sequence'],last_capture=event,**extra)
        return str(path)

    def observe_phase(self):
        phase=pointer(self,self.base+0x6D10BC)
        return uint(self,phase+0x1C784)

    def recall_status(self):
        require(self.lease and 'recall_data_address' in self.lease,'E_NO_RECALL_DATA')
        legacy=self.lease['build']==LEGACY_BUILD
        assist_v2=self.lease['build']==ASSIST_BUILD
        follow_v3=self.lease['build']==FOLLOW_V3_BUILD
        size=0x88 if legacy else (0x8C if assist_v2 else (0xAC if follow_v3 else HEADER_SIZE))
        result=decode_recall(self.read(self.lease['recall_data_address'],size),legacy=legacy,assist_v2=assist_v2,follow_v3=follow_v3,previous_ranges=self.lease['build'] not in (BUILD,TIMER9_BUILD,AI8_BUILD,RANGE7_BUILD))
        if self.lease['build'] not in (BUILD,TIMER9_BUILD,AI8_BUILD,RANGE6_BUILD,RANGE7_BUILD):result['settings']['delay_seconds']=10
        if self.lease['build'] in (BUILD,TIMER9_BUILD,AI8_BUILD,RANGE6_BUILD,RANGE7_BUILD):require(result['reinforcements']['available'],'E_GATE_DATA_HEADER')
        if self.lease['build'] in (BUILD,TIMER9_BUILD,AI8_BUILD,RANGE6_BUILD,RANGE7_BUILD):require(result['morale_policy']['available'],'E_MORALE_DATA_HEADER')
        result['reinforcements']['morale_tiers_enabled']=result['morale_policy'].get('enabled',False)
        if self.refill_wait_enabled():
            result['reinforcements'].update(wait_seconds=30,native_calendar_window_preserved=False,
                native_gate_and_timing_checks_preserved=False,native_gate_checks_preserved=True,
                timer_scope='PLAYER_AND_EACH_BODYGUARD_ARMY')
        return result

    def scan_gates(self):
        require(self.observe_phase() in (4,5),'E_GATE_SCAN_WAIT_BATTLE')
        state=player_snapshot(self)
        return read_gates(self,state)

    def inspect_group_pool(self,count):
        # Inspection never allocates, patches, suspends, or changes settings.
        result=pool_expansion.inspect(self,count)
        path=self.root/'logs'/('group_pool_'+str(count)+'_plan_'+stamp()+'.json')
        journal_write(path,dict(result,cookie=list(self.cookie)))
        return dict(result,last_report=str(path))

    def capture_pool_lifecycle(self):return pool_lifecycle.capture(self,self.root)

    def apply_manual_morale(self,percent):
        manual_morale.validate_percent(percent)
        require(self.installed() and self.lease['build']==BUILD,'E_MANUAL_MORALE_CURRENT_SESSION')
        require(self.alive(),'E_MANUAL_MORALE_PROCESS_EXITED')
        validate_all(self,self.lease['patches'])
        # No new native hooks or settings changes. Quiesce existing bridges and
        # the native periodic writer before committing the two force values.
        patches=bundle_support.all_patches(self)
        timer=self.lease.get('ambition_timer') or {}
        forbidden=[span for p in patches for span in
            ((p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),
             (p['code_address'],p['code_address']+p['code_size']))]
        forbidden.append((self.base+0x5007B0,self.base+0x500870))
        path=self.root/'logs'/('manual_morale_apply_'+self.lease['run_id']+'_'+stamp()+'.json')
        if self.writer is None:self.open_writer()
        with self.quiesce(forbidden):
            validate_all(self,self.lease['patches'])
            require(uint(self,self.lease['recall_data_address']+16)==0,'E_MANUAL_MORALE_RECALL_BUSY')
            for record in (timer,self.lease.get('tactical_balance') or {},
                           *(self.lease.get(name) or {} for name in EXTRA_MODULES)):
                if record.get('data_address'):
                    require(uint(self,record['data_address']+12)==0,'E_MANUAL_MORALE_OPTIONAL_BRIDGE_BUSY')
            result=manual_morale.apply(self,percent,path,stamp)
        self._manual_morale_application=result
        self._manual_morale_previous=None
        self._manual_morale_observing=True
        return result

    def observe_manual_morale(self):
        if not getattr(self,'_manual_morale_observing',False):return None
        result=manual_morale.observation(self,self._manual_morale_application,
                                         self._manual_morale_previous,stamp)
        path=self.root/'logs'/('manual_morale_observation_'+self.lease['run_id']+'_'+stamp()+'.json')
        result['report']=str(path);journal_write(path,result)
        if result['same_battle_context']:self._manual_morale_previous=result['snapshot']
        else:self._manual_morale_observing=False
        return result

    def refill_wait_enabled(self):
        record=(self.lease or {}).get('reinforcement_delay')
        return bool(record and all(p['installed'] for p in record['patches']) and
                    uint(self,record['data_address']+8)==1)

    def extra_status(self,name):
        require(name in EXTRA_MODULES,'E_EXTRA_NAME')
        result=EXTRA_MODULES[name].public(self,(self.lease or {}).get(name))
        if name=='detachment' and (self.lease or {}).get('native_hud'):
            if native_hud.public(self,self.lease['native_hud'])['enabled']:
                result['feedback']='NATIVE_GUARD_SPRITES_AND_NATIVE_TEXT'
        if name=='guard_army' and self.refill_wait_enabled():
            result.update(gate_timing_preserved=False,replacement_wait_seconds=30,
                          native_gate_selection_preserved=True)
        return result

    def refresh_extra(self,name):
        require(name in EXTRA_MODULES,'E_EXTRA_NAME')
        record=(self.lease or {}).get(name)
        if name=='zone_balance' and record and uint(self,record['data_address']+8)==1:
            try:zone_balance.refresh(self,record)
            except Exception as error:
                self._zone_last={'available':False,'stale':True,'error':str(error)[:512]}
        return self.extra_status(name)

    def refresh_crowd(self):
        record=(self.lease or {}).get('officer_crowd')
        if record and uint(self,record['data_address']+8)==1:
            officer_crowd.refresh(self,record)

    def set_extra(self,name,enabled,*,remove=False):
        require(name in EXTRA_MODULES,'E_EXTRA_NAME')
        if name=='detachment' and enabled:
            require(self.lease.get('detachment_support') is True,'E_DETACHMENT_RESTART_AUTO_REQUIRED')
        if name=='native_hud' and enabled:
            require(self.extra_status('detachment')['enabled'],'E_NATIVE_HUD_REQUIRE_PERSONAL_ORDERS')
            bundle_support.validate(detachment,self,self.lease['detachment'])
            require(uint(self,self.lease['recall_data_address']+detachment.EXTENSION_POINTER)==
                    self.lease['detachment']['data_address'],'E_NATIVE_HUD_ORDERS_BINDING')
        if name=='detachment' and not enabled and self.lease.get('native_hud'):
            self.set_extra('native_hud',False,remove=remove)
        if name=='story_guards':
            if enabled:
                require(self.extra_status('guard_orders')['enabled'],'E_STORY_GUARDS_REQUIRE_UNLIMITED_ORDERS')
            elif self.lease.get(name):
                # Refuse/defer a live-identity teardown before any thread pause.
                story_guards.changes_for_enabled(self,self.lease[name],False)
        if name=='guard_orders' and not enabled:
            require(not self.extra_status('story_guards')['enabled'],'E_STORY_GUARDS_REQUIRE_UNLIMITED_ORDERS')
        validate_all(self,self.lease['patches'])
        result=bundle_support.set_bundle(self,name,EXTRA_MODULES[name],enabled,remove=remove)
        self.persist_extra_observation(name,result,'SETTINGS_CHANGED')
        return result

    def set_population(self,percent):
        validate_all(self,self.lease['patches'])
        result=population.set_percent(self,percent)
        self.persist_extra_observation('population',result,'SETTINGS_CHANGED')
        return result

    def set_npc_render_request(self,enabled,target):
        validate_all(self,self.lease['patches'])
        result=npc_render_request.configure(self,enabled,target)
        result.update(requested_budget_setting=target,requested_enabled=enabled)
        self.persist_extra_observation('npc_render_request',result,'SETTINGS_CHANGED')
        return result

    def set_npc_many(self,enabled,distance):
        validate_all(self,self.lease['patches'])
        result=npc_many.configure(self,enabled,distance)
        result.update(requested_distance_setting=distance,requested_enabled=enabled)
        self.persist_extra_observation('npc_many',result,'SETTINGS_CHANGED')
        return result

    def set_ambition_duel(self,enabled,percent):
        validate_all(self,self.lease['patches'])
        result=ambition_duel.configure(self,enabled,percent)
        self.persist_extra_observation('ambition_duel',result,'SETTINGS_CHANGED')
        return result

    def persist_extra_observation(self,name,view,event='SAMPLE'):
        require(name in EXTRA_MODULES,'E_EXTRA_NAME')
        path=self.root/'logs'/(name+'_'+self.lease['run_id']+'_'+stamp()+'.json')
        journal_write(path,{'build':BUILD,'run_id':self.lease['run_id'],'recorded_utc':stamp(),
            'cookie':list(self.cookie),'event':event,name:view,'live_behavior_verified':False})
        return str(path)

    def aggression_status(self):return aggression.status(self.lease)

    def offensive_ai_status(self):
        result=offensive_ai.public(self,(self.lease or {}).get('offensive_ai'))
        result['legacy_cache']=self.aggression_status()
        return result

    def ambition_timer_status(self):
        return ambition_timer.public(self,(self.lease or {}).get('ambition_timer'))

    def tactical_balance_status(self):
        return tactical_balance.public(self,(self.lease or {}).get('tactical_balance'))

    def set_tactical_balance(self,mask,*,remove=False):
        require(type(mask) is int and 0<=mask<=tactical_balance.ALL and type(remove) is bool,
                'E_TACTICAL_MASK')
        require(self.lease and self.lease['build']==BUILD,'E_TACTICAL_CURRENT_SESSION')
        record=self.lease.get('tactical_balance')
        if not mask and not record:return self.tactical_balance_status()
        require(self.installed(),'E_TACTICAL_AUTO_NOT_RUNNING')
        if not record:
            require(not remove,'E_TACTICAL_STATE')
            validate_all(self,self.lease['patches']);tactical_balance.check_code(self)
            for name,(rva,_) in tactical_balance.SITES.items():
                native=tactical_balance.original(self.base,name)
                require(self.read(self.base+rva,len(native))==native,'E_TACTICAL_SITE_CONFLICT')
            if self.writer is None:self.open_writer()
            data=self.allocate(tactical_balance.SIZE);code=self.allocate(tactical_balance.CODE_SIZE)
            auto=self.lease['data_address'];initial=tactical_balance.initial_data(auto)
            self.write(data,initial);require(self.read(data,len(initial))==initial,'E_TACTICAL_DATA_VERIFY')
            record=tactical_balance.prepare(self.base,data,code,auto)
            for p in record['patches']:
                payload=tactical_balance.build_bridge(self.base,data,p['code_address'],auto,p['mode'])
                self.write(p['code_address'],payload)
                require(self.read(p['code_address'],len(payload))==payload,'E_TACTICAL_CODE_VERIFY')
            prior=W.DWORD()
            check(k.VirtualProtectEx(self.writer,code,tactical_balance.CODE_SIZE,0x20,C.byref(prior)))
            check(k.FlushInstructionCache(self.writer,code,tactical_balance.CODE_SIZE))
            self.log('TACTICAL_BALANCE_PREPARED',tactical_balance=record)
        tactical_balance.validate(self,record)
        require(remove or record['version']==tactical_balance.VERSION,'E_TACTICAL_LEGACY_RESTART_REQUIRED')
        require(record['auto_data_address']==self.lease['data_address'],'E_TACTICAL_AUTO_DATA_BINDING')
        patches=record['patches']
        if not remove and all(p['installed'] for p in patches) and uint(self,record['data_address']+8)==mask:
            return self.tactical_balance_status()
        if not remove:
            require(all(p['installed'] for p in patches) or not any(p['installed'] for p in patches),
                    'E_TACTICAL_RESTORE_REQUIRED')
        all_patches=[*self.lease['patches'],*self.lease.get('offensive_ai',{}).get('patches',[]),*patches]
        if self.lease.get('ambition_timer'):all_patches+=ambition_timer.patches(self.lease['ambition_timer'])
        forbidden=[span for p in all_patches for span in
                   ((p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),
                    (p['code_address'],p['code_address']+p['code_size']))]
        if self.writer is None:self.open_writer()
        with self.quiesce(forbidden):
            tactical_balance.validate(self,record)
            require(uint(self,record['data_address']+12)==0,'E_TACTICAL_BRIDGE_EXECUTING_RETRY')
            before=uint(self,record['data_address']+8);was=[p['installed'] for p in patches]
            try:
                self.write(record['data_address']+8,bytes(4))
                require(uint(self,record['data_address']+8)==0,'E_TACTICAL_DISABLE_VERIFY')
                record['state']='PENDING';self.log('TACTICAL_BALANCE_UPDATE_PENDING')
                for p in (list(reversed(patches)) if remove else patches):
                    if remove and p['installed']:
                        self.patch_site(p['site'],bytes.fromhex(p['replacement_hex']),bytes.fromhex(p['original_hex']))
                        p['installed']=False
                    elif not remove and not p['installed']:
                        p['installed']=True;self.log('TACTICAL_BALANCE_INSTALL_PENDING')
                        self.patch_site(p['site'],bytes.fromhex(p['original_hex']),bytes.fromhex(p['replacement_hex']))
                if not remove:
                    self.write(record['data_address']+8,struct.pack('<I',mask))
                    require(uint(self,record['data_address']+8)==mask,'E_TACTICAL_ENABLE_VERIFY')
                record['state']='RESTORED' if remove else 'APPLIED'
            except Exception:
                for p,previous in reversed(list(zip(patches,was))):
                    native=bytes.fromhex(p['original_hex']);patched=bytes.fromhex(p['replacement_hex'])
                    actual=self.read(p['site'],len(native))
                    require(actual in (native,patched),'E_TACTICAL_ROLLBACK_SITE_CONFLICT')
                    if not previous and actual==patched:self.patch_site(p['site'],patched,native)
                    p['installed']=self.read(p['site'],len(native))==patched
                complete=all(p['installed'] for p in patches)
                restored=before if complete else 0
                self.write(record['data_address']+8,struct.pack('<I',restored))
                require(uint(self,record['data_address']+8)==restored,'E_TACTICAL_ROLLBACK_FAILED')
                record['state']='APPLIED' if complete else ('PENDING' if any(p['installed'] for p in patches) else 'RESTORED')
                self.log('TACTICAL_BALANCE_ROLLED_BACK');raise
        self.log('TACTICAL_BALANCE_UPDATED')
        return self.tactical_balance_status()

    def persist_tactical_observation(self,view):
        path=self.root/'logs'/('tactical_balance_'+self.lease['run_id']+'_'+stamp()+'.json')
        journal_write(path,{'build':BUILD,'run_id':self.lease['run_id'],
            'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'tactical_balance':view,'live_validated':False})
        return str(path)

    def set_ambition_timer(self,enabled,*,remove=False):
        require(type(enabled) is bool and type(remove) is bool,'E_TIMER_ENABLED')
        require(self.lease and (self.lease['build']==BUILD or
                (remove and self.lease['build'] in (TIMER9_BUILD,AI8_BUILD))),'E_TIMER_CURRENT_SESSION')
        record=self.lease.get('ambition_timer')
        if not enabled and not record:return self.ambition_timer_status()
        require(self.installed(),'E_TIMER_AUTO_NOT_RUNNING')
        if not record:
            require(enabled and not remove,'E_TIMER_STATE')
            validate_all(self,self.lease['patches']);ambition_timer.check_code(self)
            require(self.read(self.base+ambition_timer.SITE,6)==ambition_timer.ORIGINAL,
                    'E_TIMER_SITE_CONFLICT')
            require(self.read(self.base+ambition_timer.SECOND_SITE,5)==ambition_timer.SECOND_ORIGINAL,
                    'E_TIMER_SITE_CONFLICT')
            if self.writer is None:self.open_writer()
            data=self.allocate(ambition_timer.SIZE);code=self.allocate(ambition_timer.CODE_SIZE)
            initial=ambition_timer.initial_data();self.write(data,initial)
            require(self.read(data,len(initial))==initial,'E_TIMER_DATA_VERIFY')
            payload=ambition_timer.build_bridge(self.base,data,code);self.write(code,payload)
            require(self.read(code,len(payload))==payload,'E_TIMER_CODE_VERIFY')
            second=ambition_timer.build_bridge(self.base,data,code+ambition_timer.SIZE,secondary=True)
            self.write(code+ambition_timer.SIZE,second)
            require(self.read(code+ambition_timer.SIZE,len(second))==second,'E_TIMER_CODE_VERIFY')
            prior=W.DWORD()
            check(k.VirtualProtectEx(self.writer,code,ambition_timer.CODE_SIZE,0x20,C.byref(prior)))
            check(k.FlushInstructionCache(self.writer,code,ambition_timer.CODE_SIZE))
            record=ambition_timer.prepare(self.base,data,code)
            self.log('AMBITION_TIMER_PREPARED',ambition_timer=record)
        ambition_timer.validate(self,record)
        timer_patches=ambition_timer.patches(record)
        if not remove and all(p['installed'] for p in timer_patches) and uint(self,record['data_address']+8)==int(enabled):
            return self.ambition_timer_status()
        if not remove:
            require(all(p['installed'] for p in timer_patches) or not any(p['installed'] for p in timer_patches),
                    'E_TIMER_RESTORE_REQUIRED')
        patches=[*self.lease['patches'],*self.lease.get('offensive_ai',{}).get('patches',[]),*timer_patches]
        forbidden=[span for p in patches for span in
            ((p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),
             (p['code_address'],p['code_address']+p['code_size']))]
        if self.writer is None:self.open_writer()
        with self.quiesce(forbidden):
            ambition_timer.validate(self,record)
            require(uint(self,record['data_address']+12)==0,'E_TIMER_BRIDGE_EXECUTING_RETRY')
            before=uint(self,record['data_address']+8);was_installed=[p['installed'] for p in timer_patches]
            try:
                self.write(record['data_address']+8,bytes(4))
                require(uint(self,record['data_address']+8)==0,'E_TIMER_DISABLE_VERIFY')
                if remove:
                    record['state']='PENDING';self.log('AMBITION_TIMER_REMOVE_PENDING')
                    for p in reversed(timer_patches):
                        if p['installed']:
                            self.patch_site(p['site'],bytes.fromhex(p['replacement_hex']),bytes.fromhex(p['original_hex']))
                            p['installed']=False
                    record['state']='RESTORED'
                else:
                    record['state']='PENDING'
                    for p in timer_patches:
                        if not p['installed']:
                            p['installed']=True;self.log('AMBITION_TIMER_INSTALL_PENDING')
                            self.patch_site(p['site'],bytes.fromhex(p['original_hex']),bytes.fromhex(p['replacement_hex']))
                    self.write(record['data_address']+8,struct.pack('<I',int(enabled)))
                    require(uint(self,record['data_address']+8)==int(enabled),'E_TIMER_ENABLE_VERIFY')
                    record['state']='APPLIED'
            except Exception:
                for p,was in reversed(list(zip(timer_patches,was_installed))):
                    original=bytes.fromhex(p['original_hex']);patched=bytes.fromhex(p['replacement_hex'])
                    actual=self.read(p['site'],len(original))
                    require(actual in (original,patched),'E_TIMER_ROLLBACK_SITE_CONFLICT')
                    if not was and actual==patched:self.patch_site(p['site'],patched,original)
                    p['installed']=self.read(p['site'],len(original))==patched
                complete=all(p['installed'] for p in timer_patches)
                self.write(record['data_address']+8,struct.pack('<I',before if complete else 0))
                require(uint(self,record['data_address']+8)==(before if complete else 0),
                        'E_TIMER_ROLLBACK_FAILED')
                record['state']='APPLIED' if complete else ('PENDING' if any(p['installed'] for p in timer_patches) else 'RESTORED')
                self.log('AMBITION_TIMER_ROLLED_BACK');raise
        self.log('AMBITION_TIMER_UPDATED')
        return self.ambition_timer_status()

    def persist_timer_observation(self,view):
        path=self.root/'logs'/('ambition_timer_'+self.lease['run_id']+'_'+stamp()+'.json')
        journal_write(path,{'build':BUILD,'run_id':self.lease['run_id'],
            'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'ambition_timer':view,'live_validated':False})
        return str(path)

    def set_offensive_ai_tests(self,mask):
        require(type(mask) is int and 0<=mask<=offensive_ai.ALL_TESTS,'E_OFFENSIVE_TEST_MASK')
        require(self.lease and self.lease['build']==BUILD,'E_OFFENSIVE_CURRENT_SESSION')
        if not mask and not self.lease.get('offensive_ai'):return self.offensive_ai_status()
        return self.set_offensive_ai(True,test_mask=mask)

    def persist_ai_observation(self,observation,event='SAMPLE'):
        path=self.root/'logs'/('ai_decisions_'+self.lease['run_id']+'_'+stamp()+'.json')
        journal_write(path,{'build':BUILD,'run_id':self.lease['run_id'],'recorded_utc':
            datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':event,
            'configuration_capture_sequence':self.lease.get('last_sequence_logged',0),
            'aggression':observation,'live_behavior_verified':False})
        return str(path)

    def set_offensive_ai(self,enabled,*,test_mask=None):
        require(type(enabled) is bool,'E_OFFENSIVE_ENABLED')
        require(self.lease and (self.lease['build']==BUILD or
                (not enabled and self.lease['build'] in (TIMER9_BUILD,AI8_BUILD))),'E_OFFENSIVE_CURRENT_SESSION')
        mask=offensive_ai.ALL_TESTS if test_mask is None else test_mask
        require(type(mask) is int and 0<=mask<=offensive_ai.ALL_TESTS,'E_OFFENSIVE_TEST_MASK')
        record=self.lease.get('offensive_ai')
        if not enabled and not record:return self.offensive_ai_status()
        require(self.installed(),'E_OFFENSIVE_AUTO_NOT_RUNNING')
        if enabled:
            validate_all(self,self.lease['patches'])
            if not record:
                for name,spec in offensive_ai.SITES.items():
                    require(self.read(self.base+spec['site_rva'],7)==bytes.fromhex(spec['original']),
                            'E_OFFENSIVE_SITE_CONFLICT_'+name)
                for rva,sig in PROFILE['offensive_ai']['code_checks'].items():
                    require(self.read(self.base+int(rva),len(bytes.fromhex(sig)))==bytes.fromhex(sig),
                            'E_OFFENSIVE_NATIVE_CODE_'+hex(int(rva)))
                if self.writer is None:self.open_writer()
                data=self.allocate(offensive_ai.DATA_SIZE);code=self.allocate(offensive_ai.CODE_SIZE)
                initial=offensive_ai.initial_data();self.write(data,initial)
                require(self.read(data,len(initial))==initial,'E_OFFENSIVE_DATA_VERIFY')
                patches=offensive_ai.prepare(self.base,data,code)
                for p in patches:
                    payload=offensive_ai.build_bridge(self.base,data,p['code_address'],p['mode'])
                    self.write(p['code_address'],payload)
                    require(self.read(p['code_address'],len(payload))==payload,'E_OFFENSIVE_CODE_VERIFY')
                prior=W.DWORD()
                check(k.VirtualProtectEx(self.writer,code,offensive_ai.CODE_SIZE,0x20,C.byref(prior)))
                check(k.FlushInstructionCache(self.writer,code,offensive_ai.CODE_SIZE))
                record={'version':offensive_ai.VERSION,'data_address':data,'code_address':code,
                        'patches':patches,'state':'PREPARED'}
                self.log('OFFENSIVE_AI_PREPARED',offensive_ai=record)
        offensive_ai.validate(self,record)
        if enabled and record['state']=='APPLIED' and all(p['installed'] for p in record['patches']):
            old_mask=uint(self,record['data_address']+8)
            if old_mask!=mask:
                if self.writer is None:self.open_writer()
                forbidden=[span for p in [*self.lease['patches'],*record['patches']] for span in
                    ((p['site'],p['site']+7),(p['code_address'],p['code_address']+p['code_size']))]
                with self.quiesce(forbidden):
                    offensive_ai.validate(self,record)
                    old_epoch=uint(self,record['data_address']+0x3C)
                    require(old_epoch<0xFFFFFFFF,'E_OFFENSIVE_EPOCH_EXHAUSTED')
                    before=struct.pack('<I',old_mask)
                    try:
                        self.write(record['data_address']+8,struct.pack('<I',mask))
                        require(uint(self,record['data_address']+8)==mask,'E_OFFENSIVE_ENABLE_VERIFY')
                        self.write(record['data_address']+0x3C,struct.pack('<I',old_epoch+1))
                        require(uint(self,record['data_address']+0x3C)==old_epoch+1,'E_OFFENSIVE_EPOCH_VERIFY')
                    except Exception:
                        self.write(record['data_address']+8,before)
                        self.write(record['data_address']+0x3C,struct.pack('<I',old_epoch))
                        require(uint(self,record['data_address']+8)==old_mask and
                                uint(self,record['data_address']+0x3C)==old_epoch,'E_OFFENSIVE_SWITCH_ROLLBACK')
                        raise
                self.log('OFFENSIVE_AI_TESTS_CHANGED',offensive_ai_test_mask=mask)
                self.persist_ai_observation(self.offensive_ai_status(),'TESTS_CHANGED')
            return self.offensive_ai_status()
        if not enabled and not any(p['installed'] for p in record['patches']):
            require(uint(self,record['data_address']+8)==0,'E_OFFENSIVE_DISABLE_STATE')
            record['state']='RESTORED';self.log('OFFENSIVE_AI_RESTORED')
            return self.offensive_ai_status()
        if enabled:require(not any(p['installed'] for p in record['patches']),'E_OFFENSIVE_RESTORE_REQUIRED')
        forbidden=[span for p in [*self.lease['patches'],*record['patches']] for span in
            ((p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),
             (p['code_address'],p['code_address']+p['code_size']))]
        if self.writer is None:self.open_writer()
        with self.quiesce(forbidden):
            offensive_ai.validate(self,record)
            self.write(record['data_address']+8,bytes(4))
            require(uint(self,record['data_address']+8)==0,'E_OFFENSIVE_DISABLE_VERIFY')
            if enabled:
                record['state']='PENDING';self.log('OFFENSIVE_AI_INSTALL_PENDING')
                try:
                    for p in record['patches']:
                        p['installed']=True;self.log('OFFENSIVE_AI_PATCH_PENDING')
                        self.patch_site(p['site'],bytes.fromhex(p['original_hex']),bytes.fromhex(p['replacement_hex']))
                    self.write(record['data_address']+8,mask.to_bytes(4,'little'))
                    require(uint(self,record['data_address']+8)==mask,'E_OFFENSIVE_ENABLE_VERIFY')
                    epoch=uint(self,record['data_address']+0x3C)
                    require(epoch<0xFFFFFFFF,'E_OFFENSIVE_EPOCH_EXHAUSTED')
                    self.write(record['data_address']+0x3C,struct.pack('<I',epoch+1))
                    record['state']='APPLIED';self.log('OFFENSIVE_AI_APPLIED')
                except Exception:
                    self.write(record['data_address']+8,bytes(4))
                    for p in reversed(record['patches']):
                        original=bytes.fromhex(p['original_hex']);patched=bytes.fromhex(p['replacement_hex'])
                        actual=self.read(p['site'],7)
                        require(actual in (original,patched),'E_OFFENSIVE_ROLLBACK_SITE_CONFLICT')
                        if actual==patched:self.patch_site(p['site'],patched,original)
                        p['installed']=False
                    record['state']='RESTORED';self.log('OFFENSIVE_AI_INSTALL_ROLLED_BACK')
                    raise
            else:
                record['state']='PENDING';self.log('OFFENSIVE_AI_REMOVE_PENDING')
                for p in reversed(record['patches']):
                    if p['installed']:
                        self.patch_site(p['site'],bytes.fromhex(p['replacement_hex']),bytes.fromhex(p['original_hex']))
                        p['installed']=False;self.log('OFFENSIVE_AI_REMOVING')
                record['state']='RESTORED';self.log('OFFENSIVE_AI_RESTORED')
        self.persist_ai_observation(self.offensive_ai_status(),'TESTS_CHANGED' if enabled else 'HOOKS_REMOVED')
        return self.offensive_ai_status()

    def set_aggression(self,enabled):
        require(type(enabled) is bool,'E_AI_ENABLED')
        require(self.installed() and (self.lease['build']==BUILD or
                (not enabled and self.lease['build'] in (TIMER9_BUILD,AI8_BUILD,RANGE6_BUILD,RANGE7_BUILD))),'E_AI_CURRENT_SESSION')
        validate_all(self,self.lease['patches'])
        forbidden=[span for p in self.lease['patches'] for span in
            ((p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),
             (p['code_address'],p['code_address']+p['code_size']))]
        previous=dict(self.lease.get('aggression_patch') or {})
        if enabled and self.aggression_status()['enabled']:
            if uint(self,self.base+0x6A93B4)==previous['cache']:return self.aggression_status()
            self.log('AI_CONTEXT_RELEASED',aggression_patch={'state':'CONTEXT_RELEASED'})
            previous={'state':'CONTEXT_RELEASED'}
        if not enabled and (self.lease.get('aggression_patch') or {}).get('state') not in ('APPLIED','PENDING'):
            return self.aggression_status()
        if self.writer is None:self.open_writer()
        with self.quiesce(forbidden):
            require(uint(self,self.lease['recall_data_address']+16)==0,'E_RECALL_BRIDGE_EXECUTING_RETRY')
            if not enabled:
                previous=self.lease['aggression_patch'];current=uint(self,self.base+0x6A93B4)
                if current!=previous['cache']:
                    self.log('AI_CONTEXT_RELEASED',aggression_patch={'state':'CONTEXT_RELEASED'})
                    return self.aggression_status()
            address=aggression.check_code(self)
            before=self.read(address,aggression.SIZE)
            try:after=aggression.transformed(before,enabled)
            except aggression.SchemaRefused as error:
                self.log('AI_SCHEMA_REFUSED',aggression_diagnostic=error.diagnostic)
                raise
            self.log('AI_CHANGE_PENDING',aggression_patch={'cache':address,'state':'PENDING',
                      'schema_verified':True,'field_offset':aggression.FIELD})
            try:
                self.write(address,after)
                require(self.read(address,len(after))==after,'E_AI_WRITE_VERIFY')
            except Exception:
                self.write(address,before)
                require(self.read(address,len(before))==before,'E_AI_ROLLBACK_FAILED')
                self.log('AI_CHANGE_ROLLED_BACK',aggression_patch=previous or
                         {'cache':address,'state':'RESTORED','schema_verified':True})
                raise
            self.log('AI_CHANGED',aggression_patch={'cache':address,
                'state':'APPLIED' if enabled else 'RESTORED','schema_verified':True,
                'field_offset':aggression.FIELD},aggression_diagnostic=None)
        return self.aggression_status()

    def set_morale_policy(self,enabled,thresholds):
        require(type(enabled) is bool,'E_MORALE_ENABLED')
        thresholds=validate_thresholds(thresholds)
        require(self.installed() and self.lease['build']==BUILD,'E_MORALE_CURRENT_SESSION')
        validate_all(self,self.lease['patches'])
        require(self.recall_status()['morale_policy']['available'],'E_MORALE_DATA_HEADER')
        forbidden=[span for p in self.lease['patches'] for span in
            ((p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),
             (p['code_address'],p['code_address']+p['code_size']))]
        address=self.lease['recall_data_address']
        with self.quiesce(forbidden):
            require(uint(self,address+16)==0,'E_RECALL_BRIDGE_EXECUTING_RETRY')
            before=self.read(address+POLICY_BASE+8,16)
            after=struct.pack('<4I',int(enabled),*thresholds)
            try:
                self.write(address+POLICY_BASE+8,after)
                require(self.read(address+POLICY_BASE+8,16)==after,'E_MORALE_WRITE_VERIFY')
            except Exception:
                self.write(address+POLICY_BASE+8,before)
                require(self.read(address+POLICY_BASE+8,16)==before,'E_MORALE_ROLLBACK_FAILED')
                raise
        self.log('MORALE_POLICY_UPDATED',morale_tiers_enabled=enabled,morale_thresholds=list(thresholds))
        return self.recall_status()

    def validate_follow_view(self):
        data=self.lease['recall_data_address']
        expected=initial_recall_data()[FOLLOW_VIEW:FOLLOW_VIEW+0x88]
        require(self.read(data+FOLLOW_VIEW,0x88)==expected,'E_FOLLOW_VIEW_CHANGED')

    def set_follow_test(self,enabled):
        require(type(enabled) is bool,'E_FOLLOW_MODE_ARGUMENT')
        require(self.installed() and self.lease['build']==BUILD,'E_FOLLOW_CURRENT_SESSION_REQUIRED')
        require(all(p['installed'] for p in self.lease['patches']),'E_FOLLOW_INCOMPLETE_BUNDLE')
        validate_all(self,self.lease['patches']);self.validate_follow_view()
        for p in self.lease['patches']:
            require(hashlib.sha256(self.read(p['code_address'],p['code_size'])).hexdigest()==p['code_sha256'],
                    'E_FOLLOW_CODE_CHANGED')
        data=self.lease['recall_data_address'];status=self.recall_status()
        require(status['enabled'] and not status['cancel_requested'],'E_FOLLOW_SESSION_STOPPING')
        if status['follow_test']['enabled']==enabled:return status
        epoch=status['follow_test']['mode_epoch'];require(epoch<0xFFFFFFFF,'E_FOLLOW_EPOCH_EXHAUSTED')
        forbidden=[span for p in self.lease['patches'] for span in
            ((p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),
             (p['code_address'],p['code_address']+p['code_size']))]
        if self.writer is None:self.open_writer()
        with self.quiesce(forbidden):
            require(uint(self,self.lease['data_address']+20)==0,'E_AUTO_BRIDGE_EXECUTING_RETRY')
            require(uint(self,data+16)==0,'E_RECALL_BRIDGE_EXECUTING_RETRY')
            require(uint(self,data+MODE_EPOCH)==epoch,'E_FOLLOW_CONFIGURATION_CHANGED')
            old=self.read(data+FOLLOW_FLAG,8)
            replacement=int(enabled).to_bytes(4,'little')+(epoch+1).to_bytes(4,'little')
            try:
                self.write(data+FOLLOW_FLAG,replacement)
                require(self.read(data+FOLLOW_FLAG,8)==replacement,'E_FOLLOW_MODE_WRITE_VERIFY')
            except Exception:
                self.write(data+FOLLOW_FLAG,old)
                require(self.read(data+FOLLOW_FLAG,8)==old,'E_FOLLOW_MODE_RESTORE_FAILED')
                raise
            self.write(data+0xA4,((uint(self,data+0xA4)+1)&0xFFFFFFFF).to_bytes(4,'little'))
        self.log('FOLLOW_TEST_MODE_CHANGED',follow_test_enabled=enabled,follow_mode_epoch=epoch+1)
        return self.recall_status()

    def audit(self,capture):
        require(self.observe_phase() in (4,5),'E_AUDIT_WAIT_BATTLE')
        validate_all(self,self.lease['patches'])
        result=audit_player(self)
        result['host_diagnostics_build']=HOST_DIAGNOSTICS_BUILD
        result['morale_observation']=read_balance(self,result['state'])
        try:result['gate_scan']=read_gates(self,result['state'])
        except Exception as error:result['gate_scan']={'available':False,'read_only':True,'error':str(error)}
        result['native_replenishment']=inspect_native_state(self,result['state'],result['player_groups'])
        result['aggression']=self.offensive_ai_status()
        result['ambition_timer']=self.ambition_timer_status()
        result['tactical_balance']=self.tactical_balance_status()
        result['extra_features']={name:self.extra_status(name) for name in EXTRA_MODULES}
        require(capture['manager']==hex(result['state']['manager']),'E_AUDIT_MANAGER_CHANGED')
        result.update(configuration_capture=capture,
                      configured_squad_count=capture.get('configured_squad_count'),
                      configured_soldiers=capture.get('configured_soldiers'),
                      matching_soldiers_current=sum(g['quantity_current'] for g in result['matching_player_groups']),
                      matching_materialized_members=sum(g['materialized_bits'].bit_count() for g in result['matching_player_groups']),
                      slot_configuration_observed=capture['state']==3,
                      startup_player_count_was_pending=capture.get('players_count_at_load')==0,
                      single_player_runtime_verified=True,
                      consistent_player_assignment_observed=(capture['state']==3 and
                        result['state']['owner']==0 and result['ownership_observed']))
        for owner,entry in result['guard_reservations'].items():
            address=result['state']['ai']+int(owner)*0xAC
            entry['owner_ai_active']=bool(uint(self,address+0x90)&1)
        require(self.observe_phase() in (4,5),'E_AUDIT_BATTLE_CHANGED')
        require(player_snapshot(self)==result['state'],'E_AUDIT_CONTEXT_CHANGED')
        result['recall']=self.recall_status()
        policy_enabled=result['recall']['morale_policy'].get('enabled',False)
        result['morale_observation']['morale_tiers_enabled']=policy_enabled
        result['morale_observation']['policy_control']='SEPARATE_NATIVE_REINFORCEMENT_FILTER'
        result['native_replenishment']['morale_tiers_enabled']=policy_enabled
        result['army_observation']=summarize_army(result)
        return result

    def persist_audit(self,result):
        path=self.root/'logs'/('auto_player_audit_'+self.lease['run_id']+'_'+stamp()+'.json')
        result=dict(result,report=str(path));journal_write(path,result)
        return str(path)

    def remove(self):
        require(self.installed(),'E_NO_INSTALLED_AUTO_HOOK')
        # Check/restore temporary Story identities before disabling their support.
        ordered=['story_guards','native_hud',*(name for name in EXTRA_MODULES if name not in ('story_guards','native_hud'))]
        for name in ordered:
            if self.lease.get(name):self.set_extra(name,False,remove=True)
        if self.lease.get('tactical_balance'):
            self.set_tactical_balance(0,remove=True)
        if self.lease.get('ambition_timer'):
            self.set_ambition_timer(False,remove=True)
        if self.lease.get('offensive_ai',{}).get('patches'):
            self.set_offensive_ai(False)
        if (self.lease.get('aggression_patch') or {}).get('state') in ('APPLIED','PENDING'):
            self.set_aggression(False)
        if self.writer is None:self.open_writer()
        patches=[p for p in self.lease['patches'] if p['installed']]
        forbidden=[]
        for p in patches:
            forbidden.extend([(p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),
                              (p['code_address'],p['code_address']+p['code_size'])])
        self.log('AUTO_BEFORE_REMOVE')
        with self.quiesce(forbidden):
            for p in patches:
                require(self.read(p['site'],len(bytes.fromhex(p['replacement_hex'])))==
                        bytes.fromhex(p['replacement_hex']),'E_AUTO_REMOVE_SITE_CONFLICT')
                require(hashlib.sha256(self.read(p['code_address'],p['code_size'])).hexdigest()==p['code_sha256'],
                        'E_AUTO_REMOVE_CODE_CHANGED')
            require(uint(self,self.lease['data_address']+20)==0,'E_AUTO_BRIDGE_EXECUTING_RETRY')
            require(uint(self,self.lease['recall_data_address']+16)==0,'E_RECALL_BRIDGE_EXECUTING_RETRY')
            self.write(self.lease['data_address']+12,(1).to_bytes(4,'little'))
            self.write(self.lease['data_address']+24,bytes(4))
            self.write(self.lease['recall_data_address']+12,(1).to_bytes(4,'little'))
            self.write(self.lease['recall_data_address']+8,bytes(4))
            if self.lease['build'] in (BUILD,TIMER9_BUILD,AI8_BUILD):self.write(self.lease['recall_data_address']+FOLLOW_FLAG,bytes(4))
            for p in reversed(patches):
                self.patch_site(p['site'],bytes.fromhex(p['replacement_hex']),bytes.fromhex(p['original_hex']))
                p['installed']=False;self.log('AUTO_REMOVING')
        self.log('AUTO_STOPPED_HOOKS_REMOVED',recall_summary=self.recall_status())
        return self.status()
