"""Unicode Windows executable identity, independent of process access."""
import ntpath
from pathlib import Path


def path_key(value):
    value=str(value)
    if value.startswith('\\\\?\\UNC\\'):value='\\\\'+value[8:]
    elif value.startswith('\\\\?\\'):value=value[4:]
    return ntpath.normpath(value).casefold()


def same_executable(first,second):return path_key(first)==path_key(second)


def validate_executable(value):
    path=Path(value).expanduser()
    if not path.is_absolute() or path.suffix.casefold()!='.exe' or not path.is_file():
        raise ValueError('Select the existing .exe used by the running game.')
    return str(path.resolve())
