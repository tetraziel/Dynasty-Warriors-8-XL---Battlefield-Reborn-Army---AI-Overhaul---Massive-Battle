"""Host-side, click-through status and command popup. No game drawing calls.

Lazy creation: importing, opening the tool, and leaving the option OFF create
no overlay. Exclusive fullscreen may cover desktop overlays; use windowed or
borderless mode for feedback. All game-memory work remains in detachment.py.
"""
import time


def presentation(mode):
    from detachment import MESSAGES
    return {'message':MESSAGES[mode],
            'icons':('FOLLOW','FOLLOW','FOLLOW','FOLLOW') if mode==0 else
                    ('DEFENSE','DEFENSE','FOLLOW','FOLLOW') if mode==1 else
                    ('DEFENSE','DEFENSE','DEFENSE','DEFENSE')}


class OrderFeedback:
    def __init__(self,parent):
        self.parent=parent;self.window=None;self.canvas=None
        self.last_event=None;self.popup_until=0;self.last_message='';self.last_status=None
        self.native_icons=False

    def hide(self):
        if self.window is not None:self.window.withdraw()

    def destroy(self):
        if self.window is not None:self.window.destroy();self.window=None

    def update(self,pid,status):
        if not status.get('enabled') or not status.get('battle_active'):
            self.hide();self.last_event=None;return
        import ctypes as C
        from ctypes import wintypes as W
        u=C.WinDLL('user32',use_last_error=True)
        u.GetForegroundWindow.restype=W.HWND
        u.GetWindowThreadProcessId.argtypes=[W.HWND,C.POINTER(W.DWORD)]
        u.GetClientRect.argtypes=[W.HWND,C.POINTER(W.RECT)]
        u.ClientToScreen.argtypes=[W.HWND,C.POINTER(W.POINT)]
        foreground=u.GetForegroundWindow();actual=W.DWORD()
        u.GetWindowThreadProcessId(foreground,C.byref(actual))
        if actual.value!=int(pid):self.hide();return
        rect=W.RECT();point=W.POINT(0,0)
        if not u.GetClientRect(foreground,C.byref(rect)) or not u.ClientToScreen(foreground,C.byref(point)):
            self.hide();return
        if rect.right<400 or rect.bottom<300:self.hide();return
        mode=status.get('mode',0);event=status.get('event_sequence',0)
        view=presentation(mode)
        if event and event!=self.last_event:
            self.popup_until=time.monotonic()+4;self.last_message=view['message']
        self.last_event=event
        if self.native_icons and time.monotonic()>=self.popup_until:
            self.hide();return
        if self.window is None:self._create(u,C,W)
        width=min(470,rect.right-40);height=100
        self.window.geometry(f'{width}x{height}+{point.x+20}+{point.y+max(20,int(rect.bottom*.22))}')
        self._draw(width,view)
        self.window.deiconify()
        # SWP_NOACTIVATE; WS_EX_NOACTIVATE and WS_EX_TRANSPARENT are set before
        # the first show. The game retains keyboard focus and mouse input.
        u.SetWindowPos.argtypes=[W.HWND,W.HWND,C.c_int,C.c_int,C.c_int,C.c_int,W.UINT]
        u.SetWindowPos(self.hwnd,W.HWND(-1),0,0,0,0,0x0010|0x0001|0x0002)

    def _create(self,u,C,W):
        import tkinter as tk
        self.window=tk.Toplevel(self.parent);self.window.withdraw()
        self.window.overrideredirect(True);self.window.attributes('-topmost',True)
        self.window.configure(bg='#010203');self.window.attributes('-transparentcolor','#010203')
        self.canvas=tk.Canvas(self.window,highlightthickness=0,bg='#010203')
        self.canvas.pack(fill='both',expand=True);self.window.update_idletasks()
        u.GetParent.argtypes=[W.HWND];u.GetParent.restype=W.HWND
        hwnd=u.GetParent(self.window.winfo_id()) or self.window.winfo_id()
        self.hwnd=hwnd
        get=u.GetWindowLongPtrW;get.argtypes=[W.HWND,C.c_int];get.restype=C.c_ssize_t
        set_=u.SetWindowLongPtrW;set_.argtypes=[W.HWND,C.c_int,C.c_ssize_t];set_.restype=C.c_ssize_t
        # LAYERED | TRANSPARENT | NOACTIVATE | TOOLWINDOW.
        set_(hwnd,-20,get(hwnd,-20)|0x80000|0x20|0x8000000|0x80)

    def _draw(self,width,view):
        c=self.canvas;c.delete('all')
        for i,kind in enumerate(() if self.native_icons else view['icons']):
            x=8+i*52;colour='#6fc8ff' if kind=='FOLLOW' else '#ffd479'
            c.create_rectangle(x,8,x+44,47,fill='#15202d',outline=colour,width=2)
            if kind=='DEFENSE':
                c.create_polygon(x+14,16,x+30,16,x+29,29,x+22,36,x+15,29,
                                 fill=colour,outline=colour)
            else:
                c.create_line(x+12,27,x+31,27,fill=colour,width=3,arrow='last')
            c.create_text(x+38,39,text=str(i+1),fill='white',font=('Segoe UI',8))
        if time.monotonic()<self.popup_until:
            c.create_rectangle(4,57,width-4,94,fill='#15202d',outline='#9bb7cd')
            c.create_text(14,75,anchor='w',text=self.last_message,fill='white',font=('Segoe UI',12,'bold'))
