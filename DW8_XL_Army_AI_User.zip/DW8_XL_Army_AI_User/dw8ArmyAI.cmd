@echo off
if not exist "%~dp0runtime\pythonw.exe" (
  echo Extract the entire tool folder before running Run.cmd.
  pause
  exit /b 1
)
start "" "%~dp0runtime\pythonw.exe" -I -B "%~dp0app.py"
