"""Private diagnostic records; pure helpers with no process or Windows imports."""
BASE=0x2400
STRIDE=0x100
KINDS=('observer','action','follow','target')
END=BASE+len(KINDS)*STRIDE
REASONS=('OK','GLOBALS','PHASE','PLAYER_BINDING','AGENT_IDENTITY',
         'MEMBER_SLOT_MASKS','GROUP_LINKS','OWNER_LIST_FAMILY','CONFIG_EVENT',
         'CONTEXT_FRESHNESS','PRIORITY_STATE','INVALID_COORDINATES','INVALID_TARGET',
         'FOLLOW_OWNER_STATE','FOLLOW_VIEW')


class Diagnostics:
    def __init__(self,x,data,kind):self.x=x;self.address=data+BASE+KINDS.index(kind)*STRIDE
    def stage(self,name):self.x.set(REASONS.index(name),disp=self.address+0x10)
    def rejected(self):
        x=self.x
        x.load('eax',disp=self.address+0x10);x.store('eax',disp=self.address)
        x.imul('edx','eax',4);x.ri(0,'edx',self.address+0x20)
        x.mem('ff',0,'edx');x.mem('ff',0,disp=self.address+0xC)
    def finish(self,label):
        self.x.op(7,0,disp=self.address+0x10);self.x.jump('eq',label)
        self.rejected();self.x.mark(label)


def decode(raw):
    if len(raw)<END:return None
    import struct
    def u(offset):return struct.unpack_from('<I',raw,offset)[0]
    result={}
    for index,kind in enumerate(KINDS):
        start=BASE+index*STRIDE;code=u(start)
        result[kind]={'last_rejection':REASONS[code] if 0<code<len(REASONS) else None,
                      'refusals':u(start+0xC),
                      'reasons':{name:u(start+0x20+4*i) for i,name in enumerate(REASONS)
                                 if i and u(start+0x20+4*i)}}
    return result
