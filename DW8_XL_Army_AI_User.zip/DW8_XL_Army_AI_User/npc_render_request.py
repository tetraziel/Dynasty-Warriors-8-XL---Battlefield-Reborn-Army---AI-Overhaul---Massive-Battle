"""Many-only selectable request budgets, with the native agent pool intact.

This changes a *request* budget, not the simultaneous NPC/render capacity.
The existing native allocation checks and all graphics buffers remain intact.
The optional creation quota becomes 60 after whole groups, to bound bursts.
"""
import struct
from core import require,word,uint
from recall_bridge import Asm,R
from bridge import relative_jump
import bundle_support as bundle

FEATURE='NPC_REQUEST_BUDGET_TEST'
MAGIC=0x3651504E;VERSION=5;LEGACY_VERSION=1;LEGACY_VERSIONS=(1,2,3,4);SIZE=0x1000;CODE_SIZE=0x8000
REQUEST_TARGET=1200;REQUEST_TARGETS={1:600,2:1200,3:1200,4:REQUEST_TARGET,5:REQUEST_TARGET}
REQUEST_CHOICES=(1200,2400,4000,10000,100000);TARGET_OFFSET=0x3C
DYNAMIC_CHOICES_BY_VERSION={3:(1200,2400,4000),4:(1200,2400,4000,10000),5:REQUEST_CHOICES}
CREATION_QUOTA=60;NATIVE_AGENT_CAPACITY=150
SITES={'REQUEST_BUDGET':(0x51EE88,'b896000000'),
       'CREATION_QUOTA':(0x59AD51,'837c24181e')}
SIGNATURES={0x51EE86:'33d2',0x51EE8D:'f7f1',0x51EEA6:'e88590feff',
            0x59AD31:'ff442418',0x59AD56:'771b',0x59AC7F:'e88ccfffff',
            0x59AC89:'81ff96000000',0x4EB940:'83b96002000000',
            0x4EB949:'b896000000',0x51361D:'8bb844210700',0x5072F3:'ff8160020000'}
COUNTERS={'visits':0x10,'request_budget_uses':0x14,'creation_quota_uses':0x18,
          'scope_skips':0x1C,'other_graphics_profile':0x20,
          'unsupported_agent_queue':0x24,'context_skips':0x28}


def validate_budget(target):
    require(type(target) is int and target in REQUEST_CHOICES,'E_NPC_REQUEST_BUDGET')
    return target


def initialize_data(raw):
    struct.pack_into('<I',raw,TARGET_OFFSET,REQUEST_TARGET)


def build_bridge(base,data,code,auto,recall,name,*,legacy=False,legacy_version=1):
    require(name in SITES,'E_NPC_REQUEST_SITE');x=Asm();x.emit('9c60')
    version=legacy_version if legacy else VERSION
    require(version in REQUEST_TARGETS,'E_NPC_REQUEST_VERSION')
    target=REQUEST_TARGETS[version]
    # The original MOV always overwrites EAX without changing flags. Set the
    # saved PUSHAD EAX slot even when disabled, busy, or outside our scope.
    if name=='REQUEST_BUDGET':x.set(150,'esp',28)
    for off,value in ((0,MAGIC),(4,version),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1)
    x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','native')
    inc=lambda key:x.mem('ff',0,disp=data+COUNTERS[key])
    inc('visits')
    x.op(7,0,disp=base+0x6CAAA0);x.jump('ne','profile_skip')
    x.load('edi',disp=base+0x6A91E0);x.sane('edi','context_skip')
    if name=='REQUEST_BUDGET':
        x.load('eax','esp',4)  # saved ESI
        x.rr('39','eax','edi');x.jump('ne','context_skip')
    x.op(7,1,'edi',0x98E8);x.jump('ne','context_skip')
    x.op(7,0x80080804,'edi',0x98E0);x.jump('ne','context_skip')
    x.load('edi',disp=base+0x6A91EC);x.sane('edi','context_skip')
    for off,value in ((0x590,1),(0x108,0)):
        x.op(7,value,'edi',off);x.jump('ne','context_skip')
    x.load('edi',disp=base+0x6D10BC);x.sane('edi','context_skip')
    x.load('eax','edi',0x1C784);x.cmp('eax',4);x.jump('eq','phase_ok')
    x.cmp('eax',5);x.jump('ne','context_skip');x.mark('phase_ok')
    x.load('edi',disp=base+0x6A91E8);x.sane('edi','context_skip')
    x.op(7,NATIVE_AGENT_CAPACITY,'edi',0x72140);x.jump('ne','queue_skip')
    x.load('eax','edi',0x7213C);x.sane('eax','queue_skip')
    x.load('eax','edi',0x72144);x.cmp('eax',150);x.jump('above','queue_skip')
    x.store('eax',disp=data+0x34)
    x.load('eax','edi',0x72148);x.cmp('eax',150);x.jump('ae','queue_skip')
    if version>=3:
        x.load('eax',disp=data+TARGET_OFFSET)
        for choice in DYNAMIC_CHOICES_BY_VERSION[version]:
            x.cmp('eax',choice);x.jump('eq','target_ok')
        x.jump('jmp','context_skip');x.mark('target_ok')
    if name=='REQUEST_BUDGET':
        if version>=3:
            x.store('eax','esp',28);inc('request_budget_uses')
            x.store('eax',disp=data+0x30)
        else:
            x.set(target,'esp',28);inc('request_budget_uses')
            x.set(target,disp=data+0x30)
    else:
        inc('creation_quota_uses');x.set(CREATION_QUOTA,disp=data+0x38)
    x.set(0,disp=data+12);x.emit('619d')
    if name=='CREATION_QUOTA':
        x.mem('81',7,'esp',0x18);x.dword(CREATION_QUOTA)
    x.emit(relative_jump(code+len(x.code),base+SITES[name][0]+5))
    for label,counter in (('profile_skip','other_graphics_profile'),
                          ('context_skip','context_skips'),('queue_skip','unsupported_agent_queue')):
        x.mark(label);inc(counter);x.jump('jmp','skip')
    x.mark('skip');inc('scope_skips');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d')
    if name=='CREATION_QUOTA':x.emit(bytes.fromhex(SITES[name][1]))
    x.emit(relative_jump(code+len(x.code),base+SITES[name][0]+5))
    return x.finish()


def check_code(memory):
    for rva,sig in SIGNATURES.items():
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),
                'E_NPC_REQUEST_NATIVE_'+hex(rva))


def configure(session,enabled,target):
    require(type(enabled) is bool,'E_NPC_REQUEST_ENABLED');target=validate_budget(target)
    record=(session.lease or {}).get('npc_render_request')
    if not record and not enabled:return public(session,None)
    if not record:
        # Publish a disabled bridge first. The selected value is verified before
        # enabling; later switches reuse the immutable code and both hook sites.
        bundle.set_bundle(session,'npc_render_request',__import__(__name__),False,prepare_disabled=True)
        record=session.lease['npc_render_request']
    require(record['version']==VERSION,'E_EXTRA_LEGACY_RESTART_REQUIRED')
    spans=[s for p in bundle.all_patches(session) for s in
        ((p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),
         (p['code_address'],p['code_address']+p['code_size']))]
    with session.quiesce(spans):
        bundle.validate(__import__(__name__),session,record)
        require(uint(session,record['data_address']+12)==0,'E_EXTRA_BRIDGE_EXECUTING_RETRY')
        require(uint(session,record['recall_data_address']+16)==0,'E_RECALL_BRIDGE_EXECUTING_RETRY')
        address=record['data_address']+TARGET_OFFSET;before=session.read(address,4)
        wanted=struct.pack('<I',target)
        if before!=wanted:
            try:
                session.write(address,wanted)
                require(session.read(address,4)==wanted,'E_NPC_REQUEST_SETTING_VERIFY')
            except Exception:
                session.write(address,before)
                require(session.read(address,4)==before,'E_NPC_REQUEST_SETTING_ROLLBACK')
                raise
            session.log('NPC_REQUEST_BUDGET_SELECTED',request_budget_target=target)
    return bundle.set_bundle(session,'npc_render_request',__import__(__name__),enabled)


def observe(memory):
    """Bounded read-only telemetry; never a rendered-pixel or atomic count."""
    result={'available':False,'read_only':True,'atomic_snapshot':False,
            'actual_rendered_npcs':None,'rendered_count_verified':False}
    try:
        manager=uint(memory,memory.base+0x6A91E8)
        selector=uint(memory,memory.base+0x6A91E0)
        require(0x10000<=manager<0xFF000000 and 0x10000<=selector<0xFF000000,'E_NPC_REQUEST_NO_CONTEXT')
        header=memory.read(manager+0x7213C,16)
        require(len(header)==16,'E_NPC_REQUEST_SHORT_READ')
        pointer,capacity,free,head=struct.unpack('<4I',header)
        require(capacity==150 and free<=capacity and head<capacity and pointer>=0x10000,
                'E_NPC_REQUEST_UNSUPPORTED_AGENT_QUEUE')
        raw=memory.read(selector+0x83C0,600*8+4)
        require(len(raw)==4804,'E_NPC_REQUEST_SHORT_READ')
        groups=set();requests=0;terminated=False
        for index in range(601):
            entry=word(raw,index*8)
            if entry==0xFFFFFFFF:terminated=True;break
            require(index<600,'E_NPC_REQUEST_SELECTION_NOT_TERMINATED')
            gid=entry&0xFFF
            require(gid<600 and gid not in groups,'E_NPC_REQUEST_SELECTION_ID')
            groups.add(gid)
            if entry&0x2000:requests+=(word(raw,index*8+4)&0x3FFFFFFF).bit_count()
        require(terminated,'E_NPC_REQUEST_SELECTION_NOT_TERMINATED')
        require(uint(memory,memory.base+0x6A91E8)==manager and
                uint(memory,memory.base+0x6A91E0)==selector,'E_NPC_REQUEST_CONTEXT_CHANGED')
        result.update(available=True,selected_groups=len(groups),
            published_requested_members_candidate=requests,
            native_agent_capacity=capacity,native_agent_free=free,
            assigned_agent_slots_including_player_and_other_actors=capacity-free,
            agent_queue_saturated=free==0,character_raw=uint(memory,memory.base+0x6CAAA0))
    except Exception as error:result['reason']=str(error)
    return result


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    version=record['version'] if record else VERSION
    require(version in REQUEST_TARGETS,'E_NPC_REQUEST_VERSION')
    target=REQUEST_TARGETS[version]
    if record and version>=3:target=uint(memory,record['data_address']+TARGET_OFFSET)
    valid=target in DYNAMIC_CHOICES_BY_VERSION[version] if version>=3 else True
    result.update(feature='NPC_'+str(target)+'_REQUEST_BUDGET_TEST',
        request_budget_target=target,request_budget_choices=list(REQUEST_CHOICES),
        selected_budget_valid=valid,effective_override_active=bool(valid and result['enabled']),
        budget_error=None if valid else 'INVALID_BUDGET_NATIVE_FALLBACK',native_request_budget=150,
        creation_quota_target=CREATION_QUOTA,native_creation_quota=30,
        creation_quota_checked_after_whole_group=True,
        scope='MANY_NATIVE_4_8_8_SINGLE_PLAYER_NATIVE_AGENT_LAYOUT',
        simultaneous_target_npcs_supported=False,simultaneous_target_npcs_verified=False,
        native_agent_capacity=NATIVE_AGENT_CAPACITY,agent_pool_expanded=False,
        graphics_buffers_expanded=False,logical_population_changed=False,
        camera_planes_changed=False,native_allocation_checks_preserved=True,
        remote_threads_created=False,game_functions_called=False,
        distinction='REQUEST_BUDGET_IS_NOT_RENDERED_NPC_CAPACITY')
    result.update({f'simultaneous_{target}_npcs_supported':False,
                   f'simultaneous_{target}_npcs_verified':False})
    if record:
        raw=memory.read(record['data_address'],0x3C)
        result.update(last_request_budget=word(raw,0x30),last_free_agents=word(raw,0x34),
                      last_creation_quota=word(raw,0x38),observation=observe(memory))
    return result
