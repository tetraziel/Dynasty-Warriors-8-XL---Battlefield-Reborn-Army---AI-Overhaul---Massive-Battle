"""Thirty seconds of native battle time before a personal/guard refill wave.

Runs on the existing owner refill caller, including its original clock CALL.
Only private timers are written. Native gate selection, morale/quantity filters,
reserve handling and the actual replenishment CALL remain in their own paths.
"""
from core import require,word
from bridge import relative_jump
from recall_bridge import Asm,R
from morale_policy import BASE as POLICY_BASE,MAGIC as POLICY_MAGIC
import bundle_support as bundle

FEATURE='PERSONAL_AND_BODYGUARD_REINFORCEMENTS_30_SECONDS'
MAGIC=0x31545752;VERSION=1;SIZE=0x1000;CODE_SIZE=0x8000
SECONDS=30;TICKS=SECONDS*60
SITES={'REFILL_CLOCK':(0x565723,'e8b8faa9ff'),
       'REFILL_RESULT':(0x56588F,'83c408f6436801')}
COUNTERS={'clock_visits':0x10,'waiting_visits':0x14,'ready_visits':0x18,
          'native_waves_observed':0x1C,'scope_skips':0x20,'full_army_visits':0x24}
TABLE=0x100;STRIDE=0x40;WORK=0x300
FIELDS={n:WORK+i*4 for i,n in enumerate(('manager','owner','owner_id','index','capacity',
    'total','count','list','tick','record','sequence'))}


def build_bridge(base,data,code,auto,recall,name,*,pool=None):
    from pool_binding import resolve
    p=resolve(pool);require(name in SITES,'E_REFILL_DELAY_SITE');x=Asm()
    def inc(off):x.mem('ff',0,disp=data+off)
    def save(reg,n):x.store(reg,disp=data+FIELDS[n])
    def load(reg,n):x.load(reg,disp=data+FIELDS[n])
    def jump_native(rva):x.emit(relative_jump(code+len(x.code),base+rva))
    # This replaces the native CALL once, rather than adding another clock call.
    if name=='REFILL_CLOCK':x.call(code,base+0x51E0)
    x.emit('9c60')
    for off,val in ((0,MAGIC),(4,VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,disp=data+off);x.jump('ne','native')
    # Reject other armies before taking the private lock or using scratch state.
    x.load('ebx','esp',16);x.sane('ebx','native')
    x.load('eax','ebx',0x38);x.cmp('eax',0);x.jump('eq','player')
    x.ri(5,'eax',122);x.cmp('eax',2);x.jump('above','native')
    x.ri(0,'eax',1);x.jump('jmp','index_ready')
    x.mark('player');x.imm('eax',0)
    x.mark('index_ready')
    x.load('edi',disp=base+0x6A91E8);x.sane('edi','native')
    x.load('ecx','ebx',0x38);x.imul('edx','ecx',0x110);x.rr('01','edx','edi');x.ri(0,'edx',0x4B0)
    x.rr('39','edx','ebx');x.jump('ne','native')
    x.op(7,0,'ebx',0x40);x.jump('ne','native')
    x.rr('89','edx','eax');x.imm('eax',0);x.imm('ecx',1)
    x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','busy')
    save('edx','index');save('edi','manager');save('ebx','owner')
    x.load('ecx','ebx',0x38);save('ecx','owner_id')
    for address,val in ((auto+24,1),(auto+20,0),(recall+8,1),(recall+12,0)):
        x.op(7,val,disp=address);x.jump('ne','scope_skip')
    x.load('eax',disp=base+0x6D10BC);x.sane('eax','scope_skip')
    x.op(7,4,'eax',0x1C784);x.jump('ne','scope_skip')
    x.load('eax',disp=base+0x6A91EC);x.sane('eax','scope_skip')
    x.op(7,1,'eax',0x590);x.jump('ne','scope_skip')
    x.op(7,0,'eax',0x108);x.jump('ne','scope_skip')
    load('edx','index');x.cmp('edx',0);x.jump('eq','roster_ok')
    x.ri(5,'edx',1);x.imul('edx','edx',0x30);x.rr('01','edx','eax')
    x.load('ecx','edx',0x1C4);load('edx','owner_id');x.rr('39','ecx','edx');x.jump('ne','scope_skip')
    x.mark('roster_ok')
    x.load('eax',disp=auto+16);x.cmp('eax',0);x.jump('eq','scope_skip');save('eax','sequence')
    load('edx','index');x.imul('edx','edx',STRIDE);x.ri(0,'edx',data+TABLE);save('edx','record')
    if name=='REFILL_RESULT':
        # Positive native EAX is the number of members actually transferred.
        x.load('eax','esp',28);x.cmp('eax',1);x.jump('below','unlock')
        x.cmp('eax',30);x.jump('above','unlock')
        load('ecx','manager');x.cmpm('ecx','edx');x.jump('ne','unlock')
        load('ecx','sequence');x.cmpm('ecx','edx',4);x.jump('ne','unlock')
        load('ecx','owner');x.cmpm('ecx','edx',8);x.jump('ne','unlock')
        x.set(0,'edx',12);x.set(0,'edx',56);x.mem('ff',0,'edx',36);inc(0x1C)
        x.jump('jmp','unlock')
    else:
        inc(0x10)
        x.load('eax',disp=base+0x6A9200);x.sane('eax','scope_skip')
        x.load('eax','eax',0x38);save('eax','tick')
        # Verify every bounded owner-list entry; only supported 30-man infantry
        # and its empty native reserve count toward this army's actual total.
        load('ebx','owner');x.load('eax','ebx',0x100)
        x.cmp('eax',3);x.jump('below','scope_skip');x.cmp('eax',6);x.jump('above','scope_skip');save('eax','count')
        load('ecx','index');x.cmp('ecx',0);x.jump('eq','player_capacity')
        x.ri(5,'eax',2);x.imul('eax','eax',30);x.jump('jmp','capacity_ready')
        x.mark('player_capacity');x.cmp('eax',5);x.jump('below','scope_skip');x.imm('eax',120)
        x.mark('capacity_ready');save('eax','capacity')
        x.load('esi','ebx',0xF8);x.sane('esi','scope_skip');save('esi','list')
        x.imm('ebp',0);x.set(0,disp=data+FIELDS['total'])
        x.mark('group_loop');x.rr('89','eax','ebp');x.rr('01','eax','eax');load('esi','list');x.rr('01','esi','eax')
        x.mem('0fb7',R['eax'],'esi');x.cmp('eax',p.group_capacity);x.jump('ae','scope_skip')
        x.imul('ecx','eax',0x268);load('edi','manager');x.rr('01','ecx','edi');x.ri(0,'ecx',p.manager_groups)
        x.cmpm('eax','ecx',0x18);x.jump('ne','scope_skip')
        load('edx','owner_id');x.cmpm('edx','ecx',0x44);x.jump('ne','scope_skip')
        x.cmp('ebp',0);x.jump('ne','infantry')
        x.op(7,1,'ecx',0x24);x.jump('ne','scope_skip');x.op(7,1,'ecx',0x28);x.jump('ne','scope_skip')
        x.jump('jmp','group_next')
        x.mark('infantry');x.op(7,0xFFFFFFFF,'ecx',0x30);x.jump('eq','reserve')
        for off,val in ((0x30,865),(0x2C,30),(0x24,30)):
            x.op(7,val,'ecx',off);x.jump('ne','scope_skip')
        x.load('eax','ecx',0x28);x.cmp('eax',30);x.jump('above','scope_skip')
        x.mem('01',R['eax'],disp=data+FIELDS['total']);x.jump('jmp','group_next')
        x.mark('reserve');x.op(7,2,'ecx',0x2C);x.jump('ne','scope_skip')
        for off in (0x28,0x10,0x14):x.op(7,0,'ecx',off);x.jump('ne','scope_skip')
        x.mark('group_next');x.ri(0,'ebp',1);load('eax','count');x.rr('39','ebp','eax');x.jump('below','group_loop')
        load('eax','total');x.cmp('eax',120);x.jump('above','scope_skip')
        # Respect the existing morale target; an unused reserve is not a loss.
        g=recall+POLICY_BASE
        x.op(7,POLICY_MAGIC,disp=g);x.jump('ne','scope_skip')
        x.op(7,1,disp=g+8);x.jump('ne','target_done')
        load('edi','manager');x.load('ecx','edi',0xC0);x.load('edx','edi',0x2EC)
        for reg in ('ecx','edx'):x.cmp(reg,999);x.jump('above','scope_skip')
        x.rr('01','edx','ecx');x.cmp('edx',0);x.jump('ne','morale_sum')
        x.imm('ecx',1);x.imm('edx',2)
        x.mark('morale_sum');x.imul('ecx','ecx',100)
        for off in (12,16,20):
            x.load('eax',disp=g+off);x.cmp('eax',1);x.jump('below','scope_skip');x.cmp('eax',99);x.jump('above','scope_skip')
            if off>12:x.load('ebx',disp=g+off-4);x.rr('39','eax','ebx');x.jump('be','scope_skip')
        for off,target in ((12,30),(16,60),(20,90)):
            x.load('eax',disp=g+off);x.emit('0fafc2');x.rr('39','ecx','eax');x.jump('below','morale_'+str(target))
        x.imm('eax',120);x.jump('jmp','morale_target')
        for target in (30,60,90):x.mark('morale_'+str(target));x.imm('eax',target);x.jump('jmp','morale_target')
        x.mark('morale_target');load('ecx','capacity');x.rr('39','eax','ecx');x.jump('ae','target_done');save('eax','capacity')
        x.mark('target_done');load('edx','record')
        for offset,field in ((0,'manager'),(4,'sequence'),(8,'owner')):
            load('eax',field);x.cmpm('eax','edx',offset);x.jump('ne','reset_context')
        x.jump('jmp','context_ok')
        x.mark('reset_context')
        for offset,field in ((0,'manager'),(4,'sequence'),(8,'owner'),(52,'owner_id')):
            load('eax',field);x.store('eax','edx',offset)
        x.set(0,'edx',12);x.set(0xFFFFFFFF,'edx',20)
        x.mark('context_ok');load('eax','capacity');x.store('eax','edx',28)
        load('ecx','total');x.store('ecx','edx',32);load('ebx','tick');x.store('ebx','edx',24)
        x.rr('39','ecx','eax');x.jump('ae','full')
        x.op(7,1,'edx',12);x.jump('ne','start_wait')
        x.cmpm('ebx','edx',16);x.jump('below','start_wait')
        x.rr('89','eax','ebx');x.mem('2b',R['eax'],'edx',16);x.cmp('eax',TICKS);x.jump('below','wait')
        x.op(7,0xFFFFFFFF,'edx',20);x.jump('eq','attempt_ready')
        x.rr('89','ecx','ebx');x.mem('2b',R['ecx'],'edx',20);x.cmp('ecx',60);x.jump('below','wait')
        x.mark('attempt_ready')
        x.store('ebx','edx',20);x.set(1,'edx',56);inc(0x18)
        # Native DIV/TEST follows. EDI=1 removes its calendar-window gating;
        # all subsequent gate, zone, morale and quantity checks still run.
        x.set(1,'esp',0);x.jump('jmp','unlock')
        x.mark('start_wait');x.set(1,'edx',12);x.store('ebx','edx',16)
        x.set(0xFFFFFFFF,'edx',20);x.mem('ff',0,'edx',40)
        x.mark('wait');x.set(0,'edx',56);x.mem('ff',0,'edx',44);inc(0x14);x.jump('jmp','wait_unlock')
        x.mark('full');x.set(0,'edx',12);x.set(0,'edx',56);inc(0x24);x.jump('jmp','wait_unlock')
    x.mark('scope_skip');inc(0x20)
    x.mark('unlock');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d')
    if name=='REFILL_RESULT':x.emit(bytes.fromhex(SITES[name][1]))
    jump_native(SITES[name][0]+len(bytes.fromhex(SITES[name][1])))
    x.mark('wait_unlock');x.set(0,disp=data+12)
    x.mark('busy');x.emit('619d')
    if name=='REFILL_RESULT':
        x.emit(bytes.fromhex(SITES[name][1]));jump_native(0x565896)
    else:jump_native(0x5658A6)
    return x.finish()


CHECKS={0x565728:'33d2f7f785d20f8572010000',
        0x521A:'b889888888f761388bc2c1e805c3',
        0x5544F3:'8b44242c5f5e5d5b83c414c3'}


def check_code(memory):
    for rva,sig in CHECKS.items():
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),
                'E_REFILL_DELAY_NATIVE_'+hex(rva))


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(wait_seconds=SECONDS,wait_ticks=TICKS,ticks_per_second=60,
        clock='NATIVE_BATTLE_TICKS',timer_scope='INDEPENDENT_PLAYER_AND_EACH_BODYGUARD_ARMY',
        begins_when='SUPPORTED_ARMY_BELOW_CURRENT_REINFORCEMENT_TARGET',
        resets_on='POSITIVE_NATIVE_REPLACEMENT_RESULT_OR_FULL_ARMY_OR_NEW_BATTLE',
        travel_time_modified=False,native_gate_and_quantity_checks_preserved=True,
        remote_threads_created=False,process_record_writes=False)
    if record:
        rows=[];raw=memory.read(record['data_address']+TABLE,STRIDE*4)
        for i in range(4):
            r=raw[i*STRIDE:(i+1)*STRIDE]
            if not word(r):continue
            elapsed=max(0,word(r,24)-word(r,16)) if word(r,12) else 0
            rows.append(dict(owner=word(r,52),waiting=bool(word(r,12)),
                remaining_ticks=max(0,TICKS-elapsed) if word(r,12) else 0,
                target=word(r,28),logical_soldiers=word(r,32),waves=word(r,36),
                timer_starts=word(r,40),ready=bool(word(r,56))))
        result['armies']=rows
    return result
