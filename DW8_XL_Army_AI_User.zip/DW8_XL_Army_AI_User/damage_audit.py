"""Opt-in native HP input trace. Never changes HP, flags or target selection.

The game-thread bridges only copy integer bit patterns to a bounded private
ring. They call no game/Windows functions and preserve the native instruction
stream. Importing this module does not open any process.
"""
import datetime
import json
import math
import struct
from core import require, word
from recall_bridge import Asm, R
from bridge import relative_jump
import bundle_support as bundle

FEATURE='NPC_DAMAGE_EVENT_AUDIT_TEST'
MAGIC=0x31474844; VERSION=1; SIZE=0x16000; CODE_SIZE=0x10000
RING=0x1000; CAPACITY=512; STRIDE=0xA0; SEQUENCE=0x30
SITES={
    # These sites follow the native SUB ESP,8. Patch only its five-byte CMP.
    'HP_DELTA_WRAPPER':(0x515413,'3d96000000'),
    'HP_ASSIGN_WRAPPER':(0x515553,'3d96000000'),
    'HP_DELTA_ITEM':(0x4DF350,'d9442404d84114'),
    'HP_ASSIGN_ITEM':(0x4DF3A0,'d9442404d9411c'),
}
COUNTERS={'visits':0x10,'captured_events':0x14,'scope_skips':0x18,
          'busy_skips':0x1C,'stack_unavailable':0x20,'sequence_exhausted':0x24}


def build_bridge(base,data,code,auto,recall,name,*,legacy=False):
    require(name in SITES and not legacy,'E_DAMAGE_AUDIT_SITE')
    frame_bias=0 if name.endswith('ITEM') else 8
    x=Asm();x.emit('9c60')
    inc=lambda key:x.mem('ff',0,disp=data+COUNTERS[key])
    for off,value in ((0,MAGIC),(4,VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    inc('visits')
    x.imm('eax',0);x.imm('ecx',1)
    x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','busy')
    # Root reads precede all dependent dereferences. No game writes follow.
    x.load('eax',disp=base+0x6D10BC);x.sane('eax','skip')
    x.op(7,4,'eax',0x1C784);x.jump('ne','skip')
    x.load('edi',disp=base+0x6A91E8);x.sane('edi','skip')
    x.load('ebx',disp=base+0x6A91D8);x.sane('ebx','skip')
    x.op(7,150,'edi',0x72140);x.jump('ne','skip')
    if name.endswith('ITEM'):
        x.load('esi','esp',24)  # original ECX is the physical record
        x.lea('eax','edi',0x6B210);x.rr('39','esi','eax');x.jump('below','skip')
        x.rr('89','edx','esi');x.rr('29','edx','eax')
        x.cmp('edx',150*0x30);x.jump('ae','skip')
        x.rr('89','eax','edx');x.imm('edx',0);x.imm('ecx',0x30);x.emit('f7f1')
        x.cmp('edx',0);x.jump('ne','skip')
    else:
        x.load('eax','esp',28);x.cmp('eax',150);x.jump('ae','skip')
        x.imul('esi','eax',0x30);x.rr('01','esi','edi');x.ri(0,'esi',0x6B210)
    x.cmpm('eax','esi');x.jump('ne','skip')
    x.imul('edx','eax',0xE0);x.rr('01','edx','ebx');x.ri(0,'edx',0x21EF8)
    x.cmpm('eax','edx',0x7C);x.jump('ne','skip')
    x.mem('f7',0,'edx',0xCC);x.dword(1);x.jump('eq','skip')
    x.load('ecx','esi',8);x.cmp('ecx',600);x.jump('ae','skip')
    x.imul('ebp','ecx',0x268);x.rr('01','ebp','edi');x.ri(0,'ebp',0x10E50)
    x.cmpm('ecx','ebp',0x18);x.jump('ne','skip')
    x.load('ecx','esi',0xC);x.cmp('ecx',30);x.jump('ae','skip')
    x.load('ecx','ebp',0x44);x.cmp('ecx',250);x.jump('ae','skip')
    x.imul('ebp','ecx',0x110);x.rr('01','ebp','edi');x.ri(0,'ebp',0x4B0)
    x.cmpm('ecx','ebp',0x38);x.jump('ne','skip')
    x.load('ecx','ebp',0x40);x.cmp('ecx',1);x.jump('above','skip')
    # Construct a slot with a zero begin sequence; publish begin last.
    x.load('ecx',disp=data+SEQUENCE);x.cmp('ecx',0xFFFFFFFE);x.jump('ae','exhausted')
    x.rr('89','ebp','ecx');x.ri(4,'ebp',CAPACITY-1)
    x.imul('ebp','ebp',STRIDE);x.ri(0,'ebp',data+RING)
    x.set(0,'ebp');x.ri(0,'ecx',1);x.store('ecx','ebp',0x9C)
    x.store('eax','ebp',0xC);x.store('edi','ebp',0x94);x.store('ebx','ebp',0x98)
    x.load('eax','ebx',0x53E90);x.store('eax','ebp',4)
    x.set(list(SITES).index(name)+1,'ebp',8)
    for field,off in ((8,0x10),(0xC,0x14),(0x14,0x24),(0x1C,0x28)):
        x.load('eax','esi',field);x.store('eax','ebp',off)
    x.load('eax','esi',0x2C);x.ri(4,'eax',255);x.store('eax','ebp',0x20)
    x.load('eax','edx',0xCC);x.store('eax','ebp',0x48)
    x.load('eax','esi',8);x.imul('eax','eax',0x268);x.rr('01','eax','edi')
    x.load('eax','eax',0x10E50+0x44);x.store('eax','ebp',0x1C)
    x.imul('eax','eax',0x110);x.rr('01','eax','edi')
    x.load('eax','eax',0x4B0+0x40);x.store('eax','ebp',0x18)
    x.load('eax','esp',40+frame_bias);x.store('eax','ebp',0x2C)
    for stack,off in ((36+frame_bias,0x30),(24,0x34),(20,0x38),(4,0x3C),(0,0x40),(8,0x44)):
        x.load('eax','esp',stack);x.store('eax','ebp',off)
    x.set(4,'ebp',0x4C);x.set(0,'ebp',0x50)
    # The stack sample must stay below NT_TIB.StackBase (FS:[4]).
    x.lea('eax','esp',36+frame_bias+16*4);x.emit('648b1504000000')
    x.rr('39','eax','edx');x.jump('above','no_stack')
    for i in range(16):
        x.load('eax','esp',36+frame_bias+i*4);x.store('eax','ebp',0x54+i*4)
    x.set(16,'ebp',0x50);x.jump('jmp','commit')
    x.mark('no_stack');inc('stack_unavailable')
    x.mark('commit');x.load('eax','ebp',0x9C);x.store('eax','ebp')
    x.store('eax',disp=data+SEQUENCE);inc('captured_events');x.jump('jmp','unlock')
    x.mark('exhausted');inc('sequence_exhausted');x.set(0,disp=data+8);x.jump('jmp','unlock')
    x.mark('skip');inc('scope_skips')
    x.mark('unlock');x.set(0,disp=data+12);x.jump('jmp','native')
    x.mark('busy');inc('busy_skips')
    x.mark('native');x.emit('619d');x.emit(bytes.fromhex(SITES[name][1]))
    x.emit(relative_jump(code+len(x.code),base+SITES[name][0]+len(bytes.fromhex(SITES[name][1]))))
    return x.finish()


def check_code(memory):
    for rva,sig in ((0x4F3260,'d94014c3'),(0x4F31B0,'d9401cc3')):
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),
                'E_DAMAGE_AUDIT_NATIVE_'+hex(rva))


def _float(raw,offset):
    value=struct.unpack_from('<f',raw,offset)[0]
    return value if math.isfinite(value) else None


def decode_event(raw,sequence,base):
    require(len(raw)==STRIDE,'E_DAMAGE_AUDIT_RECORD_SIZE')
    if word(raw)!=sequence or word(raw,0x9C)!=sequence:return None
    kind=word(raw,8)
    if not 1<=kind<=len(SITES):return None
    stack_count=word(raw,0x50)
    if stack_count not in (0,16):return None
    return {'sequence':sequence,'tick':word(raw,4),'path':list(SITES)[kind-1],
        'agent':word(raw,0xC),'squad':word(raw,0x10),'slot':word(raw,0x14),
        'side':word(raw,0x18),'owner':word(raw,0x1C),
        'physical_flags_low':hex(word(raw,0x20)),
        'hp_before':_float(raw,0x24),'hp_maximum':_float(raw,0x28),
        'input_value':_float(raw,0x2C),'input_bits':hex(word(raw,0x2C)),
        'caller_rva':hex(word(raw,0x30)-base),
        'registers':{name:hex(word(raw,offset)) for name,offset in
            (('ecx',0x34),('edx',0x38),('esi',0x3C),('edi',0x40),('ebp',0x44))},
        'actor_flags_cc':hex(word(raw,0x48)),
        'stack_words':[hex(word(raw,0x54+i*4)) for i in range(stack_count)],
        'manager':hex(word(raw,0x94)),'ai':hex(word(raw,0x98)),
        'attacker_identified':False,'musou_attribution_verified':False,
        'event_is_hp_input_not_confirmed_single_hit':True}


def drain(memory,record):
    """Append committed slots only; explicitly count overwritten/rejected slots."""
    raw=memory.read(record['data_address'],SIZE)
    require(word(raw)==MAGIC and word(raw,4)==VERSION,'E_DAMAGE_AUDIT_HEADER')
    key=(record['data_address'],tuple(memory.cookie));state=getattr(memory,'_damage_audit_reader',None)
    if not state or state['key']!=key:
        path=memory.root/'logs'/('damage_events_'+memory.log_path.stem+'.jsonl')
        state={'key':key,'cursor':0,'lost':0,'uncommitted':0,'saved':0,'path':path,'last':None}
        memory._damage_audit_reader=state
    completed=word(raw,SEQUENCE);require(completed>=state['cursor'],'E_DAMAGE_AUDIT_SEQUENCE_REVERSED')
    first=max(state['cursor']+1,completed-CAPACITY+1)
    lost=max(0,first-state['cursor']-1);pending=[];rejected=0
    utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
    for sequence in range(first,completed+1):
        at=RING+((sequence-1)&(CAPACITY-1))*STRIDE
        event=decode_event(raw[at:at+STRIDE],sequence,memory.base)
        if event is None:rejected+=1
        else:pending.append(dict(event,observed_utc=utc,process_cookie=list(memory.cookie)))
    if pending or lost or rejected:
        state['path'].parent.mkdir(exist_ok=True)
        with state['path'].open('a',encoding='utf-8') as out:
            if lost or rejected:out.write(json.dumps({'kind':'AUDIT_GAP','overwritten':lost,'uncommitted':rejected,'through_sequence':completed})+'\n')
            for event in pending:out.write(json.dumps(event,allow_nan=False)+'\n')
        state['saved']+=len(pending);state['lost']+=lost;state['uncommitted']+=rejected
        if pending:state['last']=pending[-1]
    state['cursor']=completed
    return {'saved_events':state['saved'],'overwritten_events':state['lost'],
        'uncommitted_events':state['uncommitted'],'last_event':state['last'],
        'event_log':str(state['path']),'last_sequence':completed}


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(gameplay_modified=False,hp_modified=False,classification_flags_modified=False,
        targets_modified=False,game_functions_called=False,remote_threads_created=False,
        diagnostic_hooks_installed=bool(result['hook_installed']),ring_capacity=CAPACITY,
        attacker_identification_complete=False,musou_attribution_verified=False)
    if record:result.update(drain(memory,record))
    return result
