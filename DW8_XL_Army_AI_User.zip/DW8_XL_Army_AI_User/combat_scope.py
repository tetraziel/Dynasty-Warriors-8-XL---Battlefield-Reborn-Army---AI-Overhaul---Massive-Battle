"""Pure emitters for bounded, materialized combat identities (native 150/600).

These checks never change game flags, health, orders, or allocation sizes.
Scratch belongs exclusively to the calling optional bridge's busy guard.
"""
from recall_bridge import R

ROOT=0x100


def roots(x,base,data,auto,fail):
    for off,value in ((24,1),(20,0)):
        x.op(7,value,disp=auto+off);x.jump('ne',fail)
    x.load('eax',disp=auto+16);x.cmp('eax',0);x.jump('eq',fail)
    x.store('eax',disp=data+ROOT+0x10)
    x.load('eax',disp=base+0x6D10BC);x.sane('eax',fail)
    x.op(7,4,'eax',0x1C784);x.jump('ne',fail)
    for rva,off in ((0x6A91E8,0),(0x6A91D8,4),(0x6A91EC,8),(0x6A9230,12)):
        x.load('eax',disp=base+rva);x.sane('eax',fail);x.store('eax',disp=data+ROOT+off)
    x.load('eax',disp=data+ROOT)
    x.op(7,150,'eax',0x72140);x.jump('ne',fail)
    x.load('eax',disp=data+ROOT+8)
    for off,value in ((0x590,1),(0x108,0)):
        x.op(7,value,'eax',off);x.jump('ne',fail)


def physical(x,data,dest,fail,*,prefix):
    """EAX=id; publish item/actor/group/owner pointers and IDs at dest.

    dest fields: id, item, actor, group, owner record, squad, slot, owner, side.
    No component/vtable calls. Reject inactive, dead, reused, or invalid entries.
    """
    x.cmp('eax',150);x.jump('ae',fail);x.store('eax',disp=data+dest)
    x.load('edi',disp=data+ROOT)
    x.imul('edx','eax',0x30);x.rr('01','edx','edi');x.ri(0,'edx',0x6B210)
    x.cmpm('eax','edx');x.jump('ne',fail);x.store('edx',disp=data+dest+4)
    # IEEE float positive/finite test, without touching x87/SSE.
    x.load('ecx','edx',0x14);x.cmp('ecx',0);x.jump('eq',fail)
    x.cmp('ecx',0x7F800000);x.jump('ae',fail)
    x.load('ebx',disp=data+ROOT+4)
    x.imul('ecx','eax',0xE0);x.rr('01','ecx','ebx');x.ri(0,'ecx',0x21EF8)
    x.cmpm('eax','ecx',0x7C);x.jump('ne',fail)
    x.mem('f7',0,'ecx',0xCC);x.dword(1);x.jump('eq',fail)
    x.store('ecx',disp=data+dest+8)
    x.load('eax','edx',8);x.cmp('eax',600);x.jump('ae',fail)
    x.store('eax',disp=data+dest+0x14)
    x.imul('esi','eax',0x268);x.rr('01','esi','edi');x.ri(0,'esi',0x10E50)
    x.cmpm('eax','esi',0x18);x.jump('ne',fail);x.store('esi',disp=data+dest+12)
    x.imul('eax','eax',0xA0);x.rr('01','eax','ebx');x.ri(0,'eax',0xA7F8)
    x.cmpm('eax','ecx',0x80);x.jump('ne',fail)
    x.load('eax','edx',12);x.cmp('eax',30);x.jump('ae',fail)
    x.store('eax',disp=data+dest+0x18)
    # A live item must still belong to the group's materialized/logical masks.
    x.rr('89','ecx','eax');x.imm('eax',1);x.emit('d3e0')
    for off in (0x10,0x14):
        x.mem('85',R['eax'],'esi',off);x.jump('eq',fail)
    x.load('eax','esi',0x44);x.cmp('eax',250);x.jump('ae',fail)
    x.store('eax',disp=data+dest+0x1C)
    x.imul('ebp','eax',0x110);x.rr('01','ebp','edi');x.ri(0,'ebp',0x4B0)
    x.cmpm('eax','ebp',0x38);x.jump('ne',fail);x.store('ebp',disp=data+dest+0x10)
    x.load('eax','ebp',0x40);x.cmp('eax',1);x.jump('above',fail)
    x.store('eax',disp=data+dest+0x20)


def officer(x,data,record,fail,*,allow_group_members=False):
    x.op(7,0,disp=data+record+0x18);x.jump('ne',fail)
    x.load('eax',disp=data+record+4)
    x.mem('f7',0,'eax',0x2C);x.dword(0x10);x.jump('eq',fail)
    x.load('eax',disp=data+record+12)
    if allow_group_members:
        # Native officer groups can contain the officer and its followers.
        # Slot0 + physical leader flag identifies the leader; max-size1 does not.
        x.load('ecx','eax',0x24);x.cmp('ecx',1);x.jump('below',fail)
        x.cmp('ecx',30);x.jump('above',fail)
    else:
        # Preserve the exact original emission for installed v1/v2 recovery.
        x.op(7,1,'eax',0x24);x.jump('ne',fail)


def infantry(x,data,record,fail):
    x.load('eax',disp=data+record+4)
    x.mem('f7',0,'eax',0x2C);x.dword(0x10);x.jump('ne',fail)
    x.load('eax',disp=data+record+12)
    x.load('ecx','eax',0x24);x.cmp('ecx',2);x.jump('below',fail)
    x.cmp('ecx',30);x.jump('above',fail)
    x.load('ecx','eax',0x30);x.ri(5,'ecx',865);x.cmp('ecx',36);x.jump('above',fail)
