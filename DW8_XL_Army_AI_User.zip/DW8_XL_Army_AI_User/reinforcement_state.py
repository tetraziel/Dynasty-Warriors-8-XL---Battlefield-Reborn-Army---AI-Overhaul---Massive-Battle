"""Private gate-eligibility telemetry. No process or Windows imports."""
import struct
from core import require

BASE=0x2800
END=0x2880
SCRATCH=0x2900
MAGIC=0x35475444
REASONS=('OK','GLOBALS','PHASE','PLAYER_BINDING','GROUP_IDENTITY',
         'GROUP_NOT_EMPTY','OWNER_LIST_FAMILY','CONFIG_EVENT','GROUP_AI_LINK')
COUNTERS={'intercepts':0x10,'eligible_empty_events':0x14,
          'native_protection_bypasses':0x18,'refusals':0x1C}


def initialize(buffer):
    struct.pack_into('<4I',buffer,BASE,MAGIC,1,1,0)


def decode(raw):
    if len(raw)<END or struct.unpack_from('<I',raw,BASE)[0]!=MAGIC:
        return {'available':False,'enabled':False}
    def u(off):return struct.unpack_from('<I',raw,BASE+off)[0]
    require(u(4)==1 and u(8) in (0,1),'E_GATE_DATA_SETTINGS')
    reason=u(0x20)
    return {'available':True,'enabled':bool(u(8) and struct.unpack_from('<I',raw,8)[0]
                and not struct.unpack_from('<I',raw,12)[0]),
            'implementation':'SCOPED_NATIVE_GATE_ELIGIBILITY',
            **{name:u(off) for name,off in COUNTERS.items()},
            'last_rejection':REASONS[reason] if 0<reason<len(REASONS) else None,
            'last_eligible_group':u(0x24) if u(0x14) else None,
            'last_family_quantity':u(0x28) if u(0x14) else None,
            'last_native_owner_flags_68':hex(u(0x2C)) if u(0x14) else None,
            'last_native_group_flags_50':hex(u(0x30)) if u(0x14) else None,
            'native_spawns_observed':None,'live_replenishment_verified':False,
            'maximum_family_quantity':120,'morale_override':False,
            'morale_tiers_enabled':False,'position_override':False,
            'native_gate_and_timing_checks_preserved':True}


def inspect_native_state(memory,state,groups,*,pool=None):
    """Read native gate inputs for later correlation; no writes or morale guess."""
    from pool_binding import resolve
    p=resolve(pool)
    owner=state['manager']+0x4B0+state['owner']*0x110
    record=memory.read(owner,0x110)
    def u(off):return struct.unpack_from('<I',record,off)[0]
    for group in groups:
        raw=memory.read(state['manager']+p.manager_groups+group['squad']*0x268,0x54)
        # The earlier owner-list read and this extra telemetry must describe
        # the same logical group. Retry a later audit if a native update won.
        require(struct.unpack_from('<I',raw,0x18)[0]==group['squad'] and
                struct.unpack_from('<I',raw,0x44)[0]==group['owner'] and
                all(struct.unpack_from('<I',raw,offset)[0]==group[key]
                    for offset,key in ((0x24,'quantity_max'),(0x28,'quantity_current'),
                                       (0x2C,'template'),(0x30,'unit_type'))),
                'E_AUDIT_GROUP_CHANGED')
        group['materialized_bits']=struct.unpack_from('<I',raw,0x14)[0]
        group['native_flags_50']=raw[0x50]
        group['native_field_38_raw']=struct.unpack_from('<I',raw,0x38)[0]
        group['logical_member_bits']=struct.unpack_from('<I',raw,0x10)[0]
    raw_group=memory.read(state['manager']+p.manager_groups+state['player_squad']*0x268,0x4C)
    zone=struct.unpack_from('<I',raw_group,0x48)[0]
    candidate=None
    if zone<0x80:
        address=state['manager']+0x72AC4+zone*0x560+0x41
        candidate={'zone':zone,'address':hex(address),
                   'signed_byte_41':int.from_bytes(memory.read(address,1),'little',signed=True),
                   'meaning_verified':False}
    return {'owner_flags_64':hex(struct.unpack_from('<H',record,0x64)[0]),
            'owner_flags_68':hex(u(0x68)),
            'native_gate_protection_bit_100':bool(u(0x68)&0x100),
            'native_replenishment_bit_2000':bool(u(0x68)&0x2000),
            'owner_fields_raw':{hex(off):u(off) for off in (0x54,0x98,0xA0,0xA8,0xAC)},
            'native_reserve_group':groups[-1]['squad'] if groups else None,
            'unidentified_zone_timing_input':candidate,
            'morale_field_identified':False,'morale_tiers_enabled':False,
            'requested_policy':{'low':30,'medium':60,'medium_high':90,'high':120,
                                'replacement':'PERIODIC','remove_survivors_on_drop':False}}


def summarize_army(audit,*,pool=None):
    """Separate native logical quantity from materialization and cached counters.

    Missing or unsupported identity never becomes a zero-soldier observation.
    A decrease is a quantity change, not proof of deaths or their cause.
    """
    from pool_binding import resolve
    p=resolve(pool)
    unavailable=lambda reason:{'available':False,'reason':reason,'read_only':True}
    state=audit.get('state');groups=audit.get('player_groups')
    if (not isinstance(state,dict) or not isinstance(groups,list) or not 1<=len(groups)<=6 or
        any(not isinstance(group,dict) for group in groups)):
        return unavailable('E_ARMY_GROUP_LIST_UNAVAILABLE')
    owner=state.get('owner');player=state.get('player_squad')
    ids=[g.get('squad') for g in groups]
    if (owner!=0 or any(type(i) is not int or not 0<=i<p.group_capacity for i in ids) or
        len(set(ids))!=len(ids) or player not in ids or
        any(g.get('owner')!=owner for g in groups)):
        return unavailable('E_ARMY_GROUP_IDENTITY')
    family=[]
    for group in groups:
        if group['squad']==player:
            if group.get('unit_type')!=1108 or group.get('template') not in (0,1):
                return unavailable('E_ARMY_PLAYER_IDENTITY')
            continue
        if group.get('unit_type')==0xFFFFFFFF and group.get('template')==2 and group.get('quantity_current')==0:
            continue
        if group.get('unit_type')!=865 or group.get('template')!=30:
            return unavailable('E_ARMY_FAMILY_IDENTITY')
        quantity=group.get('quantity_current');mask=group.get('materialized_bits')
        if (group.get('quantity_max')!=30 or type(quantity) is not int or not 0<=quantity<=30 or
            type(mask) is not int or not 0<=mask<=0xFFFFFFFF):
            return unavailable('E_ARMY_QUANTITY_RANGE')
        family.append({'squad':group['squad'],'quantity_current':quantity,
                       'quantity_max':30,'materialized_members':mask.bit_count(),
                       'logical_member_bits':group.get('logical_member_bits'),
                       'native_field_38_raw':group.get('native_field_38_raw'),
                       'ai_link_matches_owner':group.get('ai_link_matches_owner')})
    if not family:return unavailable('E_ARMY_FAMILY_NOT_FOUND')
    total=sum(g['quantity_current'] for g in family)
    if total>120:return unavailable('E_ARMY_FAMILY_TOTAL_RANGE')
    return {'available':True,'reason':None,'source':'NATIVE_OWNER_GROUP_QUANTITIES',
            'logical_soldiers_current':total,
            'materialized_members':sum(g['materialized_members'] for g in family),
            'nonempty_groups':sum(g['quantity_current']>0 for g in family),
            'empty_groups':sum(g['quantity_current']==0 for g in family),
            'matching_groups':family,'maximum_family_quantity':120,
            'visible_soldiers_count':None,'loss_cause':'UNDETERMINED',
            'read_only':True,'policy_applied':False}
