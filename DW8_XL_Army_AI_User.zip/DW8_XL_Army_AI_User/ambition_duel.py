"""Optional post-symbol Duel rotation. Bridges run on existing native callers.

The native selector still builds and randomly selects eligible scenarios. The
symbol-to-scenario metadata must identify all twenty collected camp ornaments;
neither officer recruitment nor the first twenty arbitrary progress bits qualify.
"""
import struct
from core import require,word,uint
from bridge import relative_jump
from recall_bridge import Asm,R
import bundle_support as bundle

FEATURE='AMBITION_POST_SYMBOLS_RANDOM_DUEL_3_TEST'
MAGIC=0x314C5544;VERSION=3;LEGACY_VERSION=1;LEGACY_VERSIONS=(1,2);SIZE=0x1000;CODE_SIZE=0x14000
SITES={
    'DUEL_SCHEDULE':(0x282DFA,'0f85cb010000'),
    'DUEL_COMPLETED_FILTER':(0x282EA3,'e8b84a1700'),
    'DUEL_SELECTED':(0x282F14,'81ff57020000'),
    'DUEL_FRESH_BATTLE':(0x52B850,'558bec83e4f8'),
    'DUEL_MATERIAL_RESULT':(0x2A867C,'0fb783a4000000'),
}
COUNTERS={'schedule_visits':0x10,'post_symbols_checks':0x14,
    'duel_rounds_requested':0x18,'ordinary_rounds_preserved':0x1C,
    'completed_duels_readmitted':0x20,'native_selections_observed':0x24,
    'fresh_duels_armed':0x28,'reward_results_observed':0x2C,
    'material_awards_applied':0x30,'duplicate_rewards_skipped':0x34,
    'scope_skips':0x38,'symbol_metadata_refusals':0x3C}
PERCENT=0x80
DEFAULT_PERCENT=(100,125,150,175,200,250)
DUEL_IDS=tuple(133+5*i for i in range(20))
# Validated symbol membership, followed by a single fresh-battle reward token.
CAMP,MASK_LO,MASK_HI,ARMED,PAID,ROUND,STAGE,GENERATION=range(0x100,0x120,4)
TEMP_LO,TEMP_HI,TEMP_FACILITY,TEMP_WEAPON=range(0x120,0x130,4)
LAST_STAGE,LAST_ROUND,LAST_DIFFICULTY,LAST_PERCENT=range(0x140,0x150,4)
LAST_BEFORE,LAST_BASELINE,LAST_AFTER=0x150,0x158,0x160
SELECTION_COUNTER,UPCOMING_ROUND,CHOSEN_ROUND,START_ROUND=range(0x168,0x178,4)
START_STAGE,START_KIND,START_SOURCE,ARMING_REASON=range(0x178,0x188,4)
ARMING_REASONS={0:'WAITING_FRESH_DUEL',1:'ARMED',2:'NOT_AMBITION',
    3:'SYMBOL_CACHE_OR_MEMBERSHIP',4:'CURRENT_BATTLE_NOT_MULTIPLE_OF_FIVE',
    5:'NOT_DUEL_KIND',6:'UNKNOWN_DUEL_SCENARIO',7:'RESUME_PRESERVES_TOKEN'}


def validate_percent(values):
    require(isinstance(values,(tuple,list)) and len(values)==6 and
            all(type(v) is int and 100<=v<=1000 for v in values),'E_DUEL_DIFFICULTY_PERCENT_100_1000')
    return tuple(values)


def initialize_data(raw):
    struct.pack_into('<6I',raw,PERCENT,*DEFAULT_PERCENT)


def build_bridge(base,data,code,auto,recall,name,*,legacy=False,legacy_version=None):
    require(name in SITES,'E_DUEL_SITE');x=Asm()
    version=(legacy_version or LEGACY_VERSION) if legacy else VERSION
    legacy=version==1
    interval=3 if version>=3 else 5
    def inc(off):x.mem('ff',0,disp=data+off)
    def save(reg,off):x.store(reg,disp=data+off)
    def load_word(reg,addr_reg=None,off=0):x.mem('0fb7',R[reg],addr_reg,off)
    def jump_native(rva):x.emit(relative_jump(code+len(x.code),base+rva))
    def known_id(reg,failed):
        x.rr('89','eax',reg);x.ri(5,'eax',133);x.cmp('eax',95);x.jump('above',failed)
        x.imm('edx',0);x.imm('ecx',5);x.emit('f7f1');x.cmp('edx',0);x.jump('ne',failed)
    def cache_scope(failed):
        x.load('edi',disp=base+0x6A9398);x.sane('edi',failed)
        x.cmpm('edi',disp=data+CAMP);x.jump('ne',failed)
        x.load('eax',disp=data+MASK_LO);x.load('edx',disp=data+MASK_HI)
        x.rr('89','ecx','eax');x.rr('09','ecx','edx');x.cmp('ecx',0);x.jump('eq',failed)
        x.load('ecx','edi',0x80);x.rr('21','ecx','eax');x.rr('39','ecx','eax');x.jump('ne',failed)
        x.load('ecx','edi',0x84);x.rr('21','ecx','edx');x.rr('39','ecx','edx');x.jump('ne',failed)
    def scheduled_round(failed,*,upcoming=False):
        load_word('eax','edi',0x582)
        if upcoming and not legacy:
            # Choices describe the NEXT battle. Confirming a choice increments
            # the native counter afterwards, before fresh battle initialization.
            # The native 999 cap must never produce an imaginary battle 1000.
            x.cmp('eax',998);x.jump('above',failed);x.ri(0,'eax',1)
        else:
            x.cmp('eax',1);x.jump('below',failed)
            x.cmp('eax',999);x.jump('above',failed)
        x.imm('edx',0);x.imm('ecx',interval);x.emit('f7f1');x.cmp('edx',0);x.jump('ne',failed)
    x.emit('9c60')
    for off,val in ((0,MAGIC),(4,version),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','native')

    if name=='DUEL_FRESH_BATTLE':
        # EDI configuration is not initialized yet. Only the native fresh/resume
        # byte is read; no configuration flags are interpreted before startup.
        if not legacy:x.set(7,disp=data+ARMING_REASON)
        x.mem('0fb6',R['eax'],'esp',40);x.cmp('eax',0);x.jump('ne','unlock')
        x.set(0,disp=data+ARMED);x.set(0,disp=data+PAID);inc(GENERATION)
        if not legacy:x.set(2,disp=data+ARMING_REASON)
    load_word('eax',off=base+0x848530)
    if name=='DUEL_FRESH_BATTLE' and not legacy:
        save('eax',START_SOURCE)
        load_word('ecx',off=base+0x848542);save('ecx',START_STAGE)
        load_word('ecx',off=base+0x84855C);save('ecx',START_KIND)
    x.cmp('eax',1);x.jump('ne','skip')

    if name=='DUEL_SCHEDULE':
        inc(0x10)
        x.load('edi','esp',16);x.sane('edi','metadata_failed')
        x.cmpm('edi',disp=base+0x6A9398);x.jump('ne','metadata_failed')
        x.load('esi',disp=base+0x6A94FC);x.sane('esi','metadata_failed')
        x.ri(0,'esi',0x16E2);x.imm('ebx',0);x.imm('ebp',0)
        x.set(0,disp=data+TEMP_LO);x.set(0,disp=data+TEMP_HI)
        x.mark('symbol_loop');load_word('eax','esi')
        x.ri(5,'eax',133);x.cmp('eax',95);x.jump('above','next_symbol')
        x.imm('edx',0);x.imm('ecx',5);x.emit('f7f1');x.cmp('edx',0);x.jump('ne','next_symbol')
        x.rr('89','ecx','eax');x.imm('edx',1);x.emit('d3e2')
        x.rr('85','ebp','edx');x.jump('ne','metadata_failed');x.rr('09','ebp','edx')
        x.rr('89','ecx','ebx');x.ri(4,'ecx',31);x.imm('edx',1);x.emit('d3e2')
        x.cmp('ebx',32);x.jump('ae','high_symbol')
        x.mem('85',R['edx'],'edi',0x80);x.jump('eq','metadata_failed')
        x.mem('09',R['edx'],disp=data+TEMP_LO);x.jump('jmp','next_symbol')
        x.mark('high_symbol');x.mem('85',R['edx'],'edi',0x84);x.jump('eq','metadata_failed')
        x.mem('09',R['edx'],disp=data+TEMP_HI)
        x.mark('next_symbol');x.ri(0,'esi',4);x.ri(0,'ebx',1);x.cmp('ebx',50);x.jump('below','symbol_loop')
        x.cmp('ebp',0xFFFFF);x.jump('ne','metadata_failed')
        save('edi',CAMP)
        for a,b in ((TEMP_LO,MASK_LO),(TEMP_HI,MASK_HI)):
            x.load('eax',disp=data+a);save('eax',b)
        inc(0x14)
        load_word('eax','edi',0x582);save('eax',LAST_ROUND)
        if not legacy:
            save('eax',SELECTION_COUNTER);x.ri(0,'eax',1);save('eax',UPCOMING_ROUND)
        scheduled_round('ordinary',upcoming=True);inc(0x18);x.set(0,disp=data+12);x.emit('619d')
        # All twenty ornaments prove the native Duel unlock. Keep the native
        # region, scenario-kind and random selection filters after this gate.
        jump_native(0x282E18)
        x.mark('ordinary');inc(0x1C);x.set(0,disp=data+12);x.emit('619d');jump_native(0x282FCB)
        x.mark('metadata_failed');inc(0x3C);x.jump('jmp','skip')
    elif name=='DUEL_COMPLETED_FILTER':
        cache_scope('skip');scheduled_round('skip',upcoming=True)
        x.load('ebx','esp',16);x.rr('39','ebx','edi');x.jump('ne','skip')
        x.load('ebx','esp',28);known_id('ebx','skip')
        inc(0x20);x.set(0,'esp',28);x.set(0,disp=data+12);x.emit('619d')
        # Replace a callee-cleaned CALL: discard its one camp argument exactly.
        x.lea('esp','esp',4);jump_native(0x282EA8)
    elif name=='DUEL_SELECTED':
        cache_scope('skip');scheduled_round('skip',upcoming=True)
        x.load('ebx','esp',0);known_id('ebx','skip');save('ebx',LAST_STAGE);inc(0x24)
        if not legacy:
            load_word('eax','edi',0x582);x.ri(0,'eax',1);save('eax',CHOSEN_ROUND)
        x.jump('jmp','unlock')
    elif name=='DUEL_FRESH_BATTLE':
        if not legacy:x.set(3,disp=data+ARMING_REASON)
        cache_scope('skip')
        if not legacy:
            load_word('eax','edi',0x582);save('eax',START_ROUND);x.set(4,disp=data+ARMING_REASON)
        if version>=3:
            x.op(7,999,disp=data+SELECTION_COUNTER);x.jump('ae','skip')
        scheduled_round('skip')
        if not legacy:x.set(5,disp=data+ARMING_REASON)
        load_word('eax',off=base+0x84855C);x.cmp('eax',12);x.jump('ne','skip')
        if not legacy:x.set(6,disp=data+ARMING_REASON)
        load_word('ebx',off=base+0x848542);known_id('ebx','skip');save('ebx',STAGE)
        load_word('eax','edi',0x582);save('eax',ROUND);x.set(1,disp=data+ARMED);inc(0x28)
        if not legacy:x.set(1,disp=data+ARMING_REASON)
        x.jump('jmp','unlock')
    else:
        inc(0x2C);cache_scope('skip')
        x.load('ebx','esp',16);x.rr('39','ebx','edi');x.jump('ne','skip')
        x.op(7,1,disp=data+ARMED);x.jump('ne','skip')
        load_word('eax','edi',0x582);x.cmpm('eax',disp=data+ROUND);x.jump('ne','skip')
        load_word('ebx',off=base+0x848542);x.cmpm('ebx',disp=data+STAGE);x.jump('ne','skip')
        known_id('ebx','skip')
        load_word('eax',off=base+0x84855C);x.cmp('eax',12);x.jump('ne','skip')
        x.load('eax',disp=base+0x6A9200);x.sane('eax','skip');x.op(7,2,'eax',0x40);x.jump('ne','skip')
        x.op(7,0,disp=data+PAID);x.jump('ne','duplicate')
        load_word('eax',off=base+0x848546);x.cmp('eax',5);x.jump('above','skip');save('eax',LAST_DIFFICULTY)
        x.imul('eax','eax',4);x.ri(0,'eax',data+PERCENT);x.load('esi','eax')
        x.cmp('esi',100);x.jump('below','skip');x.cmp('esi',1000);x.jump('above','skip');save('esi',LAST_PERCENT)
        # Preflight both resources before writing either one. A result callback
        # cannot duplicate a prize, including when a native cap is reached.
        for i in range(2):
            load_word('eax','edi',0xA4+i*2);x.cmp('eax',9999);x.jump('above','skip');save('eax',LAST_BEFORE+i*4)
            load_word('ecx','edi',0x5A8+i*2);x.cmp('ecx',9999);x.jump('above','skip');save('ecx',LAST_BASELINE+i*4)
            x.rr('39','eax','ecx');x.jump('below','skip')
        for i in range(2):
            x.load('eax',disp=data+LAST_BEFORE+i*4);x.load('ebx',disp=data+LAST_BASELINE+i*4)
            x.rr('29','eax','ebx');x.imul('eax','eax',2);x.emit('0fafc6')
            x.imm('edx',0);x.imm('ecx',100);x.emit('f7f1');x.rr('01','eax','ebx')
            x.cmp('eax',9999);x.jump('be','bounded_'+str(i));x.imm('eax',9999);x.mark('bounded_'+str(i))
            save('eax',TEMP_FACILITY+i*4)
        for i in range(2):
            x.load('eax',disp=data+TEMP_FACILITY+i*4);save('eax',LAST_AFTER+i*4)
            x.mem('6689',R['eax'],'edi',0xA4+i*2)
        x.set(1,disp=data+PAID);inc(0x30);x.jump('jmp','unlock')
        x.mark('duplicate');inc(0x34);x.jump('jmp','unlock')
    x.mark('skip');inc(0x38)
    x.mark('unlock');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d')
    if name=='DUEL_SCHEDULE':
        x.emit('3bc1');x.jump('ne','native_ordinary');jump_native(0x282E00)
        x.mark('native_ordinary');jump_native(0x282FCB)
    elif name=='DUEL_COMPLETED_FILTER':
        x.emit('68');x.dword(base+0x282EA8);jump_native(0x3F7960)
    else:
        rva,raw=SITES[name];x.emit(raw);jump_native(rva+len(bytes.fromhex(raw)))
    return x.finish()


CHECKS={0x368E99:'403de70300007605b8e703000066898182050000',
    0x282E3E:'0fb646043d95000000',0x282E91:'8b562cc1ea03f6c201',
    0x282EEA:'33d283f802',0x282F42:'c741fe03000c00',
    0x3F8180:'83f831',0x52B85A:'385d087443',
    0x2A868F:'0fb78ba80500002bc18987d0c70100',
    0x2A86B1:'0fb793aa050000',0x3798B6:'3978400f85e7000000'}


def check_code(memory):
    for rva,sig in CHECKS.items():
        wanted=bytes.fromhex(sig)
        require(memory.read(memory.base+rva,len(wanted))==wanted,'E_DUEL_NATIVE_'+hex(rva))


def validate_data(memory,record):
    validate_percent(struct.unpack('<6I',memory.read(record['data_address']+PERCENT,24)))


def configure(session,enabled,percent):
    require(type(enabled) is bool,'E_DUEL_ENABLED');percent=validate_percent(percent)
    record=(session.lease or {}).get('ambition_duel')
    if not record and not enabled:return public(session,None)
    # Prepare disabled, then publish settings before enabling any new bridge.
    bundle.set_bundle(session,'ambition_duel',__import__(__name__),False,prepare_disabled=not record)
    record=session.lease['ambition_duel']
    spans=[s for p in bundle.all_patches(session) for s in
        ((p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),(p['code_address'],p['code_address']+p['code_size']))]
    with session.quiesce(spans):
        bundle.validate(__import__(__name__),session,record)
        require(uint(session,record['data_address']+12)==0,'E_EXTRA_BRIDGE_EXECUTING_RETRY')
        address=record['data_address']+PERCENT;old=session.read(address,24)
        try:
            session.write(address,struct.pack('<6I',*percent))
            require(session.read(address,24)==struct.pack('<6I',*percent),'E_DUEL_SETTINGS_VERIFY')
        except Exception:
            session.write(address,old);raise
        session.log('AMBITION_DUEL_MULTIPLIERS_UPDATED')
    return bundle.set_bundle(session,'ambition_duel',__import__(__name__),enabled)


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(interval=3 if not record or record['version']>=3 else 5,required_camp_symbols=20,scenario_candidates=list(DUEL_IDS),
        random_selection='NATIVE_ELIGIBLE_SCENARIO_RNG',difficulty_percent=list(DEFAULT_PERCENT),
        base_material_multiplier=2,only_facility_and_weapon_materials=True,
        applies_on='NEXT_NATIVE_CHOICES_AND_FRESH_DUEL_START',
        native_stock_cap=9999,original_files_modified=False,remote_threads_created=False,
        live_validated=False)
    result.update(selection_uses_next_battle=True,duel_battles=[3,6,9] if not record or record['version']>=3 else [5,10,15],
        fresh_start_uses_current_battle=True)
    if record:
        a=record['data_address'];raw=memory.read(a,0x168)
        result.update(difficulty_percent=list(struct.unpack_from('<6I',raw,PERCENT)),
            symbol_metadata_validated=bool(word(raw,CAMP)),
            symbol_membership_masks=[hex(word(raw,MASK_LO)),hex(word(raw,MASK_HI))],
            fresh_duel_armed=bool(word(raw,ARMED)),reward_already_applied=bool(word(raw,PAID)),
            generation=word(raw,GENERATION),last_selection={'scenario':word(raw,LAST_STAGE),'round':word(raw,LAST_ROUND)},
            last_material_result={'difficulty_raw':word(raw,LAST_DIFFICULTY),'extra_percent':word(raw,LAST_PERCENT),
                'before':list(struct.unpack_from('<2I',raw,LAST_BEFORE)),
                'battle_baseline':list(struct.unpack_from('<2I',raw,LAST_BASELINE)),
                'after':list(struct.unpack_from('<2I',raw,LAST_AFTER))})
        if record['version']>=2:
            raw=memory.read(a,0x188)
            result['last_selection']['round']=word(raw,CHOSEN_ROUND)
            result['last_schedule']={'native_counter':word(raw,SELECTION_COUNTER),
                'upcoming_battle':word(raw,UPCOMING_ROUND) if word(raw,SELECTION_COUNTER)<999 else None,
                'native_counter_saturated':word(raw,SELECTION_COUNTER)>=999}
            result['last_fresh_start']={'battle':word(raw,START_ROUND),'scenario':word(raw,START_STAGE),
                'kind':word(raw,START_KIND),'mode':word(raw,START_SOURCE),
                'arming_result':('CURRENT_BATTLE_NOT_MULTIPLE_OF_THREE' if record['version']>=3 and word(raw,ARMING_REASON)==4 else ARMING_REASONS.get(word(raw,ARMING_REASON),'INVALID_RESULT'))}
        else:result.update(selection_uses_next_battle=False,duel_battles=None)
    return result
