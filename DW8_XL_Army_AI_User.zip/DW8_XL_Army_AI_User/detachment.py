"""Optional personal-squad hold orders, on the existing native battle threads.

Commands are immutable snapshots. An aligned pointer publishes each complete
order; old snapshots remain allocated until process exit, including after OFF.
Only private data and native stack-local goals are written by these bridges.
"""
import struct
import bundle_support as bundle
from core import require,word
from bridge import relative_jump
from recall_bridge import Asm,R,CONTEXT,MAGIC as RECALL_MAGIC,VERSION as RECALL_VERSION
from auto_bridge import AUTO_MAGIC,AUTO_VERSION
from family_scope import emit_family_scope
from pool_binding import resolve as resolve_pool

FEATURE='PERSONAL_SQUADS_Q_DEFENSE_TEST'
MAGIC=0x31514544;VERSION=1
EXTENSION_POINTER=0x3C0
ARENA=0x1000;RECORD_SIZE=0x200;MAX_RECORDS=4096
SIZE=ARENA+MAX_RECORDS*RECORD_SIZE;CODE_SIZE=0x8000
CURRENT=0x80;USED=0x84;LATCH=0x88;EVENT=0x90
VIEW_A=0x40;VIEW_B=0x120
SITES={'PERSONAL_COMMAND_INPUT':(0x596EA0,'558bec83e4f8'),
       'PERSONAL_LOGICAL_GOAL':(0x57D6AD,'8b8188000000')}
COUNTERS={'input_updates':0x10,'commands_accepted':0x14,'context_resets':0x18,
          'logical_hold_goals':0x1C,'scope_refusals':0x20,'arena_exhaustions':0x24}
FIELDS={n:0x200+i*4 for i,n in enumerate(('manager','owner','group','player','ai','players','phase','sequence','character','group_id','old','new','mode'))}
COMMAND_CONTEXT={'sequence':0,'manager':4,'ai':8,'players':12,'phase':16,'character':20}
MESSAGES={1:'Half of your troops are defending this position!',
          2:'All your troops are defending their positions!',
          0:'All your troops are following your lead!'}


def initialize_data(raw):
    # An already held key must be released before the first command.
    struct.pack_into('<I',raw,LATCH,1)


def emit_hold_view(x,recall,auto,group_address,*,prefix):
    """Return EAX=immutable native fixed-point view, or zero. Preserve others.

    Called only after the caller's complete personal-actor/group scope check.
    No scratch writes, locks, native calls, FP or game-record writes.
    """
    end=prefix+'_end';second=prefix+'_second';view=prefix+'_view'
    x.emit('60');x.set(0,'esp',28)
    x.load('edi',disp=recall+EXTENSION_POINTER);x.sane('edi',end)
    for off,val in ((0,MAGIC),(4,VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,'edi',off);x.jump('ne',end)
    x.load('esi','edi',CURRENT)
    x.lea('ecx','edi',ARENA);x.rr('39','esi','ecx');x.jump('below',end)
    x.lea('edx','edi',SIZE-RECORD_SIZE);x.rr('39','esi','edx');x.jump('above',end)
    x.rr('89','ecx','esi');x.ri(4,'ecx',RECORD_SIZE-1);x.cmp('ecx',0);x.jump('ne',end)
    x.load('eax','esi',0x1C);x.cmp('eax',1);x.jump('eq',prefix+'_mode')
    x.cmp('eax',2);x.jump('ne',end);x.mark(prefix+'_mode')
    x.load('edx','esi',0x18);x.cmp('edx',0);x.jump('ne',end)
    x.load('ecx','esi');x.cmp('ecx',0);x.jump('eq',end)
    for name,off in COMMAND_CONTEXT.items():
        x.load('edx','esi',off);x.cmpm('edx',disp=recall+CONTEXT[name]);x.jump('ne',end)
    x.load('ecx',disp=auto+16);x.cmpm('ecx','esi');x.jump('ne',end)
    x.load('ecx',disp=group_address)
    x.op(7,0,'ecx',0x44);x.jump('ne',end)
    x.load('edx','ecx',0x1C);x.cmp('edx',1);x.jump('below',end)
    x.cmp('edx',4);x.jump('above',end)
    # Match the current roster slot as well as the ordinal. This rejects a
    # reclassified reserve or another family member with a stale ordinal.
    x.load('ebx','esi',4);x.load('ebx','ebx',0x4B0+0xF8);x.sane('ebx',end)
    x.imul('edx','edx',2);x.rr('01','ebx','edx')
    x.mem('0fb7',R['edx'],'ebx');x.cmpm('edx','ecx',0x18);x.jump('ne',end)
    x.load('edx','ecx',0x1C)
    x.cmp('edx',2);x.jump('above',second)
    x.ri(0,'esi',VIEW_A);x.jump('jmp',view)
    x.mark(second);x.cmp('eax',2);x.jump('ne',end);x.ri(0,'esi',VIEW_B)
    x.mark(view)
    x.op(7,5,'esi',0x84);x.jump('ne',end)
    x.mem('0fb6',R['eax'],'esi',0xA0);x.cmp('eax',0x80);x.jump('ae',end)
    x.store('esi','esp',28)
    x.mark(end);x.emit('61')


def build_bridge(base,data,code,auto,recall,name,*,pool=None):
    # Current sessions use the native binding. An explicit expanded binding is
    # only an emitter input; it does not allocate or authorize a live pool.
    p=resolve_pool(pool)
    require(name in SITES,'E_DETACHMENT_SITE');x=Asm()
    inc=lambda off:x.mem('ff',0,disp=data+off)
    def save(reg,n):x.store(reg,disp=data+FIELDS[n])
    def load(reg,n):x.load(reg,disp=data+FIELDS[n])
    def ctx(reg,n):x.cmpm(reg,disp=recall+CONTEXT[n]);x.jump('ne','refuse')
    if name=='PERSONAL_LOGICAL_GOAL':x.emit(SITES[name][1])
    x.emit('9c60')
    for off,val in ((0,MAGIC),(4,VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','native')
    # Acquire rather than wait: no suspension, polling or lock cycle in game.
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=recall+16);x.jump('ne','unlock')
    for a,v in ((auto,AUTO_MAGIC),(auto+4,AUTO_VERSION),(auto+12,0),(auto+20,0),(auto+24,1),
                (recall,RECALL_MAGIC),(recall+4,RECALL_VERSION),(recall+8,1),(recall+12,0)):
        x.op(7,v,disp=a);x.jump('ne','refuse')
    for rva,n in ((0x6A91E8,'manager'),(0x6A91D8,'ai'),(0x6A91EC,'players'),(0x6D10BC,'phase')):
        x.load('edx',disp=base+rva);x.sane('edx','refuse');ctx('edx',n);save('edx',n)
    x.op(7,4,'edx',0x1C784);x.jump('ne','refuse')
    load('ecx','players');x.op(7,1,'ecx',0x590);x.jump('ne','refuse')
    x.op(7,0,'ecx',0x108);x.jump('ne','refuse');x.set(0,disp=data+FIELDS['owner'])
    x.load('eax',disp=auto+16);x.cmp('eax',0);x.jump('eq','refuse');ctx('eax','sequence');save('eax','sequence')
    load('ebx','manager');x.op(7,0,'ebx',0x4B0+0x38);x.jump('ne','refuse')
    x.op(7,0,'ebx',0x4B0+0x40);x.jump('ne','refuse')
    x.load('edx','ebx',0x4B0+0x44);ctx('edx','character');save('edx','character')
    x.load('eax','ecx',0x110);x.cmp('eax',150);x.jump('ae','refuse');ctx('eax','player_id')
    x.imul('eax','eax',0xE0);load('edx','ai');x.rr('01','eax','edx');x.ri(0,'eax',0x21EF8);save('eax','player')
    x.mem('f7',0,'eax',0xCC);x.dword(1);x.jump('eq','refuse')
    x.mem('0fb6',R['ecx'],'eax',0xD0);x.cmp('ecx',0x80);x.jump('ae','refuse')
    if name=='PERSONAL_COMMAND_INPUT':
        x.op(7,0,'esp',40);x.jump('ne','done') # Native first argument: P1 only.
        inc(0x10)
        # Native mapped HELD command mask. +1C is edge, +20 release, +24 repeat.
        # Using +18 with our latch honors keyboard/gamepad remaps and suppresses repeats.
        x.load('ecx',disp=base+0x6A95E4);x.sane('ecx','refuse')
        x.load('edx','ecx',0x18);x.ri(4,'edx',0x40)
        x.cmp('edx',0);x.jump('eq','released')
        x.op(7,0,disp=data+LATCH);x.jump('ne','done');x.set(1,disp=data+LATCH)
        x.load('eax',disp=data+CURRENT);save('eax','old')
        x.cmp('eax',0);x.jump('eq','fresh')
        x.cmp('eax',data+ARENA);x.jump('below','refuse')
        x.cmp('eax',data+SIZE-RECORD_SIZE);x.jump('above','refuse')
        x.rr('89','ecx','eax');x.ri(4,'ecx',RECORD_SIZE-1);x.cmp('ecx',0);x.jump('ne','refuse')
        for n,off in COMMAND_CONTEXT.items():
            load('edx',n);x.cmpm('edx','eax',off);x.jump('ne','fresh')
        x.load('ecx','eax',0x1C);x.cmp('ecx',2);x.jump('ae','all_follow')
        x.cmp('ecx',1);x.jump('ne','fresh');x.imm('ecx',2);x.jump('jmp','mode_ready')
        x.mark('fresh');inc(0x18);x.imm('ecx',1);x.jump('jmp','mode_ready')
        x.mark('all_follow');x.imm('ecx',0)
        x.mark('mode_ready');save('ecx','mode')
        x.load('eax',disp=data+USED);x.cmp('eax',MAX_RECORDS);x.jump('ae','exhausted')
        x.imul('eax','eax',RECORD_SIZE);x.ri(0,'eax',data+ARENA);save('eax','new')
        # Validate all four roster identities, including currently empty squads.
        load('ebx','manager');x.load('esi','ebx',0x4B0+0xF8);x.sane('esi','refuse')
        x.load('ecx','ebx',0x4B0+0x100);x.cmp('ecx',5);x.jump('below','refuse')
        x.cmp('ecx',6);x.jump('above','refuse')
        x.load('edx','ebx',0x4B0+0xFC);x.cmp('edx',6);x.jump('above','refuse')
        x.rr('39','ecx','edx');x.jump('above','refuse')
        for ordinal in range(1,5):
            x.mem('0fb7',R['eax'],'esi',ordinal*2);x.cmp('eax',p.group_capacity);x.jump('ae','refuse')
            x.imul('edi','eax',0x268);x.rr('01','edi','ebx');x.ri(0,'edi',p.manager_groups);save('edi','group')
            x.cmpm('eax','edi',0x18);x.jump('ne','refuse')
            for off,val in ((0x1C,ordinal),(0x44,0),(0x24,30),(0x2C,30),(0x30,865)):
                x.op(7,val,'edi',off);x.jump('ne','refuse')
            emit_family_scope(x,data,{n:data+FIELDS[n] for n in ('manager','owner','group')},
                              'refuse',prefix='input_family_'+str(ordinal),squad_count=4,pool=p)
        # Complete a new immutable snapshot before publishing CURRENT.
        load('edi','new');load('ecx','mode');x.cmp('ecx',2);x.jump('ne','blank')
        load('esi','old');x.emit('fc');x.imm('ecx',RECORD_SIZE//4);x.emit('f3a5');x.jump('jmp','copied')
        x.mark('blank');x.emit('fc');x.imm('eax',0);x.imm('ecx',RECORD_SIZE//4);x.emit('f3ab')
        x.mark('copied');load('edi','new')
        for n,off in COMMAND_CONTEXT.items():load('edx',n);x.store('edx','edi',off)
        x.set(0,'edi',0x18);load('ecx','mode');x.store('ecx','edi',0x1C)
        load('edx','ai');x.load('edx','edx',0x53E90);x.store('edx','edi',0x20)
        x.load('edx',disp=data+EVENT);x.ri(0,'edx',1);x.store('edx','edi',0x24)
        x.cmp('ecx',0);x.jump('eq','publish')
        x.cmp('ecx',1);x.jump('ne','second_point');x.ri(0,'edi',VIEW_A);x.jump('jmp','point')
        x.mark('second_point');x.ri(0,'edi',VIEW_B)
        x.mark('point');load('esi','player')
        for off in range(0,16,4):
            x.load('edx','esi',0x34+off);x.rr('89','eax','edx');x.ri(4,'eax',0x7FFFFFFF)
            x.cmp('eax',0x4CBEBC20);x.jump('above','refuse');x.store('edx','edi',0x20+off)
        x.mem('0fb6',R['edx'],'esi',0xD0);x.store('edx','edi',0xA0);x.store('edx','edi',0xBC)
        x.set(5,'edi',0x84)
        x.mark('publish')
        for rva,n in ((0x6A91E8,'manager'),(0x6A91D8,'ai'),(0x6A91EC,'players'),(0x6D10BC,'phase')):
            x.load('edx',disp=base+rva);x.cmpm('edx',disp=data+FIELDS[n]);x.jump('ne','refuse')
        load('edx','sequence');x.cmpm('edx',disp=auto+16);x.jump('ne','refuse')
        load('edx','phase');x.op(7,4,'edx',0x1C784);x.jump('ne','refuse')
        load('eax','new');x.store('eax',disp=data+CURRENT)
        inc(USED);inc(EVENT);inc(0x14);x.jump('jmp','done')
        x.mark('released');x.set(0,disp=data+LATCH);x.jump('jmp','done')
        x.mark('exhausted');inc(0x24);x.set(0,disp=data+CURRENT);inc(EVENT);x.jump('jmp','done')
    else:
        # Native EBX is the exact group; ECX is its group AI. Only change stack
        # locals and EAX's movement-enabled bit, leaving both native records intact.
        x.load('edi','esp',16);save('edi','group')
        x.load('eax','edi',0x18);x.cmp('eax',p.group_capacity);x.jump('ae','refuse');save('eax','group_id')
        x.imul('edx','eax',0x268);x.rr('01','edx','ebx');x.ri(0,'edx',p.manager_groups)
        x.rr('39','edx','edi');x.jump('ne','refuse')
        for off,val in ((0x44,0),(0x24,30),(0x2C,30),(0x30,865)):
            x.op(7,val,'edi',off);x.jump('ne','refuse')
        x.load('edx','edi',0x28);x.cmp('edx',1);x.jump('below','refuse');x.cmp('edx',30);x.jump('above','refuse')
        x.imul('eax','eax',0xA0);load('edx','ai');x.rr('01','eax','edx');x.ri(0,'eax',p.ai_groups)
        x.cmpm('eax','esp',24);x.jump('ne','refuse')
        load('edx','group_id');x.cmpm('edx','eax',0x74);x.jump('ne','refuse')
        load('edx','ai');x.cmpm('edx','eax',0x78);x.jump('ne','refuse')
        emit_family_scope(x,data,{n:data+FIELDS[n] for n in ('manager','owner','group')},'refuse',prefix='logical_family',squad_count=4,pool=p)
        emit_hold_view(x,recall,auto,data+FIELDS['group'],prefix='logical_view')
        x.cmp('eax',0);x.jump('eq','done')
        for rva,n in ((0x6A91E8,'manager'),(0x6A91D8,'ai'),(0x6A91EC,'players'),(0x6D10BC,'phase')):
            x.load('edx',disp=base+rva);x.cmpm('edx',disp=data+FIELDS[n]);x.jump('ne','refuse')
        load('edx','sequence');x.cmpm('edx',disp=auto+16);x.jump('ne','refuse')
        load('edx','phase');x.op(7,4,'edx',0x1C784);x.jump('ne','refuse')
        for off in range(0,16,4):x.load('edx','eax',0x20+off);x.store('edx','esp',36+0x48+off)
        x.mem('0fb6',R['edx'],'eax',0xA0);x.store('edx','esp',36+0x18)
        x.op(1,8,'esp',28);inc(0x1C);x.jump('jmp','done')
    x.mark('refuse');inc(0x20)
    x.mark('done');x.set(0,disp=recall+16)
    x.mark('unlock');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d')
    if name=='PERSONAL_COMMAND_INPUT':x.emit(SITES[name][1])
    rva,native=SITES[name];x.emit(relative_jump(code+len(x.code),base+rva+len(bytes.fromhex(native))))
    return x.finish()


def check_code(memory):
    for rva,sig in ((0x596EA6,'83ec2c8b45085356578bf8'),(0x57D6B3,'c1e803a8017540'),
                    (0x1CB96C,'8b45fc8b4c24188bd0f7d223d18955008bd1f7d223d08b45000b442414894dfc894508')):
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),'E_DETACHMENT_NATIVE_'+hex(rva))


def changes_for_enabled(memory,record,enabled):
    require(not enabled or (memory.lease or {}).get('detachment_support') is True,'E_DETACHMENT_RESTART_AUTO_REQUIRED')
    address=record['recall_data_address']+EXTENSION_POINTER
    old=memory.read(address,4);wanted=struct.pack('<I',record['data_address'] if enabled else 0)
    require(word(old) in (0,record['data_address']),'E_DETACHMENT_POINTER_CONFLICT')
    d=record['data_address'];current=memory.read(d+CURRENT,4);latch=memory.read(d+LATCH,4)
    # OFF and re-enable always restart at FOLLOW; immutable snapshots are retained.
    return [(address,old,wanted),(d+CURRENT,current,bytes(4)),(d+LATCH,latch,struct.pack('<I',1))]


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(default_enabled=False,input_action=22,input_default_key='Q',input_binding='NATIVE_COMMAND_BODYGUARD_4',
                  split_points=True,bodyguard_orders_modified=False,reinforcement_policy_modified=False,
                  game_files_modified=False,remote_threads_created=False,native_helpers_called=False,
                  feedback='NATIVE_HUD_OPTION_REQUIRED',exclusive_fullscreen_feedback_verified=False)
    if not record:return dict(result,mode=0,mode_name='FOLLOW',event_sequence=0)
    d=record['data_address'];raw=memory.read(d+CURRENT,20);p=word(raw);used=word(raw,4)
    require(used<=MAX_RECORDS,'E_DETACHMENT_ARENA')
    result.update(event_sequence=word(raw,16),immutable_snapshots_used=used)
    mode=0;stale=False;points={}
    phase=word(memory.read(record['recall_data_address']+CONTEXT['phase'],4))
    battle_active=bool(phase and word(memory.read(phase+0x1C784,4))==4)
    if p:
        require(d+ARENA<=p<=d+SIZE-RECORD_SIZE and (p-d-ARENA)%RECORD_SIZE==0,'E_DETACHMENT_SNAPSHOT')
        cmd=memory.read(p,RECORD_SIZE);mode=word(cmd,0x1C);require(mode in (0,1,2),'E_DETACHMENT_MODE')
        stale=any(word(cmd,o)!=word(memory.read(record['recall_data_address']+CONTEXT[n],4)) for n,o in COMMAND_CONTEXT.items())
        if stale or not battle_active:mode=0
        if mode:
            for key,off in (('A',VIEW_A),('B',VIEW_B)):
                if key=='B' and mode!=2:continue
                points[key]={'position':list(struct.unpack_from('<4f',cmd,off+0x20)),'zone':word(cmd,off+0xA0)}
    history=[]
    for i in range(max(0,used-8),used):
        cmd=memory.read(d+ARENA+i*RECORD_SIZE,RECORD_SIZE)
        history.append({'order_number':word(cmd,0x24),'battle_sequence':word(cmd),'game_tick':word(cmd,0x20),
                        'mode':word(cmd,0x1C),
                        'point_A':list(struct.unpack_from('<4f',cmd,VIEW_A+0x20)),
                        'point_B':list(struct.unpack_from('<4f',cmd,VIEW_B+0x20))})
    result.update(mode=mode,mode_name=('FOLLOW','HALF_DEFENSE','ALL_DEFENSE')[mode],points=points,battle_active=battle_active,
                  recent_commands=history,
                  stale_command_ignored=stale,message=MESSAGES[mode],squad_orders=['DEFENSE_A' if mode else 'FOLLOW']*2+
                  ['DEFENSE_B' if mode==2 else 'FOLLOW']*2)
    return result
