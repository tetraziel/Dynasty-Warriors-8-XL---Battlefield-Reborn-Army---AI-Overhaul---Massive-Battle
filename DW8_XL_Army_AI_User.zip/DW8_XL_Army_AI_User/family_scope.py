"""Bounded player-descriptor family check, including native secondary groups."""
from pool_binding import resolve as resolve_pool
from core import PROFILE,require

COUNT=0xB0
QUANTITY=0xB4


def emit_family_scope(x,data,addresses,fail,*,prefix,squad_count=1,native_template_zero=True,pool=None):
    """Preserve every GP register. Accept the configured infantry family.

    Other descriptor pairs must be unused; each listed group has a unique ID,
    correct self/owner and capacity; matching quantities <= 30 * squad_count.
    Empty groups do not add quantity. The current group must occur exactly once.
    This bounds the interpretation; it is not proof of every native split's cause.
    """
    p=resolve_pool(pool)
    require(type(squad_count) is int and 1<=squad_count<=4,'E_PERSONAL_SQUAD_COUNT')
    bad=prefix+'_bad';done=prefix+'_done'
    x.emit('60')
    x.load('edx',disp=addresses['manager'])
    desc=PROFILE['first_descriptor_offset']
    pairs=[(0x38,1108),(0x3C,1)]
    for i in range(squad_count):pairs.extend(((0x40+i*8,865),(0x44+i*8,30)))
    for off,value in pairs:
        x.op(7,value,'edx',desc+off)
        # Startup already accepts native player templates 0 and 1. Apply the
        # same unsigned range here; retain the exact old branch for recovery.
        x.jump('above' if off==0x3C and native_template_zero else 'ne',bad)
    for off in range(0x40+squad_count*8,0x68,4):
        x.op(7,0xFFFFFFFF,'edx',desc+off);x.jump('ne',bad)
    x.load('eax',disp=addresses['owner']);x.imul('eax','eax',0x110)
    x.rr('01','eax','edx');x.ri(0,'eax',0x4B0)
    x.load('ecx','eax',0x100);x.cmp('ecx',1);x.jump('below',bad)
    x.cmp('ecx',6);x.jump('above',bad)
    x.load('edx','eax',0xFC);x.cmp('edx',6);x.jump('above',bad)
    x.rr('39','ecx','edx');x.jump('above',bad)
    x.store('ecx',disp=data+COUNT)
    x.load('edi','eax',0xF8);x.sane('edi',bad)
    x.imm('esi',0);x.imm('ebx',0)
    for i in range(6):
        nxt=prefix+'_next_'+str(i)
        x.op(7,i+1,disp=data+COUNT);x.jump('below',nxt)
        x.mem('0fb7',0,'edi',i*2);x.cmp('eax',p.group_capacity);x.jump('ae',bad)
        for j in range(i):
            x.mem('0fb7',2,'edi',j*2);x.rr('39','eax','edx');x.jump('eq',bad)
        x.imul('ecx','eax',0x268);x.load('edx',disp=addresses['manager'])
        x.rr('01','ecx','edx');x.ri(0,'ecx',p.manager_groups)
        x.cmpm('eax','ecx',0x18);x.jump('ne',bad)
        x.load('edx',disp=addresses['owner']);x.cmpm('edx','ecx',0x44);x.jump('ne',bad)
        x.op(7,865,'ecx',0x30);x.jump('ne',nxt)
        x.op(7,30,'ecx',0x2C);x.jump('ne',nxt)
        x.op(7,30,'ecx',0x24);x.jump('ne',bad)
        x.load('eax','ecx',0x28);x.cmp('eax',30);x.jump('above',bad)
        x.rr('01','esi','eax');x.cmp('esi',30*squad_count);x.jump('above',bad)
        x.cmpm('ecx',disp=addresses['group']);x.jump('ne',nxt)
        x.emit('43');x.mark(nxt)
    x.cmp('ebx',1);x.jump('ne',bad)
    x.store('esi',disp=data+QUANTITY);x.emit('61');x.jump('jmp',done)
    x.mark(bad);x.emit('61');x.jump('jmp',fail)
    x.mark(done)
