"""Opt-in native menu orders. No process access on import or host-side AI calls."""
import math
import struct
from core import require, word
from recall_bridge import Asm, R
from bridge import relative_jump
import bundle_support as bundle

FEATURE='EXPERIMENTAL_BODYGUARD_MENU_ORDERS'
MAGIC=0x384F4742;VERSION=3;LEGACY_VERSION=1;LEGACY_VERSIONS=(1,2);SIZE=0x2000;CODE_SIZE=0x20000
SITES={
    'SECURE_AVAILABILITY':(0x40FBE1,'e81a23c2ff'),
    'SECURE_SUPPORT_THRESHOLD':(0x386D19,'3b442418722f'),
    'MOBILIZE_PICKER':(0x319803,'0f84f4000000'),
    'MOBILIZE_DESTINATION':(0x5364A0,'56578b7c240c'),
    'SECURE_MANUAL_CANCEL':(0x50BF80,'8b54240483ec10'),
    'NATIVE_GUARD_UPDATE':(0x596F7F,'8b15d8915401'),
}
LEGACY_SITES=dict(SITES)
SITES.update(SECURE_MENU_DISPLAY=(0x2BD24E,'8983a0310000'),
             SECURE_SHORTCUT=(0x59703B,'83fe017767750d'))
LEGACY_SITES_BY_VERSION={1:LEGACY_SITES,2:dict(SITES)}
COUNTERS={'availability_checks':0x10,'secure_unlimited_offers':0x14,
          'support_threshold_checks':0x18,'repeat_supports_avoided':0x1C,
          'picker_checks':0x20,'mobilize_base_pickers_opened':0x24,
          'mobilize_checks':0x28,'destinations_accepted':0x2C,
          'destinations_refused':0x30,'pending_native_updates':0x34,
          'advances_resumed':0x38,'orders_cancelled':0x3C,
          'secure_native_orders_preserved':0x40,'context_skips':0x44,
          'resume_attempts':0x48}
MENU_TID=0x50;UPDATE_TID=0x54;LAST_OWNER=0x58;LAST_BASE=0x5C;LAST_REASON=0x60
REASONS={0:'NONE',1:'NEW_SECURE_ORDER',2:'NATIVE_ORDER_CHANGED',3:'LOAD_OR_IDENTITY_CHANGED',
         4:'INVALID_DESTINATION',5:'DISABLED',6:'DESTINATION_REACHED',7:'NATIVE_FALLBACK',
         8:'ORDER_ID_CHANGED',9:'ORDER_OWNER_CHANGED',10:'ORDER_POINT_CHANGED',
         11:'ORDER_COORDINATES_CHANGED',12:'NATIVE_ADVANCE_ALREADY_ACTIVE',
         13:'CONSTRUCTOR_RESULT_MISMATCH',14:'ORDER_STATE_CHANGED',15:'SECURE_SHORTCUT',
         16:'NEW_PENDING_COMMAND',17:'ACTIVE_WAYPOINT_CHANGED',18:'ACTIVE_OWNER_CHANGED'}
EXTRA_COUNTERS={'secure_menu_dashes':0x80,'secure_shortcut_transitions':0x84,
                'ordinary_mobilize_requests':0x88,'native_advances_observed':0x8C,
                'constructor_result_mismatches':0x90}
SHORTCUT_TID=0x94
CONTINUATION_COUNTERS={'consumed_descriptor_updates':0x98,'active_waypoint_updates':0x9C,
                       'active_state_waits':0xA0}
DIAGNOSTICS=0x400;DIAGNOSTIC_STRIDE=0x80
ARRIVAL_RADIUS=900.0
REGISTRY=0x100;STRIDE=0x80;WORK=0x800
W={'manager':0,'ai':4,'players':8,'sequence':12,'owner':16,'slot':20,'entry':24,
   'base_id':28,'base_record':32,'order':36,'request':40,'owner_record':44}


def original(base,name):
    if name=='NATIVE_GUARD_UPDATE':return bytes.fromhex('8b15')+struct.pack('<I',base+0x6A91D8)
    return bytes.fromhex(SITES[name][1])


def save(x,data,name,reg):x.store(reg,disp=data+WORK+W[name])
def load(x,data,name,reg):x.load(reg,disp=data+WORK+W[name])
def inc(x,data,offset):x.mem('ff',0,disp=data+offset)


def begin(x,data,auto,recall,*,version=None):
    x.emit('9c60')
    for off,value in ((0,MAGIC),(4,VERSION if version is None else version),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12)
    x.jump('ne','native')


def common(x,base,data,auto,*,active_only=False):
    # Reject transitions before dereferencing the battle managers/roster.
    x.load('eax',disp=base+0x6D10BC);x.sane('eax','skip');x.load('eax','eax',0x1C784)
    x.cmp('eax',4);x.jump('eq','phase_ok')
    if not active_only:x.cmp('eax',5);x.jump('eq','phase_ok')
    x.jump('jmp','skip');x.mark('phase_ok')
    for reg,rva,name in [('edi',0x6A91E8,'manager'),('esi',0x6A91D8,'ai'),('ebx',0x6A91EC,'players')]:
        x.load(reg,disp=base+rva);x.sane(reg,'skip');save(x,data,name,reg)
    x.op(7,1,'ebx',0x590);x.jump('ne','skip')
    x.op(7,0,'ebx',0x108);x.jump('ne','skip')
    x.op(7,1,disp=auto+24);x.jump('ne','skip')
    x.op(7,0,disp=auto+20);x.jump('ne','skip')
    x.load('eax',disp=auto+16);x.cmp('eax',0);x.jump('eq','skip');save(x,data,'sequence','eax')


def guard_scope(x,base,data,auto,*,owner_stack=40,owner_register_frame=None,active_only=False,owner_from_slot=False):
    common(x,base,data,auto,active_only=active_only)
    if owner_from_slot:
        x.load('edx','esp',16);x.cmp('edx',3);x.jump('ae','skip');x.ri(0,'edx',122)
    else:x.load('edx','esp',owner_register_frame if owner_register_frame is not None else owner_stack)
    x.cmp('edx',122);x.jump('below','skip');x.cmp('edx',124);x.jump('above','skip')
    save(x,data,'owner','edx');x.rr('89','ecx','edx');x.ri(5,'ecx',122);save(x,data,'slot','ecx')
    x.imul('eax','ecx',0x30);load(x,data,'players','ebx');x.rr('01','eax','ebx')
    x.cmpm('edx','eax',0x1C4);x.jump('ne','skip')
    x.imul('eax','edx',0x110);load(x,data,'manager','edi');x.rr('01','eax','edi');x.ri(0,'eax',0x4B0)
    save(x,data,'owner_record','eax')
    x.cmpm('edx','eax',0x38);x.jump('ne','skip')
    x.mem('f7',0,'eax',0x64);x.dword(7);x.jump('ne','skip')
    x.op(7,0,'eax',0x40);x.jump('ne','skip')
    x.mem('f7',0,'eax',0x68);x.dword(4);x.jump('eq','skip')
    x.imul('eax','edx',0xAC);load(x,data,'ai','esi');x.rr('01','eax','esi')
    x.mem('f7',0,'eax',0x90);x.dword(1);x.jump('eq','skip')
    load(x,data,'slot','ecx');x.imul('eax','ecx',STRIDE);x.ri(0,'eax',data+REGISTRY);save(x,data,'entry','eax')
    load(x,data,'owner','edx');x.imul('edx','edx',0x40);load(x,data,'ai','esi')
    x.rr('01','edx','esi');x.ri(0,'edx',0x4F2E8);save(x,data,'order','edx')


def entry_context(x,data,fail):
    load(x,data,'entry','edx')
    for field,off in [('manager',4),('ai',8),('players',12),('sequence',16),('owner',20)]:
        load(x,data,field,'eax');x.cmpm('eax','edx',off);x.jump('ne',fail)
    load(x,data,'owner_record','eax');x.load('eax','eax',0x44)
    x.cmpm('eax','edx',24);x.jump('ne',fail)


def cancel(x,data,reason):
    load(x,data,'entry','edx');x.set(3,'edx');x.set(reason,'edx',0x30)
    x.emit('64a124000000');x.store('eax','edx',0x38)
    x.set(reason,disp=data+LAST_REASON);inc(x,data,0x3C)


def endings(x,base,data,code,name):
    x.mark('skip');inc(x,data,0x44)
    x.mark('unlock');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d')
    if name=='SECURE_AVAILABILITY':
        x.emit(relative_jump(code+len(x.code),base+0x40FBE6))
    elif name=='SECURE_SUPPORT_THRESHOLD':
        x.emit('3b442418');x.jump('below','threshold_less')
        x.emit(relative_jump(code+len(x.code),base+0x386D1F))
        x.mark('threshold_less');x.emit(relative_jump(code+len(x.code),base+0x386D4E))
    elif name=='MOBILIZE_PICKER':
        x.jump('eq','picker_native_taken')
        x.emit(relative_jump(code+len(x.code),base+0x319809))
        x.mark('picker_native_taken');x.emit(relative_jump(code+len(x.code),base+0x3198FD))
    elif name=='SECURE_SHORTCUT':
        x.emit('83fe01');x.jump('above','shortcut_native_above');x.jump('ne','shortcut_native_zero')
        x.emit(relative_jump(code+len(x.code),base+0x597042))
        x.mark('shortcut_native_above');x.emit(relative_jump(code+len(x.code),base+0x5970A7))
        x.mark('shortcut_native_zero');x.emit(relative_jump(code+len(x.code),base+0x59704F))
    else:
        x.emit(original(base,name));rva=SITES[name][0]+len(original(base,name))
        x.emit(relative_jump(code+len(x.code),base+rva))
    return x.finish()


def _build_previous(base,data,code,auto,recall,name,*,version=LEGACY_VERSION):
    require(name in SITES,'E_GUARD_ORDERS_SITE');x=Asm()
    # At this JMP the native boolean argument is still on the original stack.
    # CALL preserves the native RET 4 cleanup before any PUSHFD/PUSHAD frame.
    if name=='SECURE_AVAILABILITY':x.call(code,base+0x31F00)
    begin(x,data,auto,recall,version=version)
    if name=='SECURE_AVAILABILITY':
        inc(x,data,0x10);common(x,base,data,auto)
        x.load('eax','esp',16);x.ri(4,'eax',0xFF);x.cmp('eax',1);x.jump('ne','unlock')
        x.set(0,'esp',28);inc(x,data,0x14);x.jump('jmp','unlock')
    elif name=='SECURE_SUPPORT_THRESHOLD':
        inc(x,data,0x18);common(x,base,data,auto)
        x.mem('0fb6',R['eax'],'esp',52);x.cmp('eax',1);x.jump('ne','unlock')
        x.load('eax','esp',28);x.cmp('eax',3);x.jump('be','unlock')
        inc(x,data,0x1C);x.set(0,disp=data+12);x.emit('619d3b442418')
        x.emit(relative_jump(code+len(x.code),base+0x386D4E))
    elif name=='MOBILIZE_PICKER':
        inc(x,data,0x20);common(x,base,data,auto)
        x.op(7,1,'esp',4);x.jump('ne','unlock') # saved ESI = command
        x.op(7,0,disp=base+0x6A7734);x.jump('ne','skip')
        x.emit('64a124000000');x.store('eax',disp=data+MENU_TID)
        inc(x,data,0x24);x.set(0,disp=data+12);x.emit('619d')
        x.emit(relative_jump(code+len(x.code),base+0x319895))
    elif name=='SECURE_MANUAL_CANCEL':
        guard_scope(x,base,data,auto)
        x.load('ecx','esp',44);x.sane('ecx','skip');x.op(7,2,'ecx',4);x.jump('ne','unlock')
        load(x,data,'slot','eax');x.cmpm('eax','ecx');x.jump('ne','skip')
        inc(x,data,0x40);load(x,data,'entry','edx');x.op(7,1,'edx');x.jump('ne','unlock')
        entry_context(x,data,'unlock');cancel(x,data,1);x.jump('jmp','unlock')
    elif name=='MOBILIZE_DESTINATION':
        inc(x,data,0x28);guard_scope(x,base,data,auto)
        # A new command supersedes our previous destination, including fallback.
        load(x,data,'entry','edx');x.op(7,1,'edx');x.jump('ne','old_clear')
        cancel(x,data,7);x.mark('old_clear')
        x.load('ecx','esp',44);x.sane('ecx','refuse');save(x,data,'request','ecx')
        x.op(7,1,'esp',48);x.jump('ne','refuse');x.op(7,1,'ecx',4);x.jump('ne','refuse')
        load(x,data,'slot','eax');x.cmpm('eax','ecx');x.jump('ne','refuse')
        x.load('eax','ecx',12);x.cmp('eax',60);x.jump('ae','refuse');save(x,data,'base_id','eax')
        x.imul('edi','eax',0x244);load(x,data,'manager','edx');x.rr('01','edi','edx');x.ri(0,'edi',0xCDB24)
        save(x,data,'base_record','edi')
        x.mem('f7',0,'edi',0x23C);x.dword(1);x.jump('eq','refuse')
        # Native picker locations are waypoints, not necessarily conquerable
        # bases. Their faction is deliberately not an admission/completion gate.
        for off in (0x1C,0x20,0x24):
            x.load('eax','edi',off);x.ri(4,'eax',0x7FFFFFFF);x.cmp('eax',0x49742400);x.jump('above','refuse')
        x.mem('0fb6',R['eax'],'edi',0x2C);x.cmp('eax',128);x.jump('ae','refuse')
        load(x,data,'entry','ebx');x.set(0,'ebx')
        for field,off in [('manager',4),('ai',8),('players',12),('sequence',16),('owner',20),('base_id',28),('order',0x74)]:
            load(x,data,field,'eax');x.store('eax','ebx',off)
        load(x,data,'owner_record','eax');x.load('ecx','eax',0x44);x.store('ecx','ebx',24)
        x.set(0,'ebx',0x20);x.set(1,'ebx',0x24);x.set(0,'ebx',0x30)
        load(x,data,'ai','esi');x.load('eax','esi',0x53E90);x.store('eax','ebx',0x28);x.store('eax','ebx',0x2C)
        load(x,data,'slot','eax');x.store('eax','ebx',0x40)
        for off,val in ((0x44,1),(0x48,250),(0x4C,60),(0x50,24)):x.set(val,'ebx',off)
        load(x,data,'base_record','edi')
        for i in range(4):x.load('eax','edi',0x1C+i*4);x.store('eax','ebx',0x60+i*4)
        x.mem('0fb6',R['eax'],'edi',0x2C);x.store('eax','ebx',0x70)
        x.emit('64a124000000');x.store('eax','ebx',0x34);x.store('eax',disp=data+MENU_TID)
        load(x,data,'owner','eax');x.store('eax',disp=data+LAST_OWNER)
        load(x,data,'base_id','eax');x.store('eax',disp=data+LAST_BASE)
        x.set(1,'ebx');inc(x,data,0x2C);x.set(0,disp=data+LAST_REASON)
        # Exact existing three-argument ABI: native Secure Location constructs
        # the fixed destination; no remote thread, extra CALL or fake owner ID.
        x.set(0,disp=data+12);x.emit('619d');x.emit(relative_jump(code+len(x.code),base+0x50BF80))
        x.mark('refuse');inc(x,data,0x30);x.set(4,disp=data+LAST_REASON);x.jump('jmp','unlock')
    elif name=='NATIVE_GUARD_UPDATE':
        # Site is after the native roster/alive checks, EAX owner, EBX slot,
        # EDI players. It is never driven by the host polling thread.
        guard_scope(x,base,data,auto,owner_register_frame=28,active_only=True)
        load(x,data,'slot','eax');x.cmpm('eax','esp',16);x.jump('ne','skip')
        load(x,data,'players','eax');x.cmpm('eax','esp');x.jump('ne','skip')
        load(x,data,'entry','edx');x.op(7,1,'edx');x.jump('ne','unlock')
        inc(x,data,0x34);entry_context(x,data,'stale')
        x.emit('64a124000000');x.store('eax',disp=data+UPDATE_TID);x.store('eax','edx',0x38)
        load(x,data,'ai','esi');x.load('eax','esi',0x53E90);x.store('eax','edx',0x2C)
        load(x,data,'order','edi');x.op(7,2,'edi',0x30);x.jump('ne','changed')
        load(x,data,'owner','eax');x.cmpm('eax','edi',0x10);x.jump('ne','changed')
        x.load('eax','edx',28);x.cmp('eax',60);x.jump('ae','stale')
        x.mem('0fb6',R['ecx'],'edi',0x29);x.rr('39','eax','ecx');x.jump('ne','changed')
        for i in range(3):x.load('eax','edx',0x60+i*4);x.cmpm('eax','edi',i*4);x.jump('ne','changed')
        x.load('eax','edx',28);x.imul('edi','eax',0x244);load(x,data,'manager','esi')
        x.rr('01','edi','esi');x.ri(0,'edi',0xCDB24)
        x.mem('f7',0,'edi',0x23C);x.dword(1);x.jump('eq','stale')
        for i in range(3):x.load('eax','edx',0x60+i*4);x.cmpm('eax','edi',0x1C+i*4);x.jump('ne','stale')
        # Reach the waypoint, regardless of whether anything can be captured.
        # Save all FP state before the distance calculation or native helper.
        x.set(0x1F80,disp=data+0x7C)
        x.emit('89e581ec3002000083e4f089e60fae06dbe3fc');x.mem('0fae',2,disp=data+0x7C)
        load(x,data,'owner','eax');x.imul('edi','eax',0xAC);load(x,data,'ai','ecx');x.rr('01','edi','ecx')
        load(x,data,'entry','edx')
        x.mem('f30f10',0,'edi');x.mem('f30f5c',0,'edx',0x60);x.emit('f30f59c0')
        x.mem('f30f10',1,'edi',8);x.mem('f30f5c',1,'edx',0x68);x.emit('f30f59c9f30f58c1')
        x.set(struct.unpack('<I',struct.pack('<f',ARRIVAL_RADIUS**2))[0],disp=data+0x68)
        x.mem('0f2e',0,disp=data+0x68);x.jump('parity','fp_restore');x.jump('above','fp_restore')
        # Build ordinary Mobilize once on this native thread. The nested entry
        # sees BUSY=1 and replays its original six-byte prologue.
        x.set(2,'edx');x.set(6,'edx',0x30);x.set(6,disp=data+LAST_REASON);inc(x,data,0x48)
        load(x,data,'entry','eax');x.ri(0,'eax',0x40);x.emit('6a0150')
        load(x,data,'owner','eax');x.emit('50');load(x,data,'ai','ecx');x.ri(0,'ecx',0x4D068)
        x.call(code,base+0x5364A0)
        inc(x,data,0x38)
        x.mark('fp_restore');x.emit('0fae0e89ec');x.jump('jmp','unlock')
        x.mark('stale');cancel(x,data,3);x.jump('jmp','unlock')
        x.mark('changed');cancel(x,data,2);x.jump('jmp','unlock')
    return endings(x,base,data,code,name)


def fp_enter(x,data):
    x.set(0x1F80,disp=data+0x7C)
    x.emit('89e581ec3002000083e4f089e60fae06dbe3fc');x.mem('0fae',2,disp=data+0x7C)


def fp_leave(x):x.emit('0fae0e89ec')


def observation(x,data):
    """Record exact native fields before deciding whether an order changed."""
    load(x,data,'slot','eax');x.imul('ebx','eax',DIAGNOSTIC_STRIDE);x.ri(0,'ebx',data+DIAGNOSTICS)
    load(x,data,'order','edi')
    for source,target in ((0x30,0),(0x10,4),(0x18,12),(0,16),(4,20),(8,24)):
        x.load('eax','edi',source);x.store('eax','ebx',target)
    x.mem('0fb6',R['eax'],'edi',0x29);x.store('eax','ebx',8)
    load(x,data,'slot','eax');x.imul('ecx','eax',0x30);load(x,data,'players','edi');x.rr('01','ecx','edi')
    x.load('eax','ecx',0x1E0);x.store('eax','ebx',28)
    load(x,data,'slot','eax');x.imul('ecx','eax',12);x.rr('01','ecx','edi')
    x.load('eax','ecx',0x254);x.store('eax','ebx',32)
    load(x,data,'ai','eax');x.load('eax','eax',0x53E90);x.store('eax','ebx',40)
    load(x,data,'sequence','eax');x.store('eax','ebx',44)
    x.set(1,'ebx',36)


def _build_v2(base,data,code,auto,recall,name,*,legacy=False,version=2):
    if legacy:return _build_previous(base,data,code,auto,recall,name)
    if name in ('SECURE_AVAILABILITY','SECURE_SUPPORT_THRESHOLD','MOBILIZE_PICKER','SECURE_MANUAL_CANCEL'):
        return _build_previous(base,data,code,auto,recall,name,version=version)
    require(name in SITES,'E_GUARD_ORDERS_SITE');x=Asm();begin(x,data,auto,recall,version=version)
    if name=='SECURE_MENU_DISPLAY':
        common(x,base,data,auto)
        x.set(99999,'esp',28);inc(x,data,EXTRA_COUNTERS['secure_menu_dashes'])
        x.jump('jmp','unlock')
    elif name=='SECURE_SHORTCUT':
        # This site is reached only after the native per-guard key test.
        x.op(7,2,'esp',4);x.jump('ne','unlock')
        guard_scope(x,base,data,auto,owner_from_slot=True,active_only=True)
        load(x,data,'players','eax');x.cmpm('eax','esp');x.jump('ne','skip')
        load(x,data,'entry','edx');x.op(7,1,'edx');x.jump('ne','shortcut_clear')
        cancel(x,data,15);x.mark('shortcut_clear')
        x.emit('64a124000000');x.store('eax',disp=data+SHORTCUT_TID)
        inc(x,data,EXTRA_COUNTERS['secure_shortcut_transitions'])
        # Continue at the existing setter, ESI=1. Its timer and dispatcher remain native.
        x.set(1,'esp',4);x.set(0,disp=data+12);x.emit('619d')
        x.emit(relative_jump(code+len(x.code),base+0x597050))
    elif name=='MOBILIZE_DESTINATION':
        inc(x,data,0x28);guard_scope(x,base,data,auto)
        load(x,data,'ai','eax');x.ri(0,'eax',0x4D068);x.cmpm('eax','esp',24);x.jump('ne','skip')
        load(x,data,'entry','edx');x.op(7,1,'edx');x.jump('ne','old_clear')
        cancel(x,data,7);x.mark('old_clear')
        x.load('ecx','esp',44);x.sane('ecx','refuse');save(x,data,'request','ecx')
        x.op(7,1,'esp',48);x.jump('ne','refuse');x.op(7,1,'ecx',4);x.jump('ne','refuse')
        load(x,data,'slot','eax');x.cmpm('eax','ecx');x.jump('ne','refuse')
        x.load('eax','ecx',12);x.cmp('eax',60);x.jump('eq','ordinary');x.jump('above','refuse')
        save(x,data,'base_id','eax');x.imul('edi','eax',0x244)
        load(x,data,'manager','edx');x.rr('01','edi','edx');x.ri(0,'edi',0xCDB24);save(x,data,'base_record','edi')
        x.mem('f7',0,'edi',0x23C);x.dword(1);x.jump('eq','refuse')
        for off in (0x1C,0x20,0x24):
            x.load('eax','edi',off);x.ri(4,'eax',0x7FFFFFFF);x.cmp('eax',0x49742400);x.jump('above','refuse')
        x.mem('0fb6',R['eax'],'edi',0x2C);x.cmp('eax',128);x.jump('ae','refuse')
        load(x,data,'entry','ebx');x.set(4,'ebx') # BUILDING; never eligible for continuation
        load(x,data,'slot','eax');x.imul('edi','eax',DIAGNOSTIC_STRIDE)
        x.ri(0,'edi',data+DIAGNOSTICS);x.set(0,'edi',36)
        if version>=3:x.set(0,'edi',76)
        for field,off in [('manager',4),('ai',8),('players',12),('sequence',16),('owner',20),('base_id',28),('order',0x74)]:
            load(x,data,field,'eax');x.store('eax','ebx',off)
        load(x,data,'owner_record','eax');x.load('ecx','eax',0x44);x.store('ecx','ebx',24)
        x.set(0,'ebx',0x20);x.set(1,'ebx',0x24);x.set(0,'ebx',0x30)
        load(x,data,'ai','esi');x.load('eax','esi',0x53E90);x.store('eax','ebx',0x28);x.store('eax','ebx',0x2C)
        load(x,data,'slot','eax');x.store('eax','ebx',0x40)
        for off,val in ((0x44,1),(0x48,250),(0x4C,60),(0x50,24)):x.set(val,'ebx',off)
        load(x,data,'base_record','edi')
        for i in range(4):x.load('eax','edi',0x1C+i*4);x.store('eax','ebx',0x60+i*4)
        x.mem('0fb6',R['eax'],'edi',0x2C);x.store('eax','ebx',0x70)
        x.emit('64a124000000');x.store('eax','ebx',0x34);x.store('eax',disp=data+MENU_TID)
        load(x,data,'owner','eax');x.store('eax',disp=data+LAST_OWNER)
        load(x,data,'base_id','eax');x.store('eax',disp=data+LAST_BASE)
        # The constructor already runs on this native caller in ordinary Secure Base.
        # Keep BUSY and BUILDING until it returns; never publish a half-built continuation.
        fp_enter(x,data)
        for off in (48,44,40):x.load('eax','ebp',off);x.emit('50')
        x.load('ecx','ebp',24);x.call(code,base+0x50BF80)
        for reg,off in (('eax',28),('ecx',24),('edx',20)):x.store(reg,'ebp',off)
        load(x,data,'order','edi');x.rr('39','eax','edi');x.jump('ne','constructor_bad')
        # Movement state 23 is distinct from logical command 1 (Mobilize).
        x.set(1,'edi',0x30)
        load(x,data,'entry','edx');x.set(1,'edx');inc(x,data,0x2C);x.set(0,disp=data+LAST_REASON)
        fp_leave(x);x.set(0,disp=data+12);x.emit('619dc20c00')
        x.mark('constructor_bad');inc(x,data,EXTRA_COUNTERS['constructor_result_mismatches']);cancel(x,data,13)
        fp_leave(x);x.set(0,disp=data+12);x.emit('619dc20c00')
        x.mark('ordinary');inc(x,data,EXTRA_COUNTERS['ordinary_mobilize_requests']);x.jump('jmp','unlock')
        x.mark('refuse');inc(x,data,0x30);x.set(4,disp=data+LAST_REASON);x.jump('jmp','unlock')
    elif name=='NATIVE_GUARD_UPDATE':
        guard_scope(x,base,data,auto,owner_register_frame=28,active_only=True)
        load(x,data,'slot','eax');x.cmpm('eax','esp',16);x.jump('ne','skip')
        load(x,data,'players','eax');x.cmpm('eax','esp');x.jump('ne','skip')
        load(x,data,'entry','edx');x.op(7,1,'edx');x.jump('ne','unlock')
        inc(x,data,0x34);entry_context(x,data,'stale');observation(x,data)
        load(x,data,'entry','edx');x.emit('64a124000000');x.store('eax',disp=data+UPDATE_TID);x.store('eax','edx',0x38)
        load(x,data,'ai','esi');x.load('eax','esi',0x53E90);x.store('eax','edx',0x2C)
        load(x,data,'order','edi');x.op(7,1,'edi',0x30);x.jump('ne','changed_id')
        load(x,data,'owner','eax');x.cmpm('eax','edi',0x10);x.jump('ne','changed_owner')
        x.op(7,22,'edi',0x18);x.jump('eq','native_advance')
        x.op(7,23,'edi',0x18);x.jump('ne','changed_state')
        x.load('eax','edx',28);x.cmp('eax',60);x.jump('ae','stale')
        x.mem('0fb6',R['ecx'],'edi',0x29);x.rr('39','eax','ecx');x.jump('ne','changed_point')
        for i in range(3):x.load('eax','edx',0x60+i*4);x.cmpm('eax','edi',i*4);x.jump('ne','changed_coords')
        x.load('eax','edx',28);x.imul('edi','eax',0x244);load(x,data,'manager','esi')
        x.rr('01','edi','esi');x.ri(0,'edi',0xCDB24)
        x.mem('f7',0,'edi',0x23C);x.dword(1);x.jump('eq','stale')
        for i in range(3):x.load('eax','edx',0x60+i*4);x.cmpm('eax','edi',0x1C+i*4);x.jump('ne','stale')
        fp_enter(x,data)
        load(x,data,'owner','eax');x.imul('edi','eax',0xAC);load(x,data,'ai','ecx');x.rr('01','edi','ecx')
        load(x,data,'entry','edx')
        x.mem('f30f10',0,'edi');x.mem('f30f5c',0,'edx',0x60);x.emit('f30f59c0')
        x.mem('f30f10',1,'edi',8);x.mem('f30f5c',1,'edx',0x68);x.emit('f30f59c9f30f58c1')
        x.set(struct.unpack('<I',struct.pack('<f',ARRIVAL_RADIUS**2))[0],disp=data+0x68)
        x.mem('0f2e',0,disp=data+0x68);x.jump('parity','fp_restore');x.jump('above','fp_restore')
        x.set(2,'edx');x.set(6,'edx',0x30);x.set(6,disp=data+LAST_REASON);inc(x,data,0x48)
        load(x,data,'entry','eax');x.ri(0,'eax',0x40);x.emit('6a0150')
        load(x,data,'owner','eax');x.emit('50');load(x,data,'ai','ecx');x.ri(0,'ecx',0x4D068)
        x.call(code,base+0x5364A0);inc(x,data,0x38)
        x.mark('fp_restore');fp_leave(x);x.jump('jmp','unlock')
        x.mark('native_advance');load(x,data,'entry','edx');x.set(2,'edx');x.set(12,'edx',0x30)
        x.set(12,disp=data+LAST_REASON);inc(x,data,EXTRA_COUNTERS['native_advances_observed']);x.jump('jmp','unlock')
        for label,reason in [('stale',3),('changed_id',8),('changed_owner',9),('changed_state',14),('changed_point',10),('changed_coords',11)]:
            x.mark(label);cancel(x,data,reason);x.jump('jmp','unlock')
    return endings(x,base,data,code,name)


def build_bridge(base,data,code,auto,recall,name,*,legacy=False,legacy_version=None):
    if legacy:
        version=LEGACY_VERSION if legacy_version is None else legacy_version
        require(version in LEGACY_VERSIONS,'E_GUARD_ORDERS_LEGACY_VERSION')
        return (_build_previous(base,data,code,auto,recall,name) if version==1 else
                _build_v2(base,data,code,auto,recall,name,version=2))
    if name!='NATIVE_GUARD_UPDATE':
        return _build_v2(base,data,code,auto,recall,name,version=VERSION)
    x=Asm();begin(x,data,auto,recall)
    guard_scope(x,base,data,auto,owner_register_frame=28,active_only=True)
    load(x,data,'slot','eax');x.cmpm('eax','esp',16);x.jump('ne','skip')
    load(x,data,'players','eax');x.cmpm('eax','esp');x.jump('ne','skip')
    load(x,data,'entry','edx');x.op(7,1,'edx');x.jump('ne','unlock')
    inc(x,data,0x34);entry_context(x,data,'stale');observation(x,data)
    load(x,data,'entry','edx');x.emit('64a124000000')
    x.store('eax',disp=data+UPDATE_TID);x.store('eax','edx',0x38)
    load(x,data,'ai','esi');x.load('eax','esi',0x53E90);x.store('eax','edx',0x2C)
    # Save active AI separately from the transient command descriptor.
    load(x,data,'owner','eax');x.imul('ecx','eax',0xAC);x.rr('01','ecx','esi')
    for source,target in ((0x84,48),(0x70,56),(0,60),(4,64),(8,68)):
        x.load('eax','ecx',source);x.store('eax','ebx',target)
    x.mem('0fb6',R['eax'],'ecx',0x9C);x.store('eax','ebx',52);x.set(1,'ebx',76)
    load(x,data,'order','edi')
    # Saved live captures show an idle descriptor after native consumption:
    # command=0, owner=250, state=34, no point=60. This is not a new Guard order.
    # Adopt it only while the roster's current AND pending commands still say
    # Mobilize and the active AI still owns this exact waypoint.
    x.op(7,0,'edi',0x30);x.jump('ne','pending_descriptor')
    for off,value in ((0x10,250),(0x18,34),(0x1C,250)):
        x.op(7,value,'edi',off);x.jump('ne','changed_id')
    x.mem('0fb6',R['eax'],'edi',0x29);x.cmp('eax',60);x.jump('ne','changed_id')
    for off in (0,4,8):x.op(7,0,'edi',off);x.jump('ne','changed_coords')
    inc(x,data,CONTINUATION_COUNTERS['consumed_descriptor_updates'])
    x.op(7,1,'ebx',28);x.jump('ne','changed_id')
    x.op(7,1,'ebx',32);x.jump('ne','changed_pending')
    load(x,data,'owner','eax');x.cmpm('eax','ecx',0x70);x.jump('ne','changed_active_owner')
    x.op(7,22,'ecx',0x84);x.jump('eq','native_advance')
    x.op(7,23,'ecx',0x84);x.jump('ne','active_wait')
    load(x,data,'entry','edx');x.load('eax','edx',28)
    x.mem('0fb6',R['edi'],'ecx',0x9C);x.rr('39','eax','edi');x.jump('ne','changed_active_point')
    inc(x,data,CONTINUATION_COUNTERS['active_waypoint_updates'])
    x.jump('jmp','waypoint_context')
    x.mark('pending_descriptor')
    x.op(7,1,'edi',0x30);x.jump('ne','changed_id')
    load(x,data,'owner','eax');x.cmpm('eax','edi',0x10);x.jump('ne','changed_owner')
    x.op(7,22,'edi',0x18);x.jump('eq','native_advance')
    x.op(7,23,'edi',0x18);x.jump('ne','changed_state')
    x.load('eax','edx',28);x.cmp('eax',60);x.jump('ae','stale')
    x.mem('0fb6',R['ecx'],'edi',0x29);x.rr('39','eax','ecx');x.jump('ne','changed_point')
    for i in range(3):x.load('eax','edx',0x60+i*4);x.cmpm('eax','edi',i*4);x.jump('ne','changed_coords')
    x.mark('waypoint_context')
    load(x,data,'entry','edx');x.load('eax','edx',28);x.cmp('eax',60);x.jump('ae','stale')
    x.imul('edi','eax',0x244);load(x,data,'manager','esi')
    x.rr('01','edi','esi');x.ri(0,'edi',0xCDB24)
    x.mem('f7',0,'edi',0x23C);x.dword(1);x.jump('eq','stale')
    for i in range(3):x.load('eax','edx',0x60+i*4);x.cmpm('eax','edi',0x1C+i*4);x.jump('ne','stale')
    fp_enter(x,data)
    load(x,data,'owner','eax');x.imul('edi','eax',0xAC);load(x,data,'ai','ecx');x.rr('01','edi','ecx')
    load(x,data,'entry','edx')
    x.mem('f30f10',0,'edi');x.mem('f30f5c',0,'edx',0x60);x.emit('f30f59c0')
    x.mem('f30f10',1,'edi',8);x.mem('f30f5c',1,'edx',0x68);x.emit('f30f59c9f30f58c1')
    x.set(struct.unpack('<I',struct.pack('<f',ARRIVAL_RADIUS**2))[0],disp=data+0x68)
    x.mem('0f2e',0,disp=data+0x68);x.jump('parity','fp_restore');x.jump('above','fp_restore')
    # One native constructor call from the existing native guard update.
    # No base ownership/capture prerequisite, host AI calls or remote threads.
    x.set(2,'edx');x.set(6,'edx',0x30);x.set(6,disp=data+LAST_REASON);inc(x,data,0x48)
    load(x,data,'entry','eax');x.ri(0,'eax',0x40);x.emit('6a0150')
    load(x,data,'owner','eax');x.emit('50');load(x,data,'ai','ecx');x.ri(0,'ecx',0x4D068)
    x.call(code,base+0x5364A0);inc(x,data,0x38)
    x.mark('fp_restore');fp_leave(x);x.jump('jmp','unlock')
    x.mark('active_wait');inc(x,data,CONTINUATION_COUNTERS['active_state_waits']);x.jump('jmp','unlock')
    x.mark('native_advance');load(x,data,'entry','edx');x.set(2,'edx');x.set(12,'edx',0x30)
    x.set(12,disp=data+LAST_REASON);inc(x,data,EXTRA_COUNTERS['native_advances_observed']);x.jump('jmp','unlock')
    for label,reason in [('stale',3),('changed_id',8),('changed_owner',9),('changed_state',14),
                         ('changed_point',10),('changed_coords',11),('changed_pending',16),
                         ('changed_active_point',17),('changed_active_owner',18)]:
        x.mark(label);cancel(x,data,reason);x.jump('jmp','unlock')
    return endings(x,base,data,code,name)


def check_code(memory):
    checks={0x31F00:'807c240400740f',0x386CBD:'83f8020f94442410',
            0x386D06:'e835981500',0x386D6B:'e8a0711900',
            0x319895:'e86660f4ff',0x5221C9:'8b51046a0151',
            0x5364F6:'c7461816000000',0x50C005:'c7401817000000',
            0x50C049:'c7403002000000',0x50C054:'c20c00',0x4E0490:'83f803734a',
            0x56F898:'898784000000',0x56F8AE:'889f9c000000'}
    for rva,sig in checks.items():
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),'E_GUARD_ORDERS_NATIVE_CODE_'+hex(rva))
    require(memory.read(memory.base+0x65A5B0,12)==struct.pack('<3I',*(memory.base+r for r in (0x50C060,0x5364A0,0x50BF80))),
            'E_GUARD_ORDERS_DISPATCH_TABLE')


def changes_for_enabled(memory,record,enabled):
    if enabled:return []
    changes=[]
    for slot in range(3):
        address=record['data_address']+REGISTRY+slot*STRIDE;raw=memory.read(address,0x34)
        if word(raw)==1:
            new=bytearray(raw);struct.pack_into('<I',new,0,3);struct.pack_into('<I',new,0x30,5)
            changes.append((address,raw,bytes(new)))
    return changes


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(secure_location_unlimited=True,mobilize_select_base=True,
                  completion_condition='WAYPOINT_REACHED',arrival_radius=ARRIVAL_RADIUS,
                  location_must_be_conquerable=False,guard_order_changed=False,
                  other_skill_limits_changed=False,remote_threads_created=False,
                  periodic_thread_suspension=False,native_thread_ids_observed=False,
                  fallback_on_invalid_destination='ORDINARY_MOBILIZE',live_test_pending=True)
    if not record:return result
    raw=memory.read(record['data_address'],REGISTRY+3*STRIDE)
    result['thread_observation']={'menu_tid':word(raw,MENU_TID) or None,
                                  'native_update_tid':word(raw,UPDATE_TID) or None,
                                  'source':'X86_TEB_CLIENT_ID', 'thread_identity_forced':False}
    result['native_thread_ids_observed']=bool(word(raw,MENU_TID) or word(raw,UPDATE_TID))
    result['last_owner']=word(raw,LAST_OWNER);result['last_base']=word(raw,LAST_BASE)
    result['last_reason']=REASONS.get(word(raw,LAST_REASON),'UNKNOWN')
    result['orders']=[{'slot':slot,'status':{0:'NONE',1:'PENDING_BASE',2:'ADVANCE_RESUMED',3:'CANCELLED',4:'BUILDING'}.get(word(raw,REGISTRY+slot*STRIDE),'UNKNOWN'),
                       'owner':word(raw,REGISTRY+slot*STRIDE+20),
                       'character':word(raw,REGISTRY+slot*STRIDE+24),
                       'base_id':word(raw,REGISTRY+slot*STRIDE+28),
                       'sequence':word(raw,REGISTRY+slot*STRIDE+16),
                       'reason':REASONS.get(word(raw,REGISTRY+slot*STRIDE+0x30),'UNKNOWN'),
                       'started_tick':word(raw,REGISTRY+slot*STRIDE+0x28),
                       'last_native_tick':word(raw,REGISTRY+slot*STRIDE+0x2C)} for slot in range(3)]
    if record['version']>=2:
        extra=memory.read(record['data_address']+0x80,0x18)
        result.update({key:word(extra,offset-0x80) for key,offset in EXTRA_COUNTERS.items()})
        result.update(secure_location_display='--',mobilize_logical_order=1,
                      continuation_published_after_constructor=True,
                      quick_order_sequence=['SECURE_BASE','MOBILIZE','GUARD'],
                      standard_guard_mobilize_shortcuts_preserved=True)
        result['thread_observation']['shortcut_tid']=word(extra,SHORTCUT_TID-0x80) or None
        result['native_thread_ids_observed']=result['native_thread_ids_observed'] or bool(word(extra,SHORTCUT_TID-0x80))
        diag=memory.read(record['data_address']+DIAGNOSTICS,3*DIAGNOSTIC_STRIDE)
        for slot,item in enumerate(result['orders']):
            d=diag[slot*DIAGNOSTIC_STRIDE:(slot+1)*DIAGNOSTIC_STRIDE]
            item['native_observation']={key:word(d,off) for key,off in
                (('order_id',0),('owner',4),('point_id',8),('state',12),('current_order',28),('pending_order',32))}
            item['native_observation'].update(available=bool(word(d,36)),tick=word(d,40),sequence=word(d,44),
                position=[v if math.isfinite(v) else None for v in struct.unpack_from('<3f',d,16)],
                position_bits=list(struct.unpack_from('<3I',d,16)))
            item['expected']={'order_id':1,'owner':item['owner'],'point_id':item['base_id'],'movement_state':23}
            item['expected']['position']=list(struct.unpack_from('<3f',raw,REGISTRY+slot*STRIDE+0x60))
    if record['version']==VERSION:
        extra=memory.read(record['data_address']+0x98,12)
        result.update({key:word(extra,offset-0x98) for key,offset in CONTINUATION_COUNTERS.items()})
        result.update(continuation_source='TRANSIENT_REQUEST_OR_BOUND_ACTIVE_GUARD_AI',
                      native_descriptor_consumption_supported=True,
                      native_request_return_is_not_proof_of_live_movement=True)
        for slot,item in enumerate(result['orders']):
            d=diag[slot*DIAGNOSTIC_STRIDE:(slot+1)*DIAGNOSTIC_STRIDE]
            item['active_ai']={'available':bool(word(d,76) and word(d,36) and word(d,44)==item['sequence']),
                               'movement_state':word(d,48),
                               'point_id':word(d,52),'owner':word(d,56),
                               'position':[v if math.isfinite(v) else None for v in struct.unpack_from('<3f',d,60)]}
    return result
