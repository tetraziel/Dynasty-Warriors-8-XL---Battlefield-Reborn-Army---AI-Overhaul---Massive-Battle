"""Read the native 60-record reinforcement selector pool, not screen icons."""
import math
import struct
from core import require,player_snapshot

POOL_OFFSET,STRIDE,COUNT=0xCDB24,0x244,60
ROUTES_OFFSET,ROUTES_COUNT=0xCDAC4,24


def decode_pool(raw,routes,side,manager,*,fallback_route=None):
    require(len(raw)==STRIDE*COUNT and len(routes)==ROUTES_COUNT*4,'E_GATE_SCAN_SIZE')
    require(side in (0,1),'E_GATE_SCAN_SIDE')
    result=[]
    for i in range(COUNT):
        record=raw[i*STRIDE:(i+1)*STRIDE]
        u=lambda p:struct.unpack_from('<I',record,p)[0]
        position=list(struct.unpack_from('<3f',record,0x1C))
        coordinates_valid=(all(math.isfinite(v) for v in position) and
            0<=position[0]<128000 and 0<=position[2]<128000 and position[1]>=0)
        kind,zone,owner=u(0x30),u(0x2C),u(0x1FC)
        initialized=any(record) and coordinates_valid and kind<24 and zone<128 and owner in (0,1,2)
        route=routes[kind*4:kind*4+4] if kind<24 else None
        effective_zone=route[0] if route else zone
        reasons=[]
        if not initialized:reasons.append('UNINITIALIZED_OR_UNSUPPORTED')
        if owner!=side:reasons.append('OTHER_SIDE')
        if record[0x23C]&2:reasons.append('NATIVE_FLAG_23C_2')
        if record[0x208]:reasons.append('NATIVE_STATE_208')
        if route is None or route[2+side] not in (0,1):reasons.append('ROUTE_POLICY')
        if effective_zone>=128:reasons.append('ZONE_UNAVAILABLE')
        result.append({'slot':i,'address':hex(manager+POOL_OFFSET+i*STRIDE),
            'initialized_candidate':initialized,'position':position if all(math.isfinite(v) for v in position) else None,
            'side':owner,'route_index':kind,'stored_zone':zone,'effective_zone':effective_zone,
            'flags_23c':hex(u(0x23C)),'state_208':record[0x208],
            'eligible_by_selector_fields':not reasons,'exclusions':reasons})
    fallback_zone=(routes[fallback_route*4] if type(fallback_route) is int and
                   0<=fallback_route<24 else None)
    return {'available':True,'read_only':True,'source':'NATIVE_REINFORCEMENT_SELECTOR_513F00',
        'pool_capacity':COUNT,'initialized_candidates':sum(r['initialized_candidate'] for r in result),
        'allied_candidates':sum(r['initialized_candidate'] and r['side']==side for r in result),
        'enemy_candidates':sum(r['initialized_candidate'] and r['side']==1-side for r in result),
        'eligible_allied_candidates':sum(r['eligible_by_selector_fields'] for r in result),
        'unused_or_unsupported_slots':sum(not r['initialized_candidate'] for r in result),
        'native_fallback_zone':fallback_zone if fallback_zone is not None and fallback_zone<128 else None,
        'physical_gate_count_verified':False,'navigation_and_scenario_eligibility_verified':False,
        'personal_gate':{'created':False,'available':False,
            'reason':'UNUSED_SLOT_IS_NOT_A_VALIDATED_GATE_CONSTRUCTOR'},'records':result}


def read_gates(memory,state):
    manager=state['manager'];owner=manager+0x4B0+state['owner']*0x110
    side=struct.unpack('<I',memory.read(owner+0x40,4))[0]
    require(side in (0,1),'E_GATE_SCAN_SIDE')
    raw=memory.read(manager+POOL_OFFSET,STRIDE*COUNT)
    routes=memory.read(manager+ROUTES_OFFSET,ROUTES_COUNT*4)
    fallback=struct.unpack('<I',memory.read(manager+0x58+side*0x22C+0x30,4))[0]
    result=decode_pool(raw,routes,side,manager,fallback_route=fallback)
    require(player_snapshot(memory)==state,'E_GATE_SCAN_CONTEXT_CHANGED')
    return result
