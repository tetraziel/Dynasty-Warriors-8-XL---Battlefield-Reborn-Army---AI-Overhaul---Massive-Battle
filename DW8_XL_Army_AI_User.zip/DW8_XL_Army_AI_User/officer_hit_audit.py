"""Diagnostic before/after pairs for direct enemy-officer hits on allied infantry.

The two hooks bracket the native virtual damage call. No HP/flags are changed.
This complements the raw HP audit without altering its installed v1 payload.
"""
import datetime
import json
import math
import struct
from core import require,word
from recall_bridge import Asm,R
from bridge import relative_jump
import combat_scope as scope
import bundle_support as bundle

FEATURE='ENEMY_OFFICER_HIT_RESULTS_AUDIT'
MAGIC=0x3141484F;VERSION=2;LEGACY_VERSION=1;SIZE=0xD000;CODE_SIZE=0x8000
SITES={'HIT_BEGIN':(0x4DD6E2,'8b4c24148b10'),
       'HIT_END':(0x4DD6F7,'84c0747f8b4d60')}
COUNTERS={'began_pairs':0x10,'completed_pairs':0x14,'scope_skips':0x18,
          'busy_skips':0x1C,'unmatched_ends':0x20,'native_lethal_results':0x24}
ATTACK=0x140;VICTIM=0x180;TEMP=0x200
RING=0x1000;CAPACITY=512;STRIDE=0x60;SEQUENCE=0x30


def build_bridge(base,data,code,auto,recall,name,*,legacy=False):
    require(name in SITES,'E_OFFICER_HIT_SITE')
    version=LEGACY_VERSION if legacy else VERSION
    x=Asm();x.emit('9c60');inc=lambda off:x.mem('ff',0,disp=data+off)
    for off,value in ((0,MAGIC),(4,version),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    if name=='HIT_BEGIN':
        x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','busy')
        # A nested/unrelated end may not consume another thread's pair.
        x.set(0,disp=data+TEMP+4)
        x.load('eax','esp',8);x.sane('eax','skip');x.store('eax',disp=data+TEMP)
        scope.roots(x,base,data,auto,'skip')
        for off,dest in ((0x60,ATTACK),(0x54,VICTIM)):
            x.load('eax',disp=data+TEMP);x.load('ecx','eax',off);x.sane('ecx','skip')
            x.store('ecx',disp=data+TEMP+off)
            x.load('eax','ecx',0x18)
            scope.physical(x,data,dest,'skip',prefix=str(off))
            x.load('eax',disp=data+dest);x.imul('eax','eax',4)
            x.load('edx',disp=data+scope.ROOT+12);x.rr('01','eax','edx')
            x.load('eax','eax',0xC8);x.cmpm('eax',disp=data+TEMP+off);x.jump('ne','skip')
        scope.officer(x,data,ATTACK,'skip',allow_group_members=not legacy)
        x.op(7,1,disp=data+ATTACK+0x20);x.jump('ne','skip')
        scope.infantry(x,data,VICTIM,'skip')
        x.op(7,0,disp=data+VICTIM+0x20);x.jump('ne','skip')
        x.load('ecx',disp=data+VICTIM+4)
        for source,target in ((0x14,8),(0x1C,12),(0x2C,20)):
            x.load('eax','ecx',source);x.store('eax',disp=data+TEMP+target)
        x.load('ecx',disp=data+TEMP);x.load('eax','ecx',0x44);x.store('eax',disp=data+TEMP+16)
        x.load('eax',disp=data+scope.ROOT+4);x.load('eax','eax',0x53E90)
        x.store('eax',disp=data+TEMP+24)
        x.emit('64a124000000');x.store('eax',disp=data+TEMP+28) # TEB.ClientId.UniqueThread
        x.set(1,disp=data+TEMP+4);inc(0x10);x.jump('jmp','native')
        x.mark('skip');inc(0x18);x.set(0,disp=data+12);x.jump('jmp','native')
        x.mark('busy');inc(0x1C)
    else:
        x.op(7,1,disp=data+12);x.jump('ne','unmatched')
        x.op(7,1,disp=data+TEMP+4);x.jump('ne','unmatched')
        x.load('eax','esp',8);x.cmpm('eax',disp=data+TEMP);x.jump('ne','unmatched')
        x.emit('64a124000000');x.cmpm('eax',disp=data+TEMP+28);x.jump('ne','unmatched')
        # Match identities after the native call, even when its HP is now zero.
        for ro,rva in ((0,0x6A91E8),(4,0x6A91D8),(8,0x6A91EC)):
            x.load('eax',disp=base+rva);x.cmpm('eax',disp=data+scope.ROOT+ro);x.jump('ne','release')
        x.load('eax',disp=auto+16);x.cmpm('eax',disp=data+scope.ROOT+0x10);x.jump('ne','release')
        x.load('ecx',disp=data+VICTIM+4)
        for co,vo in ((0,0),(8,0x14),(12,0x18)):
            x.load('eax','ecx',co);x.cmpm('eax',disp=data+VICTIM+vo);x.jump('ne','release')
        x.load('eax',disp=data+SEQUENCE);x.cmp('eax',0xFFFFFFFE);x.jump('ae','release')
        x.rr('89','edi','eax');x.ri(4,'edi',CAPACITY-1)
        x.imul('edi','edi',STRIDE);x.ri(0,'edi',data+RING)
        x.set(0,'edi');x.ri(0,'eax',1);x.store('eax','edi',STRIDE-4)
        for source,target in ((TEMP+24,4),(ATTACK,8),(ATTACK+0x1C,12),(VICTIM,16),
            (VICTIM+0x1C,20),(VICTIM+0x14,24),(VICTIM+0x18,28),
            (TEMP+8,32),(TEMP+12,36),(TEMP+16,40),(TEMP+20,52)):
            x.load('eax',disp=data+source);x.store('eax','edi',target)
        x.load('eax','ecx',0x14);x.store('eax','edi',44)
        x.load('eax','esp',28);x.ri(4,'eax',255);x.store('eax','edi',48)
        x.cmp('eax',0);x.jump('eq','commit');inc(0x24)
        x.mark('commit');x.load('eax','edi',STRIDE-4);x.store('eax','edi')
        x.store('eax',disp=data+SEQUENCE);inc(0x14)
        x.mark('release');x.set(0,disp=data+TEMP+4);x.set(0,disp=data+12)
        x.jump('jmp','native')
        x.mark('unmatched');inc(0x20)
    x.mark('native');x.emit('619d')
    if name=='HIT_END':
        # Relocate both native continuations; never replay the old short JE
        # relative to our allocation.
        x.emit('84c0');x.jump('eq','survived')
        x.emit('8b4d60');x.emit(relative_jump(code+len(x.code),base+0x4DD6FE))
        x.mark('survived');x.emit(relative_jump(code+len(x.code),base+0x4DD77A))
    else:
        x.emit(bytes.fromhex(SITES[name][1]))
        x.emit(relative_jump(code+len(x.code),base+0x4DD6E8))
    return x.finish()


def check_code(memory):
    for rva,sig in ((0x21430,'8d4108c3'),(0x4DD6F5,'ffd2'),(0x4DD77A,'8b4d548b11')):
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),
                'E_OFFICER_HIT_NATIVE_'+hex(rva))


def decode(raw,sequence):
    if len(raw)!=STRIDE or word(raw)!=sequence or word(raw,STRIDE-4)!=sequence:return None
    floats=struct.unpack_from('<4f',raw,32)
    before,maximum,damage,after=floats
    if not all(math.isfinite(v) for v in floats) or maximum<=0:return None
    owner=word(raw,20)
    relation='PERSONAL_INFANTRY' if owner==0 else ('BODYGUARD_INFANTRY' if 122<=owner<=124 else 'NATIVE_ALLIED_INFANTRY')
    return dict(sequence=sequence,tick=word(raw,4),attacker_agent=word(raw,8),
        attacker_owner=word(raw,12),victim_agent=word(raw,16),victim_owner=owner,
        victim_squad=word(raw,24),victim_slot=word(raw,28),victim_family=relation,
        hp_before=before,hp_maximum=maximum,calculated_damage=damage,hp_after=after,
        hp_lost=before-after,hp_lost_fraction=(before-after)/maximum,
        native_death_result=bool(word(raw,48)),
        confirmed_lethal_hp_result=bool(word(raw,48) and after<=0),
        victim_physical_flags=hex(word(raw,52)),musou_attribution_verified=False)


def drain(memory,record):
    raw=memory.read(record['data_address'],SIZE)
    require(word(raw)==MAGIC and word(raw,4)==record.get('version',VERSION)
            and word(raw,4) in (VERSION,LEGACY_VERSION),'E_OFFICER_HIT_HEADER')
    key=(record['data_address'],tuple(memory.cookie));state=getattr(memory,'_officer_hit_reader',None)
    if not state or state['key']!=key:
        state={'key':key,'cursor':0,'saved':0,'lost':0,'rejected':0,'last':None,'families':{},
               'path':memory.root/'logs'/('officer_hit_results_'+memory.log_path.stem+'.jsonl')}
        memory._officer_hit_reader=state
    completed=word(raw,SEQUENCE);require(completed>=state['cursor'],'E_OFFICER_HIT_SEQUENCE_REVERSED')
    first=max(state['cursor']+1,completed-CAPACITY+1);lost=max(0,first-state['cursor']-1)
    events=[];rejected=0
    for sequence in range(first,completed+1):
        at=RING+((sequence-1)&(CAPACITY-1))*STRIDE
        event=decode(raw[at:at+STRIDE],sequence)
        if event is None:rejected+=1;continue
        events.append(event)
        stats=state['families'].setdefault(event['victim_family'],dict(
            hits=0,hp_lost=0.0,hp_lost_fraction_sum=0.0,lethal_results=0))
        stats['hits']+=1;stats['hp_lost']+=event['hp_lost']
        stats['hp_lost_fraction_sum']+=event['hp_lost_fraction']
        stats['lethal_results']+=int(event['confirmed_lethal_hp_result'])
        stats['average_hp_loss_percent']=100*stats['hp_lost_fraction_sum']/stats['hits']
        stats['lethal_hit_fraction']=stats['lethal_results']/stats['hits']
    if events or lost or rejected:
        state['path'].parent.mkdir(exist_ok=True)
        with state['path'].open('a',encoding='utf-8') as output:
            if lost or rejected:output.write(json.dumps(dict(kind='AUDIT_GAP',overwritten=lost,uncommitted=rejected))+'\n')
            utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
            for event in events:output.write(json.dumps(dict(event,observed_utc=utc,process_cookie=list(memory.cookie)),allow_nan=False)+'\n')
        state['saved']+=len(events);state['lost']+=lost;state['rejected']+=rejected
        if events:state['last']=events[-1]
    state['cursor']=completed
    return dict(saved_hits=state['saved'],overwritten_hits=state['lost'],uncommitted_hits=state['rejected'],
        families=state['families'],last_hit=state['last'],event_log=str(state['path']),last_sequence=completed)


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(gameplay_modified=False,native_functions_called=False,
        source='BRACKETED_NATIVE_DIRECT_DAMAGE_CALL',attacker_scope='ENEMY_OFFICER',
        hp_before_and_after_recorded=True,musou_attribution_verified=False,
        raw_hp_trace_preserved=True)
    if record:result.update(drain(memory,record))
    return result
