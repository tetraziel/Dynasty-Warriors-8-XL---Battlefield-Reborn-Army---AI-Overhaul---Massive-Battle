"""Optional native guard-order sprites for the two personal-squad halves.

The original sprite callback runs exactly once. Additional private sprites are
drawn synchronously through its original trampoline on that same render thread.
No fourth guard, global texture replacement, display-list insertion or UI file.
"""
import struct
from core import require,word
from recall_bridge import Asm,R,CONTEXT,MAGIC as RECALL_MAGIC,VERSION as RECALL_VERSION
from auto_bridge import AUTO_MAGIC,AUTO_VERSION
from bridge import relative_jump
import detachment as orders
import bundle_support as bundle
import native_hud_legacy as previous

FEATURE='PERSONAL_SQUADS_NATIVE_HUD_TEST'
MAGIC=0x3144484E;VERSION=2;LEGACY_VERSION=1;SIZE=0x14000;CODE_SIZE=0x8000;TRAMPOLINE=0x3000
LEGACY_SIZES={1:0x1000}
LEGACY_SITES=previous.SITES
SITES={**previous.SITES,'PERSONAL_NATIVE_HUD_TEXT_PREPARE':(0x5614DD,'e85efcffff')}
COUNTERS={'player_hud_callbacks':0x10,'native_icon_draws':0x14,'scope_skips':0x18,
          'resource_skips':0x1C,'layout_skips':0x20,'native_popup_preparations':0x24,
          'native_popup_draws':0x28,'native_popup_skips':0x2C}
MODE=0x40;TID=0x44;ORDER_A=0x48;ORDER_B=0x4C;POSITION=0x50
SPRITE=0x400;GAP=48.;ICON_SPACING=32.
TEXT_NODE=0x500;FONT_COPY=0x1000;FONT_BYTES=0x10DE0;GLYPHS=0x12000;MAX_GLYPHS=64
POP_COMMAND=0x60;POP_SEQUENCE=0x64;POP_TICK=0x68;POP_COUNT=0x6C;POP_FONT=0x78
POP_SECONDS=4;POP_POSITION=0xC0;FONT_SIZE=0xC8
TEXTS={0:0x600,1:0x640,2:0x680}
# Native 4215D0 consumes ESC C <alphanumeric index>, ESC R restores defaults.
# Palette1 is the blue initialized by 5D2716, also selected by ally alias A0.
# No global palette or original text is written.
BLUE_PALETTE_INDEX=1;BLUE_BEGIN=b'\x1bC1';COLOR_RESET=b'\x1bR'
COLOR_CODE_CHECKS={0x421895:'3c1b0f850f0100008a06463c437541',
                   0x4218E5:'3c52751d8b859c0d01008b8da40d01008985a00d0100898da80d0100',
                   0x421980:'8985a00d010085c0781583f8227e12b8220000008985a00d0100'}
W={n:0x100+i*4 for i,n in enumerate(('hud','bank','queue','device','mode'))}
ATLAS=bytes.fromhex('6e006e000000000018001800200020006f006f000000000018001800200020007000700000000000180018002000200071007100000000001800180020002000')


def build_bridge(base,data,code,auto,recall,name,*,legacy=False):
    if legacy:return previous.build_bridge(base,data,code,auto,recall,name)
    if name=='PERSONAL_NATIVE_HUD_TEXT_PREPARE':return build_text_prepare(base,data,code,auto,recall)
    require(name in SITES,'E_NATIVE_HUD_SITE');x=Asm();trampoline=code+TRAMPOLINE
    inc=lambda off:x.mem('ff',0,disp=data+off)
    def load(r,n):x.load(r,disp=data+W[n])
    def save(r,n):x.store(r,disp=data+W[n])
    def ctx(r,n):x.cmpm(r,disp=recall+CONTEXT[n]);x.jump('ne','scope_skip')
    def finite(r,off,end):
        x.load('eax',r,off);x.ri(4,'eax',0x7FFFFFFF);x.cmp('eax',0x461C4000);x.jump('above',end) # abs <= 10000
    x.emit('9c60')
    for off,val in ((0,MAGIC),(4,VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,disp=data+off);x.jump('ne','transparent')
    # Fast rejection for every other UI sprite, including player2 and menus.
    x.load('edx',disp=base+0x6A91A8);x.sane('edx','transparent')
    x.lea('eax','edx',4);x.cmpm('eax','esp',24);x.jump('ne','transparent')
    x.op(7,0,'edx');x.jump('ne','transparent')
    x.load('eax','esp',44);x.cmpm('eax',disp=base+0x6A9320);x.jump('ne','transparent')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','transparent')
    save('edx','hud');x.load('eax','esp',40);save('eax','device')
    x.load('eax','esp',44);save('eax','queue');inc(0x10)
    x.emit('64a124000000');x.store('eax',disp=data+TID)
    x.emit('89e581ec4002000083e4f0');x.store('esp','ebp',-4)
    # Original native inputs, including flags and pre-call FP/SSE state.
    for r,o in (('edi',0),('esi',4),('ebx',16),('edx',20),('ecx',24),('eax',28)):x.load(r,'ebp',o)
    x.mem('ff',6,'ebp',32);x.emit('9d')
    x.mem('ff',6,'ebp',44);x.mem('ff',6,'ebp',40);x.call(code,trampoline)
    for r,o in (('eax',28),('ecx',24),('edx',20)):x.store(r,'ebp',o)
    x.emit('9c');x.mem('8f',0,'ebp',32)
    # Save POST-native state, so the iterator receives its original next-node
    # pointer and the native callback's exact outputs after our two extra draws.
    x.load('esp','ebp',-4);x.mem('0fae',0,'esp')
    x.emit('dbe3');x.set(0x1F80,'ebp',-8);x.mem('0fae',2,'ebp',-8);x.emit('fc')
    for a,v in ((auto,AUTO_MAGIC),(auto+4,AUTO_VERSION),(auto+12,0),(auto+20,0),(auto+24,1),
                (recall,RECALL_MAGIC),(recall+4,RECALL_VERSION),(recall+8,1),(recall+12,0),(recall+16,0)):
        x.op(7,v,disp=a);x.jump('ne','scope_skip')
    for rva,n in ((0x6A91E8,'manager'),(0x6A91D8,'ai'),(0x6A91EC,'players'),(0x6D10BC,'phase')):
        x.load('edx',disp=base+rva);x.sane('edx','scope_skip');ctx('edx',n)
    x.load('eax','edx',0x1C784);x.cmp('eax',4);x.jump('eq','phase_ok')
    x.cmp('eax',5);x.jump('ne','scope_skip');x.mark('phase_ok')
    x.load('ecx',disp=base+0x6A91EC);x.op(7,1,'ecx',0x590);x.jump('ne','scope_skip')
    x.op(7,0,'ecx',0x108);x.jump('ne','scope_skip')
    x.load('eax',disp=auto+16);x.cmp('eax',0);x.jump('eq','scope_skip');ctx('eax','sequence')
    load('edx','hud');x.cmpm('edx',disp=base+0x6A91A8);x.jump('ne','scope_skip')
    x.mem('f6',0,'edx',8);x.emit('80');x.jump('ne','scope_skip') # Hidden first native sprite.
    x.op(7,base+0x60FDC0,'edx',4);x.jump('ne','scope_skip')
    x.op(7,base+0x60FDC0,'edx',0x109C);x.jump('ne','scope_skip')
    x.load('edi',disp=recall+orders.EXTENSION_POINTER);x.sane('edi','scope_skip')
    for off,val in ((0,orders.MAGIC),(4,orders.VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,'edi',off);x.jump('ne','scope_skip')
    x.imm('ecx',0);x.load('esi','edi',orders.CURRENT)
    x.cmp('esi',0);x.jump('eq','mode_ready')
    x.lea('edx','edi',orders.ARENA);x.rr('39','esi','edx');x.jump('below','scope_skip')
    x.lea('edx','edi',orders.SIZE-orders.RECORD_SIZE);x.rr('39','esi','edx');x.jump('above','scope_skip')
    x.rr('89','eax','esi');x.ri(4,'eax',orders.RECORD_SIZE-1);x.cmp('eax',0);x.jump('ne','scope_skip')
    for n,o in orders.COMMAND_CONTEXT.items():
        x.load('eax','esi',o);x.cmpm('eax',disp=recall+CONTEXT[n]);x.jump('ne','old_command')
    x.load('ecx','esi',0x1C);x.cmp('ecx',2);x.jump('above','scope_skip');x.jump('jmp','mode_ready')
    x.mark('old_command');x.imm('ecx',0)
    x.mark('mode_ready');save('ecx','mode');x.store('ecx',disp=data+MODE)
    # Native 4255A0 maps Guard=0 and Secure Location=2 to resources110/112.
    x.load('edi',disp=base+0x6A9334);x.sane('edi','resource_skip')
    save('edi','bank');x.load('edx','edi');x.sane('edx','resource_skip')
    x.load('eax','edx',8);x.cmp('eax',113);x.jump('below','resource_skip')
    x.cmp('eax',4096);x.jump('above','resource_skip')
    x.load('edx','edx',16);x.sane('edx','resource_skip')
    for index in (110,112):x.load('eax','edx',index*4);x.sane('eax','resource_skip')
    # The background position contains the current animated/resolution offset.
    x.load('esi',disp=base+0x659F9C);x.sane('esi','layout_skip')
    load('edi','hud');x.ri(0,'edi',0x1010)
    for off in (0x24,0x28):finite('edi',off,'layout_skip')
    for off in (0,4,0x10,0x14,0x20,0x24,0x30,0x34):finite('esi',off,'layout_skip')
    x.mem('f30f10',1,'edi',0x24);x.mem('f30f5c',1,'esi',0)
    x.mem('f30f10',2,'edi',0x28);x.mem('f30f5c',2,'esi',4)
    x.mem('f30f10',0,'esi',0x10)
    for off in (0x20,0x30):
        nxt='max_layout_'+str(off);x.mem('0f2e',0,'esi',off);x.jump('ae',nxt)
        x.mem('f30f10',0,'esi',off);x.mark(nxt)
    x.emit('f30f58c1');x.mem('f30f58',0,disp=data+0xA0) # native icon width24
    save_x=lambda off:x.mem('f30f11',0,disp=data+off)
    # Include the native name glyph bounds when available. All loops are bounded
    # and no font state, name, vertex or native HUD node is ever changed here.
    for slot in range(3):
        nxt='name_next_'+str(slot);loop='glyph_'+str(slot);advance='glyph_next_'+str(slot)
        load('edi','hud');x.ri(0,'edi',0x1048+slot*0x1C)
        x.mem('f6',0,'edi',4);x.emit('80');x.jump('ne',nxt)
        x.load('ecx','edi',0x14);x.cmp('ecx',1);x.jump('below',nxt);x.cmp('ecx',64);x.jump('above',nxt)
        x.cmpm('ecx','edi',0x10);x.jump('above',nxt)
        x.load('edx','edi',8);x.sane('edx',nxt)
        x.mark(loop);finite('edx',0x18,advance)
        x.mem('0f2e',0,'edx',0x18);x.jump('ae',advance);x.mem('f30f10',0,'edx',0x18)
        x.mark(advance);x.ri(0,'edx',0x30);x.emit('49');x.jump('ne',loop);x.mark(nxt)
    x.mem('f30f58',0,disp=data+0xA4);save_x(POSITION)
    x.mem('f30f10',0,'esi',0x34);x.emit('f30f58c2');save_x(POSITION+4)
    # Readbacks have no synchronization side effects. Abort if a load raced us.
    for rva,n in ((0x6A91E8,'manager'),(0x6A91D8,'ai'),(0x6A91EC,'players'),(0x6D10BC,'phase')):
        x.load('edx',disp=base+rva);ctx('edx',n)
    x.load('edx',disp=auto+16);ctx('edx','sequence')
    x.op(7,0,disp=recall+16);x.jump('ne','scope_skip')
    for i in range(2):
        load('esi','hud');x.ri(0,'esi',0x109C);x.imm('edi',data+SPRITE+i*0x38)
        x.imm('ecx',14);x.emit('f3a5')
        x.imm('edx',0);load('eax','mode');x.cmp('eax',2 if i else 1)
        x.jump('below','follow_'+str(i));x.imm('edx',2);x.mark('follow_'+str(i))
        x.store('edx',disp=data+ORDER_A+i*4)
        x.imm('eax',struct.unpack('<I',struct.pack('<f',i*ICON_SPACING))[0]);x.store('eax',disp=data+0xA8)
        x.mem('f30f10',0,disp=data+POSITION);x.mem('f30f58',0,disp=data+0xA8);save_x(0xB0)
        x.load('eax',disp=data+POSITION+4);x.store('eax',disp=data+0xB4)
        x.emit('68');x.dword(data+0xB0);x.emit('52')
        load('eax','bank');x.imm('ecx',data+SPRITE+i*0x38);x.call(code,base+0x4255A0)
        x.mem('ff',6,'ebp',44);x.mem('ff',6,'ebp',40)
        x.imm('ecx',data+SPRITE+i*0x38);x.call(code,trampoline);inc(0x14)
    # Text was built on the native HUD update thread, copied out of the frame
    # allocator, and is only rendered here. Never build fonts on this thread.
    x.load('eax',disp=data+POP_COUNT);x.cmp('eax',1);x.jump('below','restore')
    x.cmp('eax',MAX_GLYPHS);x.jump('above','restore')
    x.load('edx',disp=auto+16);x.cmpm('edx',disp=data+POP_SEQUENCE);x.jump('ne','restore')
    x.load('edx',disp=recall+orders.EXTENSION_POINTER);x.load('edx','edx',orders.CURRENT)
    x.cmpm('edx',disp=data+POP_COMMAND);x.jump('ne','restore')
    x.load('edx',disp=base+0x6A9328);x.cmpm('edx',disp=data+POP_FONT);x.jump('ne','restore')
    x.load('edx','edx',4);x.cmpm('edx',disp=data+FONT_COPY+4);x.jump('ne','restore')
    x.load('edx',disp=base+0x6A91D8);x.load('edx','edx',0x53E90)
    x.mem('2b',R['edx'],disp=data+POP_TICK);x.cmp('edx',POP_SECONDS*60);x.jump('ae','restore')
    for off,val in ((8,data+GLYPHS),(0x10,MAX_GLYPHS)):x.set(val,disp=data+TEXT_NODE+off)
    x.store('eax',disp=data+TEXT_NODE+0x14)
    x.mem('ff',6,'ebp',44);x.mem('ff',6,'ebp',40);x.imm('ecx',data+TEXT_NODE)
    x.call(code,base+0x429BE0);inc(0x28)
    x.jump('jmp','restore')
    x.mark('scope_skip');inc(0x18);x.jump('jmp','restore')
    x.mark('resource_skip');inc(0x1C);x.jump('jmp','restore')
    x.mark('layout_skip');inc(0x20)
    x.mark('restore');x.load('esp','ebp',-4);x.mem('0fae',1,'esp')
    x.set(0,disp=data+12);x.emit('89ec619dc20800')
    x.mark('transparent');x.emit('619d');x.emit(relative_jump(code+len(x.code),trampoline))
    main=x.finish();require(len(main)<TRAMPOLINE,'E_NATIVE_HUD_CODE_SIZE')
    native=bytes.fromhex(SITES[name][1]);return main+b'\x90'*(TRAMPOLINE-len(main))+native+relative_jump(trampoline+len(native),base+0x42A866)


def native_message(mode):
    text=orders.MESSAGES[mode].encode('ascii')
    require(text.count(b'troops')==1,'E_NATIVE_HUD_HIGHLIGHT_WORD')
    encoded=text.replace(b'troops',BLUE_BEGIN+b'troops'+COLOR_RESET)+b'\0'
    require(len(encoded)<=0x40,'E_NATIVE_HUD_TEXT_SIZE')
    return encoded


def initialize_data(raw):
    struct.pack_into('<2f',raw,0xA0,24.,GAP)
    struct.pack_into('<2f',raw,FONT_SIZE,18.,18.)
    struct.pack_into('<f',raw,0xD8,42.)
    for mode,off in TEXTS.items():
        text=native_message(mode);raw[off:off+len(text)]=text


def build_text_prepare(base,data,code,auto,recall):
    """Run after the original HUD builder, on its original update thread.

    Native helpers create glyphs in the usual frame allocator. Copy the bounded
    result to owned memory before publishing POP_COUNT, so rendering never keeps
    a pointer into an expired native font frame. No native guard node is edited.
    """
    x=Asm();inc=lambda o:x.mem('ff',0,disp=data+o)
    x.emit('9c60')
    for off,value in ((0,MAGIC),(4,VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,value,disp=data+off);x.jump('ne','transparent')
    x.load('edx',disp=base+0x6A91A8);x.sane('edx','transparent')
    x.op(7,0,'edx');x.jump('ne','transparent');x.cmpm('edx','esp',20);x.jump('ne','transparent')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','transparent')
    x.emit('89e581ec4002000083e4f0');x.store('esp','ebp',-4)
    for r,o in (('edi',0),('esi',4),('ebx',16),('edx',20),('ecx',24),('eax',28)):x.load(r,'ebp',o)
    x.mem('ff',6,'ebp',32);x.emit('9d');x.call(code,base+0x561140)
    for r,o in (('eax',28),('ecx',24),('edx',20)):x.store(r,'ebp',o)
    x.emit('9c');x.mem('8f',0,'ebp',32)
    x.load('esp','ebp',-4);x.mem('0fae',0,'esp');x.emit('dbe3fc')
    x.set(0x1F80,'ebp',-8);x.mem('0fae',2,'ebp',-8)
    for a,v in ((auto,AUTO_MAGIC),(auto+4,AUTO_VERSION),(auto+12,0),(auto+20,0),(auto+24,1),
                (recall,RECALL_MAGIC),(recall+4,RECALL_VERSION),(recall+8,1),(recall+12,0),(recall+16,0)):
        x.op(7,v,disp=a);x.jump('ne','skip')
    for rva,n in ((0x6A91E8,'manager'),(0x6A91D8,'ai'),(0x6A91EC,'players'),(0x6D10BC,'phase')):
        x.load('edx',disp=base+rva);x.sane('edx','skip');x.cmpm('edx',disp=recall+CONTEXT[n]);x.jump('ne','skip')
    x.op(7,4,'edx',0x1C784);x.jump('ne','skip')
    x.load('edx',disp=base+0x6A91EC);x.op(7,1,'edx',0x590);x.jump('ne','skip')
    x.op(7,0,'edx',0x108);x.jump('ne','skip')
    x.load('eax',disp=auto+16);x.cmp('eax',0);x.jump('eq','skip')
    x.cmpm('eax',disp=recall+CONTEXT['sequence']);x.jump('ne','skip')
    x.load('edi',disp=recall+orders.EXTENSION_POINTER);x.sane('edi','skip')
    for off,val in ((0,orders.MAGIC),(4,orders.VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,'edi',off);x.jump('ne','skip')
    x.load('esi','edi',orders.CURRENT)
    x.lea('edx','edi',orders.ARENA);x.rr('39','esi','edx');x.jump('below','skip')
    x.lea('edx','edi',orders.SIZE-orders.RECORD_SIZE);x.rr('39','esi','edx');x.jump('above','skip')
    x.rr('89','edx','esi');x.ri(4,'edx',orders.RECORD_SIZE-1);x.cmp('edx',0);x.jump('ne','skip')
    for n,off in orders.COMMAND_CONTEXT.items():
        x.load('eax','esi',off);x.cmpm('eax',disp=recall+CONTEXT[n]);x.jump('ne','skip')
    x.cmpm('esi',disp=data+POP_COMMAND);x.jump('eq','restore')
    x.load('eax','esi',0x1C);x.cmp('eax',2);x.jump('above','skip')
    x.store('eax',disp=data+0xD0);x.store('esi',disp=data+0xD4)
    x.load('edx',disp=base+0x6A91D8);x.load('edx','edx',0x53E90)
    x.mem('2b',R['edx'],'esi',0x20);x.cmp('edx',POP_SECONDS*60);x.jump('ae','skip')
    # A first render establishes the animated layout. Retry on the next native
    # update rather than publishing a popup at an unknown screen position.
    x.load('eax',disp=data+POSITION);x.cmp('eax',0);x.jump('eq','restore')
    x.store('eax',disp=data+POP_POSITION)
    x.mem('f30f10',0,disp=data+POSITION+4);x.mem('f30f5c',0,disp=data+0xD8)
    x.mem('f30f11',0,disp=data+POP_POSITION+4)
    x.load('esi',disp=base+0x6A9328);x.sane('esi','skip')
    x.store('esi',disp=data+0xDC)
    x.load('edx',disp=base+0x6A9330);x.sane('edx','skip')
    x.set(0,disp=data+POP_COUNT)
    x.imm('edi',data+FONT_COPY);x.imm('ecx',FONT_BYTES//4);x.emit('f3a5')
    x.set(base+0x60FE60,disp=data+TEXT_NODE);x.set(0x40300004,disp=data+TEXT_NODE+4)
    for off in (8,12,16,20):x.set(0,disp=data+TEXT_NODE+off)
    x.set(255,disp=data+TEXT_NODE+24)
    x.emit('6a00');x.emit('6a16');x.emit('68');x.dword(data+POP_POSITION)
    x.emit('68');x.dword(data+FONT_COPY);x.imm('ecx',data+FONT_SIZE);x.imm('edx',12)
    x.call(code,base+0x41B620)
    x.set(2,disp=data+FONT_COPY+0x10DAC);x.set(0,disp=data+FONT_COPY+0x10DB0)
    x.imm('eax',data+TEXTS[0]);x.load('edx',disp=data+0xD0)
    x.cmp('edx',0);x.jump('eq','text_ready')
    x.imm('eax',data+TEXTS[1]);x.cmp('edx',1);x.jump('eq','text_ready')
    x.imm('eax',data+TEXTS[2]);x.mark('text_ready')
    x.emit('6a006a0050');x.emit('68');x.dword(data+FONT_COPY);x.imm('eax',data+TEXT_NODE)
    x.call(code,base+0x4215D0)
    x.load('ecx',disp=data+TEXT_NODE+0x14);x.cmp('ecx',1);x.jump('below','skip')
    x.cmp('ecx',MAX_GLYPHS);x.jump('above','skip');x.store('ecx',disp=data+0xE0)
    x.load('esi',disp=data+TEXT_NODE+8);x.sane('esi','skip')
    x.imul('ecx','ecx',12);x.imm('edi',data+GLYPHS);x.emit('f3a5')
    x.load('eax',disp=data+0xD4);x.store('eax',disp=data+POP_COMMAND)
    x.load('edx','eax');x.store('edx',disp=data+POP_SEQUENCE)
    x.load('edx','eax',0x20);x.store('edx',disp=data+POP_TICK)
    x.load('edx',disp=data+0xDC);x.store('edx',disp=data+POP_FONT)
    x.load('edx',disp=data+0xE0);x.store('edx',disp=data+POP_COUNT);inc(0x24)
    x.jump('jmp','restore')
    x.mark('skip');x.set(0,disp=data+POP_COUNT);inc(0x2C)
    x.mark('restore');x.load('esp','ebp',-4);x.mem('0fae',1,'esp')
    x.set(0,disp=data+12);x.emit('89ec619d')
    x.emit(relative_jump(code+len(x.code),base+0x5614E2))
    x.mark('transparent');x.emit('619d');x.call(code,base+0x561140)
    x.emit(relative_jump(code+len(x.code),base+0x5614E2));return x.finish()


def check_code(memory):
    # These are position-independent instruction spans. The two actual absolute
    # resource/table operands and native sprite vtable are checked at this base.
    for rva,sig in ((0x42A866,'83ec4453568bf1f646048057'),(0x42AB82,'5f8d46385e5b8be55dc20800'),
                    (0x4255B1,'83fe027714c1e604'),(0x5614DB,'8bd6')):
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),'E_NATIVE_HUD_CODE_'+hex(rva))
    require(memory.read(memory.base+0x60FDC4,4)==struct.pack('<I',memory.base+0x42A860),'E_NATIVE_HUD_VTABLE')
    require(memory.read(memory.base+0x5FBD98,len(ATLAS))==ATLAS,'E_NATIVE_HUD_ATLAS')
    for rva,target in ((0x4255BB,0x5FBD98),(0x4255CB,0x5FBDC8)):
        require(memory.read(memory.base+rva,4)==struct.pack('<I',memory.base+target),'E_NATIVE_HUD_ATLAS_OPERAND')
    for rva,sig in ((0x41B620,'8b442404535556578b7c2418'),(0x4215D0,'83ec24538b5c2430558b6c2430'),
                    (0x429BE0,'558bec83e4f883ec6c538bd9')):
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),'E_NATIVE_HUD_FONT_CODE')
    for rva,sig in COLOR_CODE_CHECKS.items():
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),'E_NATIVE_HUD_COLOR_CODE')
    # Blue palette constructor: input channels80,130,240; destination ASLR-relative.
    blue=(bytes.fromhex('68ff00000068f00000006882000000b050be')+
          struct.pack('<I',memory.base+0x6AB2E4)+bytes.fromhex('e89f13a3ff'))
    require(memory.read(memory.base+0x5D2716,len(blue))==blue,'E_NATIVE_HUD_BLUE_PALETTE')
    require(memory.read(memory.base+0x60FE64,4)==struct.pack('<I',memory.base+0x429BE0),'E_NATIVE_HUD_FONT_VTABLE')


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(default_enabled=False,native_guard_icon_resources=[110,112],
                  indicators_for_squads=[[1,2],[3,4]],gap_after_guard_labels=GAP,
                  uses_native_renderer=True,external_window_for_icons=False,
                  original_guard_slots_modified=False,display_list_modified=False,
                  additional_remote_threads=0,render_calls_synchronous=True,
                  popup_text_native=bool(record and record['version']>=2),external_feedback_window=False,
                  popup_highlight_word='troops',popup_highlight_palette=BLUE_PALETTE_INDEX,
                  popup_color_method='NATIVE_INLINE_ESC_C1_ESC_R',global_palette_modified=False,
                  game_files_modified=False,live_validated=False)
    if record:
        raw=memory.read(record['data_address']+MODE,24)
        result.update(mode=word(raw),native_render_thread=word(raw,4) or None,
                      native_order_symbols=[word(raw,8),word(raw,12)],
                      last_position=list(struct.unpack_from('<2f',raw,16)))
        if record['version']>=2:
            raw=memory.read(record['data_address']+POP_COMMAND,16)
            result.update(popup_command=hex(word(raw)),popup_battle_sequence=word(raw,4),
                          popup_game_tick=word(raw,8),popup_glyph_count=word(raw,12),
                          popup_seconds=POP_SECONDS,popup_build_thread='NATIVE_HUD_UPDATE',
                          popup_frame_glyphs_copied=True)
    return result
