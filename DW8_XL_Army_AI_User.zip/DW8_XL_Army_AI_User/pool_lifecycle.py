"""On-demand construction-state diagnostics. Read handles only; no installer."""
import datetime
from pathlib import Path
import struct
from core import require,word,journal_write

ROOTS={'manager':0x6A91E8,'ai':0x6A91D8,'requests':0x6A91E0,
       'players':0x6A91EC,'phase':0x6D10BC,'secondary_snapshot':0x6A93B0,
       'map_1':0x6A9180,'map_2':0x6A9184}
ALLOCATORS={0x569BB6:'be60630e00',0x56B436:'bec03e0500',0x55AFCD:'bef0d10000',
            0x562404:'beb0590100'}
MAP_CAPACITIES=(600,600,100,100,40)


def sane(value):return 0x10000<=value<0x80000000


def inspect(memory):
    """Observe missing objects or empty pools without treating them as permission.

    Zero players is valid diagnostic input in a menu, not supported gameplay.
    A consistent observation is not proof of worker quiescence or safe mutation.
    """
    result={'available':False,'read_only':True,'live_installer_available':False,
        'process_memory_modified':False,'threads_suspended':False,
        'remote_threads_created':False,'worker_quiescence_verified':False,
        'activation_safe_verified':False}
    try:
        for attempt in range(3):
            roots={name:word(memory.read(memory.base+rva,4)) for name,rva in ROOTS.items()}
            ready=all(memory.read(memory.base+rva,5)==bytes.fromhex(expected)
                      for rva,expected in ALLOCATORS.items())
            errors={};player_count=None;phase=None;queues=None;rosters=None;selections=None;worker=None
            maps={};map_samples=[]
            for name in ('map_1','map_2'):
                pointer=roots[name]
                item={'present':bool(pointer),'address':hex(pointer),
                      'allocation_size_verified':False,'resizing_safe_verified':False}
                maps[name]=item
                if not pointer or not ready:continue
                try:
                    require(sane(pointer),'E_POOL_LIFECYCLE_MAP_POINTER')
                    header=memory.read(pointer,20);counts=memory.read(pointer+0x13DE0,20)
                    require(len(header)==20 and len(counts)==20,'E_POOL_LIFECYCLE_MAP_PARTIAL_READ')
                    quantities=struct.unpack('<5I',counts)
                    require(all(n<=cap for n,cap in zip(quantities,MAP_CAPACITIES)),
                            'E_POOL_LIFECYCLE_MAP_COUNTS')
                    item.update(instance_index_raw=word(header),view_kind_raw=word(header,8),
                        requested_view_kind_raw=word(header,12),
                        native_marker_counts=dict(zip(('ordinary','member_view_a','member_view_b','officer','special'),quantities)),
                        ordinary_native_capacity=600)
                    map_samples.extend(((pointer,header),(pointer+0x13DE0,counts)))
                except Exception as error:errors[name]=str(error)
            secondary={'present':False,'native_parent_bytes':0x96000,
                       'allocation_size_verified':False,'resizing_safe_verified':False}
            secondary_header=None
            if roots['secondary_snapshot']:
                try:
                    require(sane(roots['secondary_snapshot']),'E_POOL_LIFECYCLE_SECONDARY_POINTER')
                    secondary_header=memory.read(roots['secondary_snapshot'],8)
                    secondary.update(present=True,address=hex(roots['secondary_snapshot']),
                        valid_state_byte_raw=secondary_header[0],
                        mode_tag_raw=struct.unpack_from('<i',secondary_header,4)[0])
                except Exception as error:errors['secondary_snapshot']=str(error)
            headers=[]
            if sane(roots['players']):
                try:player_count=word(memory.read(roots['players']+0x590,4))
                except Exception as error:errors['players']=str(error)
            if sane(roots['phase']):
                try:phase=word(memory.read(roots['phase']+0x1C784,4))
                except Exception as error:errors['phase']=str(error)
            if sane(roots['manager']) and ready:
                try:
                    for off,cap in ((0x72AB0,600),(0x7213C,150)):
                        raw=memory.read(roots['manager']+off,16)
                        pointer,capacity,free,head=struct.unpack('<4I',raw)
                        require(sane(pointer) and capacity==cap and 0<=free<=cap and head<cap,
                                'E_POOL_LIFECYCLE_NATIVE_QUEUE')
                        headers.append((off,raw))
                    rows=[struct.unpack('<4I',raw) for off,raw in headers]
                    queues={name:{'capacity':row[1],'free':row[2],'head':row[3]}
                            for name,row in zip(('groups','agents'),rows)}
                    raw=memory.read(roots['manager']+0x4B0,250*0x110)
                    counts=[]
                    for owner in range(250):
                        offset=owner*0x110;capacity=word(raw,offset+0xFC);count=word(raw,offset+0x100)
                        require(0<=count<=capacity<=6,'E_POOL_LIFECYCLE_OWNER_LIST')
                        counts.append(count)
                    rosters={'nonempty':sum(n>0 for n in counts),'listed_groups':sum(counts)}
                except Exception as error:errors['manager']=str(error)
            if sane(roots['requests']) and ready:
                try:
                    selections={'group_list_empty':word(memory.read(roots['requests']+0x83C0,4))==0xFFFFFFFF,
                        'agent_list_empty':word(memory.read(roots['requests']+0x9684,4))==0xFFFFFFFF}
                    worker=memory.read(roots['requests']+0xD1BC,0x34).hex()
                except Exception as error:errors['requests']=str(error)
            after={name:word(memory.read(memory.base+rva,4)) for name,rva in ROOTS.items()}
            changed=roots!=after
            if not changed and headers:
                changed=any(memory.read(roots['manager']+off,16)!=raw for off,raw in headers)
            if not changed and player_count is not None:
                changed=word(memory.read(roots['players']+0x590,4))!=player_count
            if not changed and phase is not None:
                changed=word(memory.read(roots['phase']+0x1C784,4))!=phase
            if not changed and secondary_header is not None:
                changed=memory.read(roots['secondary_snapshot'],8)!=secondary_header
            if not changed and map_samples:
                changed=any(memory.read(pointer,len(raw))!=raw for pointer,raw in map_samples)
            if changed:continue
            absent=all(roots[key]==0 for key in ('manager','ai','requests'))
            maps_absent=all(roots[key]==0 for key in ('map_1','map_2'))
            free=bool(queues and all(row['free']==row['capacity'] for row in queues.values()))
            idle=bool(not roots['secondary_snapshot'] and maps_absent and ready and free and rosters and rosters['nonempty']==0 and
                      selections and all(selections.values()) and player_count in (0,1) and
                      phase is not None and phase not in (4,5) and not errors)
            status=('NATIVE_CODE_NOT_READY_OR_CHANGED' if not ready else
                    'PRIMARY_POOLS_ABSENT_SECONDARY_SNAPSHOT_PRESENT' if absent and secondary['present'] else
                    'PRIMARY_POOLS_ABSENT_MAP_OBJECTS_PRESENT' if absent and not maps_absent else
                    'ENGINE_OBJECTS_NOT_CREATED' if absent else
                    'IDLE_POOL_CANDIDATE_OBSERVED' if idle else 'ENGINE_OBJECTS_IN_USE_OR_UNKNOWN')
            result.update(available=True,stale=False,status=status,native_code_ready=ready,
                roots={name:hex(value) for name,value in roots.items()},player_count=player_count,
                phase_current=phase,queues=queues,owner_rosters=rosters,selections=selections,
                worker_bytes=worker,secondary_snapshot=secondary,map_objects=maps,
                all_primary_engine_objects_absent=absent,
                all_engine_objects_absent=absent and not roots['secondary_snapshot'] and maps_absent,
                all_map_objects_absent=maps_absent,
                all_queue_entries_free_observed=free,idle_candidate_observed=idle,
                snapshot_attempts=attempt+1,errors=errors,whole_process_atomicity_guaranteed=False)
            return result
        result.update(stale=True,error='E_POOL_LIFECYCLE_CONTEXT_CHANGED')
    except Exception as error:result.update(stale=True,error=str(error))
    return result


def capture(memory,root):
    result=inspect(memory)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    path=Path(root)/'logs'/('pool_lifecycle_'+stamp+'.json')
    record=dict(result,cookie=list(memory.cookie))
    journal_write(path,record)
    return dict(record,last_report=str(path))
