"""Normalize added guard infantry's incoming enemy-officer NPC damage role.

Only substitutes the local victim column in the native NPC damage matrix.
Does not change flags, health, officer statistics, or soldier-v-soldier damage.
"""
from core import require,word
from recall_bridge import Asm,R
from bridge import relative_jump
import combat_scope as scope
import bundle_support as bundle

FEATURE='BODYGUARD_INFANTRY_OFFICER_DAMAGE_TEST'
MAGIC=0x31444742;VERSION=2;LEGACY_VERSION=1;SIZE=0x1000;CODE_SIZE=0x4000
SITES={'NPC_DAMAGE_ROLE':(0x454B91,'d9ee8d04b8')}
COUNTERS={'matrix_visits':0x10,'normalized_officer_hits':0x14,
          'scope_skips':0x18,'busy_skips':0x1C}
ATTACK=0x140;VICTIM=0x180;CALC=0x1C0


def build_bridge(base,data,code,auto,recall,name,*,legacy=False):
    require(name in SITES,'E_GUARD_DAMAGE_SITE')
    version=LEGACY_VERSION if legacy else VERSION
    x=Asm();x.emit('9c60');inc=lambda off:x.mem('ff',0,disp=data+off)
    for off,value in ((0,MAGIC),(4,version),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','busy')
    inc(0x10)
    # Native EAX is the victim column, ESI the calculation structure.
    x.op(7,0,'esp',28);x.jump('ne','skip')
    x.load('eax','esp',4);x.sane('eax','skip');x.store('eax',disp=data+CALC)
    scope.roots(x,base,data,auto,'skip')
    for off,dest in ((4,ATTACK),(8,VICTIM)):
        x.load('eax',disp=data+CALC);x.load('ecx','eax',off);x.sane('ecx','skip')
        x.store('ecx',disp=data+CALC+off)
        x.load('eax','ecx',0x18) # wrapper +8 primary +10 agent id
        scope.physical(x,data,dest,'skip',prefix=str(off))
        x.load('eax',disp=data+dest);x.imul('eax','eax',4)
        x.load('edx',disp=data+scope.ROOT+12);x.rr('01','eax','edx')
        x.load('eax','eax',0xC8);x.cmpm('eax',disp=data+CALC+off);x.jump('ne','skip')
    scope.officer(x,data,ATTACK,'skip',allow_group_members=not legacy)
    x.op(7,1,disp=data+ATTACK+0x20);x.jump('ne','skip')
    scope.infantry(x,data,VICTIM,'skip')
    x.op(7,0,disp=data+VICTIM+0x20);x.jump('ne','skip')
    x.load('eax',disp=data+VICTIM+0x1C);x.ri(5,'eax',122)
    x.cmp('eax',2);x.jump('above','skip')
    x.imul('ecx','eax',0x30);x.load('edx',disp=data+scope.ROOT+8)
    x.rr('01','ecx','edx');x.ri(0,'eax',122)
    x.cmpm('eax','ecx',0x1C4);x.jump('ne','skip')
    x.load('ecx',disp=data+VICTIM+12)
    for off,value in ((0x30,865),(0x2C,30),(0x24,30)):
        x.op(7,value,'ecx',off);x.jump('ne','skip')
    x.load('eax','ecx',0x1C);x.ri(5,'eax',1);x.cmp('eax',3);x.jump('above','skip')
    # No persistent classification mutation: only the saved local column.
    x.set(4,'esp',28);inc(0x14)
    for source,target in ((ATTACK,0x30),(VICTIM,0x34)):
        x.load('eax',disp=data+source);x.store('eax',disp=data+target)
    x.load('eax','esp');x.store('eax',disp=data+0x38) # original attacker row EDI
    x.jump('jmp','unlock')
    x.mark('skip');inc(0x18)
    x.mark('unlock');x.set(0,disp=data+12);x.jump('jmp','native')
    x.mark('busy');inc(0x1C)
    x.mark('native');x.emit('619d');x.emit(bytes.fromhex(SITES[name][1]))
    x.emit(relative_jump(code+len(x.code),base+0x454B96));return x.finish()


def check_code(memory):
    for rva,sig in ((0x21430,'8d4108c3'),(0x454B27,'8b4e088b018b5024'),
                    (0x454B9A,'03c7d954240c'),(0x454C36,'d9448408')):
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),
                'E_GUARD_DAMAGE_NATIVE_'+hex(rva))


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(scope='ENEMY_OFFICER_TO_SELECTED_GUARD_INFANTRY_ONLY',
        native_victim_column=0,replacement_victim_column=4,
        classification_flags_modified=False,health_written_directly=False,
        soldier_vs_soldier_damage_modified=False,personal_infantry_damage_modified=False,
        native_damage_formula_preserved=True)
    if record:
        raw=memory.read(record['data_address']+0x30,12)
        result['last_normalized']={'attacker_agent':word(raw),'victim_agent':word(raw,4),
                                   'native_attacker_row':word(raw,8)}
    return result
