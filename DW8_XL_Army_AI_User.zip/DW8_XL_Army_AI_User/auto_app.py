"""Unified automatic GUI. Opening it never attaches to the game."""
import json
from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog
from core import BUILD,require
from auto_controller import Controller
from user_session import AutoSession
from morale_policy import validate_thresholds
from windows_memory import candidates,select_executable
from pool_expansion import preview as pool_preview
from pool_lifecycle import capture as capture_pool_lifecycle
from story_guard_scan import capture as capture_story_guard_scan,summary as story_guard_scan_summary
from windows_memory import Memory as ReadOnlyMemory
from order_feedback import OrderFeedback
from ambition_duel import DEFAULT_PERCENT,validate_percent

from settings_store import SettingsStore,BOOL_DEFAULTS,INT_CHOICES,VERSION as SETTINGS_VERSION
from executable_selection import validate_executable
from user_help import document
from user_messages import error_message,status_message

ROOT=Path(__file__).resolve().parent
COPY=json.loads((ROOT/'texts.json').read_text(encoding='utf-8'))
DISPLAY_LABELS={
    'APP_TITLE_V5_AUTO_RECALL':'DW8 XL - Army & AI',
    'SAVE_SETTINGS':'Save Settings','SELECT_EXECUTABLE':'Game executable',
    'START_AUTO':'Start','STOP_AUTO':'Stop','APPLY_SETTINGS':'Apply Settings',
    'AMBITION_STORY_FREE':'Ambition / Story / Free',
    'ARMY_AND_AI':'Army and AI','AGGRESSIVE_AI_GLOBAL':'Aggressive AI Global',
    'YOUR_ARMY':'Your Army','BATTLE_SETTINGS':'Battle settings',
    'AMBITION_SETTINGS':'Ambition','POPULATION_AND_DISPLAY':'Population and display',
    'POOL_DIAGNOSTICS':'Pool diagnostics',
    'AGGRESSIVE_AI_DESCRIPTION':'NPC reactions, infantry damage and smarter officer targeting.',
    'YOUR_ARMY_DESCRIPTION':'Story guards, squad commands, map markers, native HUD and follow.',
    'REINFORCEMENT_DELAY_30_SECONDS':'Reinforcements: 30-second wait',
    'MORALE_FIXED_THRESHOLDS':'Morale thresholds: 40% / 50% / 75%',
    'MORALE_REINFORCEMENTS':'Morale-based reinforcements',
    'TACTICAL_ABSTRACT_PARITY':'Tactical abstract parity',
    'OFFSCREEN_ZONE_FORCES_25_50':'Offscreen zone forces',
    'BODYGUARD_ARMIES_120':'Bodyguard armies - up to 120 soldiers',
    'BODYGUARD_ORDERS_EXPERIMENTAL':'Bodyguard orders',
    'AMBITION_30_MINUTES':'30-minute battles',
    'AMBITION_NO_TIME_BONUSES':'Disable time bonuses',
    'AMBITION_FRESH_BODYGUARDS_EACH_BATTLE':'Fresh bodyguards each battle (test)',
    'AMBITION_FRESH_BODYGUARDS_DESCRIPTION':'Restore selected guards next battle, including defeated guards. Enable before the series.',
    'AMBITION_POST_SYMBOLS_RANDOM_DUEL_5_TEST':'Random Duel every third battle',
    'DUEL_OFFICER_MATERIAL_DROPS_TEST':'Officer material drops in Duel',
    'DUEL_REWARD_MULTIPLIERS':'Duel reward multipliers',
    'TROOP_DENSITY':'Troop density',
    'TROOP_DENSITY_NATIVE':'Native','TROOP_DENSITY_PLUS_50':'+50%',
    'TROOP_DENSITY_PLUS_100':'+100%',
    'VISIBLE_MEMBERS_FULL_REQUEST_TEST':'Request all squad members',
    'MANY_EXTENDED_NPC_ACTIVITY_TEST':'Extended NPC activity (Many)',
    'NPC_ACTIVITY_30000':'30000 units','NPC_ACTIVITY_50000':'50000 units',
    'NPC_ACTIVITY_100000':'100000 units',
    'NPC_REQUEST_BUDGET_TEST':'NPC request budget',
    'NPC_1200_REQUEST_BUDGET_TEST':'1200','NPC_2400_REQUEST_BUDGET_TEST':'2400',
    'NPC_4000_REQUEST_BUDGET_TEST':'4000','NPC_10000_REQUEST_BUDGET_TEST':'10000',
    'NPC_100000_REQUEST_BUDGET_TEST':'100000',
    'FOG_DISTANCE_100000_TEST':'Fog Distance 100000',
    'FOG_DISTANCE_100000_DESCRIPTION':'Many + native Fog preset 0; applies through native view updates.',
    'GROUP_POOL_PLAN_600':'Native 600','GROUP_POOL_PLAN_900':'Plan 900',
    'GROUP_POOL_PLAN_1200':'Plan 1200',
    'CHECK_GROUP_POOL_PLAN_READ_ONLY':'Check selected pool plan',
    'CHECK_POOL_900_READ_ONLY':'Check pool 900','CHECK_POOL_1200_READ_ONLY':'Check pool 1200',
    'SCAN_POOL_LIFECYCLE_READ_ONLY':'Scan pool lifecycle',
    'NATIVE_GATES_ON':'Native gates: on','NATIVE_GATES_OFF':'Native gates: off',
    'FOLLOW_ON':'Follow: on','FOLLOW_OFF':'Follow: off','FOLLOW_PENDING':'Follow: pending',
}

def text(key):return COPY.get(key) or DISPLAY_LABELS.get(key,key)

class App:
    FIXED_MORALE_THRESHOLDS=(40,50,75)
    ARMY_FLAGS=('story_guards','personal_map_markers','personal_detachment',
                'personal_native_hud','personal_continuous_follow')
    COMBAT_FLAGS=('damage_audit','guard_damage','officer_crowd','officer_pursuit')

    def __init__(self,window):
        self.window=window;self.session=None;self.controller=None;self.closing=False;self.last_output=None
        self.story_guard_scan=None
        self.camera_scan=None
        self.health_scan=None
        self.pid=tk.StringVar()
        self.settings_store=SettingsStore();self.help_windows={}
        self.exe_path=tk.StringVar();self.saved_notice=tk.StringVar()
        self.status_text=tk.StringVar();self.details_text=tk.StringVar()
        self.settings_load_error=None
        self.morale_enabled=tk.BooleanVar(value=True)
        # Tommy's startup selections, from the screenshot of 25 October.
        # These initialize controls only; START_AUTO remains an explicit action.
        self.aggressive=tk.BooleanVar(value=True)
        self.your_army=tk.BooleanVar(value=True)
        self.ai_tests=[tk.BooleanVar(value=True) for _ in range(3)]
        self.ambition_30=tk.BooleanVar(value=True)
        self.tactical_passive=tk.BooleanVar(value=False)
        self.tactical_abstract=tk.BooleanVar(value=True)
        self.manual_morale_enabled=tk.BooleanVar(value=False)
        self.manual_morale_percent=tk.StringVar(value='50')
        self.no_time_bonus=tk.BooleanVar(value=True)
        self.guard_armies=tk.BooleanVar(value=True)
        self.zone_forces=tk.BooleanVar(value=True)
        self.guard_orders=tk.BooleanVar(value=True)
        self.story_guards=tk.BooleanVar(value=True)
        self.population_percent=tk.IntVar(value=100)
        self.visible_members=tk.BooleanVar(value=True)
        self.npc_many=tk.BooleanVar(value=False)
        self.npc_activity_distance=tk.IntVar(value=30000)
        self.npc_render_request=tk.BooleanVar(value=False)
        self.npc_allocation_balance=tk.BooleanVar(value=False)
        self.fog_distance=tk.BooleanVar(value=False)
        self.damage_audit=tk.BooleanVar(value=False)
        self.guard_damage=tk.BooleanVar(value=False)
        self.officer_crowd=tk.BooleanVar(value=False)
        self.officer_pursuit=tk.BooleanVar(value=False)
        self.npc_request_budget=tk.IntVar(value=1200)
        self.personal_map_markers=tk.BooleanVar(value=True)
        self.personal_detachment=tk.BooleanVar(value=True)
        self.personal_native_hud=tk.BooleanVar(value=True)
        self.personal_continuous_follow=tk.BooleanVar(value=True)
        self.ambition_fresh_guards=tk.BooleanVar(value=False)
        self.ambition_duel=tk.BooleanVar(value=True)
        self.duel_officer_drops=tk.BooleanVar(value=True)
        self.duel_percent=[tk.StringVar(value=str(v)) for v in DEFAULT_PERCENT]
        self.duel_window=None
        self.order_feedback=OrderFeedback(window);self.order_feedback_error=None
        self.group_pool_capacity=tk.IntVar(value=1200)
        self.thresholds=[tk.StringVar(value=str(v)) for v in self.FIXED_MORALE_THRESHOLDS]
        self.load_settings()
        self.normalize_groups()
        from scroll_layout import ScrollableOptions,geometry
        window.title(text('APP_TITLE_V5_AUTO_RECALL'));geometry(window)
        frame=ttk.Frame(window,padding=12);frame.pack(fill='both',expand=True)
        # PID stays internal and is never saved: it changes when the game restarts.
        self.pid_entry=ttk.Entry(frame,textvariable=self.pid,width=12)
        ttk.Label(frame,text='Game executable').grid(row=0,column=0,sticky='w',padx=(0,8))
        self.exe_entry=ttk.Entry(frame,textvariable=self.exe_path,state='readonly')
        self.exe_entry.grid(row=0,column=1,columnspan=2,sticky='ew')
        self.browse_button=ttk.Button(frame,text='Browse...',command=self.browse_executable)
        self.browse_button.grid(row=0,column=3,sticky='e',padx=(8,0))
        self.gate_status=ttk.Label(frame);self.follow_status=ttk.Label(frame)
        self.start_button=ttk.Button(frame,text=text('START_AUTO'),command=self.start)
        self.start_button.grid(row=1,column=0,sticky='w',pady=12)
        self.stop_button=ttk.Button(frame,text=text('STOP_AUTO'),command=self.stop)
        self.stop_button.grid(row=1,column=1,sticky='w')
        self.apply_button=ttk.Button(frame,text=text('APPLY_SETTINGS'),command=self.apply_settings)
        self.apply_button.grid(row=1,column=2,sticky='w')
        self.save_button=ttk.Button(frame,text='Save Settings',command=self.save_settings)
        self.save_button.grid(row=1,column=3,sticky='e')
        ttk.Label(frame,textvariable=self.saved_notice,wraplength=780).grid(
            row=2,column=0,columnspan=3,sticky='w',pady=(0,8))
        ttk.Button(frame,text='?',width=3,command=lambda:self.open_help('SETUP')).grid(
            row=2,column=3,sticky='e')
        self.options_scroll=ScrollableOptions(frame,window,tk,ttk)
        self.options_scroll.container.grid(row=3,column=0,columnspan=4,sticky='nsew',pady=4)
        controls=self.options_scroll.content
        controls.columnconfigure(0,weight=1);controls.columnconfigure(1,weight=1)
        def section(key,row,column=0,span=1):
            panel=ttk.Frame(controls,padding=10,relief='groove',borderwidth=1)
            panel.grid(row=row,column=column,columnspan=span,sticky='nsew',padx=3,pady=5)
            panel.columnconfigure(0,weight=1);panel.columnconfigure(1,weight=1)
            ttk.Label(panel,text=text(key),font=('Segoe UI',10,'bold')).grid(
                row=0,column=0,sticky='w',pady=(0,6))
            ttk.Button(panel,text='?',width=3,command=lambda:self.open_help(key)).grid(
                row=0,column=1,sticky='e',pady=(0,6))
            return panel
        self.core_panel=section('ARMY_AND_AI',0,span=2)
        self.aggressive_checkbox=ttk.Checkbutton(self.core_panel,text=text('AGGRESSIVE_AI_GLOBAL'),
            variable=self.aggressive,command=self.toggle_all_ai_tests)
        self.aggressive_checkbox.grid(row=1,column=0,sticky='w',pady=3)
        self.army_checkbox=ttk.Checkbutton(self.core_panel,text=text('YOUR_ARMY'),
            variable=self.your_army,command=self.change_your_army)
        self.army_checkbox.grid(row=1,column=1,sticky='w',pady=3)
        ttk.Label(self.core_panel,text=text('AGGRESSIVE_AI_DESCRIPTION'),wraplength=350).grid(
            row=2,column=0,sticky='nw',padx=(0,12))
        ttk.Label(self.core_panel,text=text('YOUR_ARMY_DESCRIPTION'),wraplength=350).grid(
            row=2,column=1,sticky='nw')

        self.battle_panel=section('BATTLE_SETTINGS',1)
        for row,key,var,command in (
            (1,'MORALE_REINFORCEMENTS',self.morale_enabled,None),
            (3,'TACTICAL_ABSTRACT_PARITY',self.tactical_abstract,self.change_tactical),
            (4,'OFFSCREEN_ZONE_FORCES_25_50',self.zone_forces,self.change_extras),
            (5,'BODYGUARD_ARMIES_120',self.guard_armies,self.change_extras)):
            kwargs={'command':command} if command else {}
            ttk.Checkbutton(self.battle_panel,text=text(key),variable=var,**kwargs).grid(
                row=row,column=0,columnspan=2,sticky='w',pady=3)
        self.morale_threshold_label=ttk.Label(self.battle_panel,text=text('MORALE_FIXED_THRESHOLDS'))
        self.morale_threshold_label.grid(row=2,column=0,columnspan=2,sticky='w',padx=22,pady=(0,4))
        self.guard_orders_checkbox=ttk.Checkbutton(self.battle_panel,
            text=text('BODYGUARD_ORDERS_EXPERIMENTAL'),variable=self.guard_orders,
            command=self.change_guard_orders)
        self.guard_orders_checkbox.grid(row=6,column=0,columnspan=2,sticky='w',pady=3)

        ttk.Label(self.battle_panel,text=text('REINFORCEMENT_DELAY_30_SECONDS')).grid(
            row=7,column=0,columnspan=2,sticky='w',padx=22,pady=3)

        self.ambition_panel=section('AMBITION_SETTINGS',1,1)
        for row,key,var,command in (
            (1,'AMBITION_30_MINUTES',self.ambition_30,self.change_timer),
            (2,'AMBITION_NO_TIME_BONUSES',self.no_time_bonus,self.change_extras),
            (3,'AMBITION_POST_SYMBOLS_RANDOM_DUEL_5_TEST',self.ambition_duel,None),
            (4,'DUEL_OFFICER_MATERIAL_DROPS_TEST',self.duel_officer_drops,self.change_duel_drops)):
            kwargs={'command':command} if command else {}
            ttk.Checkbutton(self.ambition_panel,text=text(key),variable=var,**kwargs).grid(
                row=row,column=0,columnspan=2,sticky='w',pady=3)
        ttk.Button(self.ambition_panel,text=text('DUEL_REWARD_MULTIPLIERS'),
            command=self.duel_settings).grid(row=5,column=0,columnspan=2,sticky='w',pady=5)
        self.ambition_fresh_guards_checkbox=ttk.Checkbutton(self.ambition_panel,
            text=text('AMBITION_FRESH_BODYGUARDS_EACH_BATTLE'),variable=self.ambition_fresh_guards,
            command=self.change_ambition_fresh_guards)
        self.ambition_fresh_guards_checkbox.grid(row=6,column=0,columnspan=2,sticky='w',pady=3)
        ttk.Label(self.ambition_panel,text=text('AMBITION_FRESH_BODYGUARDS_DESCRIPTION'),wraplength=350).grid(
            row=7,column=0,columnspan=2,sticky='w',padx=22,pady=(0,3))

        self.display_panel=section('POPULATION_AND_DISPLAY',2,span=2)
        density=ttk.Frame(self.display_panel);density.grid(row=1,column=0,sticky='w',pady=3)
        ttk.Label(density,text=text('TROOP_DENSITY')).grid(row=0,column=0,columnspan=3,sticky='w')
        for column,(percent,key) in enumerate(((0,'TROOP_DENSITY_NATIVE'),
                (50,'TROOP_DENSITY_PLUS_50'),(100,'TROOP_DENSITY_PLUS_100'))):
            ttk.Radiobutton(density,text=text(key),variable=self.population_percent,value=percent,
                command=self.change_population).grid(row=1,column=column,sticky='w',padx=(0,8))
        ttk.Checkbutton(self.display_panel,text=text('VISIBLE_MEMBERS_FULL_REQUEST_TEST'),
            variable=self.visible_members,command=self.change_visibility).grid(
                row=2,column=0,sticky='w',pady=3)
        activity=ttk.Frame(self.display_panel);activity.grid(row=1,column=1,rowspan=2,sticky='nw',pady=3)
        ttk.Checkbutton(activity,text=text('MANY_EXTENDED_NPC_ACTIVITY_TEST'),
            variable=self.npc_many,command=self.change_npc_many).grid(
                row=0,column=0,columnspan=3,sticky='w')
        for column,distance in enumerate((30000,50000,100000)):
            ttk.Radiobutton(activity,text=text('NPC_ACTIVITY_'+str(distance)),
                variable=self.npc_activity_distance,value=distance,
                command=self.change_npc_many).grid(row=1,column=column,sticky='w',padx=(0,8))
        budget=ttk.Frame(self.display_panel);budget.grid(row=3,column=0,columnspan=2,sticky='w',pady=(6,0))
        ttk.Checkbutton(budget,text=text('NPC_REQUEST_BUDGET_TEST'),variable=self.npc_render_request,
            command=self.change_npc_render_request).grid(row=0,column=0,sticky='w',padx=(0,16))
        for column,value in enumerate((1200,2400,4000,10000,100000),start=1):
            ttk.Radiobutton(budget,text=text('NPC_'+str(value)+'_REQUEST_BUDGET_TEST'),
                variable=self.npc_request_budget,value=value,command=self.change_npc_render_request).grid(
                    row=0,column=column,sticky='w',padx=(0,8))
        ttk.Checkbutton(self.display_panel,text=text('FOG_DISTANCE_100000_TEST'),
            variable=self.fog_distance,command=self.change_fog_distance).grid(
                row=4,column=0,columnspan=2,sticky='w',pady=(5,2))
        ttk.Label(self.display_panel,text=text('FOG_DISTANCE_100000_DESCRIPTION'),wraplength=680).grid(
            row=5,column=0,columnspan=2,sticky='w',padx=22,pady=(0,3))

        # No scan/check controls or debug text panel in the public window.
        self.gate_scan_button=None;self.camera_scan_button=None
        self.health_scan_button=None;self.story_scan_button=None;self.apply_morale_button=None
        status=ttk.Frame(frame,padding=(4,8));status.grid(row=4,column=0,columnspan=4,sticky='ew')
        ttk.Label(status,textvariable=self.status_text,font=('Segoe UI',10,'bold')).pack(anchor='w')
        ttk.Label(status,textvariable=self.details_text,wraplength=940).pack(anchor='w',pady=(4,0))
        frame.rowconfigure(3,weight=1,minsize=150)
        frame.columnconfigure(1,weight=1);frame.columnconfigure(2,weight=1)
        window.protocol('WM_DELETE_WINDOW',self.close)
        self.show({'build':BUILD,'status':'AUTO_DISABLED_NO_PROCESS_OPEN','enabled':False})
        if self.settings_load_error:self.saved_notice.set(self.settings_load_error)
        else:self.saved_notice.set('Settings loaded.' if self.settings_store.path.exists() else 'Choose your options. Save Settings keeps them for next time.')
        self.buttons();window.after(500,self.poll)

    def show(self,result):
        title,detail=status_message(result)
        self.status_text.set(title);self.details_text.set(detail)

    def load_settings(self):
        try:
            record=self.settings_store.load();self.exe_path.set(record['executable'])
            for name,value in record['options'].items():getattr(self,name).set(value)
            for variable,value in zip(self.duel_percent,record['duel_percent']):variable.set(str(value))
        except (ValueError,OSError) as error:
            self.settings_load_error='Saved settings could not be read; defaults loaded. '+str(error)

    def current_settings(self):
        self.normalize_groups()
        return {'version':SETTINGS_VERSION,'executable':self.exe_path.get(),
                'options':{name:getattr(self,name).get() for name in (*BOOL_DEFAULTS,*INT_CHOICES)},
                'duel_percent':[int(v.get()) for v in self.duel_percent]}

    def save_settings(self):
        try:
            self.settings_store.save(self.current_settings())
            self.saved_notice.set('Settings saved. They will load next time; press Apply Settings to update a running session.')
        except (ValueError,OSError) as error:self.saved_notice.set('Settings were not saved. '+str(error))

    def browse_executable(self):
        if self.installed() or (self.controller and self.controller.enabled):return
        path=filedialog.askopenfilename(parent=self.window,title='Select the running game executable',
            filetypes=[('Windows executable','*.exe')],initialfile=Path(self.exe_path.get()).name if self.exe_path.get() else 'Launch.exe')
        if not path:return
        try:
            path=validate_executable(path)
            self.settings_store.save_executable(path)
            self.exe_path.set(path);self.pid.set('')
            self.saved_notice.set('Game executable saved. Compatibility is checked when you press Start.')
        except (ValueError,OSError) as error:self.saved_notice.set('Executable was not saved. '+str(error))

    def open_help(self,section):
        existing=self.help_windows.get(section)
        if existing is not None and existing.winfo_exists():existing.lift();return
        title,body=document(section)
        dialog=tk.Toplevel(self.window);self.help_windows[section]=dialog
        dialog.title(title+' - Help');dialog.transient(self.window)
        width=min(700,max(420,self.window.winfo_screenwidth()-80))
        height=min(620,max(320,self.window.winfo_screenheight()-100))
        dialog.geometry(str(width)+'x'+str(height));dialog.minsize(min(420,width),min(320,height))
        frame=ttk.Frame(dialog,padding=14);frame.pack(fill='both',expand=True)
        ttk.Label(frame,text=title,font=('Segoe UI',13,'bold')).pack(anchor='w',pady=(0,10))
        content=ttk.Frame(frame);content.pack(fill='both',expand=True)
        viewer=tk.Text(content,wrap='word',font=('Segoe UI',10),padx=8,pady=8,borderwidth=0)
        scroll=ttk.Scrollbar(content,orient='vertical',command=viewer.yview)
        viewer.configure(yscrollcommand=scroll.set);scroll.pack(side='right',fill='y');viewer.pack(fill='both',expand=True)
        viewer.insert('1.0',body);viewer.configure(state='disabled')
        def close():self.help_windows.pop(section,None);dialog.destroy()
        ttk.Button(frame,text='Close',command=close).pack(anchor='e',pady=(10,0))
        dialog.protocol('WM_DELETE_WINDOW',close)

    def installed(self):return bool(self.session and self.session.installed())

    def duel_settings(self):
        if self.duel_window is not None:
            self.duel_window.lift();return
        dialog=tk.Toplevel(self.window);self.duel_window=dialog
        dialog.title('Duel reward multipliers');dialog.transient(self.window)
        frame=ttk.Frame(dialog,padding=12);frame.pack(fill='both',expand=True)
        ttk.Label(frame,text='Base reward x2, then your percentage (100-1000%)').grid(row=0,column=0,columnspan=2,pady=6)
        for i,var in enumerate(self.duel_percent):
            ttk.Label(frame,text='Difficulty index '+str(i)+' (%)').grid(row=i+1,column=0,sticky='w',pady=4)
            ttk.Entry(frame,textvariable=var,width=8).grid(row=i+1,column=1,padx=8)
        def close():self.duel_window=None;dialog.destroy()
        def apply():
            try:
                percent=validate_percent([int(v.get()) for v in self.duel_percent])
                if self.controller and self.controller.enabled:
                    self.controller.configure_ambition_duel(bool(self.ambition_duel.get()),percent)
                close()
            except Exception as error:self.error(error)
        ttk.Button(frame,text='Apply multipliers',command=apply).grid(row=7,column=0,columnspan=2,pady=8)
        dialog.protocol('WM_DELETE_WINDOW',close)

    def buttons(self):
        active=bool(self.controller and (self.controller.enabled or self.controller.stopping))
        self.start_button.configure(state='disabled' if active or self.installed() or self.closing else 'normal')
        self.stop_button.configure(state='normal' if active or self.installed() else 'disabled')
        self.pid_entry.configure(state='disabled' if active or self.installed() else 'normal')
        self.browse_button.configure(state='disabled' if active or self.installed() or self.closing else 'normal')
        self.save_button.configure(state='disabled' if self.closing else 'normal')
        running=bool(self.controller and self.controller.enabled and not self.closing)
        self.apply_button.configure(state='normal' if running else 'disabled')
        self.guard_orders_checkbox.configure(state='disabled' if self.your_army.get() else 'normal')
        view=self.controller.public() if self.controller else {}
        follow=view.get('follow_test',{'enabled':False})
        pending=follow.get('pending_change',False)
        key='FOLLOW_PENDING' if pending else ('FOLLOW_ON' if follow['enabled'] else 'FOLLOW_OFF')
        self.follow_status.configure(text=text(key))
        gates=view.get('reinforcements',{})
        self.gate_status.configure(text=text('NATIVE_GATES_ON' if gates.get('enabled') else 'NATIVE_GATES_OFF'))
        scanning=bool(self.camera_scan and self.camera_scan.public()['running'])
        health_scanning=bool(self.health_scan and self.health_scan.public()['running'])
        if self.camera_scan_button is not None:
            self.camera_scan_button.configure(text=text('STOP_NPC_ACTIVITY_SCAN' if scanning else 'SCAN_NPC_ACTIVITY_MANY_READ_ONLY'),
                                              state='disabled' if self.closing or health_scanning else 'normal')
        if self.health_scan_button is not None:
            self.health_scan_button.configure(text=text('STOP_TROOP_HEALTH_SCAN' if health_scanning else 'SCAN_TROOP_HEALTH_READ_ONLY'),
                                              state='disabled' if self.closing or scanning else 'normal')

    def error(self,error):
        if self.session:
            try:exited=not self.session.alive()
            except Exception:exited=False
            if exited:
                self.session.close();self.session=None;self.controller=None
                self.show({'status':'AUTO_PROCESS_EXITED','enabled':False,
                           'hook_installed_or_uncertain':False,'process_memory_released':True,
                           'last_read_error':str(error)})
                self.buttons();return
        self.show({'error':str(error),'hook_installed_or_uncertain':self.installed(),
                   'journal':str(self.session.log_path) if self.session else None})
        self.buttons()

    def start(self):
        try:
            thresholds=self.read_thresholds()
            require(not self.installed(),'E_STOP_EXISTING_SESSION_FIRST')
            require(not self.controller or not self.controller.enabled,'E_AUTO_ALREADY_RUNNING')
            if self.session:self.session.close();self.session=None;self.controller=None
            select_executable(self.exe_path.get().strip())
            found=candidates();require(bool(found),'E_PROCESS_NOT_FOUND')
            require(len(found)==1,'E_MULTIPLE_GAME_PROCESSES');pid=found[0]
            self.session=AutoSession(pid,self.settings_store.directory/'sessions');self.pid.set(str(pid))
            self.controller=Controller(self.session);self.controller.start()
            self.controller.configure_policy(bool(self.morale_enabled.get()),thresholds)
            self.queue_ai_tests()
            self.controller.configure_ambition_timer(bool(self.ambition_30.get()))
            self.controller.apply_pending_timer()
            self.controller.configure_tactical_balance(self.selected_tactical_mask())
            self.controller.apply_pending_tactical()
            self.queue_extras();self.controller.apply_pending_extras()
            self.show(self.controller.public());self.buttons()
        except Exception as error:
            if self.controller and self.installed():self.controller.stop()
            elif self.session:self.session.close();self.session=None;self.controller=None
            self.error(error)

    def normalize_groups(self):
        combat=bool(self.aggressive.get());army=bool(self.your_army.get())
        for var in self.ai_tests:var.set(combat)
        for name in self.COMBAT_FLAGS:getattr(self,name).set(combat)
        for name in self.ARMY_FLAGS:getattr(self,name).set(army)
        if army:self.guard_orders.set(True) # existing Story guard dependency
        self.tactical_passive.set(False);self.manual_morale_enabled.set(False)
        if self.controller:
            self.controller.manual_morale=None;self.controller.manual_morale_at=None
            self.controller.manual_morale_error=None
        if self.session:self.session._manual_morale_observing=False

    def read_thresholds(self):
        for var,value in zip(self.thresholds,self.FIXED_MORALE_THRESHOLDS):var.set(str(value))
        return validate_thresholds(self.FIXED_MORALE_THRESHOLDS)

    def selected_ai_mask(self):return sum((1<<i) for i,var in enumerate(self.ai_tests) if var.get())

    def queue_ai_tests(self):
        self.normalize_groups()
        self.controller.configure_ai_tests(7 if self.aggressive.get() else 0)

    def toggle_all_ai_tests(self):
        self.normalize_groups()
        if self.controller and self.controller.enabled:
            try:
                self.queue_ai_tests();self.queue_extras()
                self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def change_ai_tests(self):
        self.toggle_all_ai_tests()

    def change_your_army(self):
        self.normalize_groups();self.change_extras();self.buttons()

    def apply_settings(self):
        try:
            thresholds=self.read_thresholds()
            require(self.controller is not None,'E_AUTO_NOT_RUNNING')
            self.controller.configure_policy(bool(self.morale_enabled.get()),thresholds)
            self.queue_ai_tests()
            self.controller.configure_ambition_timer(bool(self.ambition_30.get()))
            self.controller.configure_tactical_balance(self.selected_tactical_mask())
            self.queue_extras()
            self.show(self.controller.public());self.buttons()
        except Exception as error:self.error(error)

    def change_timer(self):
        if self.controller and self.controller.enabled:
            try:
                self.controller.configure_ambition_timer(bool(self.ambition_30.get()))
                self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def queue_extras(self):
        self.normalize_groups()
        self.controller.configure_extra('ambition_bonus',bool(self.no_time_bonus.get()))
        self.controller.configure_extra('guard_army',bool(self.guard_armies.get()))
        self.controller.configure_extra('zone_balance',bool(self.zone_forces.get()))
        orders=bool(self.guard_orders.get() or self.your_army.get())
        if orders:self.controller.configure_extra('guard_orders',True)
        self.controller.configure_population(int(self.population_percent.get()))
        self.controller.configure_extra('visibility',bool(self.visible_members.get()))
        if not self.your_army.get():
            self.controller.configure_extra('native_hud',False)
        self.controller.configure_extra('story_guards',bool(self.story_guards.get()))
        self.controller.configure_extra('map_markers',bool(self.personal_map_markers.get()))
        self.controller.configure_extra('detachment',bool(self.personal_detachment.get() or self.personal_native_hud.get()))
        self.controller.configure_extra('native_hud',bool(self.personal_native_hud.get()))
        self.controller.configure_extra('personal_movement',bool(self.personal_continuous_follow.get()))
        if not orders:self.controller.configure_extra('guard_orders',False)
        self.controller.configure_ambition_duel(bool(self.ambition_duel.get()),
            validate_percent([int(v.get()) for v in self.duel_percent]))
        self.controller.configure_extra('duel_officer_drops',bool(self.duel_officer_drops.get()))
        self.controller.configure_npc_many(bool(self.npc_many.get()),int(self.npc_activity_distance.get()))
        self.controller.configure_npc_render_request(bool(self.npc_render_request.get()),int(self.npc_request_budget.get()))
        self.controller.configure_extra('damage_audit',bool(self.damage_audit.get()))
        self.controller.configure_extra('officer_hit_audit',bool(self.damage_audit.get()))
        self.controller.configure_extra('guard_damage',bool(self.guard_damage.get()))
        self.controller.configure_extra('officer_crowd',bool(self.officer_crowd.get()))
        self.controller.configure_extra('officer_pursuit',bool(self.officer_pursuit.get()))
        self.controller.configure_extra('reinforcement_delay',True)
        self.controller.configure_extra('npc_allocation_balance',False)
        self.controller.configure_extra('fog_distance',bool(self.fog_distance.get()))
        self.controller.configure_extra('ambition_guards',bool(self.ambition_fresh_guards.get()))

    def change_ambition_fresh_guards(self):
        if self.controller and self.controller.enabled:
            try:
                self.controller.configure_extra('ambition_guards',bool(self.ambition_fresh_guards.get()))
                self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def change_fog_distance(self):
        if self.controller and self.controller.enabled:
            try:
                self.controller.configure_extra('fog_distance',bool(self.fog_distance.get()))
                self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def change_npc_allocation_balance(self):
        if self.controller and self.controller.enabled:
            try:
                self.controller.configure_extra('npc_allocation_balance',False)
                self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def change_duel_drops(self):
        if self.duel_officer_drops.get():self.ambition_duel.set(True)

    def change_personal_hud(self):
        if self.personal_native_hud.get():self.personal_detachment.set(True)

    def change_story_guards(self):
        if self.story_guards.get():self.guard_orders.set(True)
        if self.controller and self.controller.enabled:
            try:
                self.controller.configure_extra('guard_orders',bool(self.guard_orders.get() or self.story_guards.get()))
                self.controller.configure_extra('story_guards',bool(self.story_guards.get()))
                self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def change_visibility(self):
        if self.controller and self.controller.enabled:
            try:
                self.controller.configure_extra('visibility',bool(self.visible_members.get()))
                self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def change_npc_many(self):
        if self.controller and self.controller.enabled:
            try:
                self.controller.configure_npc_many(bool(self.npc_many.get()),int(self.npc_activity_distance.get()))
                self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def change_npc_render_request(self):
        if self.controller and self.controller.enabled:
            try:
                self.controller.configure_npc_render_request(bool(self.npc_render_request.get()),int(self.npc_request_budget.get()))
                self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def change_population(self):
        if self.controller and self.controller.enabled:
            try:
                self.controller.configure_population(int(self.population_percent.get()))
                self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def change_guard_orders(self):
        if self.your_army.get():self.guard_orders.set(True)
        if self.controller and self.controller.enabled:
            try:
                self.controller.configure_extra('guard_orders',bool(self.guard_orders.get()))
                self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def change_extras(self):
        if self.controller and self.controller.enabled:
            try:
                self.queue_extras();self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def selected_tactical_mask(self):
        self.tactical_passive.set(False)
        return 2*int(bool(self.tactical_abstract.get()))

    def change_tactical(self):
        if self.controller and self.controller.enabled:
            try:
                self.controller.configure_tactical_balance(self.selected_tactical_mask())
                self.show(self.controller.public());self.buttons()
            except Exception as error:self.error(error)

    def scan_gates(self):
        try:
            require(self.controller is not None and self.controller.enabled,'E_AUTO_NOT_RUNNING')
            self.controller.scan_gates();self.show(self.controller.public())
        except Exception as error:self.error(error)

    def check_group_pool(self):
        try:
            count=int(self.group_pool_capacity.get())
            if self.controller and self.controller.enabled:
                self.controller.inspect_group_pool(count);self.show(self.controller.public())
            else:
                self.show({'status':'GROUP_POOL_PLAN_READ_ONLY','group_pool':pool_preview(count),
                           'enabled':False,'process_opened':False})
        except Exception as error:self.error(error)

    def test_group_pool(self,count):
        require(count in (900,1200),'E_GROUP_POOL_TEST_CAPACITY')
        self.group_pool_capacity.set(count)
        self.check_group_pool()

    def scan_pool_lifecycle(self):
        try:
            if self.controller and self.controller.enabled:
                self.controller.inspect_pool_lifecycle();self.show(self.controller.public());return
            if self.pid.get().strip():pid=int(self.pid.get())
            else:
                found=candidates();require(len(found)==1,'E_EXPECT_ONE_LAUNCH_PROCESS_'+str(found));pid=found[0]
            reader=ReadOnlyMemory(pid)
            try:result=capture_pool_lifecycle(reader,ROOT)
            finally:reader.close()
            self.pid.set(str(pid))
            self.show({'status':'POOL_LIFECYCLE_READ_ONLY','enabled':False,
                       'pool_lifecycle':result,'process_opened':True,'writer_opened':False})
        except Exception as error:self.error(error)

    def scan_story_guards(self):
        try:
            if self.pid.get().strip():pid=int(self.pid.get())
            else:
                found=candidates();require(len(found)==1,'E_EXPECT_ONE_LAUNCH_PROCESS_'+str(found));pid=found[0]
            reader=ReadOnlyMemory(pid)
            try:result=capture_story_guard_scan(reader,ROOT)
            finally:reader.close()
            self.pid.set(str(pid));self.story_guard_scan=story_guard_scan_summary(result)
            self.show({'status':'STORY_FREE_CAPTURE_READ_ONLY','process_opened':True,
                       'writer_opened':False,'snapshot_only_not_continuously_updated':True})
        except Exception as error:self.error(error)

    def scan_camera_follow(self):
        try:
            if self.camera_scan and self.camera_scan.public()['running']:
                self.camera_scan.stop();self.buttons();return
            require(not(self.health_scan and self.health_scan.public()['running']),'E_STOP_HEALTH_SCAN_FIRST')
            if self.pid.get().strip():pid=int(self.pid.get())
            else:
                found=candidates();require(len(found)==1,'E_EXPECT_ONE_LAUNCH_PROCESS_'+str(found));pid=found[0]
            from camera_follow_scan import Recorder
            cookie=list(self.session.cookie) if self.session else None
            many_record=(self.session.lease or {}).get('npc_many') if self.session else None
            self.camera_scan=Recorder(pid,ROOT,ReadOnlyMemory,expected_cookie=cookie,many_extension_record=many_record)
            self.camera_scan.start();self.pid.set(str(pid))
            self.show(self.controller.public() if self.controller else {'status':'CAMERA_FOLLOW_SCAN_READ_ONLY','enabled':False})
            self.buttons()
        except Exception as error:self.error(error)

    def scan_troop_health(self):
        try:
            if self.health_scan and self.health_scan.public()['running']:
                self.health_scan.stop();self.buttons();return
            require(not(self.camera_scan and self.camera_scan.public()['running']),'E_STOP_CAMERA_SCAN_FIRST')
            if self.pid.get().strip():pid=int(self.pid.get())
            else:
                found=candidates();require(len(found)==1,'E_EXPECT_ONE_LAUNCH_PROCESS_'+str(found));pid=found[0]
            from troop_health_scan import Recorder
            cookie=list(self.session.cookie) if self.session else None
            self.health_scan=Recorder(pid,ROOT,ReadOnlyMemory,expected_cookie=cookie)
            self.health_scan.start();self.pid.set(str(pid))
            self.show(self.controller.public() if self.controller else {'status':'TROOP_HEALTH_SCAN_READ_ONLY','enabled':False})
            self.buttons()
        except Exception as error:self.error(error)

    def scanners_running(self):
        return any(scan and scan.public()['running'] for scan in (self.camera_scan,self.health_scan))

    def apply_morale(self):
        self.manual_morale_enabled.set(False)
        self.error(RuntimeError('E_MANUAL_MORALE_RETIRED'))

    def stop(self):
        if self.controller:
            self.controller.stop();self.controller.step();self.show(self.controller.public())
        self.buttons()

    def poll(self):
        try:
            if self.controller:
                self.controller.step()
                if not self.session.alive():
                    self.session.close();self.session=None;self.controller=None
                    self.show({'status':'AUTO_PROCESS_EXITED','enabled':False,
                               'hook_installed_or_uncertain':False,'process_memory_released':True})
                else:self.show(self.controller.public())
            if (self.camera_scan or self.health_scan) and not self.controller:
                self.show({'status':'TROOP_HEALTH_SCAN_READ_ONLY' if self.health_scan else 'CAMERA_FOLLOW_SCAN_READ_ONLY','enabled':False})
            if self.closing and not self.installed() and not self.scanners_running():
                if self.session:self.session.close()
                self.order_feedback.destroy()
                self.window.destroy();return
            self.buttons()
        except Exception as error:
            if self.controller:self.controller.stop()
            self.error(error)
        # All battle feedback now belongs to native_hud. Never display the
        # previous desktop overlay, including while an optional hook is refused.
        try:
            hud=self.controller.extra_public('native_hud') if self.controller and self.controller.enabled else {}
            self.order_feedback.native_icons=bool(hud.get('enabled'))
            self.order_feedback.hide()
            self.order_feedback_error=None
        except Exception as error:
            self.order_feedback.hide();self.order_feedback_error=str(error)
        self.window.after(500,self.poll)

    def close(self):
        self.closing=True
        if self.camera_scan:self.camera_scan.stop()
        if self.health_scan:self.health_scan.stop()
        self.order_feedback.hide()
        if self.controller:
            self.controller.stop();self.controller.step();self.show(self.controller.public())
        if (not self.installed() or not self.session.alive()) and not self.scanners_running():
            if self.session:self.session.close()
            self.order_feedback.destroy()
            self.window.destroy()
        else:self.buttons()

if __name__=='__main__':
    window=tk.Tk();App(window);window.mainloop()
