"""Offline layout of the secondary battle-state group snapshot.

This describes both group arrays in a candidate fourth allocation. It does not patch a process,
resize a live object, or authorize changing the native serialized format.
"""
from core import require
from pool_binding import for_capacity

PARENT_SIZE=0x96000
SUBOBJECT=0x42440
GROUP_BASE=0x80E8
STRIDE=0x84
FOLLOWING_FIELD=0x1B648
MANAGER_SUBOBJECT=0x1EDC0
MANAGER_GROUP_BASE=0xE3D4
MANAGER_STRIDE=0x64
MANAGER_FOLLOWING_FIELD=0x1CE34


def layout(count):
    binding=for_capacity(count)
    # Keep the entire native parent and its following fields in place. Expanded
    # profiles put both complete replacement group arrays after that prefix.
    start=SUBOBJECT+GROUP_BASE if count==600 else PARENT_SIZE
    end=start+count*STRIDE
    manager_start=(MANAGER_SUBOBJECT+MANAGER_GROUP_BASE if count==600 else (end+15)&~15)
    manager_end=manager_start+count*MANAGER_STRIDE
    size=PARENT_SIZE if count==600 else (manager_end+15)&~15
    require(SUBOBJECT+GROUP_BASE+600*STRIDE==SUBOBJECT+FOLLOWING_FIELD,
            'E_POOL_SNAPSHOT_NATIVE_BOUNDARY')
    require(MANAGER_GROUP_BASE+600*MANAGER_STRIDE==MANAGER_FOLLOWING_FIELD,
            'E_POOL_SNAPSHOT_MANAGER_NATIVE_BOUNDARY')
    require(start>=0 and end<=size and manager_end<=size and size%16==0 and
            (count==600 or manager_start>=end),'E_POOL_SNAPSHOT_LAYOUT')
    return {'capacity':count,'record_stride':STRIDE,'parent_native_size':PARENT_SIZE,
        'parent_size_candidate':size,'parent_allocation_request_candidate':size+0x20,
        'subobject_offset':SUBOBJECT,'group_parent_offset':start,
        'group_subobject_offset':start-SUBOBJECT,'group_end':end,
        'following_native_field_parent_offset':SUBOBJECT+FOLLOWING_FIELD,
        'ai_group_offset':binding.ai_groups,
        'manager_group_parent_offset':manager_start,
        'manager_group_subobject_offset':manager_start-MANAGER_SUBOBJECT,
        'manager_group_stride':MANAGER_STRIDE,'manager_group_end':manager_end,
        'manager_following_native_field_parent_offset':MANAGER_SUBOBJECT+MANAGER_FOLLOWING_FIELD,
        'manager_live_group_offset':binding.manager_groups,
        'serialized_six_byte_iterations_candidate':PARENT_SIZE//6,
        'added_parent_bytes':size-PARENT_SIZE,'native_prefix_preserved':True,
        'native_serialized_bytes':PARENT_SIZE,'serialized_format_compatibility_verified':False,
        'native_transfer_instructions_unchanged':True,
        'expanded_arrays_mirrored_to_native_prefix':False,
        'appended_storage_excluded_from_native_transfer':count!=600,
        'native_copy_and_restore_paths_identified':True,
        'live_allocation_and_restore_validated':False,'live_installation_supported':False}


def operand_candidates(count):
    p=layout(count)
    # RVAs identify decoded instructions, never unaligned numeric matches.
    return {
        0x54A56B:('disp',GROUP_BASE,p['group_subobject_offset'],'SNAPSHOT_DESTINATION_GROUP_ARRAY'),
        0x54A571:('disp',0xA7F8,p['ai_group_offset'],'SNAPSHOT_SOURCE_AI_GROUP_ARRAY'),
        0x54A577:('imm',600,count,'SNAPSHOT_GROUP_COPY_COUNT'),
        0x4F8B1D:('disp',0xA7F8,p['ai_group_offset'],'RESTORE_DESTINATION_AI_GROUP_ARRAY'),
        0x4F8B23:('disp',GROUP_BASE,p['group_subobject_offset'],'RESTORE_SOURCE_GROUP_ARRAY'),
        0x4F8B29:('imm',600,count,'SNAPSHOT_GROUP_RESTORE_COUNT'),
        0x4ED1E4:('imm',600,count,'RESTORE_GROUP_LINK_LIMIT'),
        0x4ED1F8:('disp',0xA7F8,p['ai_group_offset'],'RESTORE_GROUP_LINK_ARRAY'),
        0x4ED4E5:('imm',600,count,'SNAPSHOT_UNLINKED_GROUP_SENTINEL'),
        0x52B398:('disp',MANAGER_GROUP_BASE,p['manager_group_subobject_offset'],'MANAGER_SNAPSHOT_DESTINATION_GROUP_ARRAY'),
        0x52B3A2:('disp',0x10E50,p['manager_live_group_offset'],'MANAGER_SNAPSHOT_SOURCE_GROUP_ARRAY'),
        0x52B3A8:('imm',600,count,'MANAGER_SNAPSHOT_SOURCE_GROUP_BOUND'),
        0x52B3C7:('imm',600,count,'MANAGER_SNAPSHOT_GROUP_COPY_COUNT'),
        0x5B5606:('disp',0x10E50,p['manager_live_group_offset'],'MANAGER_RESTORE_DESTINATION_GROUP_ARRAY'),
        0x5B560C:('imm',MANAGER_GROUP_BASE,p['manager_group_subobject_offset'],'MANAGER_RESTORE_SOURCE_GROUP_ARRAY'),
        0x5B5612:('imm',600,count,'MANAGER_SNAPSHOT_GROUP_RESTORE_COUNT'),
        0x5B5759:('imm',MANAGER_GROUP_BASE+0x60,p['manager_group_subobject_offset']+0x60,'MANAGER_RESTORE_FREE_GROUP_OWNER_SCAN'),
        0x5B5774:('imm',600,count,'MANAGER_RESTORE_FREE_GROUP_ID_BOUND'),
        0x5B5788:('disp',0x10E50,p['manager_live_group_offset'],'MANAGER_RESTORE_FREE_GROUP_ARRAY'),
        0x5B5B18:('imm',600*616,count*616,'MANAGER_RESTORE_FREE_GROUP_SCAN_BYTES'),
        0x4EB52E:('imm',600,count,'MANAGER_OWNER_SNAPSHOT_EMPTY_GROUP_SENTINEL'),
        0x4EB344:('imm',600,count,'MANAGER_OWNER_RESTORE_EMPTY_GROUP_SENTINEL'),
        0x51BEAB:('imm',600,count,'PHYSICAL_AGENT_SNAPSHOT_VALID_GROUP_BOUND'),
        0x5B5706:('imm',600,count,'PHYSICAL_AGENT_RESTORE_EMPTY_GROUP_BOUND'),
        0x5072B0:('imm',600,count,'PHYSICAL_AGENT_RESET_EMPTY_GROUP_SENTINEL'),
        0x5841D1:('imm',600,count,'PHYSICAL_AGENT_SNAPSHOT_RESTORE_GROUP_BOUND'),
        0x58420E:('imm',600,count,'PHYSICAL_AGENT_RESTORE_GROUP_ACCESS_BOUND'),
        0x584225:('disp',0x10E50,p['manager_live_group_offset'],'PHYSICAL_AGENT_RESTORE_GROUP_ACCESS_ARRAY'),
        0x3F6990:('imm',PARENT_SIZE,p['parent_size_candidate'],'PARENT_SIZE_GETTER'),
        0x3F69C0:('imm',PARENT_SIZE,p['parent_size_candidate'],'PARENT_RESET_BYTES'),
        0x3FD530:('imm',PARENT_SIZE,p['parent_size_candidate'],'PARENT_INITIALIZER_BYTES'),
        0x4084F5:('imm',PARENT_SIZE,p['parent_size_candidate'],'PARENT_GLOBAL_RESET_BYTES'),
        0x4157B8:('imm',PARENT_SIZE,p['parent_size_candidate'],'PARENT_CAPTURE_CLEAR_BYTES'),
        0x41596A:('imm',PARENT_SIZE+0x20,p['parent_allocation_request_candidate'],'PARENT_ALLOCATION_REQUEST_BYTES'),
        0x4159A8:('imm',PARENT_SIZE,p['parent_size_candidate'],'PARENT_ALLOCATION_FIRST_CLEAR_BYTES'),
        0x4159BE:('imm',PARENT_SIZE,p['parent_size_candidate'],'PARENT_ALLOCATION_PUBLISH_CLEAR_BYTES'),
        # No serializer operands: native byte count and file layout stay intact.
        # Expanded arrays still need a coherent prefix/restore bridge before use.
    }
