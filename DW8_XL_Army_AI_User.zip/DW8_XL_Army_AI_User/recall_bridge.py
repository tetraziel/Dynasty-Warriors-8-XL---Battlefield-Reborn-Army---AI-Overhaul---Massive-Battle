"""Experimental per-agent recall. Pure emitter: importing opens no process.

The CALL replacement either tail-calls the original dispatcher with its exact
inputs or invokes two native helpers and returns to the original caller.
Only our allocation is written directly. Game writes belong to native helpers.
"""
from pool_binding import resolve as resolve_pool
import math
import struct
from bridge import X86, relative_jump
from family_scope import emit_family_scope
from diagnostics import Diagnostics,END as DIAGNOSTIC_END,decode as decode_diagnostics
from reinforcement_state import initialize as initialize_gates,decode as decode_gates,END as GATE_END
from morale_policy import initialize as initialize_policy,decode as decode_policy,END as POLICY_END
from core import PROFILE, require, word

MAGIC = 0x35524344
VERSION = 4
DATA_SIZE = 0x4000
TABLE = 0x400
ENTRY_SIZE = 0x30
AGENTS = 150
# Header: magic/version/enabled/cancel/busy. Counters are diagnostic, not proof.
LEGACY_COUNTERS = {'eligible_updates': 0x20, 'movement_requests': 0x24,
            'entry_resets': 0x28, 'priority_deferrals': 0x2C,
            'inner_radius_returns': 0x30, 'context_resets': 0x34,
            'dispatch_intercepts': 0x38}
ASSIST_COUNTERS = {**LEGACY_COUNTERS, 'combat_grace_started':0x6C,
            'combat_focus_activated':0x70, 'target_filter_checks':0x74,
            'target_filter_rejections':0x78, 'target_filter_fail_open':0x7C}
FOLLOW_V3_COUNTERS = {**ASSIST_COUNTERS, 'native_follow_anchor_uses':0x98,
            'native_follow_scope_skips':0x9C,'native_follow_checks':0xA0,
            'follow_mode_switches':0xA4,'follow_switch_rallies':0xA8}
COUNTERS={**FOLLOW_V3_COUNTERS,'observation_updates':0xB8}
FOLLOW_FLAG,MODE_EPOCH=0x90,0x94
FOLLOW_VIEW=0x300
HEADER_SIZE=max(DIAGNOSTIC_END,GATE_END,POLICY_END)
# A shared scratch record is used only while busy == 1, including native calls.
SCRATCH = {name: 0x100+i*4 for i, name in enumerate((
    'manager', 'ai', 'players', 'player_id', 'player_squad', 'owner',
    'owner_record', 'player', 'agent_id', 'item', 'squad', 'group',
    'group_ai', 'entry', 'tick', 'sequence', 'phase', 'state', 'wrapper',
    'skip', 'slot', 'character'))}
CONTEXT = {name: 0x40+i*4 for i, name in enumerate((
    'sequence', 'manager', 'ai', 'players', 'player_id', 'character',
    'group', 'owner', 'phase'))}
LAST_TICK = 0x68
OUTER2, INNER2 = 0x80, 0x84
FOCUS2 = 0x88


def settings():
    s = PROFILE['recall']
    outer, inner = float(s['outer_radius']), float(s['inner_radius'])
    require(math.isfinite(outer) and math.isfinite(inner) and
            0 < inner < outer < 1_000_000, 'E_RECALL_RADII')
    focus=float(s['combat_radius'])
    require(math.isfinite(focus) and inner<=focus<outer, 'E_COMBAT_RADIUS')
    require(s['delay_seconds'] in (0,10) and s['ticks_per_second'] == 60,
            'E_RECALL_TIME_PROFILE')
    require(s['movement_option'] == 0 and s['arrival_tolerance'] == 120.0,
            'E_RECALL_NATIVE_OPTIONS')
    require(s['ordinary_states'] == [0, 24, 47, 70, 71], 'E_RECALL_STATE_PROFILE')
    require(s['max_observation_gap_ticks'] == 8, 'E_RECALL_GAP_PROFILE')
    require(s['max_tracking_gap_ticks'] == 120, 'E_TRACKING_GAP_PROFILE')
    return s


def initial_recall_data(*,legacy=False,assist_v2=False,follow_v3=False,follow_enabled=False,gate_enabled=False,policy_enabled=False,previous_ranges=False):
    s = dict(settings())
    if previous_ranges:s.update(outer_radius=2500.0,inner_radius=1200.0)
    b = bytearray(DATA_SIZE)
    struct.pack_into('<5I', b, 0, MAGIC, 1 if legacy else (2 if assist_v2 else (3 if follow_v3 else VERSION)), 1, 0, 0)
    struct.pack_into('<2f', b, OUTER2, s['outer_radius']**2, s['inner_radius']**2)
    if not legacy:struct.pack_into('<f',b,FOCUS2,s['combat_radius']**2)
    if not (legacy or assist_v2):struct.pack_into('<I',b,FOLLOW_VIEW+0x84,7)
    if not (legacy or assist_v2 or follow_v3):struct.pack_into('<I',b,0xBC,0xFFFFFFFF)
    if follow_enabled:
        require(not(legacy or assist_v2),'E_FOLLOW_NOT_AVAILABLE')
        struct.pack_into('<I',b,FOLLOW_FLAG,1)
    if gate_enabled:
        require(not(legacy or assist_v2 or follow_v3),'E_GATE_NOT_AVAILABLE')
        initialize_gates(b)
    if policy_enabled:initialize_policy(b,True)
    return bytes(b)


def decode_recall(raw,*,legacy=False,assist_v2=False,follow_v3=False,previous_ranges=False):
    current=not(legacy or assist_v2)
    updated=current and not follow_v3
    require(len(raw) >= (HEADER_SIZE if updated else (0xAC if follow_v3 else (0x88 if legacy else 0x8C))) and word(raw) == MAGIC and
            word(raw, 4) == (1 if legacy else (2 if assist_v2 else (3 if follow_v3 else VERSION))),
            'E_RECALL_DATA_HEADER')
    initial=initial_recall_data(legacy=legacy,assist_v2=assist_v2,follow_v3=follow_v3,previous_ranges=previous_ranges);end=INNER2+4 if legacy else FOCUS2+4
    require(raw[OUTER2:end]==initial[OUTER2:end], 'E_RECALL_DATA_SETTINGS')
    if current:require(word(raw,FOLLOW_FLAG) in (0,1),'E_FOLLOW_MODE_DATA')
    return {'enabled': bool(word(raw, 8)), 'cancel_requested': bool(word(raw, 12)),
            'busy': bool(word(raw, 16)),
            **{key: word(raw, off) for key, off in (LEGACY_COUNTERS if legacy else (ASSIST_COUNTERS if assist_v2 else (FOLLOW_V3_COUNTERS if follow_v3 else COUNTERS))).items()},
            'settings': {k: ({**settings(),'outer_radius':2500.0,'inner_radius':1200.0} if previous_ranges else settings())[k] for k in (
                'outer_radius', 'inner_radius', 'delay_seconds', 'ticks_per_second')},
            'combat_radius':None if legacy else settings()['combat_radius'],
            'target_filter_available':not legacy,
            'reinforcements':decode_gates(raw) if updated else {'available':False,'enabled':False},
            'morale_policy':decode_policy(raw) if updated else {'available':False,'enabled':False},
            'diagnostics':decode_diagnostics(raw) if updated else None,
            'tracking':{'source':'NATIVE_AGENT_LOOP' if updated else 'ACTION_DISPATCH',
                'maximum_unobserved_ticks':settings()['max_tracking_gap_ticks'] if updated else 8,
                'family_quantity_last':word(raw,0xB4) if updated else None,
                'follow_owner_state_last':(None if word(raw,0xBC)==0xFFFFFFFF else word(raw,0xBC)) if updated else None},
            'follow_test':{'available':current,'enabled':bool(word(raw,FOLLOW_FLAG)) if current else False,
                'mode_epoch':word(raw,MODE_EPOCH) if current else None,
                'implementation':'NATIVE_FOLLOW_ANCHOR' if current else None,
                'partial_follow_semantics':True,'native_owner_order_setter_called':False,
                'live_validated':False},
            'native_target_filter_live_validated':False,
            'native_movement_live_validated': False}


def relative_call(source, target):
    return b'\xe8'+relative_jump(source, target)[1:]


R = {'eax': 0, 'ecx': 1, 'edx': 2, 'ebx': 3,
     'esp': 4, 'ebp': 5, 'esi': 6, 'edi': 7}


class Asm(X86):
    """Small integer/SSE emitter; every memory operand uses a disp32."""
    def mem(self, opcode, reg, base=None, disp=0):
        self.emit(opcode)
        if base is None:
            self.emit(bytes([(reg << 3) | 5])); self.dword(disp)
        else:
            r = R[base]
            self.emit(bytes([0x80 | (reg << 3) | r]))
            if r == 4: self.emit('24')
            self.dword(disp)

    def load(self, reg, base=None, disp=0): self.mem('8b', R[reg], base, disp)
    def store(self, reg, base=None, disp=0): self.mem('89', R[reg], base, disp)
    def imm(self, reg, value): self.emit(bytes([0xB8+R[reg]])); self.dword(value)
    def set(self, value, base=None, disp=0):
        self.mem('c7', 0, base, disp); self.dword(value)
    def op(self, group, value, base=None, disp=0):
        self.mem('81', group, base, disp); self.dword(value)
    def ri(self, group, reg, value):
        self.emit(bytes([0x81, 0xC0 | (group << 3) | R[reg]])); self.dword(value)
    def rr(self, opcode, dest, src):
        self.emit(opcode); self.emit(bytes([0xC0 | (R[src] << 3) | R[dest]]))
    def cmp(self, reg, value): self.ri(7, reg, value)
    def cmpm(self, reg, base=None, disp=0): self.mem('3b', R[reg], base, disp)
    def imul(self, reg, src, value):
        self.emit('69'); self.emit(bytes([0xC0 | (R[reg] << 3) | R[src]])); self.dword(value)
    def lea(self, reg, base, disp): self.mem('8d', R[reg], base, disp)
    def jump(self, cond, label): self.branch({'jmp':'e9', 'eq':'0f84', 'ne':'0f85',
        'below':'0f82', 'above':'0f87', 'ae':'0f83', 'be':'0f86', 'parity':'0f8a'}[cond], label)
    def sane(self, reg, end):
        self.cmp(reg, 0x10000); self.jump('below', end)
        self.cmp(reg, 0xFF000000); self.jump('ae', end)
    def call(self, code, target):
        self.emit(relative_call(code+len(self.code), target))


def build_recall_bridge(base, data, auto_data, code,*,legacy=False,assist_v2=False,follow_v3=False,observe=False,squad_count=1,native_template_zero=True,delay_seconds=10,pool=None,detachment_support=False):
    p=resolve_pool(pool)
    s = dict(settings()); x = Asm()
    require(delay_seconds in (0,10),'E_RECALL_DELAY')
    s['delay_seconds']=delay_seconds
    updated=not(legacy or assist_v2 or follow_v3)
    require(not observe or updated,'E_OBSERVER_VARIANT')
    diag=Diagnostics(x,data,'observer' if observe else 'action') if updated else None
    def stage(name):
        if diag:diag.stage(name)
    def a(name): return data+SCRATCH[name]
    def load(reg, name): x.load(reg, disp=a(name))
    def save(reg, name): x.store(reg, disp=a(name))
    def inc(off): x.mem('ff', 0, disp=data+off)
    def equal(reg, value, end='reset_current'):
        x.cmp(reg, value); x.jump('ne', end)
    def ptr(reg, address):
        x.load(reg, disp=address); x.sane(reg, 'finish')

    # Original CALL has already pushed a return address to site+5.
    x.emit('9c60')
    x.op(7, 1, disp=data+8); x.jump('ne', 'transparent')
    x.op(7, 0, disp=data+12); x.jump('ne', 'transparent')
    x.imm('eax', 0); x.imm('ecx', 1)
    x.mem('f00fb1', R['ecx'], disp=data+16); x.jump('ne', 'transparent')
    if not observe:inc(0x38)
    stage('GLOBALS')
    x.set(0, disp=a('entry')); x.set(0, disp=a('skip'))
    # These are native globals; reject null/unbound pointers before dereference.
    ptr('edi', base+0x6A91E8); save('edi', 'manager')
    ptr('ebx', base+0x6A91D8); save('ebx', 'ai')
    ptr('edx', base+0x6A91EC); save('edx', 'players')
    ptr('eax', base+0x6D10BC); save('eax', 'phase')
    stage('PHASE')
    x.op(7, 5, 'eax', 0x1C784); x.jump('eq', 'finish')
    x.op(7, 4, 'eax', 0x1C784); x.jump('ne', 'reset_context')
    stage('PLAYER_BINDING')
    x.op(7, 1, 'edx', 0x590); x.jump('ne', 'reset_context')
    # EAX at entry is the controller, whose +4C0 is the current behavior.
    stage('AGENT_IDENTITY')
    if observe:x.load('esi','esp',0)  # EDI at native loop entry is the behavior.
    else:
        x.load('eax', 'esp', 28); x.sane('eax', 'finish')
        x.load('esi', 'eax', 0x4C0); x.sane('esi', 'finish')
    x.load('eax', 'esi', 0x7C); x.cmp('eax', AGENTS); x.jump('ae', 'finish')
    save('eax', 'agent_id')
    x.imul('ecx', 'eax', 0xE0); x.rr('01', 'ecx', 'ebx'); x.ri(0, 'ecx', 0x21EF8)
    x.rr('39', 'esi', 'ecx'); x.jump('ne', 'finish')
    x.imul('ecx', 'eax', ENTRY_SIZE); x.ri(0, 'ecx', data+TABLE); save('ecx', 'entry')
    x.mem('f7', 0, 'esi', 0xCC); x.dword(1); x.jump('eq', 'reset_current')
    x.mem('f7', 0, 'esi', 0xCC); x.dword(0x08000000); x.jump('ne', 'reset_current')
    x.mem('0fb6', R['ecx'], 'esi', 0xD2); equal('ecx', 0)
    x.load('ecx', 'esi', 0x84); x.cmp('ecx', 1); x.jump('eq', 'class_ok')
    equal('ecx', 2); x.mark('class_ok')
    stage('PLAYER_BINDING')
    x.load('ecx', 'edx', 0x110); x.cmp('ecx', AGENTS); x.jump('ae', 'reset_current')
    x.rr('39', 'eax', 'ecx'); x.jump('eq', 'reset_current'); save('ecx', 'player_id')
    x.imul('eax', 'ecx', 0x30); x.rr('01', 'eax', 'edi'); x.ri(0, 'eax', 0x6B210)
    x.load('eax', 'eax', 8); x.cmp('eax', p.group_capacity); x.jump('ae', 'reset_current')
    save('eax', 'player_squad')
    x.imul('eax', 'eax', 0x268); x.rr('01', 'eax', 'edi'); x.ri(0, 'eax', p.manager_groups)
    x.load('eax', 'eax', 0x44); x.cmp('eax', 250); x.jump('ae', 'reset_current')
    x.cmpm('eax', 'edx', 0x108); x.jump('ne', 'reset_current'); save('eax', 'owner')
    x.imul('eax', 'eax', 0x110); x.rr('01', 'eax', 'edi'); x.ri(0, 'eax', 0x4B0)
    save('eax', 'owner_record')
    x.load('ecx', 'eax', 0x38); x.cmpm('ecx', disp=a('owner')); x.jump('ne', 'reset_current')
    x.op(7, 0, 'eax', 0x40); x.jump('ne', 'reset_current')
    x.load('ecx', 'eax', 0x44); save('ecx', 'character')
    load('ecx', 'owner'); x.imul('ecx', 'ecx', 0xAC); x.rr('01', 'ecx', 'ebx')
    x.mem('f7', 0, 'ecx', 0x90); x.dword(1); x.jump('eq', 'reset_current')
    x.mem('0fb6', R['eax'], 'ecx', 0x9E); x.cmp('eax', 0x80); x.jump('eq', 'reset_current')
    load('ecx', 'player_id'); x.imul('ecx', 'ecx', 0xE0)
    x.rr('01', 'ecx', 'ebx'); x.ri(0, 'ecx', 0x21EF8); save('ecx', 'player')
    x.load('eax', 'ecx', 0x7C); x.cmpm('eax', disp=a('player_id')); x.jump('ne', 'reset_current')
    x.mem('f7', 0, 'ecx', 0xCC); x.dword(1); x.jump('eq', 'reset_current')
    load('eax', 'player_squad'); x.imul('eax', 'eax', 0xA0)
    x.rr('01', 'eax', 'ebx'); x.ri(0, 'eax', p.ai_groups)
    x.cmpm('eax', 'ecx', 0x80); x.jump('ne', 'reset_current')
    x.mem('0fb6', R['eax'], 'ecx', 0xD0); x.cmp('eax', 0x80); x.jump('ae', 'reset_current')
    stage('MEMBER_SLOT_MASKS')
    # Resolve the current member's exact native pool entry and squad.
    load('eax', 'agent_id'); x.imul('eax', 'eax', 0x30)
    x.rr('01', 'eax', 'edi'); x.ri(0, 'eax', 0x6B210); save('eax', 'item')
    x.load('ecx', 'eax', 0); x.cmpm('ecx', disp=a('agent_id')); x.jump('ne', 'reset_current')
    x.load('ecx', 'eax', 8); x.cmp('ecx', p.group_capacity); x.jump('ae', 'reset_current')
    x.cmpm('ecx', disp=a('player_squad')); x.jump('eq', 'reset_current'); save('ecx', 'squad')
    x.imul('ecx', 'ecx', 0x268); x.rr('01', 'ecx', 'edi'); x.ri(0, 'ecx', p.manager_groups)
    save('ecx', 'group')
    for offset, name in [(0x18, 'squad'), (0x44, 'owner')]:
        load('eax', name); x.cmpm('eax', 'ecx', offset); x.jump('ne', 'reset_current')
    for offset, value in [(0x2C, 30), (0x30, 865), (0x24, 30)]:
        x.op(7, value, 'ecx', offset); x.jump('ne', 'reset_current')
    x.load('eax', 'ecx', 0x28); x.cmp('eax', 0); x.jump('eq', 'reset_current')
    x.cmp('eax', 30); x.jump('above', 'reset_current')
    load('eax', 'item'); x.load('eax', 'eax', 0xC)
    x.cmp('eax', 30); x.jump('ae', 'reset_current'); save('eax', 'slot')
    x.mem('0fa3', R['eax'], 'ecx', 0x10); x.jump('ae', 'reset_current')
    x.mem('0fa3', R['eax'], 'ecx', 0x14); x.jump('ae', 'reset_current')
    stage('GROUP_LINKS')
    load('eax', 'squad'); x.imul('eax', 'eax', 0xA0)
    x.rr('01', 'eax', 'ebx'); x.ri(0, 'eax', p.ai_groups); save('eax', 'group_ai')
    x.cmpm('eax', 'esi', 0x80); x.jump('ne', 'reset_current')
    load('ecx', 'squad'); x.cmpm('ecx', 'eax', 0x74); x.jump('ne', 'reset_current')
    load('ecx', 'owner'); x.imul('ecx', 'ecx', 0xAC); x.rr('01', 'ecx', 'ebx')
    x.cmpm('ecx', 'eax', 0x78); x.jump('ne', 'reset_current')
    x.mem('f7', 0, 'eax', 0x88); x.dword(1); x.jump('eq', 'reset_current')
    stage('OWNER_LIST_FAMILY')
    if updated:
        emit_family_scope(x,data,{name:a(name) for name in ('manager','owner','group')},
                          'reset_current',prefix='tracking_family',squad_count=squad_count,native_template_zero=native_template_zero,pool=p)
    else:
        # Require exactly one matching squad in the bounded owner group-ID list.
        load('eax', 'owner_record'); x.load('edx', 'eax', 0x100)
        x.cmp('edx', 1); x.jump('below', 'reset_current')
        x.cmp('edx', 6); x.jump('above', 'reset_current')
        x.load('ecx', 'eax', 0xFC); x.cmp('ecx', 6); x.jump('above', 'reset_current')
        x.rr('39', 'edx', 'ecx'); x.jump('above', 'reset_current')
        x.load('eax', 'eax', 0xF8); x.sane('eax', 'reset_current')
        x.imm('ebx', 0); x.mark('group_scan')
        x.mem('0fb7', R['ecx'], 'eax'); x.cmp('ecx', p.group_capacity); x.jump('ae', 'reset_current')
        x.cmpm('ecx', disp=a('player_squad')); x.jump('eq', 'group_next')
        x.imul('ecx', 'ecx', 0x268); x.rr('01', 'ecx', 'edi'); x.ri(0, 'ecx', p.manager_groups)
        x.op(7, 865, 'ecx', 0x30); x.jump('ne', 'group_next')
        x.op(7, 30, 'ecx', 0x2C); x.jump('ne', 'group_next')
        x.cmpm('ecx', disp=a('group')); x.jump('ne', 'reset_current')
        x.emit('43')  # inc ebx, matching count (duplicate IDs also refuse)
        x.mark('group_next'); x.ri(0, 'eax', 2); x.emit('4a'); x.jump('ne', 'group_scan')
        equal('ebx', 1)
    stage('CONFIG_EVENT')
    # Prove this v5 controller configured a matching descriptor in its event ring.
    x.op(7, 1, disp=auto_data+24); x.jump('ne', 'reset_current')
    x.op(7, 0, disp=auto_data+20); x.jump('ne', 'reset_current')
    x.load('edx', disp=auto_data+16); x.cmp('edx', 0); x.jump('eq', 'reset_current')
    save('edx', 'sequence'); x.imm('ebx', 16); x.mark('event_scan')
    x.rr('89', 'eax', 'edx'); x.emit('48'); x.ri(4, 'eax', 15)
    x.imul('eax', 'eax', 0x200); x.ri(0, 'eax', auto_data+0x1000)
    x.cmpm('edx', 'eax', 0x1FC); x.jump('ne', 'event_next')
    x.op(7, 3, 'eax', 8); x.jump('ne', 'event_next')
    x.cmpm('edi', 'eax', 0x24); x.jump('ne', 'event_next')
    x.op(7, 1108, 'eax', 0x58); x.jump('ne', 'event_next')
    x.op(7, 1108, 'eax', 0x5C); x.jump('ne', 'event_next')
    x.op(7, 865, 'eax', 0x38); x.jump('ne', 'event_next')
    x.op(7, 30, 'eax', 0x3C); x.jump('eq', 'event_ok')
    x.mark('event_next'); x.emit('4a'); x.jump('eq', 'reset_current')
    x.emit('4b'); x.jump('ne', 'event_scan'); x.jump('jmp', 'reset_current')
    x.mark('event_ok')
    x.op(7, 1108, 'edi', PROFILE['first_descriptor_offset']+0x38); x.jump('ne', 'reset_current')
    x.op(7, 865, 'edi', PROFILE['first_descriptor_offset']+0x40); x.jump('ne', 'reset_current')
    x.op(7, 30, 'edi', PROFILE['first_descriptor_offset']+0x44); x.jump('ne', 'reset_current')
    load('ebx', 'ai'); x.load('eax', 'ebx', 0x53E90); save('eax', 'tick')
    for name, off in CONTEXT.items():
        if updated and name=='group':continue
        load('eax', name); x.cmpm('eax', disp=data+off); x.jump('ne', 'new_context')
    load('eax', 'tick'); x.cmpm('eax', disp=data+LAST_TICK); x.jump('below', 'new_context')
    x.jump('jmp', 'context_ready')
    x.mark('new_context')
    x.emit('fc'); x.imm('eax', 0); x.imm('edi', data+TABLE)
    x.imm('ecx', AGENTS*ENTRY_SIZE//4); x.emit('f3ab')
    for name, off in CONTEXT.items():
        if updated and name=='group':x.set(0,disp=data+off);continue
        load('eax', name); x.store('eax', disp=data+off)
    inc(0x34)
    x.mark('context_ready'); load('eax', 'tick'); x.store('eax', disp=data+LAST_TICK)
    load('edi', 'entry'); load('ecx', 'group'); load('edx', 'slot')
    x.op(7, 1, 'edi', 0); x.jump('ne', 'new_entry')
    x.cmpm('ecx', 'edi', 4); x.jump('ne', 'new_entry')
    x.cmpm('edx', 'edi', 8); x.jump('ne', 'new_entry')
    x.mem('2b', R['eax'], 'edi', 12)
    x.cmp('eax', s['max_tracking_gap_ticks'] if updated else s['max_observation_gap_ticks']); x.jump('above', 'new_entry')
    x.jump('jmp', 'entry_ready')
    x.mark('new_entry'); x.set(1, 'edi'); x.store('ecx', 'edi', 4); x.store('edx', 'edi', 8)
    x.set(0, 'edi', 16); x.set(0, 'edi', 20); inc(0x28)
    if not legacy:
        for offset in (24,28,32):x.set(0,'edi',offset)
    if not(legacy or assist_v2):
        x.load('eax',disp=data+MODE_EPOCH);x.store('eax','edi',36);x.set(0,'edi',40)
    x.mark('entry_ready'); load('eax', 'tick'); x.store('eax', 'edi', 12); inc(0x20)
    if not(legacy or assist_v2):
        x.load('eax',disp=data+MODE_EPOCH);x.cmpm('eax','edi',36);x.jump('eq','mode_ready')
        x.store('eax','edi',36);x.set(1,'edi',40)
        for offset in (16,20,24,28,32):x.set(0,'edi',offset)
        x.mark('mode_ready')
    if observe:inc(0xB8)
    if detachment_support:
        require(updated and squad_count==4,'E_DETACHMENT_RECALL_VERSION')
        from detachment import emit_hold_view
        emit_hold_view(x,data,auto_data,a('group'),prefix='recall_hold')
        x.cmp('eax',0);x.jump('eq','recall_follow_anchor')
        # A private view supplies the same position/zone fields consumed below.
        # Identity/context publication above always uses the real player.
        x.ri(5,'eax',0x14);save('eax','player')
        x.mark('recall_follow_anchor')
    stage('INVALID_COORDINATES')
    # Validate finite, bounded world coordinates by their IEEE-754 representation.
    load('ecx', 'player')
    for reg in ('esi', 'ecx'):
        for off in (0x34, 0x38, 0x3C, 0x40):
            x.load('eax', reg, off); x.ri(4, 'eax', 0x7FFFFFFF)
            x.cmp('eax', 0x4CBEBC20); x.jump('above', 'reset_current')
    stage('OK')
    # Save full x87, MMX, XMM0..7 and MXCSR. No call can outlive the busy guard.
    x.emit('89e581ec4002000083e4f0')  # EBP=pushad frame; aligned private FXSAVE area
    x.store('esp', 'ebp', -4); x.mem('0fae', 0, 'esp')
    x.emit('dbe3'); x.set(0x1F80, 'ebp', -8); x.mem('0fae', 2, 'ebp', -8)
    x.emit('fc')
    x.mem('f30f10', 0, 'esi', 0x34); x.mem('f30f5c', 0, 'ecx', 0x34)
    x.emit('f30f59c0')
    x.mem('f30f10', 1, 'esi', 0x3C); x.mem('f30f5c', 1, 'ecx', 0x3C)
    x.emit('f30f59c9f30f58c1')
    if not legacy:
        if not assist_v2:
            x.op(7,1,disp=data+FOLLOW_FLAG);x.jump('eq','assist_reset')
        # A second timer observes the CURRENT target relative to the player.
        # Its mode is published only after the full identity filter above.
        x.load('eax','esi',0x90);x.cmp('eax',0);x.jump('eq','assist_without_target')
        load('ebx','ai');x.lea('edx','ebx',0x21EF8)
        x.rr('39','eax','edx');x.jump('below','assist_without_target')
        x.lea('edx','edx',AGENTS*0xE0);x.rr('39','eax','edx');x.jump('ae','assist_without_target')
        x.load('edx','eax',0x7C);x.cmp('edx',AGENTS);x.jump('ae','assist_without_target')
        x.imul('edx','edx',0xE0);x.rr('01','edx','ebx');x.ri(0,'edx',0x21EF8)
        x.rr('39','eax','edx');x.jump('ne','assist_without_target')
        x.mem('f7',0,'eax',0xCC);x.dword(1);x.jump('eq','assist_without_target')
        for offset in (0x34,0x38,0x3C,0x40):
            x.load('edx','eax',offset);x.ri(4,'edx',0x7FFFFFFF)
            x.cmp('edx',0x4CBEBC20);x.jump('above','assist_without_target')
        x.store('eax','edi',32)
        x.mem('f30f10',2,'eax',0x34);x.mem('f30f5c',2,'ecx',0x34);x.emit('f30f59d2')
        x.mem('f30f10',3,'eax',0x3C);x.mem('f30f5c',3,'ecx',0x3C);x.emit('f30f59dbf30f58d3')
        x.mem('0f2e',2,disp=data+FOCUS2);x.jump('be','assist_reset')
        x.op(7,2,'edi',28);x.jump('eq','assist_ready')
        x.op(7,1,'edi',28);x.jump('eq','assist_counting')
        x.set(1,'edi',28);load('eax','tick');x.store('eax','edi',24);inc(0x6C)
        if delay_seconds==0:
            x.set(2,'edi',28);inc(0x70)
        x.jump('jmp','assist_ready')
        x.mark('assist_counting');load('eax','tick');x.mem('2b',R['eax'],'edi',24)
        x.cmp('eax',s['delay_seconds']*s['ticks_per_second']);x.jump('below','assist_ready')
        x.set(2,'edi',28);inc(0x70);x.jump('jmp','assist_ready')
        x.mark('assist_without_target');x.set(0,'edi',32)
        x.op(7,2,'edi',28);x.jump('ne','assist_reset')
        x.mem('0f2e',0,disp=data+INNER2);x.jump('above','assist_ready')
        x.mark('assist_reset');x.set(0,'edi',24);x.set(0,'edi',28)
        x.mark('assist_ready')
        x.op(7,2,'edi',28);x.jump('ne','assist_done')
        x.mem('0f2e',0,disp=data+INNER2);x.jump('be','assist_done')
        # No additional wait: the combat timer has already expired.
        x.set(2,'edi',20)
        x.mark('assist_done')
    if not(legacy or assist_v2):
        x.op(7,1,'edi',40);x.jump('eq','priority_check')
    x.op(7, 2, 'edi', 20); x.jump('eq', 'recalling')
    x.mem('0f2e', 0, disp=data+OUTER2); x.jump('be', 'inside_outer')
    x.op(7, 1, 'edi', 20); x.jump('eq', 'counting')
    x.set(1, 'edi', 20); load('eax', 'tick'); x.store('eax', 'edi', 16)
    if delay_seconds==0:
        x.set(2,'edi',20);x.jump('jmp','recalling')
    else:x.jump('jmp', 'restore')
    x.mark('counting'); load('eax', 'tick'); x.mem('2b', R['eax'], 'edi', 16)
    x.cmp('eax', s['delay_seconds']*s['ticks_per_second']); x.jump('below', 'restore')
    x.set(2, 'edi', 20); x.mark('recalling')
    x.mem('0f2e', 0, disp=data+INNER2); x.jump('be', 'inside_inner')
    if not(legacy or assist_v2):x.mark('priority_check')
    if observe:x.jump('jmp','restore')
    stage('PRIORITY_STATE')
    # A native forced timer/state wins; retain pending recall for an ordinary frame.
    x.op(7, 0, 'esi', 0xBC); x.jump('ne', 'priority')
    x.mem('f7', 0, 'esi', 0xCC); x.dword(0x20020000); x.jump('ne', 'priority')
    x.load('eax', 'esi', 0x88); x.load('edx', 'ebp', 24)
    x.rr('39', 'eax', 'edx'); x.jump('ne', 'priority')
    for state in s['ordinary_states']:
        x.cmp('eax', state); x.jump('eq', 'move')
    x.mark('priority'); inc(0x2C); x.jump('jmp', 'restore')
    x.mark('move');stage('INVALID_TARGET')
    # If a target exists, it must be an exact member of the native agent pool.
    x.load('eax', 'esi', 0x90); x.cmp('eax', 0); x.jump('eq', 'release')
    load('ebx', 'ai'); x.lea('ecx', 'ebx', 0x21EF8)
    x.rr('39', 'eax', 'ecx'); x.jump('below', 'bad_target')
    x.lea('edx', 'ecx', AGENTS*0xE0); x.rr('39', 'eax', 'edx'); x.jump('ae', 'bad_target')
    x.load('edx', 'eax', 0x7C); x.cmp('edx', AGENTS); x.jump('ae', 'bad_target')
    x.imul('edx', 'edx', 0xE0); x.rr('01', 'edx', 'ecx')
    x.rr('39', 'eax', 'edx'); x.jump('ne', 'bad_target')
    x.mark('release');stage('OK'); x.call(code, base+s['native_release_rva'])
    # Helpers may clobber caller-saved registers. Resolve inputs again afterwards.
    load('eax', 'agent_id'); load('ebx', 'ai'); x.imul('eax', 'eax', 0xE0)
    x.rr('01', 'eax', 'ebx'); x.ri(0, 'eax', 0x21EF8); save('eax', 'wrapper')
    load('ecx', 'player')
    x.emit('6800000000'); x.emit('68'); x.dword(struct.unpack('<I', struct.pack('<f', s['arrival_tolerance']))[0])
    x.mem('0fb6', R['edx'], 'ecx', 0xD0); x.emit('52')
    x.lea('ecx', 'ecx', 0x34); x.emit('51'); x.imm('eax', a('wrapper'))
    x.call(code, base+s['native_move_rva'])  # native RET 16 owns argument cleanup
    if not(legacy or assist_v2):
        load('edi','entry');x.op(7,1,'edi',40);x.jump('ne','rally_done')
        x.set(0,'edi',40);inc(0xA8);x.mark('rally_done')
    inc(0x24); x.set(1, disp=a('skip')); x.jump('jmp', 'restore')
    x.mark('bad_target'); x.set(0, 'edi'); x.set(0, 'edi', 20); x.jump('jmp', 'restore')
    x.mark('inside_inner'); inc(0x30)
    x.mark('inside_outer'); x.set(0, 'edi', 20); x.set(0, 'edi', 16)
    x.mark('restore'); x.load('esp', 'ebp', -4); x.mem('0fae', 1, 'esp')
    x.emit('89ec')  # original pushad frame
    x.jump('jmp', 'finish')
    x.mark('reset_context'); x.set(0, disp=data+CONTEXT['sequence'])
    x.jump('jmp', 'finish')
    x.mark('reset_current'); load('eax', 'entry'); x.cmp('eax', 0); x.jump('eq', 'finish')
    x.set(0, 'eax'); x.set(0, 'eax', 20)
    if not legacy:
        for offset in (24,28,32):x.set(0,'eax',offset)
    x.mark('finish')
    if diag:diag.finish('diagnostics_done')
    x.set(0, disp=data+16)
    x.op(7, 1, disp=a('skip')); x.jump('eq', 'override_return')
    x.mark('transparent'); x.emit('619d')
    if observe:
        spec=s['sites']['AGENT_OBSERVE_LOOP'];original=bytes.fromhex(spec['original'])
        require(original==bytes.fromhex('f687cc00000001'),'E_OBSERVER_NATIVE_TEST')
        x.emit(original)
        x.emit(relative_jump(code+len(x.code),base+spec['site_rva']+len(original)))
    else:x.emit(relative_jump(code+len(x.code), base+s['native_dispatch_rva']))
    x.mark('override_return'); x.emit('619dc3')
    payload = x.finish()
    require(len(payload) < 0x4000, 'E_RECALL_BRIDGE_SIZE')
    return payload
