"""Lifecycle helpers for optional, independently journaled v5 additions."""
import ctypes as C
from ctypes import wintypes as W
import hashlib
import struct
from core import BUILD,require,uint,word
from bridge import relative_jump


def all_patches(session):
    lease=session.lease or {};result=list(lease.get('patches',[]))
    for key in ('offensive_ai','tactical_balance','ambition_bonus','guard_army','zone_balance','guard_orders','population','visibility','story_guards','map_markers','detachment','native_hud','personal_movement','ambition_duel','duel_officer_drops','npc_many','npc_render_request','damage_audit','guard_damage','officer_crowd','officer_hit_audit','officer_pursuit','reinforcement_delay','npc_allocation_balance','fog_distance','ambition_guards'):
        result.extend(lease.get(key,{}).get('patches',[]))
    timer=lease.get('ambition_timer') or {}
    result.extend(p for p in (timer,timer.get('secondary') or {}) if 'site' in p)
    return result


def prepare(module,base,data,code,auto,recall,*,version=None):
    version=module.VERSION if version is None else version
    require(version==module.VERSION or version in getattr(module,'LEGACY_VERSIONS',(getattr(module,'LEGACY_VERSION',None),)),'E_EXTRA_VERSION')
    patches=[]
    sites=getattr(module,'LEGACY_SITES',module.SITES) if version!=module.VERSION else module.SITES
    sites=getattr(module,'LEGACY_SITES_BY_VERSION',{}).get(version,sites)
    for i,(name,(rva,native)) in enumerate(sites.items()):
        if hasattr(module,'original'):native=module.original(base,name).hex()
        address=code+i*0x4000
        kwargs={'legacy':True} if version!=module.VERSION else {}
        if kwargs and hasattr(module,'LEGACY_VERSIONS'):kwargs['legacy_version']=version
        payload=module.build_bridge(base,data,address,auto,recall,name,**kwargs)
        require(len(payload)<0x4000,'E_EXTRA_PAYLOAD_SIZE')
        patches.append({'mode':name,'site':base+rva,'code_address':address,
            'code_size':len(payload),'code_sha256':hashlib.sha256(payload).hexdigest(),
            'original_hex':native,'replacement_hex':relative_jump(base+rva,address,len(bytes.fromhex(native))).hex(),
            'installed':False})
    return {'version':version,'data_address':data,'code_address':code,
            'auto_data_address':auto,'recall_data_address':recall,'patches':patches,'state':'PREPARED'}


def initial_data(module,auto,recall):
    raw=bytearray(module.SIZE);struct.pack_into('<4I',raw,0,module.MAGIC,module.VERSION,0,0)
    struct.pack_into('<2I',raw,0x70,auto,recall)
    if hasattr(module,'initialize_data'):module.initialize_data(raw)
    return bytes(raw)


def validate(module,memory,record):
    data,code=record.get('data_address',0),record.get('code_address',0)
    data_size=getattr(module,'LEGACY_SIZES',{}).get(record.get('version'),module.SIZE)
    code_size=getattr(module,'LEGACY_CODE_SIZES',{}).get(record.get('version'),module.CODE_SIZE)
    spans=[(data,data_size),(code,code_size),
           (record.get('auto_data_address',0),0x3000),(record.get('recall_data_address',0),0x4000)]
    require(all(0x10000<=a and a+n<0xFF000000 for a,n in spans),'E_EXTRA_ALLOCATION')
    require(all(a+n<=b or b+m<=a for i,(a,n) in enumerate(spans) for b,m in spans[i+1:]),'E_EXTRA_ALLOCATION_OVERLAP')
    expected=prepare(module,memory.base,data,code,record['auto_data_address'],record['recall_data_address'],version=record.get('version'))
    require(all(record.get(k)==v for k,v in expected.items() if k not in ('state','patches')),'E_EXTRA_IDENTITY')
    require(len(record.get('patches',[]))==len(expected['patches']),'E_EXTRA_PATCH_COUNT')
    for saved,wanted in zip(record['patches'],expected['patches']):
        require(all(saved.get(k)==v for k,v in wanted.items() if k!='installed'),'E_EXTRA_PATCH_IDENTITY')
        current=memory.read(saved['site'],len(bytes.fromhex(saved['original_hex'])))
        require(current in (bytes.fromhex(saved['original_hex']),bytes.fromhex(saved['replacement_hex'])),'E_EXTRA_SITE_CONFLICT')
        saved['installed']=current==bytes.fromhex(saved['replacement_hex'])
        require(hashlib.sha256(memory.read(saved['code_address'],saved['code_size'])).hexdigest()==saved['code_sha256'],'E_EXTRA_CODE_CHANGED')
    raw=memory.read(data,0x78)
    require(word(raw)==module.MAGIC and word(raw,4)==record['version'] and word(raw,8) in (0,1)
            and word(raw,12) in (0,1) and word(raw,0x70)==record['auto_data_address']
            and word(raw,0x74)==record['recall_data_address'],'E_EXTRA_DATA_HEADER')
    module.check_code(memory)
    if hasattr(module,'validate_data'):module.validate_data(memory,record)


def public(module,memory,record):
    result={'available':True,'enabled':False,'hook_installed':False,'feature':module.FEATURE,'live_validated':False}
    if not record:return result
    raw=memory.read(record['data_address'],0x80)
    require(word(raw)==module.MAGIC and word(raw,4)==record['version'] and word(raw,8) in (0,1),'E_EXTRA_DATA_HEADER')
    result.update(enabled=bool(word(raw,8) and all(p['installed'] for p in record['patches'])),
                  hook_installed=any(p['installed'] for p in record['patches']),busy=bool(word(raw,12)),
                  revision=record['version'],legacy_hook_requires_upgrade=record['version']!=module.VERSION,
                  **{k:word(raw,o) for k,o in module.COUNTERS.items()})
    return result


def set_bundle(session,key,module,enabled,*,remove=False,prepare_disabled=False):
    require(not enabled or not getattr(module,'ACTIVATION_BLOCKED',None),getattr(module,'ACTIVATION_BLOCKED','E_EXTRA_BLOCKED'))
    require(type(enabled) is bool and type(remove) is bool and type(prepare_disabled) is bool,'E_EXTRA_ARGUMENT')
    require(not prepare_disabled or (not enabled and not remove),'E_EXTRA_PREPARE_ARGUMENT')
    require(session.lease and session.lease['build']==BUILD and session.installed(),'E_EXTRA_CURRENT_SESSION')
    record=session.lease.get(key)
    if not enabled and not record and not prepare_disabled:return module.public(session,None)
    if not record:
        module.check_code(session)
        for name,(rva,native) in module.SITES.items():
            if hasattr(module,'original'):native=module.original(session.base,name).hex()
            require(session.read(session.base+rva,len(bytes.fromhex(native)))==bytes.fromhex(native),'E_EXTRA_FOREIGN_SITE')
        if session.writer is None:session.open_writer()
        data=session.allocate(module.SIZE);code=session.allocate(module.CODE_SIZE)
        auto=session.lease['data_address'];recall=session.lease['recall_data_address']
        raw=initial_data(module,auto,recall);session.write(data,raw)
        # Memory.read deliberately caps one request at 1 MiB. The immutable
        # personal-order arena is larger: verify every byte in bounded chunks
        # before publishing any hook, rather than weakening that transport cap.
        for offset in range(0,len(raw),0x100000):
            part=raw[offset:offset+0x100000]
            require(session.read(data+offset,len(part))==part,'E_EXTRA_INITIAL_DATA_VERIFY')
        record=prepare(module,session.base,data,code,auto,recall)
        for p in record['patches']:
            payload=module.build_bridge(session.base,data,p['code_address'],auto,recall,p['mode'])
            session.write(p['code_address'],payload)
            require(session.read(p['code_address'],len(payload))==payload,'E_EXTRA_PAYLOAD_VERIFY')
        from windows_memory import k,check
        prior=W.DWORD();check(k.VirtualProtectEx(session.writer,code,module.CODE_SIZE,0x20,C.byref(prior)))
        check(k.FlushInstructionCache(session.writer,code,module.CODE_SIZE))
        session.log(key.upper()+'_PREPARED',**{key:record})
    validate(module,session,record)
    require(remove or record['version']==module.VERSION,'E_EXTRA_LEGACY_RESTART_REQUIRED')
    require(record['auto_data_address']==session.lease['data_address'] and
            record['recall_data_address']==session.lease['recall_data_address'],'E_EXTRA_MAIN_BINDING')
    if not remove and all(p['installed'] for p in record['patches']) and uint(session,record['data_address']+8)==int(enabled):
        return module.public(session,record)
    spans=[s for p in all_patches(session) for s in
           ((p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),
            (p['code_address'],p['code_address']+p['code_size']))]
    with session.quiesce(spans):
        validate(module,session,record)
        require(uint(session,record['data_address']+12)==0,'E_EXTRA_BRIDGE_EXECUTING_RETRY')
        require(uint(session,session.lease['recall_data_address']+16)==0,'E_RECALL_BRIDGE_EXECUTING_RETRY')
        before=uint(session,record['data_address']+8);was=[p['installed'] for p in record['patches']]
        changes=[]
        session.write(record['data_address']+8,bytes(4))
        record['state']='PENDING';session.log(key.upper()+'_CHANGE_PENDING')
        try:
            if hasattr(module,'changes_for_enabled'):
                for address,old,new in module.changes_for_enabled(session,record,enabled and not remove):
                    require(session.read(address,len(old))==old,'E_EXTRA_MUTATION_CHANGED')
                    changes.append((address,old,new));session.write(address,new)
                    require(session.read(address,len(new))==new,'E_EXTRA_MUTATION_VERIFY')
            for p in (list(reversed(record['patches'])) if remove else record['patches']):
                if remove and p['installed']:
                    session.patch_site(p['site'],bytes.fromhex(p['replacement_hex']),bytes.fromhex(p['original_hex']))
                    p['installed']=False
                elif not remove and not p['installed']:
                    p['installed']=True;session.log(key.upper()+'_PATCH_PENDING')
                    session.patch_site(p['site'],bytes.fromhex(p['original_hex']),bytes.fromhex(p['replacement_hex']))
            session.write(record['data_address']+8,struct.pack('<I',int(enabled and not remove)))
            require(uint(session,record['data_address']+8)==int(enabled and not remove),'E_EXTRA_ENABLE_VERIFY')
            record['state']='RESTORED' if remove else 'APPLIED';session.log(key.upper()+'_UPDATED')
        except Exception:
            for address,old,new in reversed(changes):
                session.write(address,old)
                require(session.read(address,len(old))==old,'E_EXTRA_MUTATION_ROLLBACK')
            for p,old in reversed(list(zip(record['patches'],was))):
                current=session.read(p['site'],len(bytes.fromhex(p['original_hex'])))
                require(current in (bytes.fromhex(p['original_hex']),bytes.fromhex(p['replacement_hex'])),'E_EXTRA_ROLLBACK_CONFLICT')
                if not old and current==bytes.fromhex(p['replacement_hex']):
                    session.patch_site(p['site'],current,bytes.fromhex(p['original_hex']))
                p['installed']=session.read(p['site'],len(current))==bytes.fromhex(p['replacement_hex'])
            complete=all(p['installed'] for p in record['patches'])
            session.write(record['data_address']+8,struct.pack('<I',before if complete else 0))
            record['state']='APPLIED' if complete else ('PENDING' if any(p['installed'] for p in record['patches']) else 'RESTORED')
            session.log(key.upper()+'_ROLLED_BACK');raise
    return module.public(session,record)
