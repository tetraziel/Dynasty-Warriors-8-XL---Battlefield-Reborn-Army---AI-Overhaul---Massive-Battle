"""Research layout: append group buffers while preserving native fixed fields.

No allocator or process adapter. Native references still need full coverage.
"""
import math
from core import require
from pool_expansion import capacity,scratch_layout

SIZES={'manager':0xE6360,'ai':0x53EC0,'requests':0xD1F0}
BASES={'manager_groups':0x10E50,'ai_groups':0xA7F8,'request_groups':0x80,
       'group_free_ids':0x72150,'group_selection':0x83C0,'scratch':0x98EC}


def place(cursor,native_offset,stride):
    # Preserve congruence for common compressed address expressions, including
    # expressions based on the record stride and powers of two up to a page.
    modulus=math.lcm(0x1000,stride)
    start=native_offset+((cursor-native_offset+modulus-1)//modulus)*modulus
    require(start>=cursor and (start-native_offset)%modulus==0,'E_APPEND_ALIGNMENT')
    return start


def layout(count):
    capacity(count);scratch=scratch_layout(count)['allocated_bytes'];buffers={}
    def add(name,kind,old,size,stride):
        if count==600:start=old
        else:start=place(ends[kind],old,stride)
        buffers[name]={'object':kind,'native_offset':old,'offset':start,'size':size,
                       'end':start+size,'stride':stride}
        if count!=600:ends[kind]=start+size
    ends=dict(SIZES)
    add('manager_groups','manager',0x10E50,count*0x268,0x268)
    add('group_free_ids','manager',0x72150,count*4,4)
    add('ai_groups','ai',0xA7F8,count*0xA0,0xA0)
    add('request_groups','requests',0x80,count*0x30,0x30)
    add('group_selection','requests',0x83C0,count*8+4,8)
    add('scratch','requests',0x98EC,scratch,1)
    sizes={kind:(end+15)&~15 for kind,end in ends.items()}
    if count!=600:
        for kind in SIZES:
            rows=sorted((r for r in buffers.values() if r['object']==kind),key=lambda r:r['offset'])
            require(rows[0]['offset']>=SIZES[kind],'E_APPEND_PREFIX_OVERLAP')
            require(all(a['end']<=b['offset'] for a,b in zip(rows,rows[1:])),'E_APPEND_BUFFER_OVERLAP')
            require(rows[-1]['end']<=sizes[kind],'E_APPEND_OBJECT_END')
    return {'strategy':'APPENDED_GROUP_BUFFERS_RESEARCH','capacity':count,'agent_capacity':150,
        'buffers':buffers,'sizes':sizes,'native_prefix_sizes':dict(SIZES),
        'added_object_bytes':sum(sizes[k]-SIZES[k] for k in SIZES),
        'fixed_offsets':{'manager_agents':0x6B210,'player_descriptors':0x6CE68,
            'manager_queue_root':0x71EE4,'manager_group_queue_header':0x72AB0,
            'manager_agent_queue_header':0x7213C,'ai_agents':0x21EF8,
            'request_agents':0x7100,'request_agent_selection':0x9684,
            'request_controls':0x98E0,'request_worker':0xD1BC},
        'native_worker_offset_preserved':True,'agent_pool_expanded':False,
        'all_native_references_verified':False,'live_installation_supported':False}
