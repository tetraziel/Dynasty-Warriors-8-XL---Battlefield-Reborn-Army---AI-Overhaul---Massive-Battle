"""Read-only candidate for the global blue/red HUD balance; no Windows imports.

Native HUD RVA 0x560850 reads force[0].68 and force[1].68 and draws their
ratio at x=926..1182, y=54 in the HUD reference coordinates. The old
zone+41 timing input is separate. This reader never enables troop scaling.
"""
import struct

HOST_DIAGNOSTICS_BUILD='v5-gate-morale-controls-3'
FORCE_START=0x58
FORCE_STRIDE=0x22C
VALUE_OFFSET=0x68
NATIVE_MAX=999


def decode_balance(raw,player_side):
    if len(raw)!=2*FORCE_STRIDE:
        return {'available':False,'reason':'E_HUD_BALANCE_SHORT_RECORD'}
    def u(side,off):return struct.unpack_from('<I',raw,side*FORCE_STRIDE+off)[0]
    ids=[u(side,0) for side in (0,1)]
    values=[u(side,VALUE_OFFSET) for side in (0,1)]
    reason=('E_HUD_BALANCE_SIDE_IDS' if ids!=[0,1] else
            ('E_HUD_BALANCE_PLAYER_SIDE' if player_side not in (0,1) else
             ('E_HUD_BALANCE_NATIVE_RANGE' if any(v>NATIVE_MAX for v in values) else None)))
    result={'available':reason is None,'reason':reason,'source':'NATIVE_HUD_FORCE_68',
            'side_ids':ids,'side_0_value':values[0],'side_1_value':values[1],
            'player_side':player_side,'native_clamp_observed':[0,NATIVE_MAX],
            'hud_dataflow_verified_offline':True,'live_screenshot_correlation_verified':False,
            'morale_tiers_enabled':False,'policy_applied':False,'read_only':True}
    if reason:return result
    total=sum(values)
    share=values[0]/total if total else 0.5
    result.update(player_value=values[player_side],opponent_value=values[1-player_side],
                  blue_share=share,red_share=1-share,
                  player_share=share if player_side==0 else 1-share,
                  zero_total_fallback=total==0)
    return result


def read_balance(memory,state):
    owner=state['manager']+0x4B0+state['owner']*0x110
    player_side=struct.unpack('<I',memory.read(owner+0x40,4))[0]
    raw=memory.read(state['manager']+FORCE_START,2*FORCE_STRIDE)
    result=decode_balance(raw,player_side)
    result['value_addresses']=[hex(state['manager']+FORCE_START+side*FORCE_STRIDE+VALUE_OFFSET)
                               for side in (0,1)]
    return result
