"""Optional local follow view and native personal-leader class exception."""
import struct
from core import require,word
from bridge import relative_jump
from recall_bridge import Asm,R,AGENTS,TABLE,ENTRY_SIZE,CONTEXT,FOLLOW_FLAG,FOLLOW_VIEW
from recall_bridge import MAGIC as RECALL_MAGIC,VERSION as RECALL_VERSION
from auto_bridge import AUTO_MAGIC,AUTO_VERSION
from target_bridge import FIELDS
from scope_bridge import emit_actor_scope
from detachment import emit_hold_view
from pool_binding import resolve as resolve_pool
import bundle_support as bundle
import personal_classification as classification
from diagnostics import REASONS as SHARED_REASONS

FEATURE='PERSONAL_SQUADS_CONTINUOUS_FOLLOW_TEST'
MAGIC=0x31464D50;VERSION=4;LEGACY_VERSION=1;LEGACY_VERSIONS=(1,2,3);SIZE=0x1000;CODE_SIZE=0x8000
LEGACY_CODE_SIZES={1:0x4000,2:0x4000,3:0x8000}
LEGACY_SITES={'PERSONAL_MOVE_ORDER':(0x5A120E,'8b8684000000')}
SITES={**LEGACY_SITES,'PERSONAL_LEADER_CLASS':classification.SITE}
LEGACY_SITES_BY_VERSION={3:SITES}
COUNTERS={'visits':0x10,'follow_views':0x14,'defense_views':0x18,
          'scope_refusals':0x1C,'combat_targets_preserved':0x20}
MOVEMENT_STATES=(39,)
DIAG_STAGE,DIAG_LAST,DIAG_RESULT,REASON_COUNTS,OBSERVED=0x80,0x84,0x88,0x100,0x200
RECALL_BUSY=0x44
REASONS=(*SHARED_REASONS,'RECALL_HEADER','ACTOR_POINTER','WRAPPER_LINK',
    'ACTOR_FLAGS','ACTOR_TIMER','ACTOR_SUBTYPE','ACTOR_CLASS','MOVEMENT_STATE',
    'LOCAL_GROUP_AI','LOCAL_OWNER','OWNER_ORDER','COMMIT_CONTEXT','COMMIT_ACTOR_STATE')
OBSERVED_FIELDS=('actor','agent_id','state','actor_class','subtype','forced_timer',
                 'flags','target','observation_tick','current_tick')
RESULTS={0:'WAITING_NATIVE_CALL',1:'FOLLOW_VIEW',2:'DEFENSE_VIEW',
         3:'COMBAT_TARGET_PRESERVED',4:'SCOPE_REFUSED',5:'RECALL_BUSY'}


class MovementDiagnostics:
    def __init__(self,x,data):self.x=x;self.data=data
    def stage(self,name):self.x.set(REASONS.index(name),disp=self.data+DIAG_STAGE)
    def rejected(self):
        x=self.x;d=self.data
        x.load('eax',disp=d+DIAG_STAGE);x.store('eax',disp=d+DIAG_LAST)
        x.imul('edx','eax',4);x.ri(0,'edx',d+REASON_COUNTS);x.mem('ff',0,'edx')
        x.set(4,disp=d+DIAG_RESULT)


def original(base,name):
    return classification.original(base) if name=='PERSONAL_LEADER_CLASS' else bytes.fromhex(LEGACY_SITES[name][1])


def build_bridge(base,data,code,auto,recall,name,*,pool=None,legacy=False,legacy_version=1):
    version=legacy_version if legacy else VERSION
    sites=LEGACY_SITES if legacy and version<3 else SITES
    p=resolve_pool(pool);require(name in sites and version in (1,2,3,4),'E_PERSONAL_MOVE_SITE')
    if name=='PERSONAL_LEADER_CLASS':
        return classification.build_bridge(base,data,code,auto,recall,magic=MAGIC,version=version,pool=p)
    x=Asm();diag=None if version==1 else MovementDiagnostics(x,data)
    inc=lambda off:x.mem('ff',0,disp=data+off)
    def load(reg,n):x.load(reg,disp=recall+FIELDS[n])
    def save(reg,n):x.store(reg,disp=recall+FIELDS[n])
    x.emit('9c60')
    for off,value in ((0,MAGIC),(4,version),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=recall+16);x.jump('ne','recall_busy' if diag else 'unlock')
    inc(0x10)
    if diag:
        x.set(0,disp=data+OBSERVED+0x28);diag.stage('RECALL_HEADER')
    for address,value in ((recall,RECALL_MAGIC),(recall+4,RECALL_VERSION),(recall+8,1),
                          (recall+12,0),(recall+FOLLOW_FLAG,1),(auto,AUTO_MAGIC),(auto+4,AUTO_VERSION)):
        x.op(7,value,disp=address);x.jump('ne','scope_failed')
    # EDI is the actor already dereferenced by the native routine. EBP is
    # its group AI; ESI its actual owner. Preserve this exact local contract.
    if diag:diag.stage('ACTOR_POINTER')
    x.load('esi','esp',0);x.load('ebx',disp=base+0x6A91D8);x.sane('ebx','scope_failed')
    x.lea('ecx','ebx',0x21EF8);x.rr('39','esi','ecx');x.jump('below','scope_failed')
    x.lea('edx','ecx',AGENTS*0xE0);x.rr('39','esi','edx');x.jump('ae','scope_failed')
    x.load('eax','esi',0x7C);x.cmp('eax',AGENTS);x.jump('ae','scope_failed')
    x.imul('edx','eax',0xE0);x.rr('01','edx','ecx');x.rr('39','esi','edx');x.jump('ne','scope_failed')
    x.imul('edi','eax',ENTRY_SIZE);x.ri(0,'edi',recall+TABLE)
    save('esi','agent');save('edi','entry')
    if diag:
        # Capture only after the exact native-pool address has been validated.
        for reg,off in (('esi',0),('eax',4)):
            x.store(reg,disp=data+OBSERVED+off)
        for src,dst,size in ((0x88,8,4),(0x84,12,4),(0xD2,16,1),(0xBC,20,4),(0xCC,24,4),(0x90,28,4)):
            if size==1:x.mem('0fb6',R['eax'],'esi',src)
            else:x.load('eax','esi',src)
            x.store('eax',disp=data+OBSERVED+dst)
        x.load('eax','edi',12);x.store('eax',disp=data+OBSERVED+32)
        x.load('eax','ebx',0x53E90);x.store('eax',disp=data+OBSERVED+36)
        x.set(1,disp=data+OBSERVED+0x28)
        diag.stage('WRAPPER_LINK');x.load('eax','esp',16);x.sane('eax','scope_failed')
        x.load('eax','eax');x.rr('39','eax','esi');x.jump('ne','scope_failed')
    emit_actor_scope(x,base,recall,auto,FIELDS,require_combat=False,squad_count=4,pool=p,
                     **({'diag':diag,'allowed_states':MOVEMENT_STATES} if diag else {}))
    if diag:diag.stage('LOCAL_OWNER')
    x.op(7,0,disp=recall+CONTEXT['owner']);x.jump('ne','scope_failed')
    if diag:diag.stage('LOCAL_GROUP_AI')
    x.load('eax','esp',8);x.cmpm('eax',disp=recall+FIELDS['group_ai']);x.jump('ne','scope_failed')
    if diag:diag.stage('LOCAL_OWNER')
    x.load('eax','esp',4);x.cmpm('eax',disp=recall+FIELDS['ai']);x.jump('ne','scope_failed')
    x.load('ecx','eax',0x84);x.store('ecx',disp=data+0x2C)
    if diag:diag.stage('OWNER_ORDER')
    x.cmp('ecx',0);x.jump('ne','scope_failed')
    # Keep native combat locomotion while a target is engaged nearby. A
    # validated pending recall (entry+20=2) may still return a far soldier.
    load('esi','agent');x.op(7,0,'esi',0x90);x.jump('eq','choose_view')
    load('edi','entry');x.op(7,2,'edi',20);x.jump('eq','choose_view')
    inc(0x20)
    if diag:x.set(3,disp=data+DIAG_RESULT)
    x.jump('jmp','finish')
    x.mark('choose_view')
    emit_hold_view(x,recall,auto,recall+FIELDS['group'],prefix='personal_move_hold')
    x.cmp('eax',0);x.jump('eq','follow')
    x.store('eax',disp=data+0x40);x.set(5,disp=data+0x30);x.jump('jmp','accepted')
    x.mark('follow')
    if diag:diag.stage('FOLLOW_VIEW')
    x.op(7,0,disp=recall+FOLLOW_VIEW+0x78);x.jump('ne','scope_failed')
    x.op(7,7,disp=recall+FOLLOW_VIEW+0x84);x.jump('ne','scope_failed')
    x.set(recall+FOLLOW_VIEW,disp=data+0x40);x.set(7,disp=data+0x30)
    x.mark('accepted')
    # Recheck current roots/publication immediately before changing the local
    # native view. Old snapshots stay allocated, but a new battle must not use
    # the previous battle's actor/owner binding.
    if diag:diag.stage('COMMIT_CONTEXT')
    for rva,n in ((0x6A91E8,'manager'),(0x6A91D8,'ai'),(0x6A91EC,'players'),(0x6D10BC,'phase')):
        x.load('eax',disp=base+rva);x.cmpm('eax',disp=recall+CONTEXT[n]);x.jump('ne','scope_failed')
    x.op(7,4,'eax',0x1C784);x.jump('ne','scope_failed')
    x.load('eax',disp=auto+16);x.cmpm('eax',disp=recall+CONTEXT['sequence']);x.jump('ne','scope_failed')
    for address,value in ((auto+12,0),(auto+20,0),(auto+24,1),(recall+8,1),(recall+12,0),(recall+FOLLOW_FLAG,1)):
        x.op(7,value,disp=address);x.jump('ne','scope_failed')
    if diag:
        diag.stage('COMMIT_ACTOR_STATE');load('esi','agent')
        x.op(7,39,'esi',0x88);x.jump('ne','scope_failed')
        x.mem('f7',0,'esi',0xCC);x.dword(1);x.jump('eq','scope_failed')
        x.mem('f7',0,'esi',0xCC);x.dword(0x28020000);x.jump('ne','scope_failed')
        x.op(7,0,'esi',0xBC);x.jump('ne','scope_failed')
        x.mem('0fb6',R['eax'],'esi',0xD2);x.cmp('eax',0);x.jump('ne','scope_failed')
    x.load('eax',disp=data+0x40);x.store('eax','esp',4)
    x.op(7,5,disp=data+0x30);x.jump('ne','count_follow');inc(0x18)
    if diag:x.set(2,disp=data+DIAG_RESULT)
    x.jump('jmp','count_done')
    x.mark('count_follow');inc(0x14)
    if diag:x.set(1,disp=data+DIAG_RESULT)
    x.mark('count_done')
    load('eax','agent');x.load('eax','eax',0x7C);x.store('eax',disp=data+0x24)
    load('eax','group_id');x.store('eax',disp=data+0x28)
    load('eax','ai');x.load('eax','eax',0x53E90);x.store('eax',disp=data+0x34)
    x.jump('jmp','finish');x.mark('scope_failed');inc(0x1C)
    if diag:diag.rejected()
    x.mark('finish');x.set(0,disp=recall+16)
    if diag:
        x.jump('jmp','unlock');x.mark('recall_busy');inc(RECALL_BUSY);x.set(5,disp=data+DIAG_RESULT)
    x.mark('unlock');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d');x.emit(SITES[name][1])
    x.emit(relative_jump(code+len(x.code),base+0x5A1214))
    return x.finish()


def validate_data(memory,record):
    if record['version']==LEGACY_VERSION:return
    # The table contract is specific to this callback, not an assumption that
    # the ordinary movement states can reach every native order consumer.
    signature=bytes.fromhex('89018b80880000008b1485')+struct.pack('<I',memory.base+0x65A2D0)+bytes.fromhex('ffe2')
    require(memory.read(memory.base+0x4EEA90,len(signature))==signature,'E_PERSONAL_MOVE_DISPATCHER')
    require(memory.read(memory.base+0x65A36C,4)==struct.pack('<I',memory.base+0x5A11D0),
            'E_PERSONAL_MOVE_CALLBACK_TABLE')


def check_code(memory):
    for rva,sig in ((0x5A11D0,'558bec83e4f883ec68'),
                    (0x5A11E5,'8b3b80bfd2000000008baf800000008b7578'),
                    (0x5A121A,'83c0fbd95c241c83f8120f870e070000'),
                    (0x5A1238,'8b767881fefa000000'),
                    (0x5A12E6,'8b5624d945688b4e20'),
                    (0x514FF0,'568bf1578bf881fe96000000'),
                    (0x515014,'83780c007529'),
                    (0x51503E,'bf01000000'),
                    (0x515049,'69f6e0000000'),
                    (0x515068,'c680da0000000089b884000000')):
        raw=bytes.fromhex(sig)
        require(memory.read(memory.base+rva,len(raw))==raw,'E_PERSONAL_MOVE_NATIVE_'+hex(rva))


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(scope='FOUR_VALIDATED_PERSONAL_INFANTRY_SQUADS',
        implementation=('LOCAL_MOVEMENT_VIEW_AND_NATIVE_LEADER_CLASS' if record and record['version']>=3 else 'LOCAL_NATIVE_MOVEMENT_ORDER_VIEW'),camera_flags_modified=False,
        owner_orders_modified=False,positions_written=False,native_calls_added=0,
        native_combat_and_forced_states_preserved=True,defense_view_supported=True,
        counters_cumulative=True,
        movement_states=list(MOVEMENT_STATES),diagnostic_revision=record['version'] if record else VERSION,
        camera_causality_live_verified=False,live_validated=False)
    result['leader_classification']=classification.public(memory,record)
    if record:
        raw=memory.read(record['data_address'],0x38)
        result['native_consumer_observed']=bool(word(raw,0x10))
        result['local_view_applied']=bool(word(raw,0x14) or word(raw,0x18))
        result['last_view']={name:word(raw,off) for name,off in
            (('agent',0x24),('group',0x28),('original_order',0x2C),('local_order',0x30),('tick',0x34))}
        if record['version']>=2:
            raw=memory.read(record['data_address'],0x22C)
            code=word(raw,DIAG_LAST)
            result['recall_busy_skips']=word(raw,RECALL_BUSY)
            result['diagnostics']={'last_rejection':REASONS[code] if 0<code<len(REASONS) else None,
                'last_result':RESULTS.get(word(raw,DIAG_RESULT),'INVALID_RESULT'),
                'reasons':{reason:word(raw,REASON_COUNTS+4*i) for i,reason in enumerate(REASONS)
                           if i and word(raw,REASON_COUNTS+4*i)},
                'observed_actor':({name:word(raw,OBSERVED+4*i) for i,name in enumerate(OBSERVED_FIELDS)}
                                  if word(raw,OBSERVED+0x28)==1 else None)}
        else:result.update(movement_states=None,diagnostic_revision=1,diagnostics=None)
    return result
