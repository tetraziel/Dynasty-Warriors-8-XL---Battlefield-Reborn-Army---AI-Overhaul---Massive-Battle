"""Skip positive native time rewards in supported single-player Ambition."""
from core import require
from recall_bridge import Asm,R
from bridge import relative_jump
import bundle_support as bundle

FEATURE='AMBITION_NO_POSITIVE_TIME_BONUSES'
MAGIC=0x38424D41;VERSION=1;SIZE=0x1000;CODE_SIZE=0x4000
SITES={'TIME_REWARD':(0x544A30,'558bec83e4f8')}
COUNTERS={'visits':0x10,'bonuses_suppressed':0x14,'seconds_suppressed':0x18,'scope_skips':0x1C}

def build_bridge(base,data,code,auto,recall,name):
    require(name=='TIME_REWARD','E_BONUS_SITE')
    x=Asm();x.emit('9c60')
    for off,value in ((0,MAGIC),(4,VERSION),(8,1)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','native')
    x.mem('ff',0,disp=data+0x10)
    # Cdecl argument remains at original ESP+4, now ESP+40. Only positive
    # bounded rewards are skipped; penalties and unsupported contexts replay.
    x.load('edx','esp',40);x.cmp('edx',1);x.jump('below','skip')
    x.cmp('edx',3600);x.jump('above','skip')
    x.mem('0fb7',R['eax'],disp=base+0x848530);x.cmp('eax',1);x.jump('ne','skip')
    x.load('edi',disp=base+0x6A9200);x.sane('edi','skip')
    x.load('eax','edi');x.ri(4,'eax',0x20003E01);x.cmp('eax',0x1000);x.jump('ne','skip')
    x.load('eax',disp=base+0x6A91EC);x.sane('eax','skip')
    x.op(7,1,'eax',0x590);x.jump('ne','skip')
    x.load('eax',disp=base+0x6D10BC);x.sane('eax','skip')
    x.op(7,4,'eax',0x1C784);x.jump('ne','skip')
    x.mem('ff',0,disp=data+0x14);x.mem('01',R['edx'],disp=data+0x18)
    x.set(0,disp=data+12);x.emit('619dc3')
    x.mark('skip');x.mem('ff',0,disp=data+0x1C);x.set(0,disp=data+12)
    x.mark('native');x.emit('619d');x.emit(bytes.fromhex(SITES[name][1]))
    x.emit(relative_jump(code+len(x.code),base+0x544A36));return x.finish()

def check_code(memory):
    checks={0x544AAE:'8b0383f8ff74368bce',0x544ACF:'05f0d20000',
            0x5AB55A:'6a1ee8cf94f9ff',0x5AB586:'6a1ee8a394f9ff'}
    for rva,sig in checks.items():
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),'E_BONUS_NATIVE_CODE_'+hex(rva))

def public(memory,record):return bundle.public(__import__(__name__),memory,record)
