"""Portable public entry point. No game connection until Start is pressed."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import tkinter as tk
from auto_app import App

if __name__=='__main__':
    window=tk.Tk();App(window);window.mainloop()
