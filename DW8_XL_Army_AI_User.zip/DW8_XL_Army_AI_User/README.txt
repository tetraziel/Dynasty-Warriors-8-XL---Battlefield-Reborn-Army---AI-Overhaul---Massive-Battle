DW8 XL - Army & AI
Public interface preview, based on v5-ambition-guard-refresh-41

QUICK START
1. Extract the entire folder to a location on your PC.
2. Start Dynasty Warriors 8 Xtreme Legends Complete Edition yourself.
3. Open DW8ArmyAI.exe (or Run.cmd). A private Python runtime is included; no Python install
   or developer tools are needed. The packaged runtime is for 64-bit Windows.
4. If necessary, Browse for the .exe that actually runs the game. The
   selected executable path is saved immediately, including Unicode paths.
5. Choose the options and press Save Settings to remember all selections.
6. Press Start. Features that prepare a battle need a new battle.
7. Use the ? button beside each section for the option explanations.
8. Press Stop before switching to another version of this tool.

SAVE IS DIFFERENT FROM APPLY
Save Settings remembers preferences. Apply Settings updates a running
session. Neither saving nor opening the window starts the game or enables
mods automatically. Preferences are stored at:
%LOCALAPPDATA%\DW8XLArmyAI\settings.json

COMPATIBILITY
Intended for 64-bit Windows 10/11 and the PC executable build supported by
the original v5. The packaged tool/runtime do not depend on the author's
personal directories, Python installation or Windows account.

Filename/path matching supports Unicode. A renamed compatible executable
is accepted. Different regional versions, updates and altered executables
can have different machine code. Selecting them is not enough to make the
mod compatible. The existing executable hash and code-signature checks
remain enabled. An unsupported build is refused before installing mods;
it needs its own verified profile. This release has not been verified on
every Asian/regional build. The game executable itself is not included.

WHAT CHANGED IN THIS COPY
- No debug/JSON panel or developer scan/check controls.
- Pool diagnostics and NPC allocation balance test are not available.
  The allocation-balance feature is always requested OFF by this interface.
- Fog Distance 100000 has no "test" suffix in its visible label.
- A saved executable chooser, Save Settings and section-help windows.
- Clear status text and error messages instead of continuous debug dumps.

RECOVERY AND GAME DATA
The original game files and save files are not edited by the tool.
Code modifications are applied to the running game memory. Internal
recovery journals are kept under the local application-data directory;
continuous battle, AI and damage-report files are not produced by this copy.
Do not run the development tool and this copy together on the same game.

Some population/display features remain experimental. Large request
numbers are not a count of simultaneously rendered NPCs and do not expand
the native engine pools. Read the ? descriptions before interpreting them.
Fresh bodyguards each battle still needs live validation after defeat.

RUNTIME LICENSES
Python and bundled Tcl/Tk notices are included inside runtime. This package
does not include any game executable or assets. Keep runtime and the .py/.json
resources together with DW8ArmyAI.exe and Run.cmd. Do not copy only the launcher.
