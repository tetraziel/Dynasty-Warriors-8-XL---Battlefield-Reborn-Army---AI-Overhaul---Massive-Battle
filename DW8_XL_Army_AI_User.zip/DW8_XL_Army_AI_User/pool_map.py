"""Offline map-array layout required by the group-pool extension. No installer."""
from core import require

STRIDE = 0x38
ORDINARY = 0x2E0
NATIVE_PREFIX = 0x15990
NATIVE_ALLOCATION_REQUEST = 0x159B0
ARRAYS = (
    ('ordinary', 0x2E0, 600),
    ('member_view_a', 0x8620, 600),
    ('member_view_b', 0x10960, 100),
    ('officer', 0x11F40, 100),
    ('special', 0x13520, 40),
)


def layout(count):
    require(type(count) is int and count in (600, 900, 1200), 'E_POOL_MAP_CAPACITY')
    start = ORDINARY if count == 600 else NATIVE_PREFIX
    end = start + count * STRIDE
    size = NATIVE_PREFIX if count == 600 else (end + 15) & ~15
    require(end <= size and start % 16 == 0 and size % 16 == 0, 'E_POOL_MAP_LAYOUT')
    return dict(capacity=count, record_stride=STRIDE,
        ordinary_offset=start, ordinary_end=end, ordinary_bytes=count * STRIDE,
        native_prefix_preserved=True, native_prefix_bytes=NATIVE_PREFIX,
        native_allocation_request_bytes=NATIVE_ALLOCATION_REQUEST,
        parent_size_candidate=size, allocation_request_candidate=size + 0x20,
        added_parent_bytes=size - NATIVE_PREFIX,
        fixed_arrays=[dict(name=name, offset=off, capacity=n, end=off + n * STRIDE)
                      for name, off, n in ARRAYS if name != 'ordinary'],
        fixed_count_offsets=[0x13DE0, 0x13DE4, 0x13DE8, 0x13DEC, 0x13DF0],
        both_map_instances_must_use_the_same_layout=True,
        existing_map_objects_migrated=False, live_installation_supported=False,
        complete_map_reference_coverage_verified=False,
        rendering_actor_pool_expanded=False)
