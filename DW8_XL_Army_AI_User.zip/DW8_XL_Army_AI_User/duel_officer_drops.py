"""Extra native ground pickups at the existing corpse-cleanup caller.

The parent Duel generator/reward module remains unchanged. No process opens
on import; the optional bridge calls the same native item helper as its caller.
"""
import struct
from core import require,word,uint
from bridge import relative_jump
from recall_bridge import Asm,R
from auto_bridge import AUTO_MAGIC,AUTO_VERSION
import ambition_duel as duel
import bundle_support as bundle

FEATURE='DUEL_OFFICER_MATERIAL_DROPS_TEST'
MAGIC=0x31524444;VERSION=2;LEGACY_VERSION=1;SIZE=0x1000;CODE_SIZE=0x4000
SITES={'DUEL_OFFICER_CORPSE_LOOT':(0x57CFA3,'8b44242c50')}
PARENT=0x78;MXCSR=0x7C;POSITION=0x180;MARKS=0x400
COUNTERS={'cleanup_visits':0x10,'eligible_officers':0x14,'duplicates_skipped':0x18,
          'metadata_refusals':0x1C,'capacity_deferrals':0x20,'native_drop_requests':0x24,
          'scope_skips':0x28,'parent_busy_skips':0x2C}
REASON=0x30
REASONS={0:'WAITING_NATIVE_CLEANUP',1:'OFF_OR_PARENT_NOT_READY',2:'CONTEXT',
         3:'NOT_DEFEATED_ENEMY_OFFICER',4:'MATERIAL_METADATA',5:'NATIVE_ITEM_CAPACITY',
         6:'DUPLICATE_OFFICER',7:'TWO_NATIVE_PICKUPS_REQUESTED',8:'PARENT_BUSY',9:'CONTEXT_CHANGED_DURING_REQUEST'}
FIELDS={n:0x100+i*4 for i,n in enumerate(('manager','ai','players','phase','parent','camp','generation',
    'agent_id','item','actor','group','owner','owner_record','metadata','facility','weapon','graphics','mark','character'))}
LAST=0x1A0
CHECKS={0x57CED0:'8b44240483ec1853555657',0x57CF44:'e89774f8ff',
        0x57CF90:'8b74241451',0x57CFA8:'e8834fffff',
        0x5722B0:'558bec83e4f8518d46ed57',0x572356:'d9eed94510d8d1',
        0x572397:'e8a48df4ff',0x419B77:'83f852',0x41A119:'0fbf760685f6',
        0x41A194:'6a006a02',0x41A1B1:'0fbf760685f6',
        0x4BB170:'8b86587c0100578bf98bde',0x4BB189:'83bb8c76000000'}


def initialize_data(raw):struct.pack_into('<I',raw,MXCSR,0x1F80)


def build_bridge(base,data,code,auto,recall,name,*,pool=None,legacy=False):
    require(name in SITES,'E_DUEL_DROP_SITE');x=Asm()
    version=LEGACY_VERSION if legacy else VERSION
    def inc(n):x.mem('ff',0,disp=data+COUNTERS[n])
    def save(reg,n):x.store(reg,disp=data+FIELDS[n])
    def load(reg,n):x.load(reg,disp=data+FIELDS[n])
    def eq(reg,val,failed='skip'):x.cmp(reg,val);x.jump('ne',failed)
    def w(reg,base_reg=None,off=0):x.mem('0fb7',R[reg],base_reg,off)
    x.emit('9c60')
    for off,val in ((0,MAGIC),(4,version),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','native')
    inc('cleanup_visits');x.set(1,disp=data+REASON)
    x.load('edi',disp=data+PARENT);x.sane('edi','unlock')
    for off,val in ((0,duel.MAGIC),(4,2 if legacy else duel.VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,'edi',off);x.jump('ne','unlock')
    save('edi','parent')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],'edi',12);x.jump('ne','busy')
    x.set(2,disp=data+REASON)
    for address,val in ((auto,AUTO_MAGIC),(auto+4,AUTO_VERSION),(auto+12,0),(auto+20,0)):
        x.op(7,val,disp=address);x.jump('ne','skip')
    for rva,n in ((0x6A91E8,'manager'),(0x6A91D8,'ai'),(0x6A91EC,'players'),(0x6D10BC,'phase')):
        x.load('eax',disp=base+rva);x.sane('eax','skip');save('eax',n)
    x.op(7,4,'eax',0x1C784);x.jump('ne','skip')
    load('eax','players');x.op(7,1,'eax',0x590);x.jump('ne','skip')
    w('eax',off=base+0x848530);eq('eax',1)
    w('eax',off=base+0x84855C);eq('eax',12)
    load('edi','parent');x.op(7,1,'edi',duel.ARMED);x.jump('ne','skip')
    x.load('eax',disp=base+0x6A9398);x.sane('eax','skip');x.cmpm('eax','edi',duel.CAMP);x.jump('ne','skip');save('eax','camp')
    w('ecx','eax',0x582);x.cmp('ecx',1);x.jump('below','skip');x.cmp('ecx',999);x.jump('above','skip')
    x.cmpm('ecx','edi',duel.ROUND);x.jump('ne','skip')
    w('ecx',off=base+0x848542);x.cmpm('ecx','edi',duel.STAGE);x.jump('ne','skip')
    x.rr('89','eax','ecx');x.ri(5,'eax',133);x.cmp('eax',95);x.jump('above','skip')
    x.imm('edx',0);x.imm('ecx',5);x.emit('f7f1');eq('edx',0)
    x.load('eax','edi',duel.GENERATION);x.cmp('eax',0);x.jump('eq','skip');save('eax','generation')
    x.set(3,disp=data+REASON)
    # Original EDI is the current 48-byte physical-member record. The cleanup
    # argument is at old ESP+2C, or PUSHAD ESP+50. Check both independently.
    x.load('esi','esp');save('esi','item');x.load('eax','esp',0x50);x.cmp('eax',150);x.jump('ae','skip');save('eax','agent_id')
    x.imul('edx','eax',0x30);load('ebx','manager');x.rr('01','edx','ebx');x.ri(0,'edx',0x6B210)
    x.rr('39','edx','esi');x.jump('ne','skip');x.cmpm('eax','esi');x.jump('ne','skip')
    x.op(7,1,'esi',4);x.jump('ne','skip');x.op(7,0,'esi',0xC);x.jump('ne','skip')
    x.mem('f7',0,'esi',0x2C);x.dword(1);x.jump('eq','skip')
    x.mem('f7',0,'esi',0x2C);x.dword(8);x.jump('ne','skip')
    x.imul('edx','eax',0xE0);load('ebx','ai');x.rr('01','edx','ebx');x.ri(0,'edx',0x21EF8);save('edx','actor')
    x.cmpm('eax','edx',0x7C);x.jump('ne','skip')
    x.mem('f7',0,'edx',0xCC);x.dword(0x20000);x.jump('eq','skip')
    x.load('eax','esi',8);x.cmp('eax',600);x.jump('ae','skip')
    x.imul('eax','eax',0x268);load('ebx','manager');x.rr('01','eax','ebx');x.ri(0,'eax',0x10E50);save('eax','group')
    x.load('ecx','esi',8);x.cmpm('ecx','eax',0x18);x.jump('ne','skip')
    x.load('edx','esi');x.cmpm('edx','eax',0x34);x.jump('ne','skip')
    x.mem('f7',0,'eax',0x50);x.dword(2);x.jump('eq','skip')
    # Native 571AF0 can add bit 4 when a defeated group becomes empty. That
    # state is compatible with a still-present dead actor awaiting cleanup.
    x.mem('f7',0,'eax',0x50);x.dword(1);x.jump('ne','skip')
    x.load('ecx','eax',0x44);x.cmp('ecx',250);x.jump('ae','skip');save('ecx','owner')
    x.imul('ecx','ecx',0x110);x.rr('01','ecx','ebx');x.ri(0,'ecx',0x4B0);save('ecx','owner_record')
    x.load('edx','eax',0x44);x.cmpm('edx','ecx',0x38);x.jump('ne','skip')
    x.op(7,1,'ecx',0x40);x.jump('ne','skip')
    # The native main group, not a squad leader/base captain or allied guard.
    x.load('edx','ecx',0x100);x.cmp('edx',1);x.jump('below','skip');x.cmp('edx',6);x.jump('above','skip')
    x.load('ebx','ecx',0xFC);x.cmp('ebx',6);x.jump('above','skip');x.rr('39','edx','ebx');x.jump('above','skip')
    x.load('ebx','ecx',0x54);x.cmpm('ebx','ecx',0x100);x.jump('ae','skip');x.cmp('ebx',6);x.jump('ae','skip')
    x.load('edx','ecx',0xF8);x.sane('edx','skip');x.imul('ebx','ebx',2);x.rr('01','edx','ebx');w('edx','edx')
    x.cmpm('edx','eax',0x18);x.jump('ne','skip')
    x.load('eax','esi',0x20);x.cmp('eax',0x487);x.jump('above','skip');x.imul('eax','eax',60)
    x.load('ecx',disp=base+0x6A93B4);x.sane('ecx','skip');x.rr('01','eax','ecx')
    w('eax','eax',0x2E);x.cmp('eax',0x386);x.jump('above','skip')
    x.cmp('eax',0x352);x.jump('below','officer');x.cmp('eax',0x354);x.jump('be','skip');x.mark('officer');save('eax','character')
    inc('eligible_officers')
    load('eax','owner');x.imul('eax','eax',4);x.ri(0,'eax',data+MARKS);save('eax','mark')
    load('edx','generation');x.cmpm('edx','eax');x.jump('eq','duplicate')
    # Resolve native one-unit entries by effect semantics, not guessed item IDs.
    x.set(4,disp=data+REASON);x.set(0xFFFFFFFF,disp=data+FIELDS['facility']);x.set(0xFFFFFFFF,disp=data+FIELDS['weapon'])
    x.load('esi',disp=base+0x6A9380);x.sane('esi','bad_metadata');save('esi','metadata');x.imm('ebx',0)
    x.mark('metadata_loop');x.op(7,0x52,'esi');x.jump('above','next_item')
    w('eax','esi',6);x.cmp('eax',1);x.jump('ne','next_item')
    w('eax','esi',8);x.cmp('eax',0x17);x.jump('above','next_item')
    w('eax','esi',4);x.cmp('eax',12);x.jump('eq','facility');x.cmp('eax',13);x.jump('ne','next_item')
    x.op(7,0xFFFFFFFF,disp=data+FIELDS['weapon']);x.jump('ne','bad_metadata');save('ebx','weapon');x.jump('jmp','next_item')
    x.mark('facility');x.op(7,0xFFFFFFFF,disp=data+FIELDS['facility']);x.jump('ne','bad_metadata');save('ebx','facility')
    x.mark('next_item');x.ri(0,'esi',20);x.ri(0,'ebx',1);x.cmp('ebx',83);x.jump('below','metadata_loop')
    for n in ('facility','weapon'):
        load('eax',n);x.cmp('eax',82);x.jump('above','bad_metadata')
    x.load('eax',disp=base+0x6A9230);x.sane('eax','skip');save('eax','graphics')
    x.op(7,2,'eax',0x768C);x.jump('below','capacity')
    load('esi','actor')
    for off in range(0,12,4):
        x.load('eax','esi',0x34+off);x.rr('89','edx','eax');x.ri(4,'edx',0x7FFFFFFF)
        x.cmp('edx',0x4CBEBC20);x.jump('above','skip');x.store('eax',disp=data+POSITION+off)
    x.set(0x3F800000,disp=data+POSITION+12)
    # Recheck the battle and actor immediately before marking/calling.
    for rva,n in ((0x6A91E8,'manager'),(0x6A91D8,'ai'),(0x6A91EC,'players'),(0x6D10BC,'phase'),(0x6A9398,'camp')):
        x.load('eax',disp=base+rva);x.cmpm('eax',disp=data+FIELDS[n]);x.jump('ne','skip')
    load('eax','phase');x.op(7,4,'eax',0x1C784);x.jump('ne','skip')
    load('eax','agent_id');x.cmpm('eax','esi',0x7C);x.jump('ne','skip')
    load('edi','parent');load('eax','generation');x.cmpm('eax','edi',duel.GENERATION);x.jump('ne','skip')
    x.op(7,1,'edi',duel.ARMED);x.jump('ne','skip')
    load('edx','mark');x.store('eax','edx')
    for n,off in (('generation',0),('owner',4),('agent_id',8),('facility',12),('weapon',16),('character',20)):
        load('eax',n);x.store('eax',disp=data+LAST+off)
    # Aligned stack-local FXSAVE. Native helpers use the same thread/ABI as the
    # displaced caller; neither its original x87/SSE state nor DF may leak.
    x.emit('89e581ec3002000083e4f00fae0424dbe3fc');x.mem('0fae',2,disp=data+MXCSR)
    for n in ('facility','weapon'):
        load('esi',n);x.emit('680000803f68ffffffff68');x.dword(data+POSITION)
        x.call(code,base+0x5722B0);x.ri(0,'esp',12);inc('native_drop_requests')
    x.emit('0fae0c2489ec');x.set(7,disp=data+REASON);x.jump('jmp','release')
    x.mark('bad_metadata');inc('metadata_refusals');x.jump('jmp','release')
    x.mark('capacity');x.set(5,disp=data+REASON);inc('capacity_deferrals');x.jump('jmp','release')
    x.mark('duplicate');x.set(6,disp=data+REASON);inc('duplicates_skipped');x.jump('jmp','release')
    x.mark('skip');inc('scope_skips')
    x.mark('release');load('edi','parent');x.set(0,'edi',12);x.jump('jmp','unlock')
    x.mark('busy');inc('parent_busy_skips');x.set(8,disp=data+REASON)
    x.mark('unlock');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d');x.emit(SITES[name][1]);x.emit(relative_jump(code+len(x.code),base+0x57CFA8))
    return x.finish()


def check_code(memory):
    for rva,sig in CHECKS.items():
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),'E_DUEL_DROP_NATIVE_'+hex(rva))
    # Verify the native effect jump-table mapping through ASLR relocation.
    for effect,handler in ((12,0x41A0FC),(13,0x41A194)):
        index=memory.read(memory.base+0x41A2CC+effect,1)[0]
        require(index<11 and uint(memory,memory.base+0x41A2A0+index*4)==memory.base+handler,
                'E_DUEL_DROP_EFFECT_'+str(effect))


def validate_data(memory,record):
    require(uint(memory,record['data_address']+MXCSR)==0x1F80,'E_DUEL_DROP_MXCSR')
    p=uint(memory,record['data_address']+PARENT)
    require(not p or (0x10000<=p<0xFF000000 and uint(memory,p)==duel.MAGIC and uint(memory,p+4)==(2 if record['version']==1 else duel.VERSION)
        and uint(memory,p+0x70)==record['auto_data_address'] and uint(memory,p+0x74)==record['recall_data_address']),
        'E_DUEL_DROP_PARENT_BINDING')
    require(p or not uint(memory,record['data_address']+8),'E_DUEL_DROP_PARENT_MISSING')


def changes_for_enabled(session,record,enabled):
    if not enabled:return []
    parent=(session.lease or {}).get('ambition_duel')
    require(parent and parent.get('version')==duel.VERSION and duel.public(session,parent)['enabled'],'E_DUEL_DROPS_REQUIRE_DUEL_GENERATOR')
    bundle.validate(duel,session,parent)
    address=record['data_address']+PARENT;old=session.read(address,4);new=struct.pack('<I',parent['data_address'])
    if old==new:return []
    marks=record['data_address']+MARKS
    return [(marks,session.read(marks,250*4),bytes(250*4)),(address,old,new)]


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(facility_per_officer=1,weapon_material_per_officer=1,physical_native_pickups=True,
        existing_weapon_drops_preserved=True,inventory_written_directly=False,
        scope='ENEMY_MAIN_OFFICERS_IN_PARENT_ARMED_POST_SYMBOLS_DUEL',
        duplicate_policy='ONCE_PER_OWNER_PER_PARENT_FRESH_DUEL_GENERATION',
        native_helper_rva='0x5722b0',native_capacity_checks_preserved=True,
        quantity_is_native_item_base_amount=True,native_pickup_bonuses_and_final_multipliers_preserved=True,
        remote_threads_created=False,live_validated=False)
    if record:
        raw=memory.read(record['data_address'],0x1B8)
        result.update(last_result=REASONS.get(word(raw,REASON),'UNKNOWN'),parent_data=hex(word(raw,PARENT)),
            last_officer={n:word(raw,LAST+i*4) for i,n in enumerate(('generation','owner','agent','facility_item','weapon_material_item','character'))},
            requests_are_not_proof_of_rendered_or_collected_pickups=True)
    return result
