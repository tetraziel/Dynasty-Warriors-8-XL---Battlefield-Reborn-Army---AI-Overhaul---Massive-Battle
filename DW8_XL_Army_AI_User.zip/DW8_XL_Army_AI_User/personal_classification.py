"""Personal leader exception inside the native class setter; pure emitter.

Only saved EDI (the requested class) may change. The original setter owns all
actor writes. No native calls, coordinate writes, timer resets or new threads.
"""
import struct
from core import require,word
from bridge import relative_jump
from recall_bridge import Asm,R,CONTEXT,FOLLOW_FLAG,FOLLOW_VIEW,MAGIC as RECALL_MAGIC,VERSION as RECALL_VERSION
from auto_bridge import AUTO_MAGIC,AUTO_VERSION
from family_scope import emit_family_scope
from detachment import emit_hold_view
from pool_binding import resolve as resolve_pool

SITE=(0x515043,'8b0dd8915401')
COUNTERS={'visits':0x300,'class_two_requests':0x304,'follow_promotions':0x308,
          'scope_refusals':0x30C,'defense_preserved':0x310,'combat_preserved':0x314,
          'recall_busy_skips':0x318}
RESULT=0x31C;LAST=0x320;STAGE=0x340;REJECTION=0x344;REASON_COUNTS=0x380
REASONS=('NONE','HEADERS','GLOBALS','PHASE','PLAYER_BINDING','ACTOR_IDENTITY',
         'ACTOR_PRIORITY','ACTOR_CLASS','ACTOR_STATE','MEMBER_ZERO','GROUP_IDENTITY',
         'GROUP_LINKS','PLAYER_GROUP','OWNER_LIST_FAMILY','FOLLOW_VIEW','COMMIT_CONTEXT',
         'COMMIT_IDENTITY')
RESULTS={0:'WAITING_NATIVE_CALL',1:'NATIVE_CLASS',2:'FOLLOW_CLASS_ONE',
         3:'DEFENSE_PRESERVED',4:'COMBAT_PRESERVED',5:'SCOPE_REFUSED',6:'RECALL_BUSY'}
FIELDS={n:0x500+i*4 for i,n in enumerate(('manager','ai','players','phase','owner','player',
    'player_id','agent','agent_id','item','group','group_id','group_ai','roster','ordinal','tick'))}
LEGACY_STATES=(0,24,39,123,124)
STATES=(0,9,24,39,123,124)
NEW_COUNTERS={'state_nine_promotions':0x348,'reduced_state_recoveries':0x34C}


def original(base):return b'\x8b\x0d'+struct.pack('<I',base+0x6A91D8)


def build_bridge(base,data,code,auto,recall,*,magic,version,pool=None):
    p=resolve_pool(pool);x=Asm()
    states=LEGACY_STATES if version<4 else STATES
    def save(reg,n):x.store(reg,disp=data+FIELDS[n])
    def load(reg,n):x.load(reg,disp=data+FIELDS[n])
    def stage(n):x.set(REASONS.index(n),disp=data+STAGE)
    def inc(n):x.mem('ff',0,disp=data+COUNTERS[n])
    def equal(reg,value):x.cmp(reg,value);x.jump('ne','refuse')
    def ctx(reg,n):x.cmpm(reg,disp=recall+CONTEXT[n]);x.jump('ne','refuse')
    x.emit('9c60')
    for off,val in ((0,magic),(4,version),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','native')
    inc('visits');x.set(1,disp=data+RESULT)
    # The native main-officer exception has already run. Never change class1/3.
    x.op(7,2,'esp');x.jump('ne','unlock');inc('class_two_requests')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=recall+16);x.jump('ne','busy')
    stage('HEADERS')
    for address,val in ((recall,RECALL_MAGIC),(recall+4,RECALL_VERSION),(recall+8,1),
                        (recall+12,0),(recall+FOLLOW_FLAG,1),(auto,AUTO_MAGIC),(auto+4,AUTO_VERSION)):
        x.op(7,val,disp=address);x.jump('ne','refuse')
    stage('GLOBALS')
    for rva,n in ((0x6A91E8,'manager'),(0x6A91D8,'ai'),(0x6A91EC,'players'),(0x6D10BC,'phase')):
        x.load('eax',disp=base+rva);x.sane('eax','refuse');ctx('eax',n);save('eax',n)
    stage('PHASE');x.op(7,4,'eax',0x1C784);x.jump('ne','refuse')
    stage('PLAYER_BINDING');load('ecx','players')
    for off,val in ((0x108,0),(0x590,1)):
        x.op(7,val,'ecx',off);x.jump('ne','refuse')
    for address,val in ((auto+12,0),(auto+20,0),(auto+24,1),(recall+CONTEXT['owner'],0)):
        x.op(7,val,disp=address);x.jump('ne','refuse')
    x.load('eax',disp=auto+16);x.cmp('eax',0);x.jump('eq','refuse');ctx('eax','sequence')
    load('edx','manager');x.lea('edi','edx',0x4B0)
    for off,val in ((0x38,0),(0x40,0)):
        x.op(7,val,'edi',off);x.jump('ne','refuse')
    x.load('eax','edi',0x44);ctx('eax','character');x.set(0,disp=data+FIELDS['owner'])
    x.load('eax','edi',0x100);x.cmp('eax',5);x.jump('below','refuse');x.cmp('eax',6);x.jump('above','refuse')
    x.load('edx','edi',0xFC);x.cmp('edx',6);x.jump('above','refuse');x.rr('39','eax','edx');x.jump('above','refuse')
    x.load('eax','ecx',0x110);x.cmp('eax',150);x.jump('ae','refuse');ctx('eax','player_id');save('eax','player_id')
    x.imul('eax','eax',0xE0);load('ebx','ai');x.rr('01','eax','ebx');x.ri(0,'eax',0x21EF8);save('eax','player')
    x.mem('f7',0,'eax',0xCC);x.dword(1);x.jump('eq','refuse')
    x.load('edx','eax',0x7C);ctx('edx','player_id')
    stage('ACTOR_IDENTITY');x.load('eax','esp',4);x.cmp('eax',150);x.jump('ae','refuse')
    x.cmpm('eax',disp=data+FIELDS['player_id']);x.jump('eq','refuse');save('eax','agent_id')
    x.imul('esi','eax',0xE0);x.rr('01','esi','ebx');x.ri(0,'esi',0x21EF8);save('esi','agent')
    x.cmpm('eax','esi',0x7C);x.jump('ne','refuse');x.store('eax',disp=data+LAST)
    for off,dest in ((0x84,8),(0x88,12),(0xBC,16)):
        x.load('edx','esi',off);x.store('edx',disp=data+LAST+dest)
    x.set(2,disp=data+LAST+4)
    stage('ACTOR_PRIORITY');x.mem('f7',0,'esi',0xCC);x.dword(1);x.jump('eq','refuse')
    x.mem('f7',0,'esi',0xCC);x.dword(0x28020000);x.jump('ne','refuse')
    x.mem('0fb6',R['eax'],'esi',0xD2);equal('eax',0)
    stage('ACTOR_CLASS');x.load('eax','esi',0x84);x.cmp('eax',1);x.jump('eq','class_ok');equal('eax',2);x.mark('class_ok')
    stage('ACTOR_STATE');x.load('eax','esi',0x88)
    for state in states:x.cmp('eax',state);x.jump('eq','state_ok')
    x.jump('jmp','refuse');x.mark('state_ok')
    # BC is deliberately retained: state123 uses it as an ordinary decision
    # countdown. The bridge does not override damage/combat/forced states.
    stage('MEMBER_ZERO');load('eax','agent_id');x.imul('eax','eax',0x30)
    load('edx','manager');x.rr('01','eax','edx');x.ri(0,'eax',0x6B210);save('eax','item')
    x.load('ecx','eax');x.cmpm('ecx','esi',0x7C);x.jump('ne','refuse')
    x.op(7,0,'eax',0xC);x.jump('ne','refuse')
    x.load('ecx','eax',8);x.cmp('ecx',p.group_capacity);x.jump('ae','refuse');save('ecx','group_id')
    x.store('ecx',disp=data+LAST+20);x.imul('edi','ecx',0x268);x.rr('01','edi','edx');x.ri(0,'edi',p.manager_groups);save('edi','group')
    stage('GROUP_IDENTITY');x.cmpm('ecx','edi',0x18);x.jump('ne','refuse')
    for off,val in ((0x44,0),(0x24,30),(0x2C,30),(0x30,865)):
        x.op(7,val,'edi',off);x.jump('ne','refuse')
    load('eax','agent_id');x.cmpm('eax','edi',0x34);x.jump('ne','refuse')
    for off in (0x10,0x14):
        x.mem('f7',0,'edi',off);x.dword(1);x.jump('eq','refuse')
    x.load('eax','edi',0x28);x.cmp('eax',0);x.jump('eq','refuse');x.cmp('eax',30);x.jump('above','refuse')
    x.load('eax','edi',0x1C);x.cmp('eax',1);x.jump('below','refuse');x.cmp('eax',4);x.jump('above','refuse');save('eax','ordinal')
    x.load('edx','edx',0x4B0+0xF8);x.sane('edx','refuse');save('edx','roster')
    x.imul('eax','eax',2);x.rr('01','eax','edx');x.mem('0fb7',R['eax'],'eax');x.rr('39','eax','ecx');x.jump('ne','refuse')
    stage('GROUP_LINKS');x.imul('eax','ecx',0xA0);x.rr('01','eax','ebx');x.ri(0,'eax',p.ai_groups);save('eax','group_ai')
    x.cmpm('eax','esi',0x80);x.jump('ne','refuse');x.cmpm('ecx','eax',0x74);x.jump('ne','refuse')
    x.cmpm('ebx','eax',0x78);x.jump('ne','refuse')
    for reg,off in (('eax',0x88),('ebx',0x90)):
        x.mem('f7',0,reg,off);x.dword(1);x.jump('eq','refuse')
    x.op(7,0,'ebx',0x84);x.jump('ne','refuse')
    stage('PLAYER_GROUP');load('eax','player_id');x.imul('eax','eax',0x30)
    load('edx','manager');x.rr('01','eax','edx');x.ri(0,'eax',0x6B210);x.load('eax','eax',8)
    x.cmp('eax',p.group_capacity);x.jump('ae','refuse');x.cmpm('eax',disp=data+FIELDS['group_id']);x.jump('eq','refuse')
    x.imul('ecx','eax',0xA0);x.rr('01','ecx','ebx');x.ri(0,'ecx',p.ai_groups)
    load('esi','player');x.cmpm('ecx','esi',0x80);x.jump('ne','refuse')
    x.imul('eax','eax',0x268);x.rr('01','eax','edx');x.ri(0,'eax',p.manager_groups)
    x.op(7,0,'eax',0x44);x.jump('ne','refuse')
    stage('OWNER_LIST_FAMILY')
    emit_family_scope(x,data,{n:data+FIELDS[n] for n in ('manager','owner','group')},'refuse',prefix='leader_family',squad_count=4,pool=p)
    load('esi','agent');x.op(7,0,'esi',0x90);x.jump('ne','combat')
    stage('FOLLOW_VIEW')
    for off,val in ((0x78,0),(0x84,7)):
        x.op(7,val,disp=recall+FOLLOW_VIEW+off);x.jump('ne','refuse')
    emit_hold_view(x,recall,auto,data+FIELDS['group'],prefix='leader_hold')
    x.cmp('eax',0);x.jump('ne','defense')
    stage('COMMIT_CONTEXT')
    for rva,n in ((0x6A91E8,'manager'),(0x6A91D8,'ai'),(0x6A91EC,'players'),(0x6D10BC,'phase')):
        x.load('eax',disp=base+rva);x.cmpm('eax',disp=data+FIELDS[n]);x.jump('ne','refuse');ctx('eax',n)
    x.op(7,4,'eax',0x1C784);x.jump('ne','refuse')
    x.load('eax',disp=auto+16);ctx('eax','sequence')
    for address,val in ((auto+12,0),(auto+20,0),(auto+24,1),(recall+8,1),(recall+12,0),(recall+FOLLOW_FLAG,1)):
        x.op(7,val,disp=address);x.jump('ne','refuse')
    stage('COMMIT_IDENTITY');load('esi','agent');load('eax','agent_id')
    x.cmpm('eax','esi',0x7C);x.jump('ne','refuse');load('ecx','group_ai');x.cmpm('ecx','esi',0x80);x.jump('ne','refuse')
    x.mem('f7',0,'esi',0xCC);x.dword(0x28020000);x.jump('ne','refuse')
    x.mem('f7',0,'esi',0xCC);x.dword(1);x.jump('eq','refuse')
    x.op(7,0,'esi',0x90);x.jump('ne','combat')
    x.mem('0fb6',R['eax'],'esi',0xD2);equal('eax',0)
    x.load('eax','esi',0x84);x.cmp('eax',1);x.jump('eq','commit_class');equal('eax',2);x.mark('commit_class')
    x.load('eax','esi',0x88);x.cmpm('eax',disp=data+LAST+12);x.jump('ne','refuse')
    load('edi','group');x.op(7,0,'edi',0x44);x.jump('ne','refuse')
    load('eax','agent_id');x.cmpm('eax','edi',0x34);x.jump('ne','refuse')
    for off in (0x10,0x14):
        x.mem('f7',0,'edi',off);x.dword(1);x.jump('eq','refuse')
    load('edx','manager');x.load('edx','edx',0x4B0+0xF8);x.cmpm('edx',disp=data+FIELDS['roster']);x.jump('ne','refuse')
    load('eax','ordinal');x.imul('eax','eax',2);x.rr('01','eax','edx');x.mem('0fb7',R['eax'],'eax');x.cmpm('eax',disp=data+FIELDS['group_id']);x.jump('ne','refuse')
    # EDI is the native setter's requested class, saved by PUSHAD at ESP+0.
    # Replaying MOV ECX,[current AI] lets that setter reset DA/write class.
    x.set(1,'esp');inc('follow_promotions');x.set(2,disp=data+RESULT)
    if version>=4:
        # State 9 uses native movement/zone navigation and was the uncovered
        # transition in the saved scan. Keep the native timer and state intact.
        x.op(7,9,disp=data+LAST+12);x.jump('ne','not_state_nine')
        x.mem('ff',0,disp=data+NEW_COUNTERS['state_nine_promotions'])
        x.mark('not_state_nine');x.load('eax',disp=data+LAST+12)
        x.cmp('eax',123);x.jump('eq','count_recovery');x.cmp('eax',124);x.jump('ne','recovery_counted')
        x.mark('count_recovery');x.mem('ff',0,disp=data+NEW_COUNTERS['reduced_state_recoveries'])
        x.mark('recovery_counted')
    load('ebx','ai');x.load('eax','ebx',0x53E90);x.store('eax',disp=data+LAST+24)
    x.jump('jmp','release')
    x.mark('combat');inc('combat_preserved');x.set(4,disp=data+RESULT);x.jump('jmp','release')
    x.mark('defense');inc('defense_preserved');x.set(3,disp=data+RESULT);x.jump('jmp','release')
    x.mark('refuse');inc('scope_refusals');x.set(5,disp=data+RESULT)
    x.load('eax',disp=data+STAGE);x.store('eax',disp=data+REJECTION)
    x.imul('eax','eax',4);x.ri(0,'eax',data+REASON_COUNTS);x.mem('ff',0,'eax')
    x.mark('release');x.set(0,disp=recall+16);x.jump('jmp','unlock')
    x.mark('busy');inc('recall_busy_skips');x.set(6,disp=data+RESULT)
    x.mark('unlock');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d');x.emit(original(base));x.emit(relative_jump(code+len(x.code),base+SITE[0]+6))
    return x.finish()


def public(memory,record):
    supported=bool(record and record['version']>=3)
    result={'available':supported,'scope':'FOUR_PERSONAL_LEADERS_REQUESTED_FOLLOW',
        'native_setter_rva':hex(SITE[0]),'requested_class_replacement':[2,1],
        'game_states_written':False,'timers_written':False,'positions_written':False,
        'remote_threads_created':False,'native_calls_added':0,'live_validated':False}
    result.update(accepted_states=list(STATES if not record or record['version']>=4 else LEGACY_STATES),
                  continuous_class_enforcement=False)
    if not supported:return result
    data=record['data_address'];raw=memory.read(data+0x300,0x180)
    get=lambda off:word(raw,off-0x300)
    result.update({name:get(off) for name,off in COUNTERS.items()})
    if record['version']>=4:result.update({name:get(off) for name,off in NEW_COUNTERS.items()})
    reason=get(REJECTION)
    result.update(last_result=RESULTS.get(get(RESULT),'INVALID_RESULT'),
        last_rejection=REASONS[reason] if 0<reason<len(REASONS) else None,
        reasons={n:get(REASON_COUNTS+4*i) for i,n in enumerate(REASONS) if i and get(REASON_COUNTS+4*i)},
        last_observed={n:get(LAST+4*i) for i,n in enumerate(('agent','requested_class','actor_class','state','timer_bc','group','promotion_tick'))})
    return result
