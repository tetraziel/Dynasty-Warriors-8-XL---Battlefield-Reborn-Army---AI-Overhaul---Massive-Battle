"""One to four native infantry groups per guard, with a native-load reserve."""
from pool_binding import resolve as resolve_pool
import struct
from core import require,uint,word,owner_groups,player_snapshot
from recall_bridge import Asm,R
from bridge import relative_jump
from morale_policy import BASE as POLICY_BASE,MAGIC as POLICY_MAGIC
import bundle_support as bundle

FEATURE='REAL_BODYGUARD_120_NATIVE_ARMY'
MAGIC=0x38414742;VERSION=4;LEGACY_VERSION=1;LEGACY_VERSIONS=(1,2,3);SIZE=0x2000;CODE_SIZE=0x8000
ROSTER_STRIDE=0x30
SITES={'CREATE_GUARD_ARMY':(0x590F8B,'8b4424246bc064'),
       'GUARD_REPLACEMENT_LIMIT':(0x5542D0,'8b0de8915401')}
COUNTERS={'creation_visits':0x10,'armies_created':0x14,'soldiers_configured':0x18,
          'creation_refusals':0x1C,'replacement_checks':0x20,'replacements_allowed':0x24,
          'replacements_blocked':0x28,'replacement_scope_skips':0x2C,'initialization_failures':0x30}
REGISTRY=0x100;STRIDE=0x80
WORK=0x400;QUEUE_IDS=0x480;POSITION=0x4A0;PAIR=0x4B0


def original(base,name):
    if name=='GUARD_REPLACEMENT_LIMIT':return bytes.fromhex('8b0d')+struct.pack('<I',base+0x6A91E8)
    return bytes.fromhex(SITES[name][1])


def build_bridge(base,data,code,auto,recall,name,*,legacy=False,legacy_version=None,pool=None):
    p=resolve_pool(pool)
    require(name in SITES,'E_GUARD_SITE')
    version=(legacy_version or LEGACY_VERSION) if legacy else VERSION
    return creation_bridge(base,data,code,auto,recall,version=version,pool=p) if name=='CREATE_GUARD_ARMY' else limit_bridge(base,data,code,auto,recall,version=version,pool=p)


def creation_bridge(base,data,code,auto,recall,*,version=VERSION,pool=None):
    p=resolve_pool(pool)
    x=Asm();inc=lambda o:x.mem('ff',0,disp=data+o)
    save=lambda reg,off:x.store(reg,disp=data+WORK+off)
    load=lambda reg,off:x.load(reg,disp=data+WORK+off)
    x.emit('9c60')
    for off,value in ((0,MAGIC),(4,version),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','native')
    inc(0x10)
    if version>=3:
        x.set(0,disp=data+0x90);x.set(0,disp=data+0x98)
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=recall+16);x.jump('ne','own_unlock')
    # This hook is inside the bodyguard constructor, after its officer group
    # was created and before native 56F970 initializes every group in its list.
    x.load('edi',disp=base+0x6A91E8);x.sane('edi','refuse');save('edi',0)
    x.load('edx',disp=base+0x6A91EC);x.sane('edx','refuse');save('edx',4)
    x.op(7,1,'edx',0x590);x.jump('ne','refuse')
    x.op(7,0,'edx',0x108);x.jump('ne','refuse')
    x.op(7,1,disp=auto+24);x.jump('ne','refuse')
    x.op(7,0,disp=auto+20);x.jump('ne','refuse')
    x.load('eax',disp=auto+16);x.cmp('eax',0);x.jump('eq','refuse');save('eax',8)
    x.load('ebx','esp',16);x.sane('ebx','refuse');save('ebx',12)
    x.load('ecx','ebx',0x38);x.ri(5,'ecx',122);x.cmp('ecx',2);x.jump('above','refuse');save('ecx',16)
    x.load('ebp','esp',8);x.sane('ebp','refuse');x.cmpm('ecx','ebp',8);x.jump('ne','refuse')
    x.rr('89','eax','ecx');x.ri(0,'eax',122);save('eax',20)
    x.imul('edx','eax',0x110);x.rr('01','edx','edi');x.ri(0,'edx',0x4B0)
    x.rr('39','edx','ebx');x.jump('ne','refuse')
    x.ri(0,'ecx',1100);x.cmpm('ecx','ebx',0x50);x.jump('ne','refuse');save('ecx',24)
    for off,value in ((0x40,0),(0xFC,6),(0x100,1)):
        x.op(7,value,'ebx',off);x.jump('ne','refuse')
    x.mem('f7',0,'ebx',0x68);x.dword(4);x.jump('eq','refuse')
    x.load('eax','ebx',0x44);x.cmp('eax',0x386)
    if version>=4:
        # Owner +44 is the unit name index, not the character-parameter ID.
        # Only the fixed Story Assault Captain may use the native name 914.
        x.jump('be','guard_name_ready');x.cmp('eax',914);x.jump('ne','refuse')
        x.op(7,1,disp=data+WORK+16);x.jump('ne','refuse')
        x.mem('0fb7',R['edx'],disp=base+0x848530);x.cmp('edx',0);x.jump('ne','refuse')
        x.mem('0fb7',R['edx'],disp=base+0x848582);x.cmp('edx',883);x.jump('ne','refuse')
        x.load('edx',disp=base+0x6A93B4);x.sane('edx','refuse')
        x.mem('0fb7',R['edx'],'edx',1101*60+0x2E);x.cmp('edx',883);x.jump('ne','refuse')
        x.mark('guard_name_ready')
    else:x.jump('above','refuse')
    save('eax',28)
    x.load('edx','ebx',0xF8);x.lea('eax','ebx',0xEC);x.rr('39','eax','edx');x.jump('ne','refuse');save('edx',32)
    x.mem('0fb7',R['eax'],'edx');x.cmp('eax',p.group_capacity);x.jump('ae','refuse');save('eax',36)
    x.imul('eax','eax',0x268);x.rr('01','eax','edi');x.ri(0,'eax',p.manager_groups)
    load('edx',20);x.cmpm('edx','eax',0x44);x.jump('ne','refuse')
    load('ecx',24);x.cmpm('ecx','eax',0x30);x.jump('ne','refuse')
    for off,value in ((0x24,1),(0x28,1)):
        x.op(7,value,'eax',off);x.jump('ne','refuse')
    x.load('ecx','eax',0x48);x.cmp('ecx',128);x.jump('ae','refuse');save('ecx',40)
    # Every requested queue entry is validated before the first native mutation.
    x.op(7,p.group_capacity,'edi',0x72AB4);x.jump('ne','refuse')
    x.load('ecx','edi',0x72AB8)
    if version<3:x.cmp('ecx',5);x.jump('below','refuse')
    x.cmp('ecx',p.group_capacity);x.jump('above','refuse')
    if version>=3:
        # 590700 can consume six template groups plus its tail reservation.
        # Leave seven per remaining/current skill reservation, plus one officer
        # for each later guard. Current guard officer was already constructed.
        # Native reserve: slot0=23, slot1=15, slot2=7. Divide the spare
        # capacity across the remaining guard positions, rounding up so an
        # uneven final budget does not systematically favor the last guard.
        x.store('ecx',disp=data+0x84);load('eax',16);x.imul('eax','eax',8)
        x.imm('edx',23);x.rr('29','edx','eax');x.store('edx',disp=data+0x8C)
        x.rr('89','eax','edx');x.ri(0,'eax',2);x.store('eax',disp=data+0x88)
        x.rr('39','ecx','eax');x.jump('below','reserve_refuse')
        x.rr('29','ecx','edx');load('eax',16);x.imm('ebx',3);x.rr('29','ebx','eax')
        x.rr('89','eax','ecx');x.rr('01','eax','ebx');x.ri(5,'eax',1)
        x.imm('edx',0);x.emit('f7f3') # DIV EBX: ceil(spare / remaining positions)
        x.cmp('eax',2);x.jump('ae','minimum_ready');x.imm('eax',2);x.mark('minimum_ready')
        x.cmp('eax',5);x.jump('be','allocation_ready')
        x.imm('eax',5);x.mark('allocation_ready');save('eax',52)
        x.ri(5,'eax',1);save('eax',48);x.store('eax',disp=data+0x98)
        load('ebx',12)
    x.load('eax','edi',0x72AB0);x.sane('eax','refuse')
    x.load('edx','edi',0x72ABC);x.cmp('edx',p.group_capacity);x.jump('ae','refuse')
    for i in range(5):
        if version>=3:
            x.op(7,i,disp=data+WORK+52);x.jump('be','preflight_done')
        x.imul('ecx','edx',4);x.rr('01','ecx','eax');x.load('ecx','ecx')
        x.cmp('ecx',p.group_capacity);x.jump('ae','refuse')
        for j in range(i):x.cmpm('ecx',disp=data+QUEUE_IDS+j*4);x.jump('eq','refuse')
        x.store('ecx',disp=data+QUEUE_IDS+i*4)
        x.imul('esi','ecx',0x268);x.rr('01','esi','edi');x.ri(0,'esi',p.manager_groups)
        x.cmpm('ecx','esi',0x18);x.jump('ne','refuse')
        for off,value in ((0x44,250),(0x28,0),(0x10,0),(0x14,0),(0x2C,2),(0x30,0xFFFFFFFF)):
            x.op(7,value,'esi',off);x.jump('ne','refuse')
        x.ri(0,'edx',1);x.cmp('edx',p.group_capacity);x.jump('below','head_'+str(i))
        x.imm('edx',0);x.mark('head_'+str(i))
    if version>=3:x.mark('preflight_done')
    load('eax',16);x.imul('eax','eax',STRIDE);x.ri(0,'eax',data+REGISTRY);save('eax',44)
    x.set(0,'eax');load('ecx',0);x.store('ecx','eax',4);load('ecx',20);x.store('ecx','eax',8)
    load('ecx',28);x.store('ecx','eax',12);load('ecx',24);x.store('ecx','eax',16)
    load('ecx',8);x.store('ecx','eax',24);load('ecx',36);x.store('ecx','eax',28)
    load('ebx',12);x.load('ecx','ebx',0x68);x.store('ecx','eax',0x34)
    if version>=3:
        load('ecx',48);x.store('ecx','eax',0x38);x.imul('ecx','ecx',30);x.store('ecx','eax',0x3C)
    for i in range(5):
        if version>=3:
            x.set(0,'eax',0x20+i*4);x.op(7,i,disp=data+WORK+52);x.jump('be','registry_next_'+str(i))
        x.load('ecx',disp=data+QUEUE_IDS+i*4);x.store('ecx','eax',0x20+i*4)
        if version>=3:x.mark('registry_next_'+str(i))
    for i in range(4):x.load('ecx','ebx',0x18+i*4);x.store('ecx',disp=data+POSITION+i*4)
    x.set(865,disp=data+PAIR);x.set(30,disp=data+PAIR+4)
    # Save the complete native x87/SSE state across the exact native helper ABI.
    x.set(0x1F80,disp=data+0x7C)
    x.emit('89e581ec3002000083e4f089e60fae06dbe3fc') # aligned FXSAVE, FNINIT, CLD
    x.mem('0fae',2,disp=data+0x7C) # standard MXCSR for native helper calls
    for i in range(5):
        if version>=3:x.op(7,i,disp=data+WORK+52);x.jump('be','creation_done')
        load('ecx',0);x.ri(0,'ecx',0x71EE4);x.call(code,base+0x4EB8F0)
        x.cmpm('eax',disp=data+QUEUE_IDS+i*4);x.jump('ne','mutation_failed')
        load('edx',32);x.mem('6689',R['eax'],'edx',(i+1)*2)
        load('edx',12);x.set(i+2,'edx',0x100)
        if i<4:
            if version>=3:x.op(7,i,disp=data+WORK+48);x.jump('eq','reserve_'+str(i))
            load('edx',40);x.emit('52');x.imm('edx',data+PAIR);x.emit('52')
            x.imm('edx',i+1);x.emit('52');load('edx',20);x.emit('52')
            x.rr('89','ecx','eax');x.imm('eax',data+POSITION);x.call(code,base+0x58EEC0)
            x.ri(0,'esp',16)
            if version>=3:x.jump('jmp','creation_next_'+str(i))
        if i==4 or version>=3:
            if version>=3:x.mark('reserve_'+str(i))
            load('edx',20);x.emit(bytes((0x6A,i+1)));x.call(code,base+0x4F1540);x.ri(0,'esp',4)
        if version>=3:x.mark('creation_next_'+str(i))
    if version>=3:x.mark('creation_done')
    load('ebx',12);x.op(1,0x2000,'ebx',0x68)
    load('eax',44);x.set(1,'eax')
    inc(0x14)
    if version>=3:
        load('ecx',48);x.imul('ecx','ecx',30);x.mem('01',R['ecx'],disp=data+0x18)
        x.op(7,4,disp=data+WORK+48);x.jump('eq','full_army');inc(0x94);x.mark('full_army')
    else:x.op(0,120,disp=data+0x18)
    x.jump('jmp','restore_fx')
    x.mark('mutation_failed');inc(0x30);x.set(0,disp=data+8)
    x.mark('restore_fx');x.emit('0fae0e89ec') # FXRSTOR [ESI]; MOV ESP,EBP
    x.jump('jmp','unlock')
    if version>=3:
        x.mark('reserve_refuse');inc(0x80);x.set(1,disp=data+0x90)
    x.mark('refuse');inc(0x1C)
    x.mark('unlock');x.set(0,disp=recall+16)
    x.mark('own_unlock');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d');x.emit(bytes.fromhex(SITES['CREATE_GUARD_ARMY'][1]))
    x.emit(relative_jump(code+len(x.code),base+0x590F92));return x.finish()


def limit_bridge(base,data,code,auto,recall,*,version=VERSION,pool=None):
    p=resolve_pool(pool)
    x=Asm();g=recall+POLICY_BASE;w=data+0x600
    inc=lambda o:x.mem('ff',0,disp=data+o)
    save=lambda r,o:x.store(r,disp=w+o)
    load=lambda r,o:x.load(r,disp=w+o)
    x.emit('9c60')
    for off,value in ((0,MAGIC),(4,version),(8,1)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    # Only the native gate/refill caller, preserving unrelated helper uses.
    x.op(7,base+0x56588F,'esp',36);x.jump('ne','native')
    x.load('edi',disp=base+0x6A91E8);x.sane('edi','native')
    x.load('ebx','esp',16);x.sane('ebx','native')
    x.load('eax','ebx',0x38);x.ri(5,'eax',122);x.cmp('eax',2);x.jump('above','native')
    x.imul('ecx','eax',STRIDE);x.ri(0,'ecx',data+REGISTRY)
    x.op(7,1,'ecx');x.jump('ne','native')
    x.cmpm('edi','ecx',4);x.jump('ne','native')
    x.ri(0,'eax',122);x.cmpm('eax','ecx',8);x.jump('ne','native')
    x.imul('edx','eax',0x110);x.rr('01','edx','edi');x.ri(0,'edx',0x4B0)
    x.rr('39','edx','ebx');x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','skip')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=recall+16);x.jump('ne','own_skip')
    save('edi',0);save('ebx',4)
    x.load('eax','ebx',0x38);save('eax',16);x.ri(5,'eax',122);save('eax',8)
    x.imul('ecx','eax',STRIDE);x.ri(0,'ecx',data+REGISTRY);save('ecx',12)
    inc(0x20)
    for address,value in ((g,POLICY_MAGIC),(g+8,1),(auto+24,1),(auto+20,0)):
        x.op(7,value,disp=address);x.jump('ne','scope_skip')
    x.load('eax',disp=base+0x6D10BC);x.sane('eax','scope_skip')
    x.op(7,4,'eax',0x1C784);x.jump('ne','scope_skip')
    load('ecx',12);x.load('eax',disp=auto+16);x.cmpm('eax','ecx',24);x.jump('ne','scope_skip')
    x.load('edx',disp=base+0x6A91EC);x.sane('edx','scope_skip')
    x.op(7,1,'edx',0x590);x.jump('ne','scope_skip')
    x.op(7,0,'edx',0x108);x.jump('ne','scope_skip')
    load('eax',8);x.imul('eax','eax',4 if version==1 else ROSTER_STRIDE);x.rr('01','eax','edx');load('ecx',16)
    x.cmpm('ecx','eax',0x1C4);x.jump('ne','scope_skip')
    load('ebx',4);load('eax',12)
    for off in (12,16):
        x.load('ecx','eax',off);x.cmpm('ecx','ebx',0x44 if off==12 else 0x50);x.jump('ne','scope_skip')
    for off,value in ((0x40,0),(0xFC,6),*(() if version>=3 else ((0x100,6),))):
        x.op(7,value,'ebx',off);x.jump('ne','scope_skip')
    if version>=3:
        x.load('ecx','eax',0x38);x.cmp('ecx',1);x.jump('below','scope_skip')
        x.cmp('ecx',4);x.jump('above','scope_skip');save('ecx',40)
        x.imul('edx','ecx',30);x.cmpm('edx','eax',0x3C);x.jump('ne','scope_skip')
        x.ri(0,'ecx',2);x.cmpm('ecx','ebx',0x100);x.jump('ne','scope_skip')
    x.load('esi','ebx',0xF8);x.sane('esi','scope_skip');save('esi',20)
    x.load('eax','esp',20);x.cmp('eax',p.group_capacity);x.jump('ae','scope_skip');save('eax',24)
    x.load('edx','esp',40);x.cmp('edx',p.group_capacity);x.jump('ae','scope_skip');save('edx',28)
    x.rr('39','eax','edx');x.jump('eq','scope_skip')
    load('ecx',12)
    if version>=3:
        x.load('eax','ecx',0x38);x.ri(0,'eax',1);x.imul('eax','eax',4);x.rr('01','ecx','eax')
        x.cmpm('edx','ecx',0x1C);x.jump('ne','scope_skip')
    else:x.cmpm('edx','ecx',0x30);x.jump('ne','scope_skip')
    x.imm('ebp',0);x.imm('ebx',0)
    for i in range(6):
        nxt='group_next_'+str(i)
        if version>=3 and i>0:
            load('eax',40);x.ri(0,'eax',1);x.cmp('eax',i);x.jump('below',nxt)
        x.mem('0fb7',R['eax'],'esi',i*2)
        load('ecx',12);x.cmpm('eax','ecx',0x1C+i*4);x.jump('ne','scope_skip')
        x.cmp('eax',p.group_capacity);x.jump('ae','scope_skip')
        x.imul('ecx','eax',0x268);load('edi',0);x.rr('01','ecx','edi');x.ri(0,'ecx',p.manager_groups)
        x.cmpm('eax','ecx',0x18);x.jump('ne','scope_skip')
        load('edx',16);x.cmpm('edx','ecx',0x44);x.jump('ne','scope_skip')
        if i==0:
            load('edx',12);x.load('edx','edx',16);x.cmpm('edx','ecx',0x30);x.jump('ne','scope_skip')
            x.op(7,1,'ecx',0x28);x.jump('ne','scope_skip')
            continue
        if version>=3:
            load('edx',40);x.ri(0,'edx',1);x.cmp('edx',i);x.jump('ne','infantry_'+str(i))
            x.op(7,0,'ecx',0x28);x.jump('ne','scope_skip')
            for off in (0x10,0x14):x.op(7,0,'ecx',off);x.jump('ne','scope_skip')
            x.jump('jmp',nxt);x.mark('infantry_'+str(i))
        elif i==5:
            x.op(7,0,'ecx',0x28);x.jump('ne','scope_skip')
            for off in (0x10,0x14):x.op(7,0,'ecx',off);x.jump('ne','scope_skip')
            x.jump('jmp',nxt)
        for off,value in ((0x30,865),(0x2C,30),(0x24,30)):
            x.op(7,value,'ecx',off);x.jump('ne','scope_skip')
        x.load('edx','ecx',0x28);x.cmp('edx',30);x.jump('above','scope_skip');x.rr('01','ebp','edx')
        load('edx',24);x.rr('39','edx','eax');x.jump('ne',nxt)
        x.emit('43');save('ecx',32)
        x.mark(nxt)
    x.cmp('ebx',1);x.jump('ne','scope_skip');save('ebp',36)
    load('esi',32);x.load('ecx','esi',0x10);x.rr('89','eax','ecx');x.ri(4,'eax',0xC0000000)
    x.cmp('eax',0);x.jump('ne','scope_skip');x.imm('ebx',0);x.imm('edx',30)
    x.mark('bits');x.emit('f7c101000000');x.jump('eq','bit_next');x.emit('43')
    x.mark('bit_next');x.emit('d1e94a');x.jump('ne','bits');x.cmpm('ebx','esi',0x28);x.jump('ne','scope_skip')
    x.imm('eax',30);x.rr('29','eax','ebx');x.store('eax',disp=data+0x4C)
    load('edi',0)
    for off,value in ((0x58,0),(0x284,1)):
        x.op(7,value,'edi',off);x.jump('ne','scope_skip')
    x.load('ecx','edi',0xC0);x.load('edx','edi',0x2EC)
    for reg in ('ecx','edx'):x.cmp(reg,999);x.jump('above','scope_skip')
    x.rr('01','edx','ecx');x.cmp('edx',0);x.jump('ne','nonzero')
    x.imm('ecx',1);x.imm('edx',2)
    x.mark('nonzero');x.imul('ecx','ecx',100)
    for off in (12,16,20):
        x.load('eax',disp=g+off);x.cmp('eax',1);x.jump('below','scope_skip')
        x.cmp('eax',99);x.jump('above','scope_skip')
        if off>12:
            x.load('ebx',disp=g+off-4);x.rr('39','eax','ebx');x.jump('be','scope_skip')
    for off,target in ((12,30),(16,60),(20,90)):
        x.load('eax',disp=g+off);x.emit('0fafc2');x.rr('39','ecx','eax');x.jump('below','target_'+str(target))
    x.imm('eax',120);x.jump('jmp','target_ready')
    for target in (30,60,90):x.mark('target_'+str(target));x.imm('eax',target);x.jump('jmp','target_ready')
    x.mark('target_ready')
    if version>=3:
        load('ecx',40);x.imul('ecx','ecx',30);x.rr('39','eax','ecx');x.jump('be','target_fits')
        x.rr('89','eax','ecx');x.mark('target_fits')
    x.store('eax',disp=data+0x48);load('ecx',36);x.store('ecx',disp=data+0x44)
    load('edx',16);x.store('edx',disp=data+0x40)
    x.mem('03',R['ecx'],disp=data+0x4C);x.rr('39','ecx','eax');x.jump('above','blocked')
    inc(0x24);x.jump('jmp','unlock_native')
    x.mark('blocked');inc(0x28);x.set(0,disp=recall+16);x.jump('jmp','own_skip')
    x.mark('scope_skip');inc(0x2C)
    x.mark('unlock_native');x.set(0,disp=recall+16);x.set(0,disp=data+12);x.jump('jmp','native')
    x.mark('own_skip');x.set(0,disp=data+12)
    x.mark('skip');x.set(0,'esp',28);x.emit('619dc3')
    x.mark('native');x.emit('619d');x.emit(original(base,'GUARD_REPLACEMENT_LIMIT'))
    x.emit(relative_jump(code+len(x.code),base+0x5542D6));return x.finish()


def check_code(memory):
    checks={0x590F13:'e838d8ffff',0x590F38:'8b4830894b508b10',0x590FD0:'e89be9fdff',
            0x4EB8F0:'83b9d40b000000',0x58EEC0:'83ec2c53558b6c2438568bf1578bf8',
            0x4F156F:'8950448b54240489501c',0x565667:'f7c600200000'}
    for rva,sig in checks.items():
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),'E_GUARD_NATIVE_CODE_'+hex(rva))


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(soldiers_per_guard=120,squads_per_guard=4,allied_charge_owners_used=False,
                  skill_required=False,gate_timing_preserved=True,minimum_guaranteed=False,
                  soldiers_per_guard_is_maximum=True,partial_army_sizes=[30,60,90,120],
                  army_sizes_adapt_to_native_capacity=not record or record['version']>=3,
                  native_roster_stride=ROSTER_STRIDE,
                  creation_requires_next_guard_initialization=True)
    if not record:return result
    if record['version']>=3:
        raw=memory.read(record['data_address']+0x80,0x14)
        result['capacity_guard']={'enabled':True,'group_pool_capacity':600,'pool_expanded':False,
            'reserve_refusals':word(raw),'last_free_groups':word(raw,4),
            'last_required_free_groups':word(raw,8),'last_reserved_native_groups':word(raw,12),
            'last_refusal_reason':'NATIVE_GROUP_RESERVE' if word(raw,16)==1 else None,
            'extra_army_policy':'DISTRIBUTE_30_60_90_120_WITH_NATIVE_RESERVE','reserve_scope':'REMAINING_BODYGUARDS_AND_THEIR_NATIVE_RESERVATIONS',
            'live_validated':False}
        result['capacity_guard']['partial_armies_created']=uint(memory,record['data_address']+0x94)
        result['capacity_guard']['last_squads_planned']=uint(memory,record['data_address']+0x98)
    armies=[]
    for slot in range(3):
        a=record['data_address']+REGISTRY+slot*STRIDE;raw=memory.read(a,0x40 if record['version']>=3 else 0x38)
        if not word(raw):continue
        squads=word(raw,0x38) if record['version']>=3 else 4
        entry={'slot':slot,'owner':word(raw,8),'character':word(raw,12),'alias':word(raw,16),
               'configured_soldiers':squads*30,'configured_squads':squads,'capture_sequence':word(raw,24),'read_only':True}
        try:
            state,owner=registered(memory,record,slot,raw)
            groups=owner_groups(memory,state,word(raw,8))
            require([g['squad'] for g in groups]==[word(raw,0x1C+i*4) for i in range(squads+2)],'E_GUARD_LIST_CHANGED')
            infantry=[g for g in groups if g['unit_type']==865 and g['template']==30]
            require(len(infantry) in (squads,squads+1) and all(g['quantity_current']<=30 for g in infantry)
                    and sum(g['quantity_current'] for g in infantry)<=squads*30,'E_GUARD_QUANTITY')
            entry.update(available=True,groups=groups,logical_soldiers=sum(g['quantity_current'] for g in infantry),
                         materialized_members=sum(g['materialized_bits'].bit_count() for g in infantry),
                         officer_quantity=groups[0]['quantity_current'],
                         guard_ai_active=bool(uint(memory,state['ai']+word(raw,8)*0xAC+0x90)&1))
        except Exception as error:entry.update(available=False,stale=True,error=str(error))
        armies.append(entry)
    result['armies']=armies
    return result


def registered(memory,record,slot,raw):
    state=player_snapshot(memory);owner_id=122+slot
    require(state['owner']==0 and state['manager']==word(raw,4),'E_GUARD_CONTEXT_CHANGED')
    require(uint(memory,record['auto_data_address']+16)==word(raw,24),'E_GUARD_LOAD_CHANGED')
    require(word(raw,8)==owner_id and uint(memory,state['players']+0x1C4+slot*ROSTER_STRIDE)==owner_id,'E_GUARD_ROSTER_CHANGED')
    owner=state['manager']+0x4B0+owner_id*0x110
    squads=word(raw,0x38) if record['version']>=3 else 4
    require(1<=squads<=4,'E_GUARD_SQUADS')
    require(uint(memory,owner+0x38)==owner_id and uint(memory,owner+0x40)==0
            and uint(memory,owner+0x44)==word(raw,12) and uint(memory,owner+0x50)==word(raw,16)
            and uint(memory,owner+0xFC)==6 and uint(memory,owner+0x100)==squads+2,'E_GUARD_IDENTITY_CHANGED')
    address=uint(memory,owner+0xF8)
    require(0x10000<=address<0xFFF00000,'E_GUARD_LIST_POINTER')
    require(list(struct.unpack('<'+'H'*(squads+2),memory.read(address,(squads+2)*2)))==[word(raw,0x1C+i*4) for i in range(squads+2)],'E_GUARD_LIST_CHANGED')
    return state,owner


def changes_for_enabled(memory,record,enabled):
    # Native groups remain until the game cleans this battle, as with the
    # player's configured squads. Relinquish only the reinforcement bit added
    # by this feature, preserving every other current flag.
    changes=[]
    for slot in range(3):
        raw=memory.read(record['data_address']+REGISTRY+slot*STRIDE,0x40 if record['version']>=3 else 0x38)
        if not word(raw) or word(raw,0x34)&0x2000:continue
        try:state,owner=registered(memory,record,slot,raw)
        except Exception:continue
        value=uint(memory,owner+0x68);after=value|0x2000 if enabled else value&~0x2000
        if value!=after:changes.append((owner+0x68,struct.pack('<I',value),struct.pack('<I',after)))
    return changes
