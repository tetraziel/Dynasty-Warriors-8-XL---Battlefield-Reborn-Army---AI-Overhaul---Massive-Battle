"""Opt-in, local enemy-officer crowd priority at a native target decision.

Host reads publish a short-lived plan. The game thread validates both actors,
asks the native target predicate, and substitutes the native setter argument.
It never writes target/strategic fields directly or creates game threads.
"""
import math
import struct
import time
from core import require,word,uint
from recall_bridge import Asm,R
from bridge import relative_jump
import combat_scope as scope
import bundle_support as bundle
from troop_health_scan import snapshot

FEATURE='ENEMY_OFFICER_CROWD_TARGET_50_TEST'
MAGIC=0x3154434F;VERSION=3;LEGACY_VERSION=1;LEGACY_VERSIONS=(1,2);SIZE=0x8000;CODE_SIZE=0x4000
SITES={'NATIVE_OFFICER_TARGET':(0x50A280,'558b6c240856')}
COUNTERS={'natural_decisions':0x10,'infantry_redirects':0x14,'player_returns':0x18,
          'native_predicate_refusals':0x1C,'scope_skips':0x20,'stale_skips':0x24,
          'busy_skips':0x28,'native_other_targets_preserved':0x2C,
          'held_infantry_decisions':0x30,'enemy_leaders_validated':0x34,
          'other_callers_preserved':0x38}
GEN=0x80;VALID=0x84;CONTEXT=0x88
PLANS=0x1000;PLAN_STRIDE=0x30;TRACK=0x4000;TRACK_STRIDE=0x20
ACTOR=0x140;TARGET=0x180;TEMP=0x200
THRESHOLD=50;RADIUS=1200.0;HEIGHT=600.0;MAX_AGE=90;REFRESH_SECONDS=0.5


def build_bridge(base,data,code,auto,recall,name,*,legacy=False,legacy_version=None):
    require(name in SITES,'E_OFFICER_CROWD_SITE')
    version=(legacy_version or LEGACY_VERSION) if legacy else VERSION
    require(version in (1,2,3),'E_OFFICER_CROWD_VERSION')
    threshold=100 if version==1 else THRESHOLD
    x=Asm();x.emit('9c60');inc=lambda off:x.mem('ff',0,disp=data+off)
    for off,value in ((0,MAGIC),(4,version),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    if version>=3:
        # Include the native retaliation decision: it otherwise overrides the
        # ordinary candidate with the player who last attacked the officer.
        x.op(7,base+0x595D78,'esp',36);x.jump('eq','supported_caller')
        x.op(7,base+0x595B90,'esp',36);x.jump('eq','supported_caller')
        x.op(7,base+0x595AA9,'esp',36);x.jump('eq','supported_caller')
        inc(0x38);x.jump('jmp','native');x.mark('supported_caller')
    else:
        x.op(7,base+0x595D78,'esp',36);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','busy')
    inc(0x10)
    x.load('eax','esp',40);x.store('eax',disp=data+TEMP)
    x.load('eax',disp=data+GEN);x.emit('a901000000');x.jump('ne','stale')
    x.store('eax',disp=data+TEMP+4)
    x.op(7,1,disp=data+VALID);x.jump('ne','stale')
    scope.roots(x,base,data,auto,'skip')
    for ro,co in ((0,0),(4,4),(8,8),(0x10,12)):
        x.load('eax',disp=data+scope.ROOT+ro);x.cmpm('eax',disp=data+CONTEXT+co);x.jump('ne','stale')
    x.load('eax',disp=data+scope.ROOT+4);x.load('eax','eax',0x53E90)
    x.mem('2b',R['eax'],disp=data+CONTEXT+16);x.cmp('eax',MAX_AGE);x.jump('above','stale')
    x.load('ecx','esp');x.sane('ecx','skip');x.load('eax','ecx',0x7C)
    scope.physical(x,data,ACTOR,'skip',prefix='officer')
    x.load('eax','esp');x.cmpm('eax',disp=data+ACTOR+8);x.jump('ne','skip')
    scope.officer(x,data,ACTOR,'skip',allow_group_members=version>=3)
    x.op(7,1,disp=data+ACTOR+0x20);x.jump('ne','skip')
    if version>=3:inc(0x34)
    x.load('eax',disp=data+ACTOR);x.imul('eax','eax',PLAN_STRIDE);x.ri(0,'eax',data+PLANS)
    x.store('eax',disp=data+TEMP+8)
    for po,ao in ((0,0),(4,0x14),(8,0x1C)):
        x.load('ecx',disp=data+ACTOR+ao);x.cmpm('ecx','eax',po);x.jump('ne','stale')
    x.load('eax',disp=data+ACTOR);x.imul('eax','eax',TRACK_STRIDE);x.ri(0,'eax',data+TRACK)
    x.store('eax',disp=data+TEMP+12)
    x.load('ecx',disp=data+CONTEXT+20);x.cmp('ecx',150);x.jump('ae','stale')
    x.load('edx',disp=data+scope.ROOT+8);x.cmpm('ecx','edx',0x110);x.jump('ne','stale')
    x.imul('edx','ecx',0xE0);x.load('ecx',disp=data+scope.ROOT+4)
    x.rr('01','edx','ecx');x.ri(0,'edx',0x21EF8)
    x.store('edx',disp=data+TEMP+16)
    x.cmpm('edx',disp=data+TEMP);x.jump('eq','allowed_argument')
    # Only replace the player's target or one previously managed by this hook.
    x.op(7,1,'eax',0x14);x.jump('ne','other')
    x.load('ecx',disp=data+scope.ROOT+0x10);x.cmpm('ecx','eax');x.jump('ne','other')
    x.load('ecx',disp=data+ACTOR+0x14);x.cmpm('ecx','eax',4);x.jump('ne','other')
    x.load('ecx','eax',8);x.cmp('ecx',150);x.jump('ae','other')
    x.imul('edx','ecx',0x30);x.load('ebx',disp=data+scope.ROOT)
    x.rr('01','edx','ebx');x.ri(0,'edx',0x6B210)
    x.cmpm('ecx','edx');x.jump('ne','other')
    x.load('ebx','eax',12);x.cmpm('ebx','edx',8);x.jump('ne','other')
    x.imul('edx','ecx',0xE0);x.load('ebx',disp=data+scope.ROOT+4)
    x.rr('01','edx','ebx');x.ri(0,'edx',0x21EF8)
    x.cmpm('edx',disp=data+TEMP);x.jump('ne','other')
    x.mark('allowed_argument')
    x.load('eax',disp=data+TEMP+8);x.load('ecx','eax',0x10)
    x.cmp('ecx',1);x.jump('above','stale')
    x.cmp('ecx',0);x.jump('eq','return_mode')
    x.op(7,threshold,'eax',12);x.jump('below','stale')
    x.jump('jmp','target_ready')
    x.mark('return_mode')
    x.op(7,threshold,'eax',12);x.jump('ae','stale')
    x.load('ecx',disp=data+TEMP+16);x.cmpm('ecx',disp=data+TEMP)
    x.jump('ne','target_ready')
    x.load('ecx',disp=data+TEMP+12);x.set(0,'ecx',0x14)
    x.jump('jmp','unlock') # native already chose player: no artificial return count
    x.mark('target_ready');x.load('eax','eax',0x14)
    scope.physical(x,data,TARGET,'skip',prefix='target')
    x.op(7,0,disp=data+TARGET+0x20);x.jump('ne','skip')
    x.load('eax',disp=data+TEMP+8)
    for po,to in ((0x14,0),(0x18,0x14),(0x1C,0x1C),(0x20,0x18)):
        x.load('ecx',disp=data+TARGET+to);x.cmpm('ecx','eax',po);x.jump('ne','stale')
    x.op(7,1,'eax',0x10);x.jump('ne','check_player')
    scope.infantry(x,data,TARGET,'skip');x.jump('jmp','predicate')
    x.mark('check_player')
    x.load('ecx',disp=data+TARGET+8);x.cmpm('ecx',disp=data+TEMP+16);x.jump('ne','skip')
    x.mark('predicate')
    # The native predicate is run at the native decision, on this game thread.
    # Save complete x87/SSE state; native calls cannot outlive our busy guard.
    x.emit('89e581ec4002000083e4f0');x.store('esp','ebp',-4)
    x.mem('0fae',0,'esp');x.emit('dbe3');x.set(0x1F80,'ebp',-8)
    x.mem('0fae',2,'ebp',-8);x.emit('fc')
    x.load('eax',disp=data+TARGET+8);x.emit('50')
    x.load('eax',disp=data+ACTOR+8);x.emit('50')
    x.call(code,base+0x589AE0);x.emit('0fb6c0');x.store('eax',disp=data+TEMP+20)
    x.load('esp','ebp',-4);x.mem('0fae',1,'esp');x.emit('89ec')
    x.op(7,0,disp=data+TEMP+20);x.jump('eq','refused')
    x.op(7,1,disp=data+VALID);x.jump('ne','stale')
    x.load('eax',disp=data+TEMP+4);x.cmpm('eax',disp=data+GEN);x.jump('ne','stale')
    x.load('ecx',disp=data+TARGET+8);x.store('ecx','esp',40)
    x.load('eax',disp=data+TEMP+12);x.load('edx',disp=data+TEMP+8)
    x.op(7,1,'edx',0x10);x.jump('ne','returned')
    for source,dest in ((scope.ROOT+0x10,0),(ACTOR+0x14,4),(TARGET,8),(TARGET+0x14,12)):
        x.load('ecx',disp=data+source);x.store('ecx','eax',dest)
    x.set(1,'eax',0x14)
    x.load('ecx',disp=data+TARGET+8);x.cmpm('ecx',disp=data+TEMP)
    x.jump('eq','held');inc(0x14);x.jump('jmp','unlock')
    x.mark('held');inc(0x30);x.jump('jmp','unlock')
    x.mark('returned');x.set(0,'eax',0x14);inc(0x18);x.jump('jmp','unlock')
    x.mark('refused');inc(0x1C);x.jump('jmp','unlock')
    x.mark('other');inc(0x2C);x.jump('jmp','unlock')
    x.mark('stale');inc(0x24);x.jump('jmp','unlock')
    x.mark('skip');inc(0x20)
    x.mark('unlock');x.set(0,disp=data+12);x.jump('jmp','native')
    x.mark('busy');inc(0x28)
    x.mark('native');x.emit('619d');x.emit(bytes.fromhex(SITES[name][1]))
    x.emit(relative_jump(code+len(x.code),base+0x50A286));return x.finish()


def check_code(memory):
    # Main v5 owns the predicate entry. Validate its untouched body and the
    # main lease separately rather than accepting a foreign entry hook.
    for rva,sig in ((0x595D73,'e80845f7ff'),(0x595B8B,'e8f046f7ff'),
                    (0x595AA4,'e8d747f7ff'),(0x50A349,'838fcc00000002'),
                    (0x589AE6,'83ec1c538b5d0c')):
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),
                'E_OFFICER_CROWD_NATIVE_'+hex(rva))
    entry=next((p for p in (getattr(memory,'lease',None) or {}).get('patches',[])
                if p['mode']=='TARGET_FILTER_ENTRY'),None)
    require(entry and memory.read(entry['site'],len(bytes.fromhex(entry['replacement_hex'])))==
            bytes.fromhex(entry['replacement_hex']),'E_OFFICER_CROWD_REQUIRE_OWNED_TARGET_FILTER')


def _alive(row):
    hp=row['hp']
    return (hp['valid_numeric_values'] and hp['current']>0 and
            row['logical_member'] and row['materialized_member'])


def plan(frame):
    """Count materialized allied infantry near each enemy officer, not map totals."""
    groups={g['squad']:g for g in frame['groups']}
    rows=[r for r in frame['agents'] if _alive(r)]
    player=next(r for r in rows if r['relation']=='PLAYER')
    allies=[r for r in rows if r['side']==0 and
        r['relation'] in ('PERSONAL_INFANTRY','BODYGUARD_INFANTRY','NATIVE_ALLIED_INFANTRY')
        and not int(r['item_flags_2c_raw'],16)&0x10]
    officers=[r for r in rows if r['side']==1 and r['slot']==0 and
        int(r['item_flags_2c_raw'],16)&0x10 and 1<=groups[r['squad']]['quantity_max']<=30]
    decisions=[]
    for officer in officers:
        origin=officer['position'];near=[]
        if origin:
            for ally in allies:
                pos=ally['position']
                if not pos or abs(pos[1]-origin[1])>HEIGHT:continue
                d2=(pos[0]-origin[0])**2+(pos[2]-origin[2])**2
                if math.isfinite(d2) and d2<=RADIUS**2:near.append((d2,ally['agent'],ally))
        active=len(near)>=THRESHOLD
        target=min(near,key=lambda t:t[:2])[2] if active else player
        decisions.append({'officer':officer,'target':target,'local_allied_infantry':len(near),
                          'priority_active':active})
    return decisions


def refresh(memory,record):
    key=(record['data_address'],tuple(memory.cookie));now=time.monotonic()
    prior=getattr(memory,'_crowd_refresh',None)
    if prior and prior['key']==key and now<prior['due']:return
    memory._crowd_refresh={'key':key,'due':now+REFRESH_SECONDS}
    address=record['data_address'];generation=uint(memory,address+GEN)
    require(not generation&1,'E_OFFICER_CROWD_PUBLICATION_INTERRUPTED')
    generation=(generation+2)&0xFFFFFFFE
    try:
        capture=uint(memory,record['auto_data_address']+16)
        frame=snapshot(memory);decisions=plan(frame);state=frame['state']
        require(capture==uint(memory,record['auto_data_address']+16),'E_OFFICER_CROWD_LOAD_CHANGED')
        payload=bytearray(150*PLAN_STRIDE)
        for decision in decisions:
            a,t=decision['officer'],decision['target']
            struct.pack_into('<10I',payload,a['agent']*PLAN_STRIDE,
                a['agent'],a['squad'],a['owner'],decision['local_allied_infantry'],
                int(decision['priority_active']),t['agent'],t['squad'],t['owner'],t['slot'],frame['player_agent'])
        context=struct.pack('<6I',state['manager'],state['ai'],state['players'],capture,
                            frame['tick_after'],frame['player_agent'])
        memory.write(address+GEN,struct.pack('<I',(generation-1)&0xFFFFFFFF))
        memory.write(address+VALID,bytes(4))
        # Transport.write uses ctypes.create_string_buffer, which accepts
        # immutable bytes but rejects bytearray before WriteProcessMemory.
        memory.write(address+PLANS,bytes(payload));memory.write(address+CONTEXT,context)
        memory.write(address+VALID,struct.pack('<I',1))
        memory.write(address+GEN,struct.pack('<I',generation))
        memory._crowd_last={'available':True,'stale':False,'tick':frame['tick_after'],
            'officers':[{'agent':d['officer']['agent'],'local_allied_infantry':d['local_allied_infantry'],
                'priority_active':d['priority_active'],'planned_target_agent':d['target']['agent']}
                for d in decisions]}
    except Exception as error:
        memory.write(address+VALID,bytes(4))
        # Recover only our own interrupted publication; never leave an odd plan.
        memory.write(address+GEN,struct.pack('<I',generation))
        memory._crowd_last={'available':False,'stale':True,
                            'error_type':type(error).__name__,'error':str(error)[:512]}


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    threshold=100 if record and record['version']==LEGACY_VERSION else THRESHOLD
    result.update(threshold_allied_infantry=threshold,local_radius_xz=RADIUS,
        maximum_height_difference=HEIGHT,maximum_plan_age_ticks=MAX_AGE,
        count_scope='ALIVE_MATERIALIZED_ALLIED_INFANTRY',native_target_predicate_used=True,
        target_changed_at='NATIVE_ACQUISITION_DECISION_ONLY',
        direct_target_writes=False,offscreen_orders_modified=False,remote_threads_created=False,
        returns_to_native_player_priority_below_threshold=True)
    version=record['version'] if record else VERSION
    result.update(officer_groups_with_followers_supported=version>=3,
        retaliation_player_priority_overridden=version>=3,
        supported_native_callers=['0x595d78','0x595b90','0x595aa9'] if version>=3 else ['0x595d78'])
    if record:result['local_plan']=getattr(memory,'_crowd_last',None)
    return result
