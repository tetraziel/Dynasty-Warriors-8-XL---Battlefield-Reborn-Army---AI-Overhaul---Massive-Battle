"""Optional 100000-unit Fog/view distance at verified native consumers.

No registry/preset/shared-constant writes. Existing native updates consume the
override. Only the two validated primary CView Far copies may be overwritten,
immediately after their native FSTP. No extra x87 instructions on that path.
"""
import struct
from core import require,word
from recall_bridge import Asm,R
from bridge import relative_jump
import bundle_support as bundle

FEATURE='FOG_DISTANCE_100000_TEST'
MAGIC=0x31474F46;VERSION=1;SIZE=0x1000;CODE_SIZE=0x18000
DISTANCE=100000.0;NATIVE_DISTANCE=80000.0
SITES={'SCENE_DISTANCE':(0x3B5B6D,'dc0d88ea4b01'),
       'VIEW_PARAMETERS':(0x3B5E3C,'dc0d88ea4b01'),
       'MOTION_VIEW':(0x22D02B,'dc0d88ea4b01'),
       'RENDER_VIEW':(0x208084,'dc0d88ea4b01'),
       'SCENE_VIEW_UPDATE':(0x3BF76D,'dc0d88ea4b01'),
       'PRIMARY_VIEW_FAR_COPY':(0x115919,'d99838010000')}
COUNTERS={'visits':0x10,'distance_multiplications':0x14,'primary_view_far_updates':0x18,
          'primary_view_far_overrides':0x1C,'primary_view_already_target':0x20,
          'nonstandard_far_preserved':0x24,'scope_skips':0x28,'busy_skips':0x2C,
          **{name.lower()+'_visits':0x30+i*4 for i,name in enumerate(SITES)}}
LAST_NATIVE,LAST_VIEW=0x50,0x54
DOUBLE_OFFSET,FLOAT_OFFSET=0x80,0x88
NATIVE_BITS=struct.unpack('<I',struct.pack('<f',NATIVE_DISTANCE))[0]
TARGET_BITS=struct.unpack('<I',struct.pack('<f',DISTANCE))[0]
SIGNATURES={0x115916:'d9451c',0x11591F:'d94520',0x115A21:'d98638010000',
            0x115A6A:'d98684000000',0x20807F:'e8bc21e3ff',
            0x3B5E37:'e80444c8ff',0x3B5B62:'e8d946c8ff',
            0x22D026:'e815d2e0ff',0x3BF768:'e8d3aac7ff'}


def original(base,name):
    return (b'\xDC\x0D'+struct.pack('<I',base+0x61EA88)) if name!='PRIMARY_VIEW_FAR_COPY' else bytes.fromhex(SITES[name][1])


def initialize_data(raw):
    struct.pack_into('<df',raw,DOUBLE_OFFSET,DISTANCE,DISTANCE)


def validate_data(memory,record):
    require(memory.read(record['data_address']+DOUBLE_OFFSET,12)==struct.pack('<df',DISTANCE,DISTANCE),
            'E_FOG_DISTANCE_CONSTANT_CHANGED')


def build_bridge(base,data,code,auto,recall,name,*,pool=None):
    require(name in SITES,'E_FOG_DISTANCE_SITE');x=Asm();x.emit('9c60')
    inc=lambda key:x.mem('ff',0,disp=data+COUNTERS[key])
    for off,value in ((0,MAGIC),(4,VERSION),(8,1),(0x70,auto),(0x74,recall),
                      (DOUBLE_OFFSET,0),(DOUBLE_OFFSET+4,0x40F86A00),(FLOAT_OFFSET,TARGET_BITS)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','busy')
    inc('visits')
    for address,value in ((auto+24,1),(auto+20,0),(recall+8,1),(recall+12,0),
                          (base+0x6CAAA0,0),(base+0x6CAAA4,0)):
        x.op(7,value,disp=address);x.jump('ne','skip')
    x.load('eax',disp=base+0x6A91EC);x.sane('eax','skip')
    for off,value in ((0x590,1),(0x108,0)):
        x.op(7,value,'eax',off);x.jump('ne','skip')
    x.load('eax',disp=base+0x6D10BC);x.sane('eax','skip')
    x.load('eax','eax',0x1C784);x.cmp('eax',3);x.jump('below','skip');x.cmp('eax',5);x.jump('above','skip')
    inc(name.lower()+'_visits')
    if name=='PRIMARY_VIEW_FAR_COPY':
        x.load('esi','esp',28);x.sane('esi','skip') # original EAX is the CView
        x.load('edi',disp=base+0x6A9574);x.sane('edi','skip')
        x.lea('eax','edi',0x40);x.rr('39','esi','eax');x.jump('eq','primary')
        x.lea('eax','edi',0x2C8);x.rr('39','esi','eax');x.jump('ne','skip')
        x.mark('primary');x.op(7,base+0x617660,'esi',0);x.jump('ne','skip')
        # Exactly the original pop/store, followed by one bounded integer write.
        # The x87 stack, control word, SSE and status have native semantics.
        x.mem('d9',3,'esi',0x138);inc('primary_view_far_updates')
        x.store('esi',disp=data+LAST_VIEW);x.load('eax','esi',0x138);x.store('eax',disp=data+LAST_NATIVE)
        x.cmp('eax',TARGET_BITS);x.jump('eq','already_target')
        x.cmp('eax',NATIVE_BITS);x.jump('ne','nonstandard')
        x.set(TARGET_BITS,'esi',0x138);inc('primary_view_far_overrides');x.jump('jmp','done')
        x.mark('already_target');inc('primary_view_already_target');x.jump('jmp','done')
        x.mark('nonstandard');inc('nonstandard_far_preserved')
        x.mark('done');x.set(0,disp=data+12);x.emit('619d');x.jump('jmp','return')
    else:
        inc('distance_multiplications');x.set(0,disp=data+12);x.emit('619d')
        x.mem('dc',1,disp=data+DOUBLE_OFFSET);x.jump('jmp','return')
    x.mark('skip');inc('scope_skips');x.set(0,disp=data+12);x.jump('jmp','native')
    x.mark('busy');inc('busy_skips')
    x.mark('native');x.emit('619d');x.emit(original(base,name))
    x.mark('return');x.emit(relative_jump(code+len(x.code),base+SITES[name][0]+6))
    return x.finish()


def check_code(memory):
    for rva,sig in SIGNATURES.items():
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),'E_FOG_DISTANCE_NATIVE_'+hex(rva))
    require(memory.read(memory.base+0x61EA88,8)==struct.pack('<d',NATIVE_DISTANCE),'E_FOG_DISTANCE_NATIVE_CONSTANT')


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(target_distance_units=DISTANCE,native_base_distance_units=NATIVE_DISTANCE,
        scope='SINGLE_PLAYER_MANY_FOG_RAW_0_PHASE_3_4_5_VERIFIED_CONSUMERS_AND_PRIMARY_CVIEW',
        selected_graphics_preset_modified=False,shared_native_constant_modified=False,
        optical_fog_shader_modified=False,near_plane_or_fov_modified=False,
        native_updates_required_for_activation_and_restore=True,
        all_fog_consumers_covered=False,actual_rendered_npcs=None,pools_expanded=False,
        npc_activity_or_request_budget_modified=False,game_functions_called=False,remote_threads_created=False,
        distance_or_render_benefit_verified=False)
    if record:
        raw=memory.read(record['data_address']+LAST_NATIVE,8)
        result['last_primary_view']={'native_far':struct.unpack('<f',raw[:4])[0],'address':hex(word(raw,4))}
    return result
