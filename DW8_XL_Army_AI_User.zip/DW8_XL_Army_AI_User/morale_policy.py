"""Bounded settings and telemetry for whole native reinforcement waves."""
import struct
from core import require

BASE,END,MAGIC=0x2A00,0x2B00,0x364C4D44
DEFAULT_THRESHOLDS=(40,50,65)


def validate_thresholds(values):
    require(isinstance(values,(list,tuple)) and len(values)==3 and
            all(type(v) is int for v in values) and 0<values[0]<values[1]<values[2]<100,
            'E_MORALE_THRESHOLDS')
    return tuple(values)


def target_for(left,right,thresholds=DEFAULT_THRESHOLDS):
    thresholds=validate_thresholds(thresholds)
    require(type(left) is int and type(right) is int and 0<=left<=999 and 0<=right<=999,
            'E_MORALE_VALUES')
    if left+right==0:return 30*(1+sum(50>=t for t in thresholds))
    return 30*(1+sum(left*100>=(left+right)*t for t in thresholds))


def initialize(buffer,enabled=False,thresholds=DEFAULT_THRESHOLDS):
    values=validate_thresholds(thresholds)
    struct.pack_into('<6I',buffer,BASE,MAGIC,1,int(enabled),*values)


def decode(raw):
    if len(raw)<END or struct.unpack_from('<I',raw,BASE)[0]!=MAGIC:
        return {'available':False,'enabled':False}
    u=lambda off:struct.unpack_from('<I',raw,BASE+off)[0]
    require(u(4)==1 and u(8) in (0,1),'E_MORALE_POLICY_HEADER')
    thresholds=validate_thresholds([u(12),u(16),u(20)])
    return {'available':True,'enabled':bool(u(8) and struct.unpack_from('<I',raw,8)[0]
            and not struct.unpack_from('<I',raw,12)[0]),'threshold_percentages':list(thresholds),
        'threshold_quantities':[30,60,90,120],'measurement':'PLAYER_BLUE_BAR_SHARE',
        'replacement':'WHOLE_NATIVE_WAVES','survivors_removed_on_drop':False,
        'reserve_included':True,'intercepts':u(0x20),'allowed':u(0x24),'blocked':u(0x28),
        'scope_skips':u(0x2C),'last_target':u(0x30) if u(0x20) else None,
        'last_total':u(0x34) if u(0x20) else None,'last_wave':u(0x38) if u(0x20) else None,
        'partial_wave_clipping':False,'live_validated':False}
