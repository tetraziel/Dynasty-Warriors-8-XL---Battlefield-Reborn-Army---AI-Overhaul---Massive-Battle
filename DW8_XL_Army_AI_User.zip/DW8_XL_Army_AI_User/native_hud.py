"""Optional personal order HUD submitted through the native HUD queue."""
from core import word,require
import struct
import bundle_support as bundle
import native_hud_legacy as v1
import native_hud_v2 as v2
from native_hud_v2 import (FEATURE,MAGIC,SIZE,CODE_SIZE,TRAMPOLINE,MODE,TID,ORDER_A,ORDER_B,POSITION,
    SPRITE,ICON_SPACING,TEXT_NODE,FONT_COPY,FONT_BYTES,GLYPHS,MAX_GLYPHS,POP_COMMAND,
    POP_SEQUENCE,POP_TICK,POP_COUNT,POP_FONT,POP_SECONDS,POP_POSITION,FONT_SIZE,TEXTS,W,ATLAS,
    BLUE_PALETTE_INDEX,BLUE_BEGIN,COLOR_RESET,COLOR_CODE_CHECKS,native_message)
from native_hud_queue import build as build_queue

VERSION=3;LEGACY_VERSION=2;LEGACY_VERSIONS=(1,2)
GAP=144.
LEGACY_SIZES={1:0x1000,2:SIZE}
LEGACY_SITES_BY_VERSION={1:v1.SITES,2:v2.SITES}
LEGACY_SITES=v2.SITES
SITES={'PERSONAL_NATIVE_HUD_TEXT_PREPARE':(0x5614DD,'e85efcffff')}
COUNTERS={'native_hud_updates':0x10,'native_icon_enqueues':0x14,'scope_skips':0x18,
          'resource_skips':0x1C,'layout_skips':0x20,'native_popup_preparations':0x24,
          'native_popup_enqueues':0x28,'native_popup_skips':0x2C,'queue_refusals':0x30}


def initialize_data(raw):
    v2.initialize_data(raw)
    # Extra room for guard labels extending beyond the original order icons.
    struct.pack_into('<f',raw,0xA4,GAP)


def build_bridge(base,data,code,auto,recall,name,*,legacy=False,legacy_version=None):
    if legacy:
        module=v1 if legacy_version==1 else v2
        return module.build_bridge(base,data,code,auto,recall,name)
    require(name in SITES,'E_NATIVE_HUD_SITE')
    return build_queue(base,data,code,auto,recall)


def check_code(memory):
    v2.check_code(memory)
    # Native HUD submission: fixed-size records, bounds and native queue tag.
    for rva,sig in ((0x5614FB,'81b820300000ff0300008d4e04'),
                    (0x561510,'890f8bb81c30000081c140110000894f04'),
                    (0x561537,'83801c3000000c8b881c300000019020300000c70100000000')):
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),'E_NATIVE_HUD_QUEUE_CODE')


def public(memory,record):
    if record and record['version']<VERSION:
        result=v2.public(memory,record)
        result.update(legacy_hook_requires_upgrade=True)
        return result
    result=bundle.public(__import__(__name__),memory,record)
    result.update(default_enabled=False,native_guard_icon_resources=[110,112],
        indicators_for_squads=[[1,2],[3,4]],gap_after_guard_labels=GAP,
        uses_native_renderer=True,external_feedback_window=False,original_guard_slots_modified=False,
        display_list_modified=True,submission_method='NATIVE_HUD_PRODUCER_QUEUE',
        rendering_callback_hooked=False,render_node_identity_comparison=False,
        additional_remote_threads=0,popup_text_native=True,popup_highlight_word='troops',
        popup_highlight_palette=1,popup_color_method='NATIVE_INLINE_ESC_C1_ESC_R',
        global_palette_modified=False,game_files_modified=False,live_validated=False)
    if record:
        a=record['data_address'];raw=memory.read(a+MODE,24)
        result['gap_after_guard_labels']=struct.unpack('<f',memory.read(a+0xA4,4))[0]
        result.update(mode=word(raw),native_hud_update_thread=word(raw,4) or None,
            native_order_symbols=[word(raw,8),word(raw,12)],last_position=list(struct.unpack_from('<2f',raw,16)))
        raw=memory.read(a+POP_COMMAND,16)
        result.update(popup_command=hex(word(raw)),popup_battle_sequence=word(raw,4),
            popup_game_tick=word(raw,8),popup_glyph_count=word(raw,12),popup_seconds=POP_SECONDS,
            popup_build_thread='NATIVE_HUD_UPDATE',popup_frame_glyphs_copied=True,
            enqueue_counters_are_not_render_confirmation=True)
    return result
