"""Let native depletion bookkeeping include only verified personal infantry.

Replays MOV EBX,[ESI+68]; SHR EBX,8. On a verified empty personal group,
clears bit zero of the local EBX value before the original TEST BL,1.
It neither writes game records nor calls a spawn routine. The native caller
still performs depletion, gate, timing, location and replenishment handling.
"""
from pool_binding import resolve as resolve_pool
from core import PROFILE,require
from bridge import relative_jump
from recall_bridge import Asm,R
from family_scope import emit_family_scope,QUANTITY
from reinforcement_state import BASE,MAGIC,SCRATCH,REASONS


def build_reinforcement_bridge(base,data,auto_data,code,*,pool=None):
    p=resolve_pool(pool)
    spec=PROFILE['recall']['sites']['GATE_DEPLETION_SITE']
    original=bytes.fromhex(spec['original'])
    require(original==bytes.fromhex('8b5e68c1eb08'),'E_GATE_NATIVE_READ')
    x=Asm();g=data+BASE
    fields={name:data+SCRATCH+i*4 for i,name in enumerate(
        ('manager','ai','players','owner','group','squad','player_squad','stage'))}
    def save(reg,name):x.store(reg,disp=fields[name])
    def load(reg,name):x.load(reg,disp=fields[name])
    def stage(name):x.set(REASONS.index(name),disp=fields['stage'])
    def fail_if(cond):x.jump(cond,'refused')
    def inc(off):x.mem('ff',0,disp=g+off)
    def ptr(reg,address):
        x.load(reg,disp=address);x.sane(reg,'refused')

    x.emit('9c60')
    x.op(7,MAGIC,disp=g);x.jump('ne','transparent')
    x.op(7,1,disp=g+8);x.jump('ne','transparent')
    x.op(7,1,disp=data+8);x.jump('ne','transparent')
    x.op(7,0,disp=data+12);x.jump('ne','transparent')
    # At this native point EAX is the owner index. Ignore other owners before
    # taking the shared lock; saved registers still contain all native inputs.
    x.op(7,0,'esp',28);x.jump('ne','transparent')
    x.imm('eax',0);x.imm('ecx',1)
    x.mem('f00fb1',R['ecx'],disp=data+16);x.jump('ne','transparent')
    inc(0x10);x.set(0,disp=fields['owner']);stage('GLOBALS')
    ptr('edi',base+0x6A91E8);save('edi','manager')
    ptr('ebx',base+0x6A91D8);save('ebx','ai')
    ptr('edx',base+0x6A91EC);save('edx','players')
    ptr('eax',base+0x6D10BC)
    x.load('ecx','esp',8);x.rr('39','ecx','edi');fail_if('ne')
    stage('PHASE');x.op(7,4,'eax',0x1C784);fail_if('ne')
    stage('PLAYER_BINDING')
    x.op(7,1,'edx',0x590);fail_if('ne')
    x.op(7,0,'edx',0x108);fail_if('ne')
    x.load('eax','edx',0x110);x.cmp('eax',150);fail_if('ae')
    x.imul('ecx','eax',0x30);x.rr('01','ecx','edi');x.ri(0,'ecx',0x6B210)
    x.cmpm('eax','ecx');fail_if('ne')
    x.load('ecx','ecx',8);x.cmp('ecx',p.group_capacity);fail_if('ae');save('ecx','player_squad')
    x.imul('edx','ecx',0x268);x.rr('01','edx','edi');x.ri(0,'edx',p.manager_groups)
    for off,value in ((0x44,0),(0x30,1108),(0x24,1),(0x28,1)):
        x.op(7,value,'edx',off);fail_if('ne')
    x.op(7,1,'edx',0x2C);fail_if('above')
    x.imul('edx','eax',0xE0);x.rr('01','edx','ebx');x.ri(0,'edx',0x21EF8)
    x.cmpm('eax','edx',0x7C);fail_if('ne')
    x.mem('f7',0,'edx',0xCC);x.dword(1);fail_if('eq')
    x.mem('f7',0,'edx',0xCC);x.dword(0x08000000);fail_if('eq')
    x.mem('f7',0,'ebx',0x90);x.dword(1);fail_if('eq')
    x.mem('0fb6',R['eax'],'ebx',0x9E);x.cmp('eax',0x80);fail_if('ae')
    # Native ESI must be the live player-owner record, never a copied record.
    x.rr('89','eax','edi');x.ri(0,'eax',0x4B0)
    x.load('ecx','esp',4);x.rr('39','ecx','eax');fail_if('ne')
    x.op(7,0,'eax',0x38);fail_if('ne')
    x.op(7,0,'eax',0x40);fail_if('ne')
    stage('GROUP_IDENTITY')
    x.load('esi','esp',20);x.sane('esi','refused')
    x.load('eax','esi',0x18);x.cmp('eax',p.group_capacity);fail_if('ae')
    x.cmpm('eax',disp=fields['player_squad']);fail_if('eq');save('eax','squad')
    x.imul('ecx','eax',0x268);x.rr('01','ecx','edi');x.ri(0,'ecx',p.manager_groups)
    x.rr('39','ecx','esi');fail_if('ne');save('ecx','group')
    for off,value in ((0x44,0),(0x30,865),(0x2C,30),(0x24,30)):
        x.op(7,value,'esi',off);fail_if('ne')
    stage('GROUP_NOT_EMPTY')
    for off in (0x28,0x10,0x14):x.op(7,0,'esi',off);fail_if('ne')
    stage('GROUP_AI_LINK')
    x.imul('ecx','eax',0xA0);x.rr('01','ecx','ebx');x.ri(0,'ecx',p.ai_groups)
    x.cmpm('eax','ecx',0x74);fail_if('ne')
    x.cmpm('ebx','ecx',0x78);fail_if('ne')
    stage('OWNER_LIST_FAMILY')
    emit_family_scope(x,data,{name:fields[name] for name in ('manager','owner','group')},
                      'refused',prefix='gate_family',squad_count=PROFILE['player_squad_count'],pool=p)
    stage('CONFIG_EVENT')
    x.op(7,1,disp=auto_data+24);fail_if('ne')
    x.op(7,0,disp=auto_data+20);fail_if('ne')
    x.load('edx',disp=auto_data+16);x.cmp('edx',0);fail_if('eq')
    x.imm('ebx',16);x.mark('event_scan')
    x.rr('89','eax','edx');x.emit('48');x.ri(4,'eax',15)
    x.imul('eax','eax',0x200);x.ri(0,'eax',auto_data+0x1000)
    x.cmpm('edx','eax',0x1FC);x.jump('ne','event_next')
    x.op(7,3,'eax',8);x.jump('ne','event_next')
    load('edi','manager');x.cmpm('edi','eax',0x24);x.jump('ne','event_next')
    for off,value in ((0x58,1108),(0x5C,1108),(0x38,865)):
        x.op(7,value,'eax',off);x.jump('ne','event_next')
    x.op(7,30,'eax',0x3C);x.jump('eq','event_ok')
    x.mark('event_next');x.emit('4a');fail_if('eq')
    x.emit('4b');x.jump('ne','event_scan');x.jump('jmp','refused')
    x.mark('event_ok');inc(0x14)
    load('eax','squad');x.store('eax',disp=g+0x24)
    x.load('eax',disp=data+QUANTITY);x.store('eax',disp=g+0x28)
    x.load('ecx','esp',4);x.load('eax','ecx',0x68);x.store('eax',disp=g+0x2C)
    load('esi','group');x.mem('0fb6',R['ecx'],'esi',0x50);x.store('ecx',disp=g+0x30)
    x.ri(4,'eax',0x100);x.cmp('eax',0);x.jump('eq','eligible')
    inc(0x18)
    x.mark('eligible');x.set(0,disp=data+16);x.emit('619d')
    x.emit(original);x.emit('83e3fe')  # local EBX only; native TEST follows immediately
    x.emit(relative_jump(code+len(x.code),base+spec['site_rva']+len(original)))
    x.mark('refused');inc(0x1C)
    x.load('eax',disp=fields['stage']);x.store('eax',disp=g+0x20)
    x.set(0,disp=data+16)
    x.mark('transparent');x.emit('619d');x.emit(original)
    x.emit(relative_jump(code+len(x.code),base+spec['site_rva']+len(original)))
    result=x.finish();require(len(result)<0x4000,'E_GATE_BRIDGE_SIZE')
    return result
