"""Bounded read-only recorder. Importing never opens a process or starts work.

The worker is local to this tool, has its own read-only handle, and never uses
AutoSession, an existing writer, native calls, hooks or thread suspension.
"""
import collections
import copy
import datetime as dt
import json
import math
from pathlib import Path
import struct
import threading
import time
from core import Refused,require,word,uint,player_snapshot
import npc_activity_scan as npc

SCAN_BUILD='v5-npc-activity-many-readonly-2'
ROOTS={'manager':0x6A91E8,'ai':0x6A91D8,'players':0x6A91EC,'phase':0x6D10BC}
CAMERA_RVA=0x6A9574
SELECTION_RVA=0x6A91E0
SIGNATURES={0x5A11E5:'8b3b80bfd2000000008baf800000008b7578',
            0x584068:'f6401001740bf64014017405',
            0x529375:'8b5034',0x55FD92:'8b16d9450c',**npc.SIGNATURES}
SECONDS=90.0
INTERVAL=0.2

def exact(memory,address,size):
    require(0x10000<=address and address+size<0xFFF00000 and 0<size<=0x100000,'E_CAMERA_SCAN_READ_RANGE')
    raw=memory.read(address,size);require(len(raw)==size,'E_CAMERA_SCAN_SHORT_READ');return raw

def vec(raw,offset=0):
    values=list(struct.unpack_from('<4f',raw,offset))
    return values if all(math.isfinite(v) and abs(v)<100_000_000 for v in values) else None

def distance(a,b):return math.hypot(a[0]-b[0],a[2]-b[2]) if a and b else None

def check_code(memory):
    for rva,code in SIGNATURES.items():
        expected=bytes.fromhex(code)
        require(exact(memory,memory.base+rva,len(expected))==expected,'E_CAMERA_SCAN_NATIVE_'+hex(rva))

def camera_data(memory):
    """Capture the verified manager subobject layout, without naming opaque fields.

    224BA0 constructs two 288-byte records at manager+40. 224590 initializes
    their vtables and three 16-byte plane-shaped records at +218. The XZ test
    below mirrors the shape of 4E3EC0 at radius zero; full render visibility,
    occlusion and the exact relation to the current selection are NOT proven.
    """
    result={'available':False,'actual_render_visibility_verified':False,
            'pose_semantics_verified':False,'plane_binding_to_selector_verified':False}
    try:
        root=uint(memory,memory.base+CAMERA_RVA);result['manager']=hex(root)
        raw=exact(memory,root+0x40,0x288)
        require(word(raw)==memory.base+0x617660,'E_CAMERA_SCAN_CAMERA_VTABLE')
        planes=[vec(raw,0x218+i*16) for i in range(3)]
        result.update(available=True,record_address=hex(root+0x40),raw_hex=raw.hex(),
            vector_candidates={hex(off):vec(raw,off) for off in (4,0x14,0x24,0x34)},
            xz_planes_candidate=planes)
    except Exception as error:result['error']=str(error)
    return result

def plane_candidate(camera,position):
    planes=camera.get('xz_planes_candidate')
    if not position or not planes or any(p is None for p in planes):return None
    if any(abs(p[0])+abs(p[2])<1e-8 for p in planes):return None
    # A point/zero-radius XZ heuristic, never a label for actual drawn pixels.
    return all(p[0]*position[0]+p[2]*position[2]+p[3]>=0 for p in planes)

def snapshot(memory,*,many_extension_record=None):
    began=time.monotonic()
    roots={name:uint(memory,memory.base+rva) for name,rva in ROOTS.items()}
    phase=word(exact(memory,roots['phase']+0x1C784,4))
    require(phase in (4,5),'E_CAMERA_SCAN_WAIT_BATTLE')
    state=player_snapshot(memory);require(state['owner']==0,'E_CAMERA_SCAN_PLAYER_OWNER_NOT_ZERO')
    require(all(state[n]==roots[n] for n in ('manager','ai','players')),'E_CAMERA_SCAN_CONTEXT_CHANGED')
    manager,ai,players=(state[n] for n in ('manager','ai','players'))
    tick=word(exact(memory,ai+0x53E90,4))
    items=exact(memory,manager+0x6B210,150*0x30)
    actors=exact(memory,ai+0x21EF8,150*0xE0)
    player_id=word(exact(memory,players+0x110,4));require(player_id<150,'E_CAMERA_SCAN_PLAYER_ID')
    player=actors[player_id*0xE0:(player_id+1)*0xE0]
    require(word(player,0x7C)==player_id and word(player,0xCC)&1,'E_CAMERA_SCAN_PLAYER_IDENTITY')
    player_position=vec(player,0x34)
    camera=camera_data(memory)
    try:selection=uint(memory,memory.base+SELECTION_RVA)
    except Exception:selection=0
    roster=exact(memory,players+0x1C0,3*0x30)
    selected=[word(roster,4+i*0x30) for i in range(3)]
    owners=[];bindings=[];actor_links=[];personal_ids=[]
    for owner in [0,*sorted({o for o in selected if 122<=o<=124})]:
        record=exact(memory,manager+0x4B0+owner*0x110,0x110)
        owner_ai=exact(memory,ai+owner*0xAC,0xAC)
        if owner and (word(record,0x38)!=owner or not word(owner_ai,0x90)&1):
            owners.append({'owner':owner,'available':False,'reason':'INACTIVE_OR_UNBOUND_GUARD'});continue
        require(word(record,0x38)==owner,'E_CAMERA_SCAN_OWNER_IDENTITY')
        count,cap,pointer=(word(record,n) for n in (0x100,0xFC,0xF8))
        require(0<=count<=cap<=6,'E_CAMERA_SCAN_ROSTER_BOUNDS')
        ids=list(struct.unpack('<'+'H'*count,exact(memory,pointer,count*2))) if count else []
        require(len(set(ids))==count and all(g<600 for g in ids),'E_CAMERA_SCAN_ROSTER_IDS')
        bindings.append((owner,record[0xF8:0x104],pointer,bytes(struct.pack('<'+'H'*count,*ids))))
        if owner==0:
            require(ids and ids[0]==state['player_squad'],'E_CAMERA_SCAN_PLAYER_ROSTER')
        groups=[]
        for ordinal,gid in enumerate(ids):
            if owner==0 and not 1<=ordinal<=4:continue
            address=manager+0x10E50+gid*0x268
            group=exact(memory,address,0x268);ga=exact(memory,ai+0xA7F8+gid*0xA0,0xA0)
            require(word(group,0x18)==gid and word(group,0x44)==owner,'E_CAMERA_SCAN_GROUP_IDENTITY')
            if owner==0:
                if not all(word(group,o)==v for o,v in ((0x1C,ordinal),(0x24,30),(0x2C,30),(0x30,865))):continue
                require(word(group,0x28)<=30,'E_CAMERA_SCAN_PERSONAL_IDENTITY')
                personal_ids.append(gid)
            members=[]
            for index in range(150):
                item=items[index*0x30:(index+1)*0x30];slot=word(item,0xC)
                if word(item)!=index or word(item,8)!=gid or slot>=30:continue
                if not word(group,0x10)&word(group,0x14)&(1<<slot):continue
                actor=actors[index*0xE0:(index+1)*0xE0]
                if (word(actor,0x7C)!=index or word(actor,0x80)!=ai+0xA7F8+gid*0xA0
                    or not word(actor,0xCC)&1):continue
                pos=vec(actor,0x34)
                members.append({'agent':index,'slot':slot,'is_group_leader':word(group,0x34)==index,
                    'position':pos,'distance_player_xz':distance(pos,player_position),
                    'state_88':word(actor,0x88),'class_84':word(actor,0x84),'subtype_d2':actor[0xD2],
                    'zone_d0':actor[0xD0],'forced_timer_bc':word(actor,0xBC),
                    'flags_cc':hex(word(actor,0xCC)),'target_90':hex(word(actor,0x90)),
                    'movement_command_68_raw':word(actor,0x68),'movement_command_6c_raw':word(actor,0x6C),
                    'movement_scalar_c0_raw':word(actor,0xC0),
                    'xz_plane_test_candidate':plane_candidate(camera,pos),
                    'actual_render_visibility':None,'actor_raw_hex':actor.hex(),'item_raw_hex':item.hex()})
                actor_links.append((index,word(actor,0x80)))
            row={'squad':gid,'ordinal':ordinal,'owner':owner,'quantity':word(group,0x28),
                'template':word(group,0x2C),'unit_type':word(group,0x30),
                'position':vec(group),'zone':word(group,0x48),'leader_agent':word(group,0x34),
                'leader_materialized':bool(word(group,0x10)&word(group,0x14)&1),
                'logical_bits':hex(word(group,0x10)),'materialized_bits':hex(word(group,0x14)),
                'ai_position':vec(ga),'ai_waypoint_20':vec(ga,0x20),'ai_destination_40':vec(ga,0x40),
                'ai_flags_88':hex(word(ga,0x88)),'ai_state_80':word(ga,0x80),
                'ai_owner_link_matches':word(ga,0x78)==ai+owner*0xAC,
                'group_raw_hex':group.hex(),'group_ai_raw_hex':ga.hex(),'members':members}
            try:row['native_selection_raw_hex']=exact(memory,selection+0x80+gid*0x30,0x30).hex() if selection>=0x10000 else None
            except Exception as error:row['selection_read_error']=str(error)
            groups.append(row)
        owners.append({'owner':owner,'available':True,'character':word(record,0x44),
            'position':vec(record,0x18),'ai_position':vec(owner_ai),'ai_destination':vec(owner_ai,0x40),
            'order_84':word(owner_ai,0x84),'state_88':word(owner_ai,0x88),
            'owner_raw_hex':record.hex(),'owner_ai_raw_hex':owner_ai.hex(),'groups':groups})
    activity,activity_guard=npc.capture(memory,state,player_id,player_position,selected,
                                        personal_ids,items,actors)
    import npc_many
    activity['many_comparison_sites_raw']={name:exact(memory,memory.base+rva,6).hex()
                                           for name,(rva,unused) in npc_many.SITES.items()}
    activity['many_extension']={'known_record_provided':False,'enabled':None}
    if many_extension_record is not None:
        npc_many.bundle.validate(npc_many,memory,many_extension_record)
        activity['many_extension']={**npc_many.public(memory,many_extension_record),
                                    'known_record_provided':True,'record_validated_read_only':True}
    native_sites=all(activity['many_comparison_sites_raw'][name]==sig for name,(unused,sig) in npc_many.SITES.items())
    effective=None
    if native_sites or activity['many_extension'].get('known_record_provided'):
        effective=list(activity['selector'].get('threshold_bytes',[])[:3])
        if activity['many_extension'].get('enabled') and activity['character_raw']==0 and effective==[4,8,8]:
            effective=list(activity['many_extension']['virtual_thresholds'])
    activity['effective_thresholds_candidate']=effective
    # Reject mixed load/roster/agent identities. Movement itself may progress
    # during the bounded read; retain the native tick span explicitly.
    require(roots=={n:uint(memory,memory.base+rva) for n,rva in ROOTS.items()},'E_CAMERA_SCAN_CONTEXT_CHANGED')
    require(player_snapshot(memory)==state and uint(memory,players+0x110)==player_id,'E_CAMERA_SCAN_CONTEXT_CHANGED')
    require(exact(memory,players+0x1C0,3*0x30)==roster,'E_CAMERA_SCAN_GUARD_ROSTER_CHANGED')
    for owner,binding,pointer,ids in bindings:
        require(exact(memory,manager+0x4B0+owner*0x110+0xF8,12)==binding,'E_CAMERA_SCAN_ROSTER_CHANGED')
        if ids:require(exact(memory,pointer,len(ids))==ids,'E_CAMERA_SCAN_ROSTER_CHANGED')
    actors_after=exact(memory,ai+0x21EF8,150*0xE0)
    items_after=exact(memory,manager+0x6B210,150*0x30)
    for index,link in actor_links:
        again=actors_after[index*0xE0:(index+1)*0xE0]
        require(word(again,0x7C)==index and word(again,0x80)==link and word(again,0xCC)&1
            and items_after[index*0x30:index*0x30+16]==items[index*0x30:index*0x30+16],
            'E_CAMERA_SCAN_ACTOR_REBOUND')
    npc.verify(memory,activity_guard,items_after,actors_after,activity)
    require(roots=={n:uint(memory,memory.base+rva) for n,rva in ROOTS.items()}
            and player_snapshot(memory)==state,'E_CAMERA_SCAN_CONTEXT_CHANGED')
    phase_after=uint(memory,roots['phase']+0x1C784);tick_after=uint(memory,ai+0x53E90)
    require(phase_after==phase and tick<=tick_after<=tick+6,'E_CAMERA_SCAN_SAMPLE_CHANGED')
    return {'utc':dt.datetime.now(dt.timezone.utc).isoformat(),'read_only':True,
        'cookie':list(memory.cookie),'state':state,'phase':phase,'tick_before':tick,'tick_after':tick_after,
        'read_elapsed_ms':round((time.monotonic()-began)*1000,3),'atomic_snapshot_guaranteed':False,
        'player_agent':player_id,'player_position':player_position,'player_raw_hex':player.hex(),
        'camera':camera,'selected_guards':selected,'owners':owners,
        'scan_build':SCAN_BUILD,'personal_family_groups_observed':personal_ids,'npc_activity':activity}

class Recorder:
    def __init__(self,pid,root,reader_factory,*,expected_cookie=None,seconds=SECONDS,interval=INTERVAL,many_extension_record=None):
        require(type(pid) is int and pid>0,'E_CAMERA_SCAN_PID')
        require(0<seconds<=120 and 0.2<=interval<=2,'E_CAMERA_SCAN_BOUNDS')
        self.pid=pid;self.root=Path(root);self.reader_factory=reader_factory
        self.expected_cookie=list(expected_cookie) if expected_cookie else None
        self.many_extension_record=copy.deepcopy(many_extension_record)
        self.seconds=seconds;self.interval=interval;self.cancel=threading.Event();self.lock=threading.Lock();self.thread=None
        self.state={'status':'CAMERA_FOLLOW_SCAN_NOT_STARTED','running':False,'read_only':True,
            'writer_opened':False,'process_memory_modified':False,'remote_threads_created':False,
            'game_functions_called':False,'samples':0,'rejected_samples':0,'last_error':None,'scan_build':SCAN_BUILD,
            'requested_graphics_profile':'MANY','scope':'ALL_NATIVE_NPCS','game_graphics_setting_modified':False}

    def public(self):
        with self.lock:return dict(self.state)

    def update(self,**values):
        with self.lock:self.state.update(values)

    def start(self):
        require(self.thread is None,'E_CAMERA_SCAN_ALREADY_STARTED')
        self.update(status='CAMERA_FOLLOW_SCAN_STARTING',running=True)
        self.thread=threading.Thread(target=self.run,name='DW8 read-only camera scan',daemon=True)
        try:self.thread.start()
        except Exception:
            self.update(status='CAMERA_FOLLOW_SCAN_ERROR',running=False);raise

    def stop(self):self.cancel.set()

    def run(self):
        memory=None;stream=None;counts=collections.Counter();states=collections.Counter();groups={}
        npc_states=collections.Counter();npc_classes=collections.Counter()
        stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
        path=self.root/'logs'/('camera_follow_'+stamp+'.jsonl');began=time.monotonic()
        status='CAMERA_FOLLOW_SCAN_COMPLETE';fatal=None
        try:
            path.parent.mkdir(parents=True,exist_ok=True);stream=path.open('x',encoding='utf-8')
            self.update(last_report=str(path),summary_report=str(path.with_suffix('.summary.json')))
            memory=self.reader_factory(self.pid)
            if self.expected_cookie is not None:
                require(list(memory.cookie)==self.expected_cookie,'E_CAMERA_SCAN_PROCESS_RESTARTED')
            check_code(memory)
            self.update(status='CAMERA_FOLLOW_SCAN_RECORDING',cookie=list(memory.cookie))
            while not self.cancel.is_set() and time.monotonic()-began<self.seconds:
                started=time.monotonic()
                try:
                    frame=(snapshot(memory,many_extension_record=self.many_extension_record)
                           if self.many_extension_record is not None else snapshot(memory))
                    counts['samples']+=1
                    for owner in frame['owners']:
                        if owner['owner']!=0:continue
                        for g in owner['groups']:
                            key=(tuple(frame['state'].values()),g['squad'])
                            last=groups.get(key);groups[key]=(frame['tick_after'],g['position'],frame['phase'])
                            for a in g['members']:states[str(a['state_88'])]+=1
                            if last and frame['phase']==last[2]==4 and 0<frame['tick_after']-last[0]<=42:
                                moved=distance(last[1],g['position'])
                                if moved is not None:counts['group_motion_pairs']+=1;counts['group_moving_pairs' if moved>1 else 'group_stationary_pairs']+=1
                    activity=frame['npc_activity']
                    if frame['phase']==4:
                        for entry in activity['summary']['npc_state_observations']:
                            npc_states[(entry['relation'],entry['state'])]+=entry['count']
                        for entry in activity['summary']['npc_class_observations']:
                            npc_classes[(entry['relation'],entry['class'])]+=entry['count']
                    if not activity['native_highest_profile_observed']:counts['non_many_profile_samples']+=1
                    stream.write(json.dumps(frame,ensure_ascii=False,allow_nan=False)+'\n');stream.flush()
                    self.update(samples=counts['samples'],last_error=None,last_phase=frame['phase'],
                        last_native_tick=frame['tick_after'],camera_available=frame['camera']['available'],
                        graphics_profile_status=activity['graphics_profile_status'],
                        character_raw=activity['character_raw'],npc_summary=activity['summary'])
                except Refused as error:
                    code=str(error);counts[code]+=1;counts['rejected_samples']+=1
                    stream.write(json.dumps({'utc':dt.datetime.now(dt.timezone.utc).isoformat(),
                        'read_only':True,'sample_rejected':True,'error':code})+'\n');stream.flush()
                    self.update(rejected_samples=counts['rejected_samples'],last_error=code)
                self.cancel.wait(max(0,self.interval-(time.monotonic()-started)))
            if self.cancel.is_set():status='CAMERA_FOLLOW_SCAN_STOPPED'
        except Exception as error:status='CAMERA_FOLLOW_SCAN_ERROR';fatal=str(error)
        finally:
            if memory is not None:
                try:memory.close()
                except Exception as error:fatal=fatal or str(error);status='CAMERA_FOLLOW_SCAN_ERROR'
            if stream is not None:stream.close()
            summary={**self.public(),'status':status,'running':False,'fatal_error':fatal,
                'elapsed_seconds':round(time.monotonic()-began,3),'counts':dict(counts),
                'personal_actor_state_samples':dict(states),'actual_render_visibility_verified':False,
                'all_npc_state_samples':[{'relation':k[0],'state':k[1],'observations':v} for k,v in npc_states.items()],
                'all_npc_class_samples':[{'relation':k[0],'class':k[1],'observations':v} for k,v in npc_classes.items()],
                'camera_causal_conclusion':None,'group_motion_threshold_native_units':1,
                'note':'Materialization and plane candidates are not actual rendered visibility; paused pairs are excluded.'}
            try:
                path.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
            except Exception as error:fatal=fatal or str(error);status='CAMERA_FOLLOW_SCAN_ERROR'
            self.update(status=status,running=False,fatal_error=fatal,elapsed_seconds=summary['elapsed_seconds'])
