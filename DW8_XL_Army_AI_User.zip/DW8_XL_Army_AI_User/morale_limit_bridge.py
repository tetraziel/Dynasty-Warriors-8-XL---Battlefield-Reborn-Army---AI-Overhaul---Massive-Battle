"""Filter the existing native reinforcement CALL; never adds a spawn CALL."""
from pool_binding import resolve as resolve_pool
from core import PROFILE,require
from recall_bridge import Asm,R
from bridge import relative_jump
from family_scope import emit_family_scope,QUANTITY
from morale_policy import BASE,MAGIC


def build_morale_limit_bridge(base,data,auto_data,code,*,pool=None):
    p=resolve_pool(pool)
    spec=PROFILE['recall']['sites']['MORALE_LIMIT_SITE']
    x=Asm();g=data+BASE;scratch=data+0x2C00
    f={n:scratch+i*4 for i,n in enumerate(('manager','owner','group','source','destination','players'))}
    inc=lambda off:x.mem('ff',0,disp=g+off)
    def reject(cond):x.jump(cond,'scope_skip')
    x.emit('9c60')
    for address,value in ((g,MAGIC),(g+8,1),(data+8,1),(data+12,0)):
        x.op(7,value,disp=address);x.jump('ne','transparent')
    # Restrict before the shared lock: native EBX must be the live player owner.
    x.load('edi',disp=base+0x6A91E8);x.sane('edi','transparent')
    x.lea('eax','edi',0x4B0);x.cmpm('eax','esp',16);x.jump('ne','transparent')
    x.imm('eax',0);x.imm('ecx',1)
    x.mem('f00fb1',R['ecx'],disp=data+16);x.jump('ne','busy_skip')
    x.store('edi',disp=f['manager']);x.set(0,disp=f['owner'])
    x.load('eax',disp=base+0x6D10BC);x.sane('eax','scope_skip')
    x.op(7,4,'eax',0x1C784);reject('ne')
    x.load('ebx',disp=base+0x6A91EC);x.sane('ebx','scope_skip')
    x.store('ebx',disp=f['players'])
    for off,value in ((0x590,1),(0x108,0)):
        x.op(7,value,'ebx',off);reject('ne')
    x.op(7,0,'edi',0x4B0+0x38);reject('ne')
    x.op(7,0,'edi',0x4B0+0x40);reject('ne')
    x.load('eax','esp',20);x.cmp('eax',p.group_capacity);reject('ae')
    x.store('eax',disp=f['source'])
    x.load('ecx','esp',40);x.cmp('ecx',p.group_capacity);reject('ae')
    x.rr('39','eax','ecx');reject('eq');x.store('ecx',disp=f['destination'])
    x.imul('esi','eax',0x268);x.rr('01','esi','edi');x.ri(0,'esi',p.manager_groups)
    x.store('esi',disp=f['group'])
    for off,value in ((0x44,0),(0x30,865),(0x2C,30),(0x24,30)):
        x.op(7,value,'esi',off);reject('ne')
    x.cmpm('eax','esi',0x18);reject('ne')
    x.imul('edx','ecx',0x268);x.rr('01','edx','edi');x.ri(0,'edx',p.manager_groups)
    x.cmpm('ecx','edx',0x18);reject('ne')
    for off,value in ((0x44,0),(0x28,0),(0x10,0),(0x14,0)):
        x.op(7,value,'edx',off);reject('ne')
    # Destination must be the owner's final reserved group, not another army.
    x.load('eax','edi',0x4B0+0x100);x.cmp('eax',2);reject('below')
    x.cmp('eax',6);reject('above');x.emit('48')
    x.load('ebx','edi',0x4B0+0xF8);x.sane('ebx','scope_skip')
    x.rr('01','eax','eax');x.rr('01','ebx','eax')
    x.mem('0fb7',R['eax'],'ebx');x.rr('39','eax','ecx');reject('ne')
    emit_family_scope(x,data,f,'scope_skip',prefix='morale_family',squad_count=4,pool=p)
    # Match a successful configuration from this native ring/context.
    x.op(7,1,disp=auto_data+24);reject('ne')
    x.load('edx',disp=auto_data+16);x.cmp('edx',0);reject('eq');x.imm('ebx',16)
    x.mark('events');x.rr('89','eax','edx');x.emit('48');x.ri(4,'eax',15)
    x.imul('eax','eax',0x200);x.ri(0,'eax',auto_data+0x1000)
    x.cmpm('edx','eax',0x1FC);x.jump('ne','event_next')
    x.op(7,3,'eax',8);x.jump('ne','event_next')
    x.load('edi',disp=f['manager']);x.cmpm('edi','eax',0x24);x.jump('ne','event_next')
    for off,value in ((0x58,1108),(0x5C,1108),(0x38,865),(0x3C,30)):
        x.op(7,value,'eax',off);x.jump('ne','event_next')
    x.jump('jmp','event_ok')
    x.mark('event_next');x.emit('4a');reject('eq');x.emit('4b');x.jump('ne','events');x.jump('jmp','scope_skip')
    x.mark('event_ok')
    # Validate native logical mask against quantity before predicting the wave.
    x.load('esi',disp=f['group']);x.load('ecx','esi',0x10)
    x.rr('89','eax','ecx');x.ri(4,'eax',0xC0000000);x.cmp('eax',0);reject('ne')
    x.imm('ebx',0);x.imm('edx',30);x.mark('bits')
    x.emit('f7c101000000');x.jump('eq','bit_next');x.emit('43')
    x.mark('bit_next');x.emit('d1e94a');x.jump('ne','bits')
    x.cmpm('ebx','esi',0x28);reject('ne')
    x.imm('eax',30);x.rr('29','eax','ebx');x.store('eax',disp=g+0x38)
    for offset,value in ((0x58,0),(0x284,1)):
        x.op(7,value,'edi',offset);reject('ne')
    x.load('ecx','edi',0xC0);x.cmp('ecx',999);reject('above')
    x.load('edx','edi',0x2EC);x.cmp('edx',999);reject('above')
    x.rr('01','edx','ecx');x.cmp('edx',0);x.jump('ne','nonzero')
    x.imm('ecx',1);x.imm('edx',2)
    x.mark('nonzero');x.imul('ecx','ecx',100)
    # Thresholds are positive increasing percentages, updated under quiescence.
    x.load('eax',disp=g+12);x.cmp('eax',1);reject('below')
    x.load('ebx',disp=g+16);x.rr('39','ebx','eax');reject('be')
    x.load('esi',disp=g+20);x.rr('39','esi','ebx');reject('be')
    x.cmp('esi',100);reject('ae')
    for offset,target in ((12,30),(16,60),(20,90)):
        x.load('eax',disp=g+offset);x.emit('0fafc2');x.rr('39','ecx','eax')
        x.jump('below','target_'+str(target))
    x.imm('eax',120);x.jump('jmp','target_ready')
    for target in (30,60,90):x.mark('target_'+str(target));x.imm('eax',target);x.jump('jmp','target_ready')
    x.mark('target_ready');x.store('eax',disp=g+0x30);inc(0x20)
    x.load('ecx',disp=data+QUANTITY);x.store('ecx',disp=g+0x34)
    x.mem('03',R['ecx'],disp=g+0x38);x.rr('39','ecx','eax');x.jump('above','blocked')
    inc(0x24);x.set(0,disp=data+16);x.jump('jmp','transparent')
    x.mark('blocked');inc(0x28);x.set(0,disp=data+16);x.jump('jmp','skip')
    x.mark('scope_skip');inc(0x2C);x.set(0,disp=data+16);x.jump('jmp','transparent')
    x.mark('busy_skip')
    x.mark('skip');x.set(0,'esp',28);x.emit('619dc3')
    x.mark('transparent');x.emit('619d')
    x.emit(relative_jump(code+len(x.code),base+0x5542D0))
    result=x.finish();require(len(result)<0x4000,'E_MORALE_BRIDGE_SIZE');return result
