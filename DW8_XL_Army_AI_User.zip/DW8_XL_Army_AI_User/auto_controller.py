"""Automatic capture/audit logging; no Windows calls in this controller."""
import hashlib
import json
import struct
import time
from core import PROFILE
from battle_morale import HOST_DIAGNOSTICS_BUILD
from morale_policy import validate_thresholds
from ambition_duel import validate_percent
from npc_render_request import validate_budget
from npc_many import validate_distance

RETRY_REMOVE=('E_THREAD_IN_SITE','E_THREAD_SET_CHANGED','E_AUTO_BRIDGE_EXECUTING_RETRY',
              'E_RECALL_BRIDGE_EXECUTING_RETRY','E_TIMER_BRIDGE_EXECUTING_RETRY',
              'E_TACTICAL_BRIDGE_EXECUTING_RETRY','E_EXTRA_BRIDGE_EXECUTING_RETRY',
              'E_STORY_GUARDS_ACTIVE_FINISH_BATTLE_FIRST')


def same_configured_descriptor(success,refusal):
    """Recognize only the observed adjacent Story copier / Ambition duplicate.

    Keep a read-only audit reference; never convert a refusal into permission
    to write an occupied slot or to reconfigure a native game record.
    """
    if not isinstance(success,dict) or not isinstance(refusal,dict):return False
    seq=success.get('sequence');next_seq=refusal.get('sequence')
    if type(seq) is not int or type(next_seq) is not int or not 0<seq<0xFFFFFFFF:return False
    if (next_seq!=seq+1 or success.get('state')!=3 or refusal.get('state')!=4 or
        success.get('mode')!='STORY_FREE' or refusal.get('mode')!='AMBITION' or
        refusal.get('reason')!='SLOT_ALREADY_OCCUPIED' or
        success.get('configured_squad_count')!=PROFILE['player_squad_count']):return False
    for key in ('destination','manager','players'):
        if not success.get(key) or success[key]!=refusal.get(key):return False
    if success.get('after_pair')!=[865,30] or refusal.get('before_pair')!=[865,30] or refusal.get('source_pair')!=[865,30]:return False
    for event in (success,refusal):
        if not event.get('player1_markers_match') or event.get('descriptor_player_marker')!=1108 or event.get('source_player_marker')!=1108:return False
    try:
        raw=bytes.fromhex(success.get('descriptor_after_hex',''))
        before=bytes.fromhex(refusal.get('descriptor_before_hex',''))
        if len(raw)!=0x78 or raw!=before:return False
        if struct.unpack_from('<2I',raw,0x38) not in ((1108,0),(1108,1)):return False
        for i in range(PROFILE['player_squad_count']):
            if struct.unpack_from('<2I',raw,0x40+i*8)!=(865,30):return False
        if struct.unpack_from('<2I',raw,0x60)!=(0xFFFFFFFF,0xFFFFFFFF):return False
    except (TypeError,ValueError,struct.error):return False
    return True

class Controller:
    def __init__(self,port,*,clock=time.monotonic):
        self.port=port;self.clock=clock;self.enabled=False;self.stopping=False
        self.status='AUTO_DISABLED';self.cursor=0;self.capture=None;self.audit_capture=None
        self.configured=0;self.refused=0;self.lost=0;self.report=None
        self.error=None;self.audit_error=None;self.audit_due=0;self.audit_saved=0
        self.fingerprint=None;self.cleanup_blocked=False
        self.recall=None
        self.follow_desired=None;self.follow_error=None
        self.morale=None;self.morale_at=None;self.morale_sequence=None
        self.army=None
        self.gates=None;self.gates_at=None;self.policy_desired=None;self.policy_error=None
        self.group_pool=None;self.group_pool_at=None
        self.group_pool_tests={}
        self.pool_lifecycle=None;self.pool_lifecycle_at=None
        self.aggression_desired=None;self.aggression_error=None
        self.ai_due=0;self.ai_report=None;self.ai_logging_error=None
        self.timer_desired=None;self.timer_error=None;self.timer_report=None
        self.timer_due=0;self.timer_fingerprint=None;self.timer_logging_error=None
        self.tactical_desired=None;self.tactical_error=None;self.tactical_report=None
        self.tactical_due=0;self.tactical_fingerprint=None;self.tactical_logging_error=None
        self.manual_morale=None;self.manual_morale_error=None;self.manual_morale_due=0
        self.manual_morale_at=None
        self.extras_desired={};self.extras_errors={};self.extras_reports={};self.extras_fingerprints={};self.extras_due=0

    def start(self):
        self.port.start()
        self.cursor=self.port.lease.get('last_sequence_logged',0)
        self.capture=self.port.lease.get('last_capture')
        previous=self.port.lease.get('last_successful_capture')
        self.audit_capture=(self.capture if self.capture and self.capture.get('state')==3 else
                            previous if same_configured_descriptor(previous,self.capture) else None)
        self.enabled=True;self.status='AUTO_WAITING_CONFIGURATION';self.error=None
        self.stopping=False;self.cleanup_blocked=False
        self.follow_desired=None;self.follow_error=None
        self.morale=None;self.morale_at=None;self.morale_sequence=None
        self.army=None
        self.gates=None;self.gates_at=None;self.policy_desired=None;self.policy_error=None
        self.aggression_desired=None;self.aggression_error=None
        self.ai_due=0;self.ai_report=None;self.ai_logging_error=None
        self.timer_desired=None;self.timer_error=None;self.timer_report=None
        self.timer_due=0;self.timer_fingerprint=None;self.timer_logging_error=None
        self.tactical_desired=None;self.tactical_error=None;self.tactical_report=None
        self.tactical_due=0;self.tactical_fingerprint=None;self.tactical_logging_error=None
        self.manual_morale=None;self.manual_morale_error=None;self.manual_morale_due=0
        self.manual_morale_at=None
        self.extras_desired={};self.extras_errors={};self.extras_reports={};self.extras_fingerprints={};self.extras_due=0
        self.audit_error=None;self.fingerprint=None;self.audit_due=0;self.audit_saved=0
        if self.audit_capture and self.capture.get('state')==4:self.status='AUTO_ALREADY_CONFIGURED_AUDIT_CONTINUES'
        self.recall=self.port.recall_status()
        # A recovered session can still have FOLLOW OFF. Queue the same checked
        # private-mode update automatically; transient busy states retry in step.
        if not self.recall.get('follow_test',{}).get('enabled',False):self.follow_desired=True

    def set_follow_test(self,enabled):
        if not self.enabled or self.stopping:raise RuntimeError('E_FOLLOW_AUTO_NOT_RUNNING')
        if type(enabled) is not bool:raise RuntimeError('E_FOLLOW_MODE_ARGUMENT')
        self.follow_desired=enabled;self.follow_error=None

    def stop(self):
        self.extras_desired.clear()
        self.tactical_desired=None
        self.timer_desired=None
        self.follow_desired=None
        self.policy_desired=None;self.aggression_desired=None
        self.enabled=False;self.stopping=self.port.installed();self.cleanup_blocked=False
        self.status='AUTO_STOPPING' if self.stopping else 'AUTO_STOPPED'

    def configure_policy(self,enabled,thresholds):
        if not self.enabled or self.stopping:raise RuntimeError('E_POLICY_AUTO_NOT_RUNNING')
        if type(enabled) is not bool:raise RuntimeError('E_MORALE_ENABLED')
        self.policy_desired=(enabled,validate_thresholds(thresholds));self.policy_error=None

    def configure_aggression(self,enabled):
        if not self.enabled or self.stopping:raise RuntimeError('E_AI_AUTO_NOT_RUNNING')
        if type(enabled) is not bool:raise RuntimeError('E_AI_ENABLED')
        self.aggression_desired=enabled;self.aggression_error=None

    def configure_ai_tests(self,mask):
        if not self.enabled or self.stopping:raise RuntimeError('E_AI_AUTO_NOT_RUNNING')
        if type(mask) is not int or not 0<=mask<=7:raise RuntimeError('E_OFFENSIVE_TEST_MASK')
        self.aggression_desired=mask;self.aggression_error=None

    def configure_ambition_timer(self,enabled):
        if not self.enabled or self.stopping:raise RuntimeError('E_TIMER_AUTO_NOT_RUNNING')
        if type(enabled) is not bool:raise RuntimeError('E_TIMER_ENABLED')
        self.timer_desired=enabled;self.timer_error=None

    def apply_pending_timer(self):
        if self.timer_desired is None:return
        try:
            self.port.set_ambition_timer(self.timer_desired)
            self.timer_desired=None;self.timer_error=None;self.timer_due=0
        except Exception as error:
            self.timer_error=str(error)
            if not any(code in str(error) for code in RETRY_REMOVE):self.timer_desired=None

    def configure_tactical_balance(self,mask):
        if not self.enabled or self.stopping:raise RuntimeError('E_TACTICAL_AUTO_NOT_RUNNING')
        if type(mask) is not int or not 0<=mask<=3:raise RuntimeError('E_TACTICAL_MASK')
        self.tactical_desired=mask;self.tactical_error=None

    def apply_pending_tactical(self):
        if self.tactical_desired is None:return
        try:
            self.port.set_tactical_balance(self.tactical_desired)
            self.tactical_desired=None;self.tactical_error=None;self.tactical_due=0
        except Exception as error:
            self.tactical_error=str(error)
            if not any(code in str(error) for code in RETRY_REMOVE):self.tactical_desired=None

    def scan_gates(self):
        result=self.port.scan_gates();self.gates=result;self.gates_at=self.clock();return result

    def inspect_group_pool(self,count):
        if not self.enabled:raise RuntimeError('E_AUTO_NOT_RUNNING')
        self.group_pool=self.port.inspect_group_pool(count);self.group_pool_at=self.clock()
        self.group_pool_tests[str(count)]={'result':self.group_pool,'at':self.group_pool_at}
        return self.group_pool

    def inspect_pool_lifecycle(self):
        if not self.enabled:raise RuntimeError('E_AUTO_NOT_RUNNING')
        self.pool_lifecycle=self.port.capture_pool_lifecycle();self.pool_lifecycle_at=self.clock()
        return self.pool_lifecycle

    def configure_extra(self,name,enabled):
        if not self.enabled or self.stopping:raise RuntimeError('E_EXTRA_AUTO_NOT_RUNNING')
        if name not in ('ambition_bonus','guard_army','zone_balance','guard_orders','visibility','story_guards','map_markers','detachment','native_hud','personal_movement','duel_officer_drops','npc_many','npc_render_request','damage_audit','guard_damage','officer_crowd','officer_hit_audit','officer_pursuit','reinforcement_delay','npc_allocation_balance','fog_distance','ambition_guards') or type(enabled) is not bool:raise RuntimeError('E_EXTRA_ARGUMENT')
        self.extras_desired[name]=enabled;self.extras_errors.pop(name,None)

    def configure_population(self,percent):
        if not self.enabled or self.stopping:raise RuntimeError('E_EXTRA_AUTO_NOT_RUNNING')
        if type(percent) is not int or percent not in (0,50,100):raise RuntimeError('E_POPULATION_PERCENT')
        self.extras_desired['population']=percent;self.extras_errors.pop('population',None)

    def configure_npc_render_request(self,enabled,target):
        if not self.enabled or self.stopping:raise RuntimeError('E_EXTRA_AUTO_NOT_RUNNING')
        if type(enabled) is not bool:raise RuntimeError('E_NPC_REQUEST_ENABLED')
        self.extras_desired['npc_render_request']=(enabled,validate_budget(target))
        self.extras_errors.pop('npc_render_request',None)

    def configure_npc_many(self,enabled,distance):
        if not self.enabled or self.stopping:raise RuntimeError('E_EXTRA_AUTO_NOT_RUNNING')
        if type(enabled) is not bool:raise RuntimeError('E_NPC_MANY_ENABLED')
        self.extras_desired['npc_many']=(enabled,validate_distance(distance))
        self.extras_errors.pop('npc_many',None)

    def configure_ambition_duel(self,enabled,percent):
        if not self.enabled or self.stopping:raise RuntimeError('E_EXTRA_AUTO_NOT_RUNNING')
        if type(enabled) is not bool:raise RuntimeError('E_DUEL_ENABLED')
        self.extras_desired['ambition_duel']=(enabled,validate_percent(percent))
        self.extras_errors.pop('ambition_duel',None)

    def extra_public(self,name):
        try:view=self.port.extra_status(name) if hasattr(self.port,'extra_status') else {'available':False,'enabled':False}
        except Exception as error:view={'available':False,'hook_installed_or_uncertain':True,'read_error':str(error)}
        return {**view,'pending_change':name in self.extras_desired,
                'error':self.extras_errors.get(name),'last_report':self.extras_reports.get(name)}

    def apply_pending_extras(self):
        pending=list(self.extras_desired.items())
        if self.extras_desired.get('story_guards') is False:
            pending.sort(key=lambda item:0 if item==('native_hud',False) else
                         (1 if item[0]=='story_guards' else 2))
        for name,enabled in pending:
            if name=='guard_orders' and enabled is False and self.extras_desired.get('story_guards') is False:
                continue # Story identity teardown may wait until battle end.
            try:
                if name=='population':self.port.set_population(enabled)
                elif name=='ambition_duel':self.port.set_ambition_duel(*enabled)
                elif name=='npc_render_request' and type(enabled) is tuple:self.port.set_npc_render_request(*enabled)
                elif name=='npc_many' and type(enabled) is tuple:self.port.set_npc_many(*enabled)
                else:self.port.set_extra(name,enabled)
                self.extras_desired.pop(name,None)
                self.extras_errors.pop(name,None);self.extras_due=0
            except Exception as error:
                self.extras_errors[name]=str(error)
                if name in ('detachment','native_hud') and hasattr(self.port,'persist_extra_observation'):
                    try:
                        self.extras_reports[name]=self.port.persist_extra_observation(name,
                            {'available':False,'enabled':False,'requested_enabled':enabled,
                             'error':str(error)[:512]},'SETTINGS_REFUSED')
                    except Exception:pass
                if not any(code in str(error) for code in RETRY_REMOVE):self.extras_desired.pop(name,None)

    def sample_extras_if_due(self):
        if not hasattr(self.port,'extra_status') or self.clock()<self.extras_due:return
        self.extras_due=self.clock()+2
        for name in ('ambition_bonus','guard_army','zone_balance','guard_orders','population','visibility','story_guards','map_markers','detachment','native_hud','personal_movement','ambition_duel','duel_officer_drops','npc_many','npc_render_request','damage_audit','guard_damage','officer_crowd','officer_hit_audit','officer_pursuit','reinforcement_delay','npc_allocation_balance','fog_distance','ambition_guards'):
            try:
                view=(self.port.refresh_extra(name) if hasattr(self.port,'refresh_extra') else self.port.extra_status(name))
                fingerprint=json.dumps(view,sort_keys=True)
                if view.get('hook_installed') and fingerprint!=self.extras_fingerprints.get(name):
                    self.extras_reports[name]=self.port.persist_extra_observation(name,view)
                    self.extras_fingerprints[name]=fingerprint
            except Exception as error:self.extras_errors[name]='OBSERVATION_'+str(error)

    def apply_manual_morale(self,percent):
        if not self.enabled or self.stopping:raise RuntimeError('E_MANUAL_MORALE_AUTO_NOT_RUNNING')
        try:
            self.manual_morale=self.port.apply_manual_morale(percent)
            self.manual_morale_error=None;self.manual_morale_due=self.clock()+2
            self.manual_morale_at=self.clock()
        except Exception as error:
            self.manual_morale_error=str(error)
            raise

    def sample_manual_morale_if_due(self):
        if not self.manual_morale or self.clock()<self.manual_morale_due:return
        self.manual_morale_due=self.clock()+2
        try:
            result=self.port.observe_manual_morale()
            if result:
                self.manual_morale={**self.manual_morale,'observation':result}
                self.manual_morale_at=self.clock()
            self.manual_morale_error=None
        except Exception as error:self.manual_morale_error=str(error)

    def step(self):
        if not self.port.alive():
            self.extras_desired.clear()
            self.tactical_desired=None
            self.timer_desired=None
            self.follow_desired=None
            self.policy_desired=None;self.aggression_desired=None
            self.enabled=False;self.stopping=False;self.status='AUTO_PROCESS_EXITED';return
        if self.stopping:
            if self.cleanup_blocked:return
            try:
                if self.port.lease and 'data_address' in self.port.lease:
                    try:self.collect()
                    except Exception as error:self.audit_error='STOP_CAPTURE_'+str(error)
                if self.port.installed():self.port.remove()
                self.recall=self.port.recall_status()
                self.stopping=False;self.status='AUTO_STOPPED';self.error=None
            except Exception as error:
                self.error=str(error)
                self.cleanup_blocked=not any(code in str(error) for code in RETRY_REMOVE)
                self.status='AUTO_REMOVE_REQUIRED' if self.cleanup_blocked else 'AUTO_RETRY_STOP'
            return
        if not self.enabled:return
        try:
            self.collect();self.audit_if_due()
            self.recall=self.port.recall_status()
            self.apply_pending_timer()
            self.apply_pending_tactical()
            self.apply_pending_extras()
            if self.policy_desired is not None:
                try:
                    self.recall=self.port.set_morale_policy(*self.policy_desired)
                    self.policy_desired=None;self.policy_error=None
                except Exception as error:
                    self.policy_error=str(error)
                    if not any(code in str(error) for code in RETRY_REMOVE):self.policy_desired=None
            if self.aggression_desired is not None:
                try:
                    if hasattr(self.port,'set_offensive_ai_tests'):
                        mask=(7 if self.aggression_desired else 0) if type(self.aggression_desired) is bool else self.aggression_desired
                        self.port.set_offensive_ai_tests(mask)
                    else:self.port.set_aggression(self.aggression_desired)
                    self.aggression_desired=None;self.aggression_error=None
                    self.ai_due=0
                except Exception as error:
                    self.aggression_error=str(error)
                    if not any(code in str(error) for code in RETRY_REMOVE):self.aggression_desired=None
            if self.follow_desired is not None:
                try:
                    self.recall=self.port.set_follow_test(self.follow_desired)
                    self.follow_desired=None;self.follow_error=None
                except Exception as error:
                    self.follow_error=str(error)
                    if not any(code in str(error) for code in RETRY_REMOVE):raise
            self.sample_ai_if_due()
            self.sample_timer_if_due()
            self.sample_tactical_if_due()
            self.sample_manual_morale_if_due()
            if hasattr(self.port,'refresh_crowd'):self.port.refresh_crowd()
            self.sample_extras_if_due()
        except Exception as error:
            self.error=str(error);self.enabled=False;self.stopping=self.port.installed()
            self.status='AUTO_STOPPING_AFTER_ERROR' if self.stopping else 'AUTO_HALTED'

    def sample_ai_if_due(self):
        if not hasattr(self.port,'persist_ai_observation') or self.clock()<self.ai_due:return
        self.ai_due=self.clock()+2
        try:
            view=self.port.offensive_ai_status()
            if view.get('hook_installed'):
                self.ai_report=self.port.persist_ai_observation(view)
            self.ai_logging_error=None
        except Exception as error:self.ai_logging_error=str(error)

    def sample_timer_if_due(self):
        if not hasattr(self.port,'persist_timer_observation') or self.clock()<self.timer_due:return
        self.timer_due=self.clock()+2
        try:
            view=self.port.ambition_timer_status()
            fingerprint=json.dumps(view,sort_keys=True)
            if view.get('hook_installed') and fingerprint!=self.timer_fingerprint:
                self.timer_report=self.port.persist_timer_observation(view)
                self.timer_fingerprint=fingerprint
            self.timer_logging_error=None
        except Exception as error:self.timer_logging_error=str(error)

    def sample_tactical_if_due(self):
        if not hasattr(self.port,'persist_tactical_observation') or self.clock()<self.tactical_due:return
        self.tactical_due=self.clock()+2
        try:
            view=self.port.tactical_balance_status();fingerprint=json.dumps(view,sort_keys=True)
            if view.get('hook_installed') and fingerprint!=self.tactical_fingerprint:
                self.tactical_report=self.port.persist_tactical_observation(view)
                self.tactical_fingerprint=fingerprint
            self.tactical_logging_error=None
        except Exception as error:self.tactical_logging_error=str(error)

    def collect(self):
        batch=self.port.events(self.cursor)
        if batch['events']:
            if batch['lost_events']:
                self.lost+=batch['lost_events']
                self.port.log('AUTO_EVENT_OVERFLOW',lost_events_total=self.lost)
            for event in batch['events']:
                retained=(self.audit_capture if same_configured_descriptor(self.audit_capture,event) else None)
                self.report=self.port.persist_capture(event)
                self.cursor=event['sequence'];self.capture=event
                self.audit_capture=event if event['state']==3 else retained
                self.audit_error=None;self.fingerprint=None;self.audit_due=self.clock()+1
                self.audit_saved=0
                self.morale=None;self.morale_at=None;self.morale_sequence=None
                self.army=None
                self.gates=None;self.gates_at=None
                if event['state']==3:
                    self.configured+=1
                    self.status=('AUTO_SQUADS_CONFIGURED_WAITING_NEXT' if event.get('configured_squad_count',1)>1
                                 else 'AUTO_SLOT_CONFIGURED_WAITING_NEXT')
                else:
                    self.refused+=1;self.status='AUTO_CONFIGURATION_REFUSED_WAITING_NEXT'
                    if retained:self.status='AUTO_ALREADY_CONFIGURED_AUDIT_CONTINUES'
        if not batch['header']['enabled'] or batch['header']['counter_exhausted']:
            if self.enabled:raise RuntimeError('E_AUTO_NATIVE_DISABLED')

    @staticmethod
    def audit_fingerprint(result):
        selected={'player_groups':result.get('player_groups'),
                  'guard_reservations':result.get('guard_reservations'),
                  'ownership_observed':result.get('ownership_observed'),
                  'morale_observation':result.get('morale_observation')}
        selected['gate_scan']=result.get('gate_scan')
        return hashlib.sha256(json.dumps(selected,sort_keys=True).encode()).hexdigest()

    def audit_if_due(self):
        now=self.clock()
        if not self.audit_capture or now<self.audit_due:return
        self.audit_due=now+2
        try:result=self.port.audit(self.audit_capture)
        except Exception as error:
            self.audit_error=str(error);return
        self.audit_error=None;fingerprint=self.audit_fingerprint(result)
        self.morale=result.get('morale_observation');self.morale_at=now
        self.army=result.get('army_observation')
        self.gates=result.get('gate_scan');self.gates_at=now
        self.morale_sequence=self.audit_capture['sequence']
        if fingerprint!=self.fingerprint or now-self.audit_saved>=15:
            self.report=self.port.persist_audit(result)
            self.fingerprint=fingerprint;self.audit_saved=now

    def public(self):
        if self.status=='AUTO_PROCESS_EXITED':
            return {'status':self.status,'enabled':False,'hook_installed_or_uncertain':False,
                    'process_memory_released':True,'host_revision':'v5-ambition-guard-refresh-41'}
        return {'status':self.status,'enabled':self.enabled,'modes':['AMBITION','STORY_FREE'],
                'host_revision':'v5-ambition-guard-refresh-41',
                'pool_lifecycle':{**(self.pool_lifecycle or {'available':False,'read_only':True}),
                    'stale':bool(not self.enabled or self.pool_lifecycle_at is None or self.clock()-self.pool_lifecycle_at>5)},
                'group_pool_tests':{count:{**item['result'],
                    'stale':bool(not self.enabled or self.clock()-item['at']>5)}
                    for count,item in self.group_pool_tests.items()},
                'group_pool':{**(self.group_pool or {'status':'NOT_CHECKED','read_only':True,
                    'native_capacity':600,'expansion_applied':False,'single_player_only':True}),
                    'sample_kind':'ON_DEMAND_READ_ONLY',
                    'stale':bool(not self.enabled or self.group_pool_at is None or self.clock()-self.group_pool_at>5)},
                'extra_features':{name:self.extra_public(name)
                    for name in ('ambition_bonus','guard_army','zone_balance','guard_orders','population','visibility','story_guards','map_markers','detachment','native_hud','personal_movement','ambition_duel','duel_officer_drops','npc_many','npc_render_request','damage_audit','guard_damage','officer_crowd','officer_hit_audit','officer_pursuit','reinforcement_delay','npc_allocation_balance','fog_distance','ambition_guards')},
                'manual_morale':{'available':False,'retired_from_tool':True,'continuous_override':False,
                    'last_application':self.manual_morale,'error':self.manual_morale_error,
                    'stale':bool(not self.enabled or self.manual_morale_error or self.manual_morale_at is None
                                 or self.clock()-self.manual_morale_at>5)},
                'tactical_balance':{**(self.port.tactical_balance_status() if hasattr(self.port,'tactical_balance_status') else
                    {'available':False,'enabled':False}),'pending_change':self.tactical_desired is not None,
                    'error':self.tactical_error,'last_report':self.tactical_report,
                    'logging_error':self.tactical_logging_error},
                'ambition_timer':{**(self.port.ambition_timer_status() if hasattr(self.port,'ambition_timer_status') else
                    {'available':False,'enabled':False}),'pending_change':self.timer_desired is not None,
                    'error':self.timer_error,'last_report':self.timer_report,
                    'logging_error':self.timer_logging_error},
                'host_diagnostics_build':HOST_DIAGNOSTICS_BUILD,
                'gate_scan':{**(self.gates or {'available':False}),
                    'stale':bool(not self.enabled or self.audit_error or self.gates_at is None
                                 or self.clock()-self.gates_at>5)},
                'morale_policy':{**((self.recall or {}).get('morale_policy') or {'available':False,'enabled':False}),
                    'pending_change':self.policy_desired is not None,'error':self.policy_error},
                'aggression':{**(self.port.offensive_ai_status() if hasattr(self.port,'offensive_ai_status') else
                    self.port.aggression_status() if hasattr(self.port,'aggression_status') else {'available':False,'enabled':False}),
                    'pending_change':self.aggression_desired is not None,'error':self.aggression_error,
                    'last_report':self.ai_report,'logging_error':self.ai_logging_error},
                'morale_observation':{**(self.morale or {'available':False}),
                    'sample_kind':'LAST_SUCCESSFUL_AUDIT','sample_sequence':self.morale_sequence,
                    'stale':bool(not self.enabled or self.audit_error or self.morale_at is None
                                 or self.clock()-self.morale_at>5)},
                'army_observation':{**(self.army or {'available':False}),
                    'sample_kind':'LAST_SUCCESSFUL_AUDIT','sample_sequence':self.morale_sequence,
                    'stale':bool(not self.army or not self.army.get('available') or not self.enabled
                                 or self.audit_error or self.morale_at is None
                                 or self.clock()-self.morale_at>5)},
                'hook_installed_or_uncertain':self.port.installed(),
                'configuration_events_logged':self.cursor,'configured_since_start':self.configured,
                'audit_capture_sequence':self.audit_capture['sequence'] if self.audit_capture else None,
                'audit_continues_after_duplicate':bool(self.audit_capture and self.capture
                    and self.capture.get('state')==4),
                'refused_since_start':self.refused,'lost_event_reports':self.lost,
                'last_capture':self.capture,'last_report':self.report,
                'error':self.error,'audit_wait_or_error':self.audit_error,
                'recall':self.recall,'recall_experimental':True,
                'reinforcements':(self.recall or {}).get('reinforcements',{'available':False,'enabled':False}),
                'army_configuration':{'squads':PROFILE['player_squad_count'],
                    'soldiers_per_squad':30,'total_soldiers':PROFILE['player_squad_count']*30,
                    'follow_automatic':True},
                'follow_test':{**((self.recall or {}).get('follow_test') or {'enabled':False}),
                    'pending_change':self.follow_desired is not None,
                    'requested_enabled':self.follow_desired,'error':self.follow_error},
                'live_follow_verified':False,'allied_charge_independence_verified':False}
