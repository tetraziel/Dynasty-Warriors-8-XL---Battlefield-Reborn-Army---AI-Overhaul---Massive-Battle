"""Fresh Ambition initialization only. Pure emitter; no process access on import."""
import hashlib
import struct
from core import PROFILE,require,word
from bridge import relative_jump
from recall_bridge import Asm,R

MAGIC=0x38544D41
VERSION=1
SIZE=0x1000
CODE_SIZE=0x2000
MINUTES=30
TICKS=MINUTES*60*60
SITE=0x52BA25
ORIGINAL=bytes.fromhex('8b470483c408')
SECOND_SITE=0x5B5FBC
SECOND_TARGET=0x2030A0
SECOND_ORIGINAL=bytes.fromhex('e8dfd0c4ff')
COUNTERS={'initializations_observed':0x10,'extensions_applied':0x14,
          'other_modes_skipped':0x18,'context_skipped':0x1C,
          'unlimited_skipped':0x20,'already_long_enough':0x24}
RESULTS={0:'WAITING_NEXT_INITIALIZATION',1:'EXTENDED_TO_30_MINUTES',
         2:'OTHER_MODE',3:'CONTEXT_NOT_FRESH_SINGLE_PLAYER',4:'UNLIMITED',
         5:'ALREADY_AT_LEAST_30_MINUTES'}

def initial_data():
    b=bytearray(SIZE)
    struct.pack_into('<4I',b,0,MAGIC,VERSION,0,0)
    struct.pack_into('<I',b,0x40,TICKS)
    return bytes(b)

def build_bridge(base,data,code,*,secondary=False):
    x=Asm()
    def inc(off):x.mem('ff',0,disp=data+off)
    def save(reg,off):x.store(reg,disp=data+off)
    x.emit('9c60')
    for off,value in ((0,MAGIC),(4,VERSION),(8,1),(0x40,TICKS)):
        x.op(7,value,disp=data+off);x.jump('ne','original')
    x.imm('eax',0);x.imm('ecx',1)
    x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','original')
    inc(0x10)
    x.sane('edi','context')
    x.load('eax',disp=base+0x6A9200);x.rr('39','eax','edi');x.jump('ne','context')
    save('edi',0x28)
    x.mem('0fb7',R['ecx'],disp=base+0x848530);save('ecx',0x3C)
    x.load('edx','edi');save('edx',0x38)
    x.cmp('ecx',1);x.jump('ne','mode')
    x.rr('89','ecx','edx');x.ri(4,'ecx',0x20003E00)
    x.cmp('ecx',0x1000);x.jump('ne','mode')
    x.mem('f7',0,'edi');x.dword(1);x.jump('ne','context')
    if not secondary:
        x.op(7,0,'ebp',8);x.jump('ne','context') # native resume flag
    x.load('eax','edi',0x38);save('eax',0x34)
    x.cmp('eax',0);x.jump('ne','context')
    x.load('eax','edi',0x3C);save('eax',0x2C);save('eax',0x30)
    x.cmp('eax',0xFFFFFFFF);x.jump('eq','unlimited')
    x.cmp('eax',0);x.jump('eq','context')
    x.cmp('eax',TICKS);x.jump('ae','long_enough')
    # The only game-data write: its actual native limit, never elapsed time.
    x.set(TICKS,'edi',0x3C);x.set(TICKS,disp=data+0x30)
    inc(0x14);x.set(1,disp=data+0x44);x.jump('jmp','unlock')
    for label,counter,result in (('mode',0x18,2),('context',0x1C,3),
                                 ('unlimited',0x20,4),('long_enough',0x24,5)):
        x.mark(label);inc(counter);x.set(result,disp=data+0x44);x.jump('jmp','unlock')
    x.mark('unlock');x.set(0,disp=data+12)
    x.mark('original');x.emit('619d')
    if secondary:
        # Entry is a replaced CALL. Tail-call its original target, preserving
        # the caller's existing return address and every native argument.
        x.emit(relative_jump(code+len(x.code),base+SECOND_TARGET))
    else:
        x.emit(ORIGINAL)
        x.emit(relative_jump(code+len(x.code),base+SITE+len(ORIGINAL)))
    result=x.finish();require(len(result)<SIZE,'E_TIMER_BRIDGE_SIZE');return result

def prepare(base,data,code):
    payload=build_bridge(base,data,code)
    second=build_bridge(base,data,code+SIZE,secondary=True)
    return {'version':VERSION,'data_address':data,'code_address':code,
            'code_size':len(payload),'code_sha256':hashlib.sha256(payload).hexdigest(),
            'site':base+SITE,'original_hex':ORIGINAL.hex(),
            'replacement_hex':relative_jump(base+SITE,code,len(ORIGINAL)).hex(),
            'installed':False,'state':'PREPARED',
            'secondary':{'site':base+SECOND_SITE,'original_hex':SECOND_ORIGINAL.hex(),
                'replacement_hex':(bytes([0xE8])+relative_jump(base+SECOND_SITE,code+SIZE)[1:]).hex(),
                'code_address':code+SIZE,'code_size':len(second),
                'code_sha256':hashlib.sha256(second).hexdigest(),'installed':False}}

def patches(record):return [record,record['secondary']]

def check_code(memory):
    for rva,sig in PROFILE['ambition_timer']['code_checks'].items():
        wanted=bytes.fromhex(sig)
        require(memory.read(memory.base+int(rva),len(wanted))==wanted,
                'E_TIMER_NATIVE_CODE_'+hex(int(rva)))
    for rva,spec in PROFILE['ambition_timer']['relocated_code_checks'].items():
        wanted=bytes.fromhex(spec['prefix'])+struct.pack('<I',memory.base+spec['target_rva'])
        require(memory.read(memory.base+int(rva),len(wanted))==wanted,
                'E_TIMER_RELOCATED_CODE_'+hex(int(rva)))

def validate(memory,record):
    require(record.get('version')==VERSION,'E_TIMER_JOURNAL_VERSION')
    data,code=record.get('data_address',0),record.get('code_address',0)
    require(0x10000<=data<0xFFF00000-SIZE and 0x10000<=code<0xFFF00000-CODE_SIZE
            and (data+SIZE<=code or code+CODE_SIZE<=data),'E_TIMER_ALLOCATIONS')
    expected=prepare(memory.base,data,code)
    require(all(record.get(k)==v for k,v in expected.items() if k not in ('installed','state','secondary')),
            'E_TIMER_JOURNAL_IDENTITY')
    for saved,wanted in zip(patches(record),patches(expected)):
        if saved is not record:
            require(all(saved.get(k)==v for k,v in wanted.items() if k!='installed'),'E_TIMER_JOURNAL_IDENTITY')
        original=bytes.fromhex(saved['original_hex']);actual=memory.read(saved['site'],len(original))
        require(actual in (original,bytes.fromhex(saved['replacement_hex'])),'E_TIMER_SITE_CONFLICT')
        saved['installed']=actual!=original
        require(hashlib.sha256(memory.read(saved['code_address'],saved['code_size'])).hexdigest()==saved['code_sha256'],
                'E_TIMER_CODE_CHANGED')
    raw=memory.read(data,0x48)
    require(struct.unpack_from('<2I',raw)==(MAGIC,VERSION) and word(raw,8) in (0,1)
            and word(raw,12) in (0,1) and word(raw,0x40)==TICKS,'E_TIMER_DATA_HEADER')
    check_code(memory)

def public(memory,record=None):
    result={'available':True,'enabled':False,'hook_installed':False,
            'implementation':'FRESH_AMBITION_NATIVE_TIME_LIMIT',
            'minimum_start_minutes':MINUTES,'ticks_per_second':60,'target_ticks':TICKS,
            'applies_on_fresh_initialization':True,'retroactive_extension':False,'elapsed_time_modified':False,
            'continuous_refresh':False,'live_validated':False}
    if not record:return result
    raw=memory.read(record['data_address'],0x48)
    require(struct.unpack_from('<2I',raw)==(MAGIC,VERSION) and word(raw,8) in (0,1)
            and word(raw,0x40)==TICKS,'E_TIMER_DATA_HEADER')
    complete=record['installed'] and record.get('secondary',{'installed':True})['installed']
    result.update(hook_installed=bool(record['installed'] or record.get('secondary',{}).get('installed')),
                  enabled=bool(complete and word(raw,8)),busy=bool(word(raw,12)),
                  **{n:word(raw,o) for n,o in COUNTERS.items()},
                  last_result=RESULTS.get(word(raw,0x44),'UNKNOWN'),
                  last_configuration=hex(word(raw,0x28)),last_mode=word(raw,0x3C),
                  last_mode_flags=hex(word(raw,0x38)),last_elapsed_ticks=word(raw,0x34),
                  last_limit_before_ticks=word(raw,0x2C),last_limit_after_ticks=word(raw,0x30))
    return result
