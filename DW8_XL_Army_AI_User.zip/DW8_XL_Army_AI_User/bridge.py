"""Pure x86 emitter. No native calls; replays displaced arithmetic exactly."""
import struct
from core import PROFILE,require,word

MAGIC=0x34535744
DATA_SIZE=0x1000
OFF_STATE=8
OFF_CANCEL=12
STATES={0:'IDLE',1:'WAITING_FOR_CONFIGURATION',2:'WRITING_CONFIGURATION',
        3:'ONE_SLOT_CONFIGURED',4:'REFUSED_CONFIGURATION',5:'CANCELLED'}
REASONS={0:'NONE',1:'PLAYER_POINTER',2:'PLAYER_COUNT',3:'PLAYER_OWNER_CONTEXT',
         4:'DESCRIPTOR_KIND',5:'FIRST_SQUAD_TEMPLATE',6:'SLOT_ALREADY_OCCUPIED',
         7:'SOURCE_SLOT_NOT_EMPTY',8:'STORY_SLOT_TEMPLATE_NOT_EMPTY',
         9:'DESTINATION_PLAYER1_MARKER',10:'SOURCE_PLAYER1_MARKER'}

def relative_jump(source,target,size=5):
    require(5<=size<=7,'E_JUMP_SIZE')
    delta=((target-source-5+0x80000000)&0xffffffff)-0x80000000
    return b'\xe9'+struct.pack('<i',delta)+b'\x90'*(size-5)

class X86:
    def __init__(self): self.code=bytearray();self.labels={};self.fixes=[]
    def emit(self,value): self.code.extend(bytes.fromhex(value) if isinstance(value,str) else value)
    def dword(self,value): self.emit(struct.pack('<I',value&0xffffffff))
    def mark(self,name):
        require(name not in self.labels,'E_DUPLICATE_LABEL');self.labels[name]=len(self.code)
    def branch(self,opcode,name):
        self.emit(opcode);self.fixes.append((len(self.code),name));self.dword(0)
    def finish(self):
        for offset,name in self.fixes:
            struct.pack_into('<i',self.code,offset,self.labels[name]-(offset+4))
        return bytes(self.code)

def initial_data(mode):
    require(mode in PROFILE['modes'],'E_MODE')
    data=bytearray(DATA_SIZE)
    struct.pack_into('<7I',data,0,MAGIC,4,1,0,0,0,1 if mode=='AMBITION' else 2)
    return bytes(data)

def build_bridge(base,data,code_address,mode,*,worker=False,squad_count=1):
    require(mode in PROFILE['modes'],'E_MODE')
    require(type(squad_count) is int and 1<=squad_count<=4,'E_PERSONAL_SQUAD_COUNT')
    spec=PROFILE['modes'][mode];x=X86()
    def load_abs(reg,address): x.emit(bytes([0x8b,0x05|(reg<<3)]));x.dword(address)
    def store_abs(reg,address): x.emit(bytes([0x89,0x05|(reg<<3)]));x.dword(address)
    def set_abs(address,value): x.emit('c705');x.dword(address);x.dword(value)
    def cmp_abs(address,value): x.emit('813d');x.dword(address);x.dword(value)
    def reject(reason): set_abs(data+0x14,reason);set_abs(data+OFF_STATE,4);x.branch('e9','finish')
    def fail_if(opcode,label): x.branch(opcode,label)
    x.emit('9c60') # pushfd; pushad. The x87/SSE state is never touched.
    cmp_abs(data+OFF_STATE,1);fail_if('0f85','finish')
    cmp_abs(data+OFF_CANCEL,0);fail_if('0f85','cancel')
    if mode=='STORY_FREE':
        x.emit('81ff78000000');fail_if('0f85','finish') # EDI == 120
        x.emit('89f7') # EDI = ESI destination; EBX already source.
    else:
        x.emit('83f900');fail_if('0f85','finish') # ECX == first outer index
        x.emit('89f38d7fd0') # EBX = ESI source; EDI -= 0x30
    load_abs(2,base+PROFILE['manager_rva']) # EDX manager
    x.emit('8d82');x.dword(PROFILE['first_descriptor_offset'])
    x.emit('39c7');fail_if('0f85','finish') # exact first manager descriptor
    # Acquire a one-shot request only after matching the correct record.
    x.emit('b801000000b902000000f00fb10d');x.dword(data+OFF_STATE)
    fail_if('0f85','finish')
    store_abs(7,data+0x1c);store_abs(3,data+0x20);store_abs(2,data+0x24)
    # Full 0x78-byte descriptor before and after, integer operations only.
    for offset in range(0,0x78,4):
        x.emit(bytes([0x8b,0x47,offset]));store_abs(0,data+0x100+offset)
    for offset,destination in [(0,0x40),(4,0x44),(0x40,0x30),(0x44,0x34)]:
        x.emit(bytes([0x8b,0x47,offset]));store_abs(0,data+destination)
    x.emit(bytes([0x8b,0x43,spec['source_type_offset']]));store_abs(0,data+0x48)
    x.emit(bytes([0x8b,0x43,spec['source_template_offset']]));store_abs(0,data+0x4c)
    x.emit('8b4738');store_abs(0,data+0x58)
    x.emit(bytes([0x8b,0x43,spec['source_type_offset']-8]));store_abs(0,data+0x5c)
    load_abs(0,base+PROFILE['players_rva']);store_abs(0,data+0x28)
    x.emit('3d00000100');fail_if('0f82','bad_pointer')
    x.emit('3d0000f0ff');fail_if('0f83','bad_pointer')
    x.emit('8b8890050000');store_abs(1,data+0x54) # player count at +0x590
    x.emit('8b9008010000');store_abs(2,data+0x2c) # capture owner even before count is initialized
    x.emit('83f901')
    if mode=='STORY_FREE':
        # This copier runs before the player pool is bound (observed count=0,
        # owner=250). Target Player1 by both configuration markers below.
        fail_if('0f84','count_allowed')
        x.emit('83f900');fail_if('0f85','bad_count')
        x.emit('81fafa000000');fail_if('0f85','bad_count')
        x.mark('count_allowed')
    else:
        fail_if('0f85','bad_count')
    # During startup 250 is unbound, outside the 0..249 native owner pool.
    # Identify this configuration by its Player1 marker, never use 250 as an index.
    x.emit('83fa00');fail_if('0f84','owner_allowed')
    x.emit('81fafa000000');fail_if('0f85','bad_owner')
    x.mark('owner_allowed')
    x.emit('817f3854040000');fail_if('0f85','bad_player_marker')
    x.emit(bytes([0x81,0x7b,spec['source_type_offset']-8]));x.dword(1108)
    fail_if('0f85','bad_source_player_marker')
    x.emit('837f0401');fail_if('0f87','bad_kind') # native descriptor kind 0 or 1
    x.emit('837f3c01');fail_if('0f87','bad_first') # first (player) group template 0 or 1
    x.emit('837f40ff');fail_if('0f85','occupied')
    x.emit(bytes([0x83,0x7b,spec['source_type_offset'],0xff]));fail_if('0f85','bad_source')
    if mode=='STORY_FREE':
        x.emit('837f44ff');fail_if('0f85','bad_template')
    # Validate all requested slots before the first write. Leave the native
    # player group and every unused pair untouched, including the final pair.
    for i in range(1,squad_count):
        offset=0x40+i*8
        x.emit(bytes([0x83,0x7f,offset,0xff]));fail_if('0f85','occupied')
        x.emit(bytes([0x83,0x7b,spec['source_type_offset']+i*8,0xff]));fail_if('0f85','bad_source')
        if mode=='STORY_FREE':
            x.emit(bytes([0x83,0x7f,offset+4,0xff]));fail_if('0f85','bad_template')
    if squad_count>1:
        for offset in range(0x40+squad_count*8,0x68,4):
            x.emit(bytes([0x83,0x7f,offset,0xff]));fail_if('0f85','occupied')
    for i in range(squad_count):
        offset=0x40+i*8
        x.emit(bytes([0xc7,0x47,offset]));x.dword(PROFILE['troop_type'])
        x.emit(bytes([0xc7,0x47,offset+4]));x.dword(PROFILE['squad_template'])
    for offset in range(0,0x78,4):
        x.emit(bytes([0x8b,0x47,offset]));store_abs(0,data+0x180+offset)
    set_abs(data+0x38,PROFILE['troop_type']);set_abs(data+0x3c,PROFILE['squad_template'])
    set_abs(data+OFF_STATE,3);x.branch('e9','finish')
    for label,reason in [('bad_pointer',1),('bad_count',2),('bad_owner',3),('bad_kind',4),
                         ('bad_first',5),('occupied',6),('bad_source',7),('bad_template',8),
                         ('bad_player_marker',9),('bad_source_player_marker',10)]:
        x.mark(label);reject(reason)
    x.mark('cancel');set_abs(data+OFF_STATE,5)
    x.mark('finish');x.emit('619d') # popad; popfd
    if worker:
        x.emit('c3') # Internal automatic wrapper only; game registers/flags unchanged.
    else:
        x.emit(bytes.fromhex(spec['original'])) # replay increments/adds, with their original flags
        jump_at=code_address+len(x.code)
        x.emit(relative_jump(jump_at,base+spec['site_rva']+len(bytes.fromhex(spec['original']))))
    code=x.finish()
    require(len(code)<0x4000,'E_BRIDGE_SIZE')
    return code

def decode_status(raw):
    require(len(raw)>=0x1f8,'E_STATUS_SIZE')
    require(word(raw)==MAGIC and word(raw,4)==4,'E_DATA_HEADER')
    state=word(raw,OFF_STATE)
    result={'state':state,'status':STATES.get(state,'UNKNOWN'),
            'reason':REASONS.get(word(raw,0x14),'UNKNOWN'),
            'cancel_requested':bool(word(raw,OFF_CANCEL)),
            'destination':hex(word(raw,0x1c)),'source':hex(word(raw,0x20)),
            'manager':hex(word(raw,0x24)),'players':hex(word(raw,0x28)),
            'players_owner_at_load':word(raw,0x2c),'players_count_at_load':word(raw,0x54),
            'before_pair':[word(raw,0x30),word(raw,0x34)],
            'after_pair':[word(raw,0x38),word(raw,0x3c)],
            'source_pair':[word(raw,0x48),word(raw,0x4c)],
            'descriptor_alias':word(raw,0x40),'descriptor_kind':word(raw,0x44),
            'descriptor_player_marker':word(raw,0x58),'source_player_marker':word(raw,0x5c),
            'runtime_owner_binding_pending':word(raw,0x2c)==250,
            'runtime_player_count_pending':word(raw,0x54)==0,
            'player1_markers_match':word(raw,0x58)==word(raw,0x5c)==1108,
            'live_ownership_verified':False,'live_follow_verified':False}
    if state in (3,4):
        result['descriptor_before_hex']=raw[0x100:0x178].hex()
    if state==3:result['descriptor_after_hex']=raw[0x180:0x1f8].hex()
    if state==3:
        slots=[off for off in range(0x40,0x68,8)
               if word(raw,0x180+off)==PROFILE['troop_type'] and
                  word(raw,0x184+off)==PROFILE['squad_template']]
        result.update(configured_squad_count=len(slots),soldiers_per_squad=30,
                      configured_soldiers=len(slots)*30)
        if len(slots)>1:result['status']='PLAYER_SQUADS_CONFIGURED'
    return result
