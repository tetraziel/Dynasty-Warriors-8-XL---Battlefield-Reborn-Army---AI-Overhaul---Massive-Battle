"""Exact mod field, applied only after both native banks identify themselves."""
import base64
import json
import struct
import zlib
from pathlib import Path
from core import require,pointer,Refused

SCHEMA=json.loads((Path(__file__).with_name('aggression_schema.json')).read_text())
PREFIX=zlib.decompress(base64.b64decode(SCHEMA['prefix_zlib_base64']))
ROWS,STRIDE,FIELD=1160,60,0x26
BANK=ROWS*STRIDE
SIZE=2*BANK
require(len(PREFIX)==ROWS*36,'E_AI_SCHEMA')


class SchemaRefused(Refused):
    def __init__(self,code,diagnostic):
        super().__init__(code);self.diagnostic=diagnostic


def check_code(memory):
    expected=bytes.fromhex('3d8704000077118b15')+struct.pack('<I',memory.base+0x6A93B4)+bytes.fromhex('8bc8c1e1042bc88d048ac333c0c3')
    require(memory.read(memory.base+0x4050,len(expected))==expected,'E_AI_CACHE_GETTER')
    return pointer(memory,memory.base+0x6A93B4)


def transformed(raw,enable):
    require(len(raw)==SIZE,'E_AI_CACHE_SIZE')
    result=bytearray(raw)
    for bank in range(2):
        for row in range(ROWS):
            at=bank*BANK+row*STRIDE;prefix=PREFIX[row*36:(row+1)*36]
            actual_id=struct.unpack_from('<I',raw,at)[0]
            diagnostic={'bank':bank,'row':row,'field_offset':hex(FIELD),
                        'record_hex':raw[at:at+STRIDE].hex(),
                        'original_prefix_hex':prefix.hex(),
                        'backup_record_hex':raw[BANK+row*STRIDE:BANK+(row+1)*STRIDE].hex()}
            if actual_id!=row:
                raise SchemaRefused('E_AI_CACHE_ROW_ID',{**diagnostic,'expected_id':row,'actual_id':actual_id})
            before=struct.unpack_from('<H',prefix,34)[0]
            value=struct.unpack_from('<H',raw,at+FIELD)[0]
            if value not in ((before,) if enable else (before,0xFFFF)):
                raise SchemaRefused('E_AI_FIELD_CONFLICT',{**diagnostic,
                    'expected_value':before,'actual_value':value,'actual_hex':hex(value)})
            if bank==1:
                # The original bank establishes the entire serialized prefix,
                # including the exact 16-bit field and its byte boundaries.
                observed=bytearray(raw[at+4:at+40]);observed[34:36]=prefix[34:36]
                if bytes(observed)!=prefix:
                    raise SchemaRefused('E_AI_BACKUP_SCHEMA_MISMATCH',diagnostic)
            struct.pack_into('<H',result,at+FIELD,0xFFFF if enable else before)
    return bytes(result)


def status(lease):
    patch=(lease or {}).get('aggression_patch') or {}
    return {'available':True,'enabled':patch.get('state')=='APPLIED',
        'implementation':'VERIFIED_UNIT_CACHE_BOTH_BANKS','field_offset':hex(FIELD),
        'rows':ROWS,'banks':2,'scope':'ALLIES_AND_ENEMIES_SHARED_DEFINITIONS',
        'runtime_schema_verified':patch.get('schema_verified',False),
        'restore_required':patch.get('state') in ('APPLIED','PENDING'),
        'uncertain':patch.get('state')=='PENDING',
        'diagnostic':(lease or {}).get('aggression_diagnostic'),
        'live_behavior_verified':False,'last_state':patch.get('state','OFF')}
