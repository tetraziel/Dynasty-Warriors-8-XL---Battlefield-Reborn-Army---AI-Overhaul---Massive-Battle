"""Read-only validation and reports. No Windows imports or process writes."""
import json
import struct
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PROFILE=json.loads((ROOT/'profile.json').read_text(encoding='utf-8'))
PROFILE_HASH=PROFILE['exe_sha256']
BUILD=PROFILE['build']

class Refused(RuntimeError): pass
def require(condition,code):
    if not condition: raise Refused(code)
def word(raw,offset=0): return struct.unpack_from('<I',raw,offset)[0]
def uint(memory,address): return word(memory.read(address,4))
def pointer(memory,address):
    value=uint(memory,address)
    require(0x10000<=value<0xFFF00000,'E_POINTER_'+hex(address))
    return value
def journal_write(path,record):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix('.pending')
    temporary.write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    temporary.replace(path)

def validate_profile(memory,mode,installed=None,*,owned_sites=None):
    require(mode in PROFILE['modes'],'E_MODE')
    config=PROFILE['modes'][mode]
    expected=bytes.fromhex(config['original']) if installed is None else installed
    actual=memory.read(memory.base+config['site_rva'],len(expected))
    require(actual==expected,'E_SITE_CHANGED_'+mode)
    for rva,value in config['code_checks'].items():
        expected=bytes.fromhex(value)
        require(memory.read(memory.base+int(rva),len(expected))==expected,
                'E_CODE_SIGNATURE_'+hex(int(rva)))
    require(memory.read(memory.base+PROFILE['v3_site_rva'],5)==
            bytes.fromhex(PROFILE['v3_site_original']),'E_V3_HOOK_ACTIVE_OR_OTHER_PATCH')
    # Refuse the other v4 path if another window installed a hook there.
    for other,spec in PROFILE['modes'].items():
        if other!=mode:
            expected=(owned_sites or {}).get(other,bytes.fromhex(spec['original']))
            require(memory.read(memory.base+spec['site_rva'],len(expected))==expected,
                    'E_OTHER_MODE_HOOK_OR_PATCH')
    return {'build':BUILD,'status':'PROFILE_READ_ONLY','mode':mode,
            'cookie':list(memory.cookie),'site':hex(memory.base+config['site_rva']),
            'live_validated':False,'game_files_modified':False}

def player_snapshot(memory,*,pool=None):
    """Works during battle pause too; does not require phase.current == 4."""
    from pool_binding import resolve
    p=resolve(pool)
    manager=pointer(memory,memory.base+0x6A91E8)
    ai=pointer(memory,memory.base+0x6A91D8)
    players=pointer(memory,memory.base+0x6A91EC)
    require(uint(memory,players+0x590)==1,'E_SINGLE_PLAYER_REQUIRED')
    agent=uint(memory,players+0x110)
    require(agent<150,'E_PLAYER_AGENT')
    squad=uint(memory,manager+0x6B210+agent*0x30+8)
    require(squad<p.group_capacity,'E_PLAYER_SQUAD')
    owner=uint(memory,manager+p.manager_groups+squad*0x268+0x44)
    require(owner<250 and owner==uint(memory,players+0x108),'E_PLAYER_CHAIN')
    record=memory.read(manager+0x4B0+owner*0x110,0x110)
    require(word(record,0x38)==owner and word(record,0x40)==0,'E_PLAYER_RECORD')
    active=memory.read(ai+owner*0xAC,0xAC)
    require(word(active,0x90)&1 and active[0x9E]!=0x80,'E_PLAYER_NOT_ACTIVE')
    return {'manager':manager,'ai':ai,'players':players,'owner':owner,
            'character':word(record,0x44),'player_squad':squad}

def owner_groups(memory,state,owner,*,pool=None):
    from pool_binding import resolve
    p=resolve(pool)
    require(0<=owner<250,'E_OWNER_RANGE')
    record=memory.read(state['manager']+0x4B0+owner*0x110,0x110)
    require(word(record,0x38)==owner,'E_OWNER_RECORD_'+str(owner))
    count=word(record,0x100);capacity=word(record,0xFC)
    require(0<=count<=capacity<=6,'E_GROUP_COUNT_'+str(owner))
    ids=[]
    if count:
        address=word(record,0xF8)
        require(0x10000<=address<0xFFF00000,'E_GROUP_LIST')
        ids=list(struct.unpack('<'+'H'*count,memory.read(address,count*2)))
        require(len(set(ids))==count and all(i<p.group_capacity for i in ids),'E_GROUP_IDS')
    result=[]
    for index in ids:
        group=memory.read(state['manager']+p.manager_groups+index*0x268,0x268)
        require(word(group,0x18)==index and word(group,0x44)==owner,'E_GROUP_OWNER')
        ai=memory.read(state['ai']+p.ai_groups+index*0xA0,0xA0)
        result.append({'squad':index,'owner':word(group,0x44),
                       'quantity_max':word(group,0x24),'quantity_current':word(group,0x28),
                       'template':word(group,0x2C),'unit_type':word(group,0x30),
                       'materialized_bits':word(group,0x14),
                       'ai_owner_link':hex(word(ai,0x78)),
                       'ai_link_matches_owner':word(ai,0x78)==state['ai']+owner*0xAC})
    return result

def audit_player(memory,*,pool=None):
    from pool_binding import resolve
    p=resolve(pool)
    state=player_snapshot(memory,pool=p)
    player=owner_groups(memory,state,state['owner'],pool=p)
    guards={}
    for owner in (244,245,246):
        try: guards[str(owner)]={'groups':owner_groups(memory,state,owner,pool=p)}
        except Exception as error: guards[str(owner)]={'unavailable':str(error)}
    # Re-resolve after the reads to detect a mission/context change during collection.
    require(player_snapshot(memory,pool=p)==state,'E_AUDIT_CONTEXT_CHANGED')
    candidate=[g for g in player if g['unit_type']==PROFILE['troop_type'] and
               g['template']==PROFILE['squad_template']]
    phase=pointer(memory,memory.base+0x6D10BC)
    return {'build':BUILD,'status':'PLAYER_AUDIT_READ_ONLY','cookie':list(memory.cookie),
            'phase_current':uint(memory,phase+0x1C784),'state':state,
            'player_groups':player,'matching_player_groups':candidate,'guard_reservations':guards,
            'player_owner_is_first_descriptor':state['owner']==0,
            'ownership_observed':bool(candidate),'causal_origin_proven':False,
            'follow_behavior_proven':False,'allied_charge_independence_proven':False}
