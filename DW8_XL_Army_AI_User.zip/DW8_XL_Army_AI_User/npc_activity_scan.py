"""Read-only native NPC/selection telemetry. No process access on import.

All offsets describe the current native 600-group / 150-agent layout. This
module never installs hooks, resizes pools, invokes game functions or writes
process memory. Snapshots are bounded observations, not atomic engine frames.
"""
import collections
import math
import struct
from core import require,word,uint

CHARACTER_RVA=0x6CAAA0
SELECTION_RVA=0x6A91E0
GROUP_COUNT=600
AGENT_COUNT=150
SELECTOR_BYTES=0xD1BC  # Includes bounded scratch, excludes worker objects.
SIGNATURES={0x507E5D:'c1e909',0x5082E6:'c1e909',
            0x51EB32:'c786e098000004080880',
            0x4EBD41:'e87a81ffff',0x4EBE4B:'e87080ffff'}


def exact(memory,address,size):
    require(0x10000<=address and address+size<0xFFF00000 and 0<size<=0x100000,'E_NPC_SCAN_READ_RANGE')
    raw=memory.read(address,size)
    require(len(raw)==size,'E_NPC_SCAN_SHORT_READ')
    return raw


def vec(raw,offset=0):
    values=list(struct.unpack_from('<4f',raw,offset))
    return values if all(math.isfinite(v) and abs(v)<100_000_000 for v in values) else None


def distance(a,b):
    return math.hypot(a[0]-b[0],a[2]-b[2]) if a is not None and b is not None else None


def plane_test(planes,position,margin):
    if planes is None or position is None:return None
    return all(p[0]*position[0]+p[2]*position[2]+p[3]>=-margin for p in planes)


def selection_lists(raw):
    result={}
    for name,start,stride,capacity in (('groups',0x83C0,8,600),('agents',0x9684,4,150)):
        rows=[];terminated=False;invalid=0;seen=set();duplicates=0
        # One native sentinel entry is allocated after each bounded list.
        for slot in range(capacity+1):
            value=word(raw,start+slot*stride)
            if value==0xFFFFFFFF:terminated=True;break
            if slot==capacity:invalid+=1;break
            index=value&0xFFF
            if index>=capacity:invalid+=1
            if index in seen:duplicates+=1
            seen.add(index)
            entry={'id':index,'raw':hex(value),'flags':hex(value&0xFFFFF000)}
            if name=='groups':entry['requested_members_mask_raw']=hex(word(raw,start+slot*stride+4))
            rows.append(entry)
        result[name]={'entries':rows,'terminated':terminated,'invalid_ids':invalid,'duplicate_ids':duplicates,
                      'complete_and_well_formed':terminated and not invalid and not duplicates}
    return result


def selector(memory):
    root=uint(memory,memory.base+SELECTION_RVA)
    if root<0x10000:return {'available':False,'reason':'NO_NATIVE_SELECTION_CONTEXT'},root,None
    raw=exact(memory,root,SELECTOR_BYTES)
    ps=[vec(raw,i*16) for i in range(3)]
    if any(p is None or sum(v*v for v in p[:3])<1e-10 for p in ps):ps=None
    controls=raw[0x98E0:0x98EC]
    result={'available':True,'address':hex(root),'native_layout_groups':600,'native_layout_agents':150,
            'threshold_bytes':list(controls[:4]),'control_raw_hex':controls.hex(),
            'control_98e4_raw':word(controls,4),'view_count_raw':word(controls,8),
            'view0_planes':ps,'view0_planes_raw_hex':raw[:0x30].hex(),
            'view1_planes_raw_hex':raw[0x30:0x60].hex(),
            'reference_positions':[vec(raw,0x60),vec(raw,0x70)],
            'lists':selection_lists(raw),'worker_scratch_raw_hex':raw[0x98EC:].hex(),
            'worker_scratch_instant_or_layout_semantics_verified':False,
            'actual_callback_decisions_or_rendered_pixels_recorded':False}
    return result,root,raw


def queues(memory,manager):
    result={}
    for name,offset,expected in (('groups',0x72AB0,600),('agents',0x7213C,150)):
        raw=exact(memory,manager+offset,16)
        pointer,capacity,free,head=struct.unpack('<4I',raw)
        result[name]={'pointer':hex(pointer),'capacity':capacity,'free':free,'head':head,
                      'native_geometry_valid':0x10000<=pointer<0xFFF00000 and capacity==expected and free<=capacity and head<capacity,
                      'raw_hex':raw.hex()}
    return result


def group_identity(raw):
    return tuple(word(raw,off) for off in (0x18,0x1C,0x24,0x2C,0x30,0x44))


def owner_identity(raw):
    return tuple(word(raw,off) for off in (0x38,0x40,0x44,0x50))


def capture(memory,state,player_id,player_position,selected,personal_ids,items,actors):
    manager,ai=state['manager'],state['ai']
    character=uint(memory,memory.base+CHARACTER_RVA)
    selection,selection_root,selection_raw=selector(memory)
    owner_rows=exact(memory,manager+0x4B0,250*0x110)
    owner_ai=exact(memory,ai,250*0xAC)
    native_groups=exact(memory,manager+0x10E50,600*0x268)
    native_group_ai=exact(memory,ai+0xA7F8,600*0xA0)
    player_side=word(owner_rows,0x40)
    player_side=player_side if player_side in (0,1) else None
    records=[];rejections=collections.Counter();tracked=[];used_owners=set();group_bindings={}
    npc_counts=collections.Counter();state_counts=collections.Counter();class_counts=collections.Counter()
    planes=selection.get('view0_planes')
    lists=selection.get('lists',{})
    requests={r['id']:r for r in lists.get('groups',{}).get('entries',[])} if lists.get('groups',{}).get('complete_and_well_formed') else {}
    selected_agents={r['id']:r for r in lists.get('agents',{}).get('entries',[])} if lists.get('agents',{}).get('complete_and_well_formed') else {}
    links=collections.defaultdict(list)
    for index in range(150):
        item=items[index*0x30:(index+1)*0x30]
        if word(item)==index and word(item,8)<600 and word(item,0xC)<30:links[word(item,8)].append(index)
    for gid in range(600):
        group=native_groups[gid*0x268:(gid+1)*0x268]
        owner,capacity,quantity=(word(group,off) for off in (0x44,0x24,0x28))
        if word(group,0x18)!=gid or owner>=250 or not 1<=capacity<=30 or quantity>capacity:
            rejections['UNBOUND_OR_UNSUPPORTED_GROUP']+=1;continue
        o=owner_rows[owner*0x110:(owner+1)*0x110]
        oa=owner_ai[owner*0xAC:(owner+1)*0xAC]
        side=word(o,0x40)
        if word(o,0x38)!=owner or side not in (0,1) or not word(oa,0x90)&1:
            rejections['UNBOUND_OR_INACTIVE_OWNER']+=1;continue
        group_bindings[gid]=group_identity(group);used_owners.add(owner)
        relation='ALLIED' if player_side is not None and side==player_side else 'ENEMY' if player_side is not None else 'UNKNOWN'
        role=('PERSONAL' if owner==0 and gid in personal_ids else 'PLAYER_MAIN' if owner==0 and gid==state['player_squad']
              else 'BODYGUARD' if owner in selected else 'ORDINARY')
        ga=native_group_ai[gid*0xA0:(gid+1)*0xA0]
        sr=selection_raw[0x80+gid*0x30:0x80+(gid+1)*0x30] if selection_raw is not None else None
        flags=struct.unpack_from('<H',sr,0x16)[0] if sr is not None else None
        added=4 if flags is not None and not flags&0x400 and flags&8 else 0
        subtracted=(8 if flags&0x400 else 4) if flags is not None and flags&0x40 else 0
        members=[];logical,materialized=word(group,0x10),word(group,0x14)
        for index in links.get(gid,()):
            item=items[index*0x30:(index+1)*0x30];slot=word(item,0xC)
            if not logical&materialized&(1<<slot):continue
            actor=actors[index*0xE0:(index+1)*0xE0]
            if word(actor,0x7C)!=index or word(actor,0x80)!=ai+0xA7F8+gid*0xA0 or not word(actor,0xCC)&1:
                rejections['ACTOR_IDENTITY_OR_LINK']+=1;continue
            ar=selection_raw[0x7100+index*0x20:0x7100+(index+1)*0x20] if selection_raw is not None else None
            pos=vec(actor,0x34)
            members.append({'agent':index,'slot':slot,'is_group_leader':word(group,0x34)==index,
                'item_identity_hex':item[:16].hex(),'position':pos,'distance_player_xz':distance(pos,player_position),
                'state_88':word(actor,0x88),'class_84':word(actor,0x84),'reference_a0_raw':word(actor,0xA0),
                'timer_bc':word(actor,0xBC),'flags_cc':hex(word(actor,0xCC)),
                'movement_command_68_raw':word(actor,0x68),'movement_command_6c_raw':word(actor,0x6C),
                'target_90_raw':hex(word(actor,0x90)),'zone_d0':actor[0xD0],'subtype_d2':actor[0xD2],
                'selection_cached_position':vec(ar) if ar is not None else None,
                'selection_record_raw_hex':ar.hex() if ar is not None else None,
                'selection_list_entry':selected_agents.get(index),
                'selector_xz_test_reconstructed':plane_test(planes,vec(ar),50) if ar is not None else None,
                'actual_render_visibility':None})
            tracked.append((index,word(actor,0x80)))
            if index!=player_id:
                npc_counts[relation]+=1;state_counts[(relation,word(actor,0x88))]+=1
                class_counts[(relation,word(actor,0x84))]+=1
        officer=(capacity==1 and word(group,0x2C) in (0,1) and word(group,0x1C)==0
                 and word(group,0x30)==word(o,0x50) and word(o,0x44)<=0x386)
        records.append({'squad':gid,'owner':owner,'side_raw':side,'relation_to_player':relation,'owner_kind':role,
            'character_raw':word(o,0x44),'is_officer_group_candidate':officer,
            'ordinal':word(group,0x1C),'quantity':quantity,'capacity':capacity,
            'template_raw':word(group,0x2C),'unit_type_raw':word(group,0x30),
            'position':vec(group),'distance_player_xz':distance(vec(group),player_position),
            'logical_bits':hex(logical),'materialized_bits':hex(materialized),'group_flags_50':hex(word(group,0x50)),
            'zone':word(group,0x48),'leader_agent_raw':word(group,0x34),'members':members,
            'ai_position':vec(ga),'ai_waypoint_20':vec(ga,0x20),'ai_destination_40':vec(ga,0x40),
            'ai_flags_88':hex(word(ga,0x88)),'ai_state_80':word(ga,0x80),
            'ai_owner_link_matches':word(ga,0x78)==ai+owner*0xAC,
            'owner_order_84':word(oa,0x84),'owner_state_88':word(oa,0x88),
            'selection_record_raw_hex':sr.hex() if sr is not None else None,
            'selection_cached_position':vec(sr) if sr is not None else None,
            'selection_flags_16':hex(flags) if flags is not None else None,
            'distance_priority_added_bins':added if flags is not None else None,
            'distance_priority_subtracted_bins':subtracted if flags is not None else None,
            'group_selection_list_entry':requests.get(gid),
            'selector_xz_test_reconstructed':plane_test(planes,vec(sr),800) if sr is not None else None,
            'actual_render_visibility':None})
    result={'available':True,'read_only':True,'scope':'ALL_BOUND_NATIVE_GROUPS_AND_MATERIALIZED_AGENTS',
            'requested_graphics_profile':'MANY','character_raw':character,'native_highest_profile_raw':0,
            'native_highest_profile_observed':character==0,'character_label_mapping_live_verified':False,
            'graphics_profile_status':'MANY_NATIVE_HIGH_PROFILE' if character==0 else 'CHECK_GAME_CHARACTER_MANY_SETTING',
            'graphics_setting_modified':False,'player_side_raw':player_side,
            'queues':queues(memory,manager),'selector':selection,'groups':records,
            'summary':{'bound_groups':len(records),'materialized_npcs_by_relation':dict(npc_counts),
                'npc_state_observations':[{'relation':k[0],'state':k[1],'count':v} for k,v in state_counts.items()],
                'npc_class_observations':[{'relation':k[0],'class':k[1],'count':v} for k,v in class_counts.items()],
                'groups_by_kind':dict(collections.Counter(g['owner_kind'] for g in records)),
                'excluded_records':dict(rejections)},
            'group_pool_expansion_applied':False,'render_limit_removed':False,
            'physical_model_transform_read':False,'lifetime_identity_or_atomicity_guaranteed':False}
    guard={'manager':manager,'ai':ai,'character':character,'groups':group_bindings,
           'owners':{owner:owner_identity(owner_rows[owner*0x110:(owner+1)*0x110]) for owner in used_owners},
           'tracked':tracked,'actors':actors,'items':items,'selector_root':selection_root,'selector_raw':selection_raw}
    return result,guard


def verify(memory,guard,items_after,actors_after,result):
    require(uint(memory,memory.base+CHARACTER_RVA)==guard['character'],'E_NPC_SCAN_GRAPHICS_SETTING_CHANGED')
    require(uint(memory,memory.base+SELECTION_RVA)==guard['selector_root'],'E_NPC_SCAN_SELECTOR_REBOUND')
    owners=exact(memory,guard['manager']+0x4B0,250*0x110)
    groups=exact(memory,guard['manager']+0x10E50,600*0x268)
    for gid,binding in guard['groups'].items():
        require(group_identity(groups[gid*0x268:(gid+1)*0x268])==binding,'E_NPC_SCAN_GROUP_REBOUND')
    for owner,binding in guard['owners'].items():
        require(owner_identity(owners[owner*0x110:(owner+1)*0x110])==binding,'E_NPC_SCAN_OWNER_REBOUND')
    for index,link in guard['tracked']:
        actor=actors_after[index*0xE0:(index+1)*0xE0]
        require(word(actor,0x7C)==index and word(actor,0x80)==link and word(actor,0xCC)&1
                and items_after[index*0x30:index*0x30+16]==guard['items'][index*0x30:index*0x30+16],
                'E_NPC_SCAN_ACTOR_REBOUND')
    if guard['selector_raw'] is not None:
        after=exact(memory,guard['selector_root'],SELECTOR_BYTES);before=guard['selector_raw']
        result['selector'].update(
            planes_changed_during_sample=before[:0x60]!=after[:0x60],
            lists_or_controls_changed_during_sample=before[0x83C0:0x98EC]!=after[0x83C0:0x98EC],
            worker_scratch_changed_during_sample=before[0x98EC:]!=after[0x98EC:],
            exact_callback_time_synchronized=False)
