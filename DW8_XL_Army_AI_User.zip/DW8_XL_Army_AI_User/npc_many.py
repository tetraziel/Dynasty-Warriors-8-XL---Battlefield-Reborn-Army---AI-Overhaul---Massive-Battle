"""Optional Many-only virtual distance thresholds. No game calls or NPC writes.

Four byte comparisons read a selected virtual threshold instead of native 8.
The stored selector controls, near tier, camera planes, budgets, native orders,
actor states, timers, coordinates and all pool sizes remain untouched.
"""
import struct
from core import require,word,uint
from recall_bridge import Asm,R
from bridge import relative_jump
import bundle_support as bundle

FEATURE='MANY_EXTENDED_NPC_ACTIVITY_TEST'
MAGIC=0x594E414D;VERSION=5;LEGACY_VERSION=1;LEGACY_VERSIONS=(1,2,3,4);SIZE=0x1000;CODE_SIZE=0x10000
SITES={'AGENT_MIDDLE':(0x4EBD67,'3a83e1980000'),
       'AGENT_OUTER':(0x4EBD76,'3a83e2980000'),
       'GROUP_MIDDLE':(0x4EBE75,'3a81e1980000'),
       'GROUP_OUTER':(0x4EBE84,'3a81e2980000')}
SIGNATURES={0x4EBD51:'8b4c24188a040e',0x4EBD8A:'3c06',
            0x4EBE5B:'8b5424148a0416',0x4EBE98:'8b14f7',
            0x507E5D:'c1e909',0x5082E6:'c1e909'}
COUNTERS={'visits':0x10,'extended_comparisons':0x14,'scope_skips':0x18,
          'agent_comparisons':0x1C,'group_comparisons':0x20,
          'other_graphics_profile':0x24,'other_selector_profile':0x28,
          'context_skips':0x2C}
TARGET_THRESHOLD=60
LEGACY_THRESHOLD=12
THRESHOLDS_BY_VERSION={1:12,2:23,3:60,4:TARGET_THRESHOLD,5:TARGET_THRESHOLD}
DISTANCE_CHOICES={30000:60,50000:99,100000:197}
DISTANCE_CHOICES_BY_VERSION={4:{30000:60,50000:99},5:DISTANCE_CHOICES}
THRESHOLD_OFFSET=0x30


def validate_distance(distance):
    require(type(distance) is int and distance in DISTANCE_CHOICES,'E_NPC_MANY_DISTANCE')
    return distance


def initialize_data(raw):
    struct.pack_into('<I',raw,THRESHOLD_OFFSET,TARGET_THRESHOLD)


def build_bridge(base,data,code,auto,recall,name,*,legacy=False,legacy_version=1):
    require(name in SITES,'E_NPC_MANY_SITE');x=Asm()
    version=legacy_version if legacy else VERSION
    require(version in THRESHOLDS_BY_VERSION,'E_NPC_MANY_VERSION')
    target=THRESHOLDS_BY_VERSION[version]
    x.emit('9c60')
    for off,value in ((0,MAGIC),(4,version),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1)
    x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','native')
    inc=lambda key:x.mem('ff',0,disp=data+COUNTERS[key])
    inc('visits')
    x.op(7,0,disp=base+0x6CAAA0);x.jump('ne','profile_skip')
    # PUSHAD's EBX and ECX slots preserve the actual caller selector pointer.
    agent=name.startswith('AGENT')
    x.load('esi','esp',16 if agent else 24)
    x.load('eax',disp=base+0x6A91E0);x.sane('eax','context_skip')
    x.rr('39','esi','eax');x.jump('ne','context_skip')
    # Do not narrow the native wider 4/16/16 profile or reinterpret unknown
    # control combinations. Only the observed normal 4/8/8 profile is widened.
    x.op(7,0x80080804,'esi',0x98E0);x.jump('ne','selector_skip')
    x.load('eax',disp=base+0x6A91EC);x.sane('eax','context_skip')
    for off,value in ((0x590,1),(0x108,0)):
        x.op(7,value,'eax',off);x.jump('ne','context_skip')
    x.load('eax',disp=base+0x6D10BC);x.sane('eax','context_skip')
    x.load('eax','eax',0x1C784);x.cmp('eax',4);x.jump('eq','phase_ok')
    x.cmp('eax',5);x.jump('ne','context_skip');x.mark('phase_ok')
    if version>=4:
        x.load('eax',disp=data+THRESHOLD_OFFSET)
        for threshold in DISTANCE_CHOICES_BY_VERSION[version].values():
            x.cmp('eax',threshold);x.jump('eq','setting_ok')
        x.jump('jmp','context_skip');x.mark('setting_ok')
    inc('extended_comparisons');inc('agent_comparisons' if agent else 'group_comparisons')
    x.set(0,disp=data+12);x.emit('619d')
    # Keep the native eight-bit comparison flags and every GP/x87/SSE value.
    # Host changes quiesce this entire payload, including the unlocked tail.
    if version>=4:x.mem('3a',R['eax'],disp=data+THRESHOLD_OFFSET)
    else:x.emit('3c');x.emit(bytes([target]))
    x.emit(relative_jump(code+len(x.code),base+SITES[name][0]+6))
    x.mark('profile_skip');inc('other_graphics_profile');x.jump('jmp','skip')
    x.mark('selector_skip');inc('other_selector_profile');x.jump('jmp','skip')
    x.mark('context_skip');inc('context_skips')
    x.mark('skip');inc('scope_skips');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d');x.emit(bytes.fromhex(SITES[name][1]))
    x.emit(relative_jump(code+len(x.code),base+SITES[name][0]+6))
    return x.finish()


def check_code(memory):
    for rva,signature in SIGNATURES.items():
        require(memory.read(memory.base+rva,len(bytes.fromhex(signature)))==bytes.fromhex(signature),
                'E_NPC_MANY_NATIVE_'+hex(rva))


def configure(session,enabled,distance):
    require(type(enabled) is bool,'E_NPC_MANY_ENABLED');distance=validate_distance(distance)
    record=(session.lease or {}).get('npc_many')
    if not record and not enabled:return public(session,None)
    if not record:
        bundle.set_bundle(session,'npc_many',__import__(__name__),False,prepare_disabled=True)
        record=session.lease['npc_many']
    require(record['version']==VERSION,'E_EXTRA_LEGACY_RESTART_REQUIRED')
    spans=[s for p in bundle.all_patches(session) for s in
        ((p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),
         (p['code_address'],p['code_address']+p['code_size']))]
    with session.quiesce(spans):
        bundle.validate(__import__(__name__),session,record)
        require(uint(session,record['data_address']+12)==0,'E_EXTRA_BRIDGE_EXECUTING_RETRY')
        require(uint(session,record['recall_data_address']+16)==0,'E_RECALL_BRIDGE_EXECUTING_RETRY')
        address=record['data_address']+THRESHOLD_OFFSET;before=session.read(address,4)
        wanted=struct.pack('<I',DISTANCE_CHOICES[distance])
        if before!=wanted:
            try:
                session.write(address,wanted)
                require(session.read(address,4)==wanted,'E_NPC_MANY_SETTING_VERIFY')
            except Exception:
                session.write(address,before)
                require(session.read(address,4)==before,'E_NPC_MANY_SETTING_ROLLBACK')
                raise
            session.log('NPC_MANY_DISTANCE_SELECTED',requested_distance_units=distance)
    return bundle.set_bundle(session,'npc_many',__import__(__name__),enabled)


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    version=record['version'] if record else VERSION
    require(version in THRESHOLDS_BY_VERSION,'E_NPC_MANY_VERSION')
    target=THRESHOLDS_BY_VERSION[version]
    choices=DISTANCE_CHOICES_BY_VERSION.get(version,DISTANCE_CHOICES)
    if record and version>=4:target=uint(memory,record['data_address']+THRESHOLD_OFFSET)
    valid=target in choices.values() if version>=4 else True
    selected=next((d for d,t in choices.items() if t==target),None)
    result.update(scope='MANY_SINGLE_PLAYER_NORMAL_SELECTOR_PROFILE',
        native_thresholds=[4,8,8],virtual_thresholds=[4,target,target] if valid else [4,8,8],
        distance_choices=list(choices),selected_distance_units=selected,
        selected_threshold_raw=target,configuration_valid=valid,
        configuration_error=None if valid else 'INVALID_DISTANCE_NATIVE_FALLBACK',
        effective_override_active=bool(valid and result['enabled']),
        approximate_native_full_update_boundary=3585,
        approximate_extended_full_update_boundary=target*512-511 if valid else None,
        real_world_meters_verified=False,selector_controls_modified=False,
        near_tier_preserved=True,native_wider_profiles_preserved=True,
        camera_planes_modified=False,draw_distance_modified=False,
        pools_expanded=False,native_agent_budget_preserved=True,
        native_orders_and_combat_states_preserved=True,
        game_functions_called=False,remote_threads_created=False,
        live_movement_or_render_effect_verified=False)
    return result
