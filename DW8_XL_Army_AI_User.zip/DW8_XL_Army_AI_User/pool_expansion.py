"""Separate pool expansion research and read-only checks; no installer."""
import json
from pathlib import Path
import struct
from core import require,word

NATIVE=600;AGENTS=150;MEMBERS=30;CAPACITIES=(600,900,1200)
SOURCE_SHA256='dba757e9c79aed3416bff7d7b6f12d581e5ef0982412a318daee27e58beced8a'
BLOCKERS=(
    'NATIVE_GROUP_BOUNDS_AND_INDIRECT_USERS_NOT_FULLY_CLASSIFIED',
    'STACK_LOADED_MANAGER_ROOT_GUARDS_REQUIRE_ENTRY_FRAME_PROOF',
    'REQUEST_SCRATCH_INDIRECT_REFERENCE_COVERAGE_INCOMPLETE',
    'SECONDARY_AI_SNAPSHOT_GROUP_STORAGE_AND_CONSUMERS_NOT_EXPANDED',
    'SECONDARY_MANAGER_SNAPSHOT_AND_NATIVE_PREFIX_RESTORE_BRIDGE_NOT_INTEGRATED',
    'SECONDARY_SNAPSHOT_SERIALIZED_FORMAT_AND_TRANSFER_BUFFERS_NOT_VALIDATED',
    'SERIALIZER_RESULT_AND_WRITER_BACKEND_GUARD_NOT_INTEGRATED',
    'MAP_MARKER_STORAGE_AND_LIFECYCLE_CANDIDATES_NOT_INTEGRATED',
    'NATIVE_CONSTRUCTION_AND_DESTRUCTION_COVERAGE_INCOMPLETE',
    'LIVE_SESSION_BINDINGS_AND_PRIVATE_CACHE_SIZES_NOT_INTEGRATED',
    'SAFE_INSTALLATION_STAGE_NOT_LIVE_VALIDATED')


def capacity(value):
    require(type(value) is int and value in CAPACITIES,'E_GROUP_POOL_CAPACITY')
    return value


def scratch_layout(count):
    """Address plan of the observed sequential group/agent sorting paths.

    Two byte classifications, two uint16 sorted-ID lists, four 129-entry
    uint16 histogram banks plus four padding bytes, and N packed 8-byte
    output records. Agent sorting reuses this storage after a native clear.
    This does not establish coverage of every indirect engine reference.
    """
    capacity(count);histogram=count*6;packed=histogram+4*129*2+4
    required=packed+count*8
    return {'classification_a':0,'classification_b':count,
        'sorted_ids_a':count*2,'sorted_ids_b':count*4,
        'histograms':histogram,'histogram_bytes':1036,
        'packed_output':packed,'packed_output_bytes':count*8,
        'required_bytes':required,'allocated_bytes':max(0x38D0,(required+15)&~15),
        'agent_pass_required_bytes':150*14+1036,
        'observed_paths_only':True,'all_indirect_users_verified':False}


def shift(kind,offset,count):
    """Map original object fields using the observed scratch address plan."""
    capacity(count);require(type(offset) is int and offset>=0,'E_GROUP_POOL_OFFSET')
    extra=count-NATIVE
    if kind=='manager':
        return offset+extra*(0x268*int(offset>=0x6B210)+4*int(offset>=0x72AB0))
    if kind=='ai':return offset+extra*0xA0*int(offset>=0x21EF8)
    if kind=='requests':
        return (offset+extra*(0x30*int(offset>=0x7100)+8*int(offset>=0x9684))+
                (scratch_layout(count)['allocated_bytes']-0x38D0)*int(offset>=0xD1BC))
    if kind=='queue':return shift('manager',0x71EE4+offset,count)-shift('manager',0x71EE4,count)
    require(False,'E_GROUP_POOL_OBJECT')


def layout(count):
    capacity(count);extra=count-NATIVE
    def region(name,start,size,stride=None,count=None,verified=True):
        return dict(name=name,start=start,size=size,end=start+size,stride=stride,
                    count=count,layout_verified=verified)
    m=lambda off:shift('manager',off,count)
    a=lambda off:shift('ai',off,count)
    r=lambda off:shift('requests',off,count)
    manager=[region('owners_and_header',0,0x10E50),
        region('groups',0x10E50,count*0x268,0x268,count),
        region('agents',m(0x6B210),AGENTS*0x30,0x30,AGENTS),
        region('agent_auxiliary',m(0x6CE30),0x71EE4-0x6CE30),
        region('agent_free_ids',m(0x71EE4),AGENTS*4,4,AGENTS),
        region('agent_queue_metadata',m(0x7213C),20),
        region('group_free_ids',m(0x72150),count*4,4,count),
        region('group_queue_metadata',m(0x72AB0),20),
        region('other_manager_objects',m(0x72AC4),0xE6360-0x72AC4)]
    ai=[region('owners',0,0xA7F8),region('groups',0xA7F8,count*0xA0,0xA0,count),
        region('agents',a(0x21EF8),AGENTS*0xE0,0xE0,AGENTS),
        region('other_ai_objects',a(0x2A238),0x53EC0-0x2A238)]
    scratch=scratch_layout(count);scratch_size=scratch['allocated_bytes']
    requests=[region('header',0,0x80),region('groups',0x80,count*0x30,0x30,count),
        region('agents',r(0x7100),AGENTS*0x20,0x20,AGENTS),
        region('group_selection',r(0x83C0),count*8+4),
        region('agent_selection',r(0x9684),AGENTS*4+4),
        region('control',r(0x98E0),12),
        region('scratch_candidate',r(0x98EC),scratch_size,verified=count==NATIVE),
        region('worker',r(0xD1BC),0x34)]
    sizes={'manager':0xE6360+extra*620,'ai':0x53EC0+extra*160,
           'requests':r(0xD1F0)}
    for kind,regions in (('manager',manager),('ai',ai),('requests',requests)):
        require(all(left['end']==right['start'] for left,right in zip(regions,regions[1:])),
                'E_GROUP_POOL_REGIONS_'+kind)
        require(regions[-1]['end']==sizes[kind],'E_GROUP_POOL_SIZE_'+kind)
    return {'capacity':count,'agent_capacity':AGENTS,'maximum_members':MEMBERS,
        'sizes':sizes,'regions':{'manager':manager,'ai':ai,'requests':requests},
        'added_inline_bytes':sum(sizes.values())-(0xE6360+0x53EC0+0xD1F0),
        'heap_and_graphics_cost_included':False,
        'scratch_size_candidate':scratch_size,'scratch_growth_verified':count==NATIVE,
        'scratch_address_plan':scratch,
        'group_bitmap_words_required':(count+31)//32,'native_group_bitmap_words':19,
        'native_group_bitmap_first_unsafe_id':608,'native_stack_return_alias_id':640,
        'supported_player_count':1,'coop_supported':False,
        'coop_bitmap_expansion_required_for_single_player':False,
        'global_layout_coverage_complete':False}


def preview(count):
    plan=layout(count)
    from pool_append import layout as append_layout
    from pool_binding import for_capacity
    from pool_snapshot import layout as snapshot_layout
    from pool_map import layout as map_layout
    binding=for_capacity(count)
    manifest_path=Path(__file__).with_name('pool_candidates.json')
    candidates=None
    if manifest_path.exists():
        manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
        require(manifest.get('source_sha256')==SOURCE_SHA256,'E_GROUP_POOL_SOURCE')
        chosen=manifest.get('profiles',{}).get(str(count),{})
        candidates={'units':len(chosen.get('units',[])),
            'operand_changes_including_overlaps':sum(len(u['changes']) for u in chosen.get('units',[])),
            'deduplicated_changed_bytes':chosen.get('deduplicated_changed_bytes'),
            'native_activation_supported':False,'offline_candidate_only':True}
    return {'feature':'GROUP_POOL_EXPERIMENTAL','requested_capacity':count,
        'native_capacity':NATIVE,'expansion_applied':False,'read_only':True,
        'status':'NATIVE_POOL_NO_CHANGE' if count==NATIVE else 'REFUSED_INCOMPLETE_POOL_EXPANSION',
        'activation_available':count==NATIVE,'blockers':[] if count==NATIVE else list(BLOCKERS),
        'single_player_only':True,'second_player_must_be_refused':True,
        'requires_coherent_native_construction':True,
        'existing_live_objects_resized':False,
        'rendering':{'agent_pool_capacity':150,'agent_pool_expanded':False,
            'group_pool_is_not_a_visible_actor_limit':True,'unlimited_renderer_implemented':False},
        'layout_candidate':plan,'compiled_candidates':candidates,
        'appended_layout_candidate':append_layout(count),
        'accessor_research':{'recognized_shapes':271,'static_root_evidence':226,
            'static_roots_unresolved':45,'companion_fields_relocated_and_interpreted':7,
            'register_root_runtime_guard_candidates':30,'runtime_guard_sites':60,
            'stack_root_cases_not_guarded':15,'offline_only':True,
            'native_manager_equality_and_nonnull_checks':True,
            'live_installer_available':False,'allocator_lifetime_safety_verified':False,
            'whole_engine_reference_coverage_verified':False},
        'ai_reference_research':{'saved_reference_set':58,'array_geometry_verified':57,
            'indexed_field_references':55,'array_cursor_references':2,
            'native_cursor_loops_adapted_offline':2,'unresolved_reference_rvas':['0x526bf1'],
            'pending_mixed_manager_ai_loop':True,'pending_auxiliary_destination_capacity_verified':False,
            'mixed_loop_candidate_available_separately':True,
            'mixed_loop_unified_offline_candidate':True,
            'mixed_loop_primary_manifest_integrated':False,
            'id_bounds_and_all_callers_verified':False,'reference_set_exhaustive':False,
            'compiled_candidate_units':299,'offline_only':True,'live_installer_available':False},
        'map_buffer_research':{'native_ordinary_capacity':600,
            'native_next_array_is_separate_storage':True,
            'candidate_layout':map_layout(count),'isolated_candidate_units':14,
            'native_mixed_loop_rva':'0x5267f0',
            'constructor_destructor_allocation_and_draw_adapted_offline':True,
            'high_group_coordinates_and_pe_relocations_interpreted':True,
            'sprite_resource_preparation_adapted_offline':True,
            'sprite_resource_native_entry_interpreted':True,
            'native_two_map_root_teardown_interpreted':True,
            'primary_pool_manifest_integrated':False,
            'all_native_references_and_callers_verified':False,
            'live_installer_available':False,'offline_only':True},
        'unified_primary_map_research':{'compiled_units':315,
            'unchanged_native_helper_dependencies':2,
            'known_component_overlaps_consistent':True,
            'construction_queue_binding_and_map_sequence_interpreted':True,
            'relocated_sequence_interpreted':True,
            'secondary_snapshot_integrated':False,'guarded_unknown_roots_integrated':False,
            'existing_live_objects_migrated':False,'complete_engine_coverage':False,
            'live_installation_supported':False,'offline_only':True},
        'stack_root_conditional_research':{'supported_accessors':15,'separate_guard_sites':33,
            'native_stack_slot_shapes_verified':True,
            'current_thread_tib_range_checked':True,
            'root_matches_current_manager_required':True,
            'ordinary_contiguous_readable_stack_assumed':True,
            'independent_page_protections_verified':False,
            'static_caller_root_proof_completed':False,
            'register_only_plan_modified':False,
            'live_installation_supported':False,'offline_only':True},
        'guarded_unified_research':{'source_candidate_units':341,'native_context_fragments':46,
            'conditional_accessor_candidates':45,'conditional_sites_available':93,
            'conditional_sites_in_candidate':0 if count==NATIVE else 93,
            'guards_rebuilt_for_selected_image_base':True,
            'simulation_ranges_are_not_live_write_commands':True,
            'declared_tool_code_sites_cataloged':43,
            'tool_sites_inside_simulation_ranges':1,'tool_hook_bytes_changed_by_candidate':0,
            'all_existing_payload_bindings_integrated':False,
            'static_root_and_worker_lifecycle_proofs_completed':False,
            'readable_stack_page_assumption_preserved':True,
            'live_installation_supported':False,'offline_only':True},
        'unified_snapshot_research':{'compiled_units':341,
            'secondary_snapshot_integrated_offline':True,
            'native_legacy_byte_promotion_prototype_available':True,
            'prototype_known_group_fields_only':True,
            'private_full_image_storage_prototype_available_offline':True,
            'native_game_save_format_adapter_available':False,
            'native_prefix_save_adapter_implemented':False,
            'complete_live_migration_implemented':False,
            'whole_engine_reference_coverage_verified':False,
            'live_installation_supported':False,'offline_only':True},
        'native_snapshot_transfer_research':{'native_parent_chunk_bytes':614400,
            'forward_reverse_read_write_loop_samples_interpreted':True,
            'sampled_loop_positions':['FIRST','MIDDLE','LAST'],
            'full_native_transfer_loop_executed':False,
            'bounded_immutable_stream_staging_available_offline':True,
            'complete_private_image_coupled_by_capture_digest':True,
            'native_prefix_alone_identifies_capture':False,
            'native_vanilla_prefix_projection_implemented':False,
            'native_save_callers_and_atomic_commit_integrated':False,
            'live_save_restore_adapter_available':False,'offline_only':True},
        'native_stream_dispatch_research':{'prefix_components':16,
            'snapshot_is_conditional_last_component':True,
            'native_dispatcher_order_and_failure_paths_interpreted':True,
            'native_component_lengths_verified':False,
            'failed_dispatcher_rolls_back_prior_components':False,
            'outer_writer_consumes_serializer_result':False,
            'outer_writer_backend_after_false_result_reproduced_offline':True,
            'failure_guard_x86_candidate_available_offline':True,
            'failure_guard_native_cleanup_and_success_return_interpreted':True,
            'failure_guard_integrated_in_live_writer':False,
            'expanded_snapshot_stream_adapter_available':False,
            'live_installation_supported':False,'offline_only':True},
        'private_expanded_stream_research':{'candidate_capacities':[900,1200],
            'parent_bytes':{'900':823200,'1200':892800},
            'registered_stream_entry_and_parent_guards_interpreted':True,
            'dispatcher_completion_cursor_guard_interpreted':True,
            'native_protocol_word_serializer_interpreted':True,
            'isolated_copy_size_operand_changes':5,
            'expanded_copy_sampled_in_four_modes':True,
            'full_copy_loop_interpreted':False,
            'full_private_stream_roundtrip_modeled':True,
            'high_group_native_record_restore_interpreted':True,
            'opaque_component_prefix_lengths_proven':False,
            'fixed_component_full_native_loops_interpreted':7,
            'additional_composite_component_contracts':7,
            'content_independent_component_count':14,
            'composite_contract_modes':[0,1,2,3],
            'composite_contract_payload_bytes_unknown':True,
            'composite_contract_native_callees_replaced_with_stubs':False,
            'remaining_component_lengths_unproven':2,
            'remaining_unproven_component_indices':[0,15],
            'known_successful_prefix_minimum_bytes':130637,
            'ordinary_zero_header_conditional_components':[0,15],
            'ordinary_zero_header_component_count':16,
            'ordinary_zero_header_successful_prefix_bytes':133269,
            'ordinary_security_cookie_success_path_interpreted':True,
            'ordinary_registered_offline_candidate_bound_to_length_contract':True,
            'ordinary_all_object_allocations_and_lifetimes_proven':False,
            'all_sixteen_native_component_bodies_interpreted_in_fixture':True,
            'full_native_fixture_prefix_bytes':133269,
            'full_native_fixture_protocol_bytes':4,
            'nonzero_component_fixture_roundtrip_verified':True,
            'complete_all_state_prefix_contract_proven':False,
            'ordinary_native_writer_buffers_verified':False,
            'opaque_component_buffer_safety_proven':False,
            'partial_component_rollback_implemented':False,
            'native_game_save_format_compatible':False,
            'worker_coordination_verified':False,
            'live_installer_available':False,'offline_only':True},
        'native_io_buffer_research':{'native_ordinary_buffer_bytes':753477,
            'expanded_ordinary_buffer_bytes':{'900':962277,'1200':1031877},
            'expanded_file_staging_bytes':{'900':962281,'1200':1031881},
            'native_brief_buffer_bytes':665767,'brief_size_constants_changed':False,
            'cold_allocation_operand_candidates':5,'read_guards':4,'write_guards':2,
            'native_construction_release_and_size_consumers_interpreted':True,
            'native_integrity_bodies_interpreted_on_small_buffers':True,
            'full_size_integrity_loops_interpreted':False,
            'full_size_integrity_byte_models_verified':True,
            'ordinary_native_reader_writer_roundtrip_interpreted_with_api_stubs':True,
            'partial_io_and_checksum_failures_refused_in_candidate':True,
            'padded_registered_stream_supported_offline':True,
            'existing_native_objects_resized':False,
            'all_indirect_buffer_users_verified':False,
            'native_save_compatible_with_unmodified_loader':False,
            'allocator_worker_lifetime_coordination_verified':False,
            'live_installer_available':False,'offline_only':True},
        'secondary_ai_snapshot':{'native_group_capacity':600,'record_stride':132,
            'array_end_is_next_native_field':True,'expanded':False,
            'allocation_and_other_consumers_verified':False,
            'copy_restore_native_paths_identified':True,
            'parent_global_rva':'0x6a93b0','restore_entry_rva':'0x4f8a50',
            'candidate_layout':snapshot_layout(count),
            'serialized_format_and_transfer_buffers_verified':False},
        'secondary_manager_snapshot':{'native_group_capacity':600,'record_stride':100,
            'native_subobject_offset':'0x1edc0','native_array_offset':'0xe3d4',
            'native_following_agent_array_offset':'0x1ce34',
            'manager_and_ai_arrays_reserved_separately_offline':True,
            'copy_restore_native_paths_identified':True,'isolated_candidate_units':26,
            'free_queue_rebuild_candidate_includes_high_group_ids':True,
            'owner_roster_empty_sentinel_adapted_offline':True,
            'physical_agent_group_capture_reset_restore_prefix_adapted_offline':True,
            'physical_agent_complete_actor_restore_verified':False,
            'unused_slot_defaults_checked_against_native_constructors':True,
            'native_physical_agent_capacity':150,'native_members_per_group':30,
            'native_serializer_bytes_unchanged':True,
            'native_prefix_bridge_implemented':False,'existing_parent_migration_implemented':False,
            'live_installation_supported':False},
        'tool_binding_candidate':{'binding':binding.record(),
            'zone_cache_required_bytes':binding.zone_cache_size,
            'emitters_accept_explicit_binding':True,
            'personal_q_and_map_emitters_accept_explicit_binding':True,
            'personal_q_and_map_native_historical_payload_vectors':9,
            'personal_q_defense_cycle_and_map_high_ids_interpreted':True,
            'personal_q_follow_immutable_hold_view_bound_offline':True,
            'current_live_session_uses_native_binding':True,
            'live_session_binding_selection_implemented':False,
            'installation_authorized':False},
        'live_validated':False,'remote_threads_created':False,'game_files_modified':False}


def native_snapshot(memory):
    """Read native queue headers only, with before/after consistency checks."""
    try:
        pointer=memory.base+0x6A91E8
        for _ in range(3):
            manager=word(memory.read(pointer,4))
            require(0x10000<=manager<0xFFF00000,'E_GROUP_POOL_MANAGER_NOT_READY')
            players=word(memory.read(memory.base+0x6A91EC,4))
            require(0x10000<=players<0xFFF00000,'E_GROUP_POOL_PLAYERS_NOT_READY')
            player_count=word(memory.read(players+0x590,4))
            require(player_count==1,'E_GROUP_POOL_SINGLE_PLAYER_REQUIRED')
            headers=[memory.read(manager+off,16) for off in (0x72AB0,0x7213C)]
            require(all(len(raw)==16 for raw in headers),'E_GROUP_POOL_PARTIAL_READ')
            groups,agents=[struct.unpack('<4I',raw) for raw in headers]
            require(groups[1]==NATIVE and agents[1]==AGENTS,'E_GROUP_POOL_UNKNOWN_NATIVE_LAYOUT')
            require(all(0x10000<=p<0xFFF00000 and 0<=free<=cap and head<cap
                        for p,cap,free,head in (groups,agents)),'E_GROUP_POOL_QUEUE_FIELDS')
            if (word(memory.read(pointer,4))!=manager or
                word(memory.read(memory.base+0x6A91EC,4))!=players or
                word(memory.read(players+0x590,4))!=player_count or
                any(memory.read(manager+off,16)!=raw for off,raw in zip((0x72AB0,0x7213C),headers))):continue
            def item(row,groups=False):
                p,cap,free,head=row
                return {'capacity':cap,'free':free,'allocated':cap-free,'head':head,
                        'reserved_zero_quantity_groups_included':groups}
            return {'available':True,'read_only':True,'manager':hex(manager),
                    'player_count':player_count,'single_player_verified_in_sample':True,
                    'groups':item(groups,True),'agents':item(agents),
                    'whole_process_atomicity_guaranteed':False,'physical_actor_count':None}
        return {'available':False,'read_only':True,'stale':True,'error':'E_GROUP_POOL_SNAPSHOT_CHANGED'}
    except Exception as error:
        return {'available':False,'read_only':True,'stale':True,'error':str(error)}


def inspect(memory,count):
    result=preview(count);result['native_snapshot']=native_snapshot(memory)
    return result
