"""Optional bounded infantry density; native construction builds all masks.

No process access on import, no extra group allocation, no pool-limit edits.
The original template has thirty member slots, verified at 4EA0BF/4EA0D2.
"""
from pool_binding import resolve as resolve_pool
import json
from pathlib import Path
import struct
from core import require,word,uint
from recall_bridge import Asm,R
from bridge import relative_jump
import bundle_support as bundle

FEATURE='BOUNDED_INFANTRY_DENSITY_BOTH_FACTIONS'
MAGIC=0x38504F50;VERSION=3;LEGACY_VERSION=1;LEGACY_VERSIONS=(1,2)
LEGACY_SIZES={1:0x1000,2:0x1000};SIZE=0x7000;CODE_SIZE=0x4000
SITES={'NATIVE_INITIAL_QUANTITY':(0x58EFE1,'8b0083c404')}
PERCENT=0x80
ELIGIBLE=0x100;ORIGINAL=0x200;COMPLETED=0x3700;TABLE_RVA=0x6CAC88;STRIDE=0x180
SCHEMA=json.loads(Path(__file__).with_name('population_templates.json').read_text(encoding='utf-8'))
require(SCHEMA['schema']==1 and SCHEMA['count']==35 and SCHEMA['stride']==STRIDE
        and SCHEMA['runtime_table_rva']==TABLE_RVA,'E_POPULATION_SCHEMA')
SAFE_IDS={865,866,867,868,869,870,873,877,879,886,887}
for i,row in enumerate(SCHEMA['rows']):
    before=bytes.fromhex(row['original_hex']);after=bytes.fromhex(row['completed_hex'])
    require(row['index']==i and len(before)==len(after)==STRIDE,'E_POPULATION_SCHEMA_ROW')
    n=word(before);require(n==row['quantity'] and 1<=n<=30,'E_POPULATION_SCHEMA_QUANTITY')
    if row['eligible']:
        require(2<=n<30 and before[:0x18]==after[:0x18],'E_POPULATION_SCHEMA_HEADER')
        for off in (0x18,0x90,0x108):
            require(before[off:off+n*4]==after[off:off+n*4],'E_POPULATION_SCHEMA_PREFIX')
        ids=struct.unpack_from('<30I',after,0x108)
        require(set(ids[1:])<=set(ids[1:n])<=SAFE_IDS,'E_POPULATION_SCHEMA_IDS')
        positions=list(zip(struct.unpack_from('<30i',after,0x18),struct.unpack_from('<30i',after,0x90)))
        require(len(set(positions))==30 and all(-8<=x<=8 and -8<=z<=8 for x,z in positions),
                'E_POPULATION_SCHEMA_POSITIONS')
    else:require(before==after,'E_POPULATION_SCHEMA_EXCLUDED')
require(len(SCHEMA['rows'])==35,'E_POPULATION_SCHEMA_COUNT')
COUNTERS={'visits':0x10,'eligible_groups':0x14,'increased_groups':0x18,
          'capped_groups':0x1C,'scope_skips':0x20,'native_soldiers':0x24,
          'effective_soldiers':0x28,'allied_groups_increased':0x2C,'enemy_groups_increased':0x30}

def original(base,name):return bytes.fromhex(SITES[name][1])

def initialize_data(raw):
    for row in SCHEMA['rows']:
        i=row['index'];struct.pack_into('<I',raw,ELIGIBLE+i*4,int(row['eligible']))
        for off,key in ((ORIGINAL,'original_hex'),(COMPLETED,'completed_hex')):
            raw[off+i*STRIDE:off+(i+1)*STRIDE]=bytes.fromhex(row[key])


def validate_data(memory,record):
    if record['version']<3:return
    expected=bytearray(SIZE);initialize_data(expected)
    for off,n in ((ELIGIBLE,35*4),(ORIGINAL,35*STRIDE),(COMPLETED,35*STRIDE)):
        require(memory.read(record['data_address']+off,n)==bytes(expected[off:off+n]),
                'E_POPULATION_PRIVATE_TEMPLATE_CHANGED')


def build_bridge(base,data,code,auto,recall,name,*,legacy=False,legacy_version=None,pool=None):
    p=resolve_pool(pool)
    if legacy:return legacy_bridge(base,data,code,auto,recall,name,version=legacy_version or 1,pool=p)
    require(name in SITES,'E_POPULATION_SITE');x=Asm()
    x.emit(original(base,name));x.emit('9c60')
    for off,val in ((0,MAGIC),(4,VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','native')
    inc=lambda off:x.mem('ff',0,disp=data+off)
    inc(0x10)
    x.load('ebx',disp=data+PERCENT);x.cmp('ebx',50);x.jump('eq','mode_ok')
    x.cmp('ebx',100);x.jump('ne','skip');x.mark('mode_ok')
    x.load('ecx','esp',28);x.cmp('ecx',2);x.jump('below','skip')
    x.cmp('ecx',30);x.jump('eq','already_full');x.jump('above','skip')
    x.load('edi',disp=base+0x6A91E8);x.sane('edi','skip')
    x.load('eax','esi',0x18);x.cmp('eax',p.group_capacity);x.jump('ae','skip')
    x.imul('edx','eax',0x268);x.rr('01','edx','edi');x.ri(0,'edx',p.manager_groups)
    x.rr('39','edx','esi');x.jump('ne','skip');x.store('eax',disp=data+0x34)
    x.load('eax','esi',0x30);x.cmp('eax',865);x.jump('below','skip');x.cmp('eax',901);x.jump('above','skip')
    x.load('eax','esi',0x44);x.cmp('eax',250);x.jump('ae','skip');x.store('eax',disp=data+0x38)
    x.imul('edx','eax',0x110);x.rr('01','edx','edi');x.ri(0,'edx',0x4B0)
    x.cmpm('eax','edx',0x38);x.jump('ne','skip')
    x.load('eax','edx',0x40);x.cmp('eax',1);x.jump('above','skip');x.store('eax',disp=data+0x48)
    x.load('ebp','esi',0x2C);x.cmp('ebp',35);x.jump('ae','skip');x.store('ebp',disp=data+0x8C)
    x.imul('edx','ebp',4);x.ri(0,'edx',data+ELIGIBLE);x.op(7,1,'edx');x.jump('ne','skip')
    x.imul('edx','ebp',STRIDE);x.rr('89','eax','edx');x.ri(0,'eax',base+TABLE_RVA)
    # 58EFDD saved the getter pointer at pre-hook ESP+4C. After ADD ESP,4
    # and PUSHFD/PUSHAD it is at +6C; validate it against the native table.
    x.cmpm('eax','esp',0x6C);x.jump('ne','template_refuse');x.store('eax',disp=data+0xC0)
    x.rr('89','edi','edx');x.ri(0,'edi',data+ORIGINAL)
    x.cmpm('ecx','edi');x.jump('ne','template_refuse')
    # Accept exactly the saved original or our completed record. A foreign
    # template is never repaired speculatively. Completion preserves quantity,
    # every header value, and every originally active member.
    for label,off,matched,failed in (('original',ORIGINAL,'complete','try_completed'),
                                   ('completed',COMPLETED,'scaled','template_refuse')):
        if label=='completed':x.mark('try_'+label)
        x.load('esi',disp=data+0xC0);x.imul('edi','ebp',STRIDE);x.ri(0,'edi',data+off);x.imm('ecx',96)
        x.mark('compare_'+label);x.load('eax','esi');x.cmpm('eax','edi');x.jump('ne',failed)
        x.ri(0,'esi',4);x.ri(0,'edi',4);x.emit('49');x.jump('ne','compare_'+label);x.jump('jmp',matched)
    x.mark('complete');x.emit('fc')
    for off in (0x18,0x90,0x108):
        x.load('ecx','esp',28);x.imul('edx','ecx',4)
        x.imul('esi','ebp',STRIDE);x.ri(0,'esi',data+COMPLETED+off);x.rr('01','esi','edx')
        x.load('edi',disp=data+0xC0);x.ri(0,'edi',off);x.rr('01','edi','edx')
        x.imm('eax',30);x.rr('29','eax','ecx');x.rr('89','ecx','eax');x.emit('f3a5')
    inc(0x84)
    x.mark('scaled');x.load('ecx','esp',28);x.load('ebx',disp=data+PERCENT)
    inc(0x14);x.mem('01',R['ecx'],disp=data+0x24);x.store('ecx',disp=data+0x3C)
    x.cmp('ebx',50);x.jump('ne','double')
    x.imul('edx','ecx',3);x.ri(0,'edx',1);x.emit('d1ea');x.jump('jmp','scaled_count')
    x.mark('double');x.imul('edx','ecx',2);x.mark('scaled_count')
    x.store('edx',disp=data+0x44);x.cmp('edx',30);x.jump('be','bounded')
    x.imm('edx',30);inc(0x1C);x.mark('bounded');x.store('edx',disp=data+0x40)
    x.mem('01',R['edx'],disp=data+0x28);inc(0x18)
    x.op(7,0,disp=data+0x48);x.jump('ne','enemy');inc(0x2C);x.jump('jmp','side_done')
    x.mark('enemy');inc(0x30);x.mark('side_done');x.store('edx','esp',28);x.jump('jmp','unlock')
    x.mark('already_full');inc(0x90);x.jump('jmp','skip')
    x.mark('template_refuse');inc(0x88)
    x.mark('skip');inc(0x20)
    x.mark('unlock');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d');x.emit(relative_jump(code+len(x.code),base+0x58EFE6))
    return x.finish()


def legacy_bridge(base,data,code,auto,recall,name,*,version,pool=None):
    p=resolve_pool(pool)
    require(name in SITES,'E_POPULATION_SITE');x=Asm()
    # EAX points at the template. Replay before saving: ADD ESP,4 discards
    # the native getter argument; both its flags and stack effect must survive.
    x.emit(original(base,name));x.emit('9c60')
    for off,val in ((0,MAGIC),(4,version),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','native')
    inc=lambda off:x.mem('ff',0,disp=data+off)
    inc(0x10)
    x.load('ebx',disp=data+PERCENT);x.cmp('ebx',50);x.jump('eq','mode_ok')
    x.cmp('ebx',100);x.jump('ne','skip');x.mark('mode_ok')
    x.load('ecx','esp',28);x.cmp('ecx',2);x.jump('below','skip');x.cmp('ecx',30);x.jump('above','skip')
    x.load('edi',disp=base+0x6A91E8);x.sane('edi','skip')
    x.load('eax','esi',0x18);x.cmp('eax',p.group_capacity);x.jump('ae','skip')
    x.imul('edx','eax',0x268);x.rr('01','edx','edi');x.ri(0,'edx',p.manager_groups)
    x.rr('39','edx','esi');x.jump('ne','skip')
    x.store('eax',disp=data+0x34)
    x.load('eax','esi',0x30);x.cmp('eax',865);x.jump('below','skip');x.cmp('eax',901);x.jump('above','skip')
    x.load('eax','esi',0x44);x.cmp('eax',250);x.jump('ae','skip');x.store('eax',disp=data+0x38)
    x.imul('edx','eax',0x110);x.rr('01','edx','edi');x.ri(0,'edx',0x4B0)
    x.cmpm('eax','edx',0x38);x.jump('ne','skip')
    x.load('edi','edx',0x40);x.cmp('edi',1);x.jump('above','skip')
    x.load('eax','esi',0x2C);x.cmp('eax',34);x.jump('above','skip')
    inc(0x14);x.mem('01',R['ecx'],disp=data+0x24);x.store('ecx',disp=data+0x3C)
    x.cmp('ebx',50);x.jump('ne','double')
    x.imul('edx','ecx',3);x.ri(0,'edx',1);x.emit('d1ea');x.jump('jmp','scaled')
    x.mark('double');x.imul('edx','ecx',2);x.mark('scaled')
    x.store('edx',disp=data+0x44);x.cmp('edx',30);x.jump('be','bounded')
    x.imm('edx',30);inc(0x1C);x.mark('bounded')
    x.store('edx',disp=data+0x40);x.store('edi',disp=data+0x48)
    x.mem('01',R['edx'],disp=data+0x28);x.rr('39','edx','ecx');x.jump('eq','unlock')
    inc(0x18);x.cmp('edi',0);x.jump('ne','enemy');inc(0x2C);x.jump('jmp','side_done')
    x.mark('enemy');inc(0x30);x.mark('side_done')
    x.store('edx','esp',28) # native EAX: capacity, live count, last slot and masks use this same count
    x.jump('jmp','unlock')
    x.mark('skip');inc(0x20)
    x.mark('unlock');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d');x.emit(relative_jump(code+len(x.code),base+0x58EFE6))
    return x.finish()

def check_code(memory):
    checks={0x58EFDD:'8944244c',0x58EFE6:'8944241483f801',
            0x58F004:'894e243bc177028bc848894e28',0x58F19A:'8b7c2414',
            0x4EA0BF:'be1e000000',0x4EA0D2:'81c180010000'}
    for rva,sig in checks.items():
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),
                'E_POPULATION_NATIVE_'+hex(rva))

def set_percent(session,percent):
    require(type(percent) is int and percent in (0,50,100),'E_POPULATION_PERCENT')
    record=(session.lease or {}).get('population')
    if not record and percent==0:return public(session,None)
    bundle.set_bundle(session,'population',__import__(__name__),bool(percent))
    record=session.lease['population']
    spans=[s for p in bundle.all_patches(session) for s in
        ((p['site'],p['site']+len(bytes.fromhex(p['original_hex']))),(p['code_address'],p['code_address']+p['code_size']))]
    with session.quiesce(spans):
        bundle.validate(__import__(__name__),session,record)
        require(uint(session,record['data_address']+12)==0,'E_EXTRA_BRIDGE_EXECUTING_RETRY')
        address=record['data_address']+PERCENT;before=session.read(address,4)
        require(word(before) in (0,50,100),'E_POPULATION_STORED_PERCENT')
        try:
            session.write(address,struct.pack('<I',percent))
            require(uint(session,address)==percent,'E_POPULATION_SETTING_VERIFY')
        except Exception:
            session.write(address,before);raise
        session.log('POPULATION_PERCENT_UPDATED')
    return public(session,record)

def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(available=True,activation_blocked=False,reason=None,hook_revision=VERSION,
        eligible_template_indices=[r['index'] for r in SCHEMA['rows'] if r['eligible']],
        template_completion='ORIGINAL_MEMBERS_PRESERVED_UNUSED_SLOTS_COMPLETED',
        template_quantity_modified=False,template_completions_retained_until_process_exit=True,
        existing_groups_resized=False,special_templates_excluded=True)
    result.update(requested_increase_percent=0,scope='INFANTRY_BOTH_FACTIONS',
        applies_on='NEXT_NATIVE_GROUP_INITIALIZATION',retroactive=False,
        group_capacity=600,group_capacity_expanded=False,maximum_members_per_group=30,
        materialized_actor_capacity_expanded=False,new_groups_allocated=0,
        full_map_percentage_guaranteed=False,counters_are_cumulative_initializations=True,
        template_writes_scope='UNUSED_MEMBER_FIELDS_ONLY',live_validated=False)
    if record:
        raw=memory.read(record['data_address'],0x84)
        result.update({k:word(raw,o) for k,o in COUNTERS.items()})
        result['requested_increase_percent']=word(raw,PERCENT)
        result['additional_soldiers_configured']=word(raw,0x28)-word(raw,0x24)
        result['last_group']={'group':word(raw,0x34),'owner':word(raw,0x38),
            'native_quantity':word(raw,0x3C),'effective_quantity':word(raw,0x40),
            'requested_quantity':word(raw,0x44),'side':word(raw,0x48)}
        if record['version']>=3:
            raw=memory.read(record['data_address']+0x84,0x10)
            result.update(templates_completed=word(raw),template_shape_refusals=word(raw,4),
                          last_template=word(raw,8),already_full_groups_unchanged=word(raw,12))
    return result
