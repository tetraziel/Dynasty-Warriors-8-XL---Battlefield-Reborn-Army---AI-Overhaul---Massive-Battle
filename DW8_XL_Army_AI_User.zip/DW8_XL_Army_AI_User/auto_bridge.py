"""Persistent startup wrappers around the filtered player-squad worker.

Both mode hooks share a lock and a bounded event ring. The host never rearms
game data between battles and cannot miss a quick load because of polling.
"""
import struct
from bridge import MAGIC,X86,build_bridge,decode_status,relative_jump
from core import PROFILE,require,word

AUTO_MAGIC=0x41535744
AUTO_VERSION=1
AUTO_DATA_SIZE=0x3000
SCRATCH=0x200
RING=0x1000
SLOT_SIZE=0x200
SLOTS=16
WORKER_CODE=0x1000

def initial_auto_data():
    result=bytearray(AUTO_DATA_SIZE)
    struct.pack_into('<8I',result,0,AUTO_MAGIC,AUTO_VERSION,1,0,0,0,1,0)
    return bytes(result)

def decode_header(raw):
    require(len(raw)>=0x20 and word(raw)==AUTO_MAGIC and word(raw,4)==AUTO_VERSION,
            'E_AUTO_DATA_HEADER')
    return {'state':word(raw,8),'cancel_requested':bool(word(raw,12)),
            'published_sequence':word(raw,16),'busy':bool(word(raw,20)),
            'enabled':bool(word(raw,24)),'counter_exhausted':bool(word(raw,28))}

def decode_event(raw,sequence):
    require(len(raw)==SLOT_SIZE,'E_AUTO_EVENT_SIZE')
    require(word(raw,0x10)==sequence and word(raw,0x1fc)==sequence,'E_AUTO_EVENT_CHANGED')
    result=decode_status(raw)
    require(result['state'] in (3,4),'E_AUTO_EVENT_STATE')
    mode={1:'AMBITION',2:'STORY_FREE'}.get(word(raw,0x18))
    require(mode is not None,'E_AUTO_EVENT_MODE')
    return dict(result,sequence=sequence,mode=mode)

def build_auto_bridge(base,data,code_address,mode,*,squad_count=1):
    require(mode in PROFILE['modes'],'E_MODE')
    spec=PROFILE['modes'][mode];scratch=data+SCRATCH;x=X86()
    def mov_mem(address,value):x.emit('c705');x.dword(address);x.dword(value)
    def load_eax(address):x.emit('a1');x.dword(address)
    def store_eax(address):x.emit('a3');x.dword(address)
    def cmp_mem(address,value):x.emit('813d');x.dword(address);x.dword(value)
    def jump(op,label):x.branch(op,label)
    x.emit('9c60')
    cmp_mem(data+12,0);jump('0f85','finish')
    cmp_mem(data+24,1);jump('0f85','finish')
    if mode=='AMBITION':
        x.emit('83f900');jump('0f85','finish');x.emit('8d47d0')
    else:
        x.emit('81ff78000000');jump('0f85','finish');x.emit('89f0')
    x.emit('8b15');x.dword(base+PROFILE['manager_rva'])
    x.emit('81c2');x.dword(PROFILE['first_descriptor_offset'])
    x.emit('39d0');jump('0f85','finish')
    # Shared lock covers clearing scratch, executing either worker and publishing.
    x.emit('b800000000b901000000f00fb10d');x.dword(data+20)
    jump('0f85','finish')
    load_eax(data+16);x.emit('3dfeffffff');jump('0f83','exhausted')
    x.emit('fc31c0bf');x.dword(scratch);x.emit('b980000000f3ab') # clear 512-byte scratch
    mov_mem(scratch,MAGIC);mov_mem(scratch+4,4);mov_mem(scratch+8,1)
    mov_mem(scratch+0x18,1 if mode=='AMBITION' else 2)
    load_eax(data+16);x.emit('40');store_eax(scratch+0x10)
    mov_mem(data+8,2)
    # Invoke only our own integer worker with the original game inputs.
    x.emit('619d')
    call_at=code_address+len(x.code)
    x.emit(b'\xe8'+relative_jump(call_at,code_address+WORKER_CODE)[1:])
    x.emit('9c60')
    load_eax(scratch+8);x.emit('83f803');jump('0f84','publish')
    x.emit('83f804');jump('0f85','unlock')
    x.mark('publish')
    load_eax(scratch+0x10);x.emit('4883e00fc1e0098db8');x.dword(data+RING)
    x.emit('c787fc01000000000000') # invalidate slot marker before copying
    x.emit('be');x.dword(scratch);x.emit('b980000000fcf3a5')
    load_eax(scratch+0x10);x.emit('8947fc') # publish complete slot (EDI advanced 512)
    store_eax(data+16)
    load_eax(scratch+8);store_eax(data+8)
    x.mark('unlock');mov_mem(data+20,0);jump('e9','finish')
    x.mark('exhausted');mov_mem(data+28,1);mov_mem(data+24,0)
    mov_mem(data+8,5);jump('e9','unlock')
    x.mark('finish');x.emit('619d');x.emit(bytes.fromhex(spec['original']))
    x.emit(relative_jump(code_address+len(x.code),base+spec['site_rva']+len(bytes.fromhex(spec['original']))))
    wrapper=x.finish();require(len(wrapper)<WORKER_CODE,'E_AUTO_WRAPPER_SIZE')
    worker=build_bridge(base,scratch,code_address+WORKER_CODE,mode,worker=True,squad_count=squad_count)
    result=wrapper+b'\x90'*(WORKER_CODE-len(wrapper))+worker
    require(len(result)<0x4000,'E_AUTO_BRIDGE_SIZE')
    return result

def read_events(memory,data,after):
    """Reader detects ring overwrite and never publishes a torn capture."""
    header=decode_header(memory.read(data,0x20));last=header['published_sequence']
    require(0<=after<=last,'E_AUTO_CURSOR')
    start=max(after+1,last-SLOTS+1);lost=max(0,start-(after+1));events=[]
    for sequence in range(start,last+1):
        address=data+RING+((sequence-1)&(SLOTS-1))*SLOT_SIZE
        if word(memory.read(address+0x1fc,4))!=sequence:break
        raw=memory.read(address,SLOT_SIZE)
        if word(memory.read(address+0x1fc,4))!=sequence:break
        try:events.append(decode_event(raw,sequence))
        except Exception:break # writer advanced while the snapshot was read; retry later
    return {'header':header,'events':events,'lost_events':lost,
            'next_cursor':events[-1]['sequence'] if events else after}
