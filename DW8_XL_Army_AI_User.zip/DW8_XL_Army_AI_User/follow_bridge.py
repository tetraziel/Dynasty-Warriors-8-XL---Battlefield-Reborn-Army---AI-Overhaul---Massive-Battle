"""Opt-in native FOLLOW anchor for the personal infantry only.

At 58A07E the native helper is about to read the owner's order. For the
validated personal soldier, a private immutable two-field view selects the
native state-7 branch and player-owner zero. The actual owner/squad pointers
in game memory are never changed. The helper keeps its native zone checks.
This is an anchor experiment, not the complete owner-level 7/8 order setter.
"""
from pool_binding import resolve as resolve_pool
from bridge import relative_jump
from core import PROFILE,require
from recall_bridge import Asm,R,AGENTS,TABLE,ENTRY_SIZE,FOLLOW_FLAG,FOLLOW_VIEW,CONTEXT
from scope_bridge import emit_actor_scope
from target_bridge import FIELDS
from diagnostics import Diagnostics


def build_follow_bridge(base,data,auto_data,code,*,follow_v3=False,squad_count=1,native_template_zero=True,pool=None,detachment_support=False):
    p=resolve_pool(pool)
    spec=PROFILE['recall']['sites']['FOLLOW_ANCHOR_SITE']
    original=bytes.fromhex(spec['original'])
    require(original==bytes.fromhex('8b8684000000'),'E_FOLLOW_NATIVE_READ')
    x=Asm()
    diag=Diagnostics(x,data,'follow') if not follow_v3 else None
    def load(reg,name):x.load(reg,disp=data+FIELDS[name])
    def save(reg,name):x.store(reg,disp=data+FIELDS[name])
    def inc(offset):x.mem('ff',0,disp=data+offset)

    x.emit('9c60')
    for offset,value in ((8,1),(12,0),(FOLLOW_FLAG,1)):
        x.op(7,value,disp=data+offset);x.jump('ne','transparent')
    x.load('ebx',disp=base+0x6A91D8);x.sane('ebx','transparent')
    # The native helper pushed EBX, EBP, ESI and EDI (16 bytes). Its first
    # argument is therefore at +20; our PUSHFD/PUSHAD add another 36 bytes.
    x.load('esi','esp',56);x.lea('ecx','ebx',0x21EF8)
    x.rr('39','esi','ecx');x.jump('below','transparent')
    x.lea('edx','ecx',AGENTS*0xE0);x.rr('39','esi','edx');x.jump('ae','transparent')
    x.load('eax','esi',0x7C);x.cmp('eax',AGENTS);x.jump('ae','transparent')
    x.imul('edx','eax',0xE0);x.rr('01','edx','ecx')
    x.rr('39','esi','edx');x.jump('ne','transparent')
    x.imul('edi','eax',ENTRY_SIZE);x.ri(0,'edi',data+TABLE)
    x.op(7,1,'edi');x.jump('ne','transparent')
    x.imm('eax',0);x.imm('ecx',1)
    x.mem('f00fb1',R['ecx'],disp=data+16);x.jump('ne','transparent')
    save('esi','agent');save('edi','entry');inc(0xA0)
    emit_actor_scope(x,base,data,auto_data,FIELDS,require_combat=False,follow_v3=follow_v3,diag=diag,squad_count=squad_count,native_template_zero=native_template_zero,pool=p)
    if diag:diag.stage('FOLLOW_OWNER_STATE')
    # The immutable view names owner zero. Other runtime bindings fail open.
    x.op(7,0,disp=data+CONTEXT['owner']);x.jump('ne','scope_failed')
    x.load('eax','esp',4);x.cmpm('eax',disp=data+FIELDS['ai']);x.jump('ne','scope_failed')
    if diag:
        x.load('edx','eax',0x84);x.store('edx',disp=data+0xBC)
    x.op(7,0,'eax',0x84);x.jump('ne','scope_failed')
    x.load('eax','esp',8);x.cmpm('eax',disp=data+FIELDS['manager']);x.jump('ne','scope_failed')
    if detachment_support:
        require(not follow_v3 and squad_count==4,'E_DETACHMENT_FOLLOW_VERSION')
        from detachment import emit_hold_view
        emit_hold_view(x,data,auto_data,data+FIELDS['group'],prefix='follow_hold')
        x.cmp('eax',0);x.jump('eq','follow_player_view')
        x.store('eax','esp',4);inc(0x98);x.jump('jmp','finish')
        x.mark('follow_player_view')
    if diag:diag.stage('FOLLOW_VIEW')
    x.op(7,0,disp=data+FOLLOW_VIEW+0x78);x.jump('ne','scope_failed')
    x.op(7,7,disp=data+FOLLOW_VIEW+0x84);x.jump('ne','scope_failed')
    # Only local ESI changes. State 7 reads the view's +78, then ESI becomes
    # the real player-owner index; no other field of the private view is used.
    x.set(data+FOLLOW_VIEW,'esp',4);inc(0x98);x.jump('jmp','finish')
    x.mark('scope_failed');inc(0x9C)
    if diag:diag.rejected()
    x.mark('finish');x.set(0,disp=data+16)
    x.mark('transparent');x.emit('619d');x.emit(original)
    x.emit(relative_jump(code+len(x.code),base+spec['site_rva']+len(original)))
    payload=x.finish();require(len(payload)<0x4000,'E_FOLLOW_BRIDGE_SIZE')
    return payload
