"""Explicit immutable group-array bindings for offline preparation.

All current live callers retain NATIVE. A binding is an address description,
not evidence that a process was expanded, and never installs anything.
"""
from dataclasses import dataclass,asdict
from functools import lru_cache
from core import require


@dataclass(frozen=True,slots=True)
class PoolBinding:
    group_capacity:int=600
    manager_groups:int=0x10E50
    ai_groups:int=0xA7F8
    request_groups:int=0x80
    group_free_ids:int=0x72150
    group_selection:int=0x83C0
    scratch:int=0x98EC
    scratch_bytes:int=0x38D0

    @property
    def zone_cache_size(self):
        return max(0x4000,(0x1400+self.group_capacity*16+0xFFF)&~0xFFF)

    def record(self):return {'schema':1,'strategy':'NATIVE' if self.group_capacity==600 else 'APPENDED_GROUP_BUFFERS',**asdict(self)}


NATIVE=PoolBinding()


def for_capacity(count):
    require(type(count) is int and count in (600,900,1200),'E_GROUP_POOL_CAPACITY')
    return _for_capacity(count)


@lru_cache(maxsize=3)
def _for_capacity(count):
    if count==600:return NATIVE
    from pool_append import layout
    buffers=layout(count)['buffers']
    return PoolBinding(count,*(buffers[name]['offset'] for name in
        ('manager_groups','ai_groups','request_groups','group_free_ids','group_selection','scratch')),
        buffers['scratch']['size'])


def resolve(value=None):
    if value is None:return NATIVE
    require(type(value) is PoolBinding,'E_POOL_BINDING_TYPE')
    require(all(type(v) is int for v in asdict(value).values()) and
            value==for_capacity(value.group_capacity),'E_POOL_BINDING_LAYOUT')
    return value


def from_record(record):
    require(type(record) is dict,'E_POOL_BINDING_RECORD')
    value=for_capacity(record.get('group_capacity'))
    require(type(record.get('schema')) is int and
            all(type(record.get(key)) is int for key in asdict(value)), 'E_POOL_BINDING_RECORD')
    require(record==value.record(),'E_POOL_BINDING_RECORD')
    return value


def validate_queue(memory,manager,*,pool=None):
    """Read an expected queue header, without enabling use of the binding."""
    import struct
    p=resolve(pool)
    pointer,capacity,free,head=struct.unpack('<4I',memory.read(manager+0x72AB0,16))
    require(pointer==manager+p.group_free_ids and capacity==p.group_capacity and
            0<=free<=capacity and head<capacity,'E_POOL_BINDING_NATIVE_QUEUE')
    return {'capacity':capacity,'free':free,'head':head,'pool_binding':p.record(),
            'activation_authorized':False,'read_only':True}
