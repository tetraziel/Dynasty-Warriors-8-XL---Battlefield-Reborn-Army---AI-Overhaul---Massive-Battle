"""Explicit one-shot HUD balance control. No process opens or hooks on import."""
import struct
from auto_bridge import decode_header,read_events
from battle_morale import read_balance,NATIVE_MAX
from core import PROFILE,require,pointer,uint,player_snapshot,owner_groups,journal_write

FEATURE='v5-manual-morale-percent-1'


def validate_percent(value):
    require(type(value) is int and 0<=value<=100,'E_MANUAL_MORALE_PERCENT_0_100')
    return value


def native_values(percent):
    """Fixed scale: exact integer percentages inside the two native endpoints."""
    validate_percent(percent)
    return [min(NATIVE_MAX,percent*10),min(NATIVE_MAX,(100-percent)*10)]


def context(memory):
    lease=memory.lease or {}
    require(lease.get('cookie')==list(memory.cookie),'E_MANUAL_MORALE_PROCESS_COOKIE')
    phase=pointer(memory,memory.base+0x6D10BC)
    phase_current=uint(memory,phase+0x1C784)
    require(phase_current in (4,5),'E_MANUAL_MORALE_WAIT_BATTLE')
    state=player_snapshot(memory)
    require(uint(memory,state['players']+0x104)==0,'E_MANUAL_MORALE_BLUE_PLAYER_REQUIRED')
    header=decode_header(memory.read(lease['data_address'],0x20))
    require(header['enabled'] and not header['cancel_requested'] and not header['busy'],
            'E_MANUAL_MORALE_AUTO_BUSY_OR_DISABLED')
    sequence=header['published_sequence']
    require(sequence>0,'E_MANUAL_MORALE_NO_BATTLE_CAPTURE')
    events=read_events(memory,lease['data_address'],sequence-1)['events']
    require(len(events)==1 and events[0]['sequence']==sequence,'E_MANUAL_MORALE_CAPTURE_CHANGED')
    event=events[0]
    require(event.get('manager')==hex(state['manager']) and
            event.get('players')==hex(state['players']) and event.get('player1_markers_match'),
            'E_MANUAL_MORALE_CAPTURE_CONTEXT')
    config=pointer(memory,memory.base+0x6A9200)
    identity=[uint(memory,config+off) for off in (0x28,0x2C,0x30,0x34)]
    require(identity[0]<=5,'E_MANUAL_MORALE_DIFFICULTY_RANGE')
    return {'cookie':list(memory.cookie),'state':state,'phase_object':phase,
            'phase_current':phase_current,'config':config,'config_identity':identity,
            'capture_sequence':sequence,'capture_mode_label':event['mode']}


def identity(view):
    return {k:view[k] for k in ('cookie','state','phase_object','config','config_identity','capture_sequence')}


def snapshot(memory):
    before=context(memory)
    balance=read_balance(memory,before['state'])
    require(balance['available'] and balance['player_side']==0,'E_MANUAL_MORALE_FORCE_LAYOUT')
    groups=owner_groups(memory,before['state'],before['state']['owner'])
    groups=[g for g in groups if g['unit_type']==PROFILE['troop_type'] and g['template']==PROFILE['squad_template']]
    require(all(0<=g['quantity_current']<=g['quantity_max']<=30 for g in groups),
            'E_MANUAL_MORALE_GROUP_QUANTITY')
    config=before['config']
    result=dict(before,elapsed_ticks=uint(memory,config+0x38),limit_ticks=uint(memory,config+0x3C),
                balance=balance,player_groups=groups,
                logical_soldiers=sum(g['quantity_current'] for g in groups),
                materialized_members=sum(g['materialized_bits'].bit_count() for g in groups))
    require(identity(context(memory))==identity(before),'E_MANUAL_MORALE_CONTEXT_CHANGED')
    return result


def apply(memory,percent,path,utc_now):
    """Caller suspends game threads; only the two force+68 uints may be written."""
    values=native_values(percent)
    before=snapshot(memory)
    addresses=[int(a,16) for a in before['balance']['value_addresses']]
    saved=[memory.read(a,4) for a in addresses]
    record={'feature':FEATURE,'status':'PENDING','event':'APPLY_MORALE','requested_percent':percent,
            'mapping':'BLUE=min(999,10*p); RED=min(999,10*(100-p))',
            'utc':utc_now(),'before':before,'requested_native_values':values,
            'continuous_override':False,'game_files_modified':False,
            'npc_stats_or_difficulty_written':False,'live_behavior_validated':False,
            'report':str(path)}
    journal_write(path,record) # Refuse before writing if the event cannot be recorded.
    try:
        for address,value in zip(addresses,values):memory.write(address,struct.pack('<I',value))
        require([uint(memory,a) for a in addresses]==values,'E_MANUAL_MORALE_WRITE_VERIFY')
        after=snapshot(memory)
        require(identity(after)==identity(before),'E_MANUAL_MORALE_CONTEXT_CHANGED')
        record.update(status='APPLIED_ONCE',applied_utc=utc_now(),after=after)
        journal_write(path,record)
    except Exception as error:
        rollback_errors=[]
        for address,payload in zip(addresses,saved):
            try:
                memory.write(address,payload)
                require(memory.read(address,4)==payload,'E_MANUAL_MORALE_ROLLBACK_VERIFY')
            except Exception as rollback:rollback_errors.append(str(rollback))
        record.update(status='ROLLBACK_FAILED' if rollback_errors else 'ROLLED_BACK',
                      error=str(error),rollback_errors=rollback_errors)
        journal_write(path,record)
        require(not rollback_errors,'E_MANUAL_MORALE_ROLLBACK_FAILED_'+str(rollback_errors))
        raise
    return record


def observation(memory,applied,previous,utc_now):
    """Read-only follow-up. Quantities are not proved deaths or off-screen events."""
    current=snapshot(memory)
    same=identity(current)==identity(applied['after'])
    old={g['squad']:g['quantity_current'] for g in (previous or applied['after'])['player_groups']}
    new={g['squad']:g['quantity_current'] for g in current['player_groups']}
    return {'feature':FEATURE,'event':'OBSERVATION','utc':utc_now(),
            'status':'OBSERVING' if same else 'BATTLE_CONTEXT_CHANGED',
            'apply_report':applied['report'],'requested_percent':applied['requested_percent'],
            'snapshot':current,'same_battle_context':same,
            'logical_quantity_deltas':({str(g):new[g]-old[g] for g in new.keys()&old.keys()} if same else {}),
            'missing_group_ids':sorted(old.keys()-new.keys()) if same else [],
            'new_group_ids':sorted(new.keys()-old.keys()) if same else [],
            'missing_groups_treated_as_zero':False,'causal_morale_loss_proven':False,
            'offscreen_combat_proven':False,'read_only':True}
