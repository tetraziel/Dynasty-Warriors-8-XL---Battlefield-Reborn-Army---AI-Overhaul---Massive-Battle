"""Opt-in native-capacity admission, plus creation-return telemetry.

Runs after the existing MOV/DIV budget calculation. It caps only a larger
local budget at the verified native queue capacity, preserving native priority
selection and release/creation code. It does not grow any pool or change fog.
"""
from core import require,word
from recall_bridge import Asm,R
from bridge import relative_jump
import bundle_support as bundle

FEATURE='NPC_ALLOCATION_BALANCE_TEST'
MAGIC=0x314C4142;VERSION=1;SIZE=0x1000;CODE_SIZE=0x8000
CAPACITY=150
SITES={'ADMISSION_BUDGET':(0x51EE93,'8b54241851'),
       'CREATION_RETURN':(0x59AC8F,'7210807c240f00')}
COUNTERS={'visits':0x10,'admission_visits':0x14,'budgets_capped':0x18,
          'creation_returns_observed':0x1C,'successful_agent_returns':0x20,
          'failed_agent_returns':0x24,'failures_with_queue_full':0x28,
          'native_pass_aborts_observed':0x2C,'native_deferrals_observed':0x30,
          'budgets_already_within_capacity':0x34,'scope_skips':0x38,'busy_skips':0x3C}
LAST_INPUT,LAST_EFFECTIVE,LAST_FREE,LAST_CAPACITY,LAST_AGENT=range(0x40,0x54,4)


def build_bridge(base,data,code,auto,recall,name,*,pool=None):
    require(name in SITES,'E_NPC_BALANCE_SITE');x=Asm();x.emit('9c60')
    inc=lambda key:x.mem('ff',0,disp=data+COUNTERS[key])
    for off,val in ((0,MAGIC),(4,VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','busy')
    inc('visits')
    for address,val in ((auto+24,1),(auto+20,0),(auto+12,0),(recall+8,1),(recall+12,0)):
        x.op(7,val,disp=address);x.jump('ne','skip')
    x.load('eax',disp=auto+16);x.cmp('eax',0);x.jump('eq','skip')
    x.op(7,0,disp=base+0x6CAAA0);x.jump('ne','skip')
    x.load('esi',disp=base+0x6A91E0);x.sane('esi','skip')
    if name=='ADMISSION_BUDGET':
        x.cmpm('esi','esp',4);x.jump('ne','skip') # original ESI is the selector
    else:
        x.load('eax','esp',8);x.sane('eax','skip') # native EBP frame
        x.cmpm('esi','eax',8);x.jump('ne','skip')
    for off,val in ((0x98E8,1),(0x98E0,0x80080804)):
        x.op(7,val,'esi',off);x.jump('ne','skip')
    x.load('eax',disp=base+0x6A91EC);x.sane('eax','skip')
    for off,val in ((0x590,1),(0x108,0)):
        x.op(7,val,'eax',off);x.jump('ne','skip')
    x.load('eax',disp=base+0x6D10BC);x.sane('eax','skip')
    x.op(7,4,'eax',0x1C784);x.jump('ne','skip')
    x.load('edi',disp=base+0x6A91E8);x.sane('edi','skip')
    x.op(7,CAPACITY,'edi',0x72140);x.jump('ne','skip')
    x.load('eax','edi',0x7213C);x.sane('eax','skip')
    x.load('edx','edi',0x72148);x.cmp('edx',CAPACITY);x.jump('ae','skip')
    x.load('edx','edi',0x72144);x.cmp('edx',CAPACITY);x.jump('above','skip')
    x.store('edx',disp=data+LAST_FREE);x.set(CAPACITY,disp=data+LAST_CAPACITY)
    if name=='ADMISSION_BUDGET':
        inc('admission_visits');x.load('eax','esp',28);x.store('eax',disp=data+LAST_INPUT)
        x.cmp('eax',CAPACITY);x.jump('be','fits')
        x.set(CAPACITY,'esp',28);x.imm('eax',CAPACITY);inc('budgets_capped');x.jump('jmp','budget_ready')
        x.mark('fits');inc('budgets_already_within_capacity')
        x.mark('budget_ready');x.store('eax',disp=data+LAST_EFFECTIVE)
    else:
        inc('creation_returns_observed');x.load('eax','esp',0);x.store('eax',disp=data+LAST_AGENT)
        x.cmp('eax',CAPACITY);x.jump('ae','failure');inc('successful_agent_returns');x.jump('jmp','unlock')
        x.mark('failure');inc('failed_agent_returns')
        x.cmp('edx',0);x.jump('ne','failure_kind');inc('failures_with_queue_full')
        x.mark('failure_kind')
        x.mem('0fb6',R['eax'],'esp',36+0xF);x.cmp('eax',0);x.jump('ne','deferred')
        inc('native_pass_aborts_observed');x.jump('jmp','unlock')
        x.mark('deferred');inc('native_deferrals_observed')
    x.jump('jmp','unlock')
    x.mark('skip');inc('scope_skips')
    x.mark('unlock');x.set(0,disp=data+12);x.jump('jmp','native')
    x.mark('busy');inc('busy_skips')
    x.mark('native');x.emit('619d')
    def jump_native(rva):x.emit(relative_jump(code+len(x.code),base+rva))
    if name=='ADMISSION_BUDGET':
        x.emit(bytes.fromhex(SITES[name][1]));jump_native(0x51EE98)
    else:
        # Recreate the original short branch, not its relocated byte offset.
        # CMP EDI,150 at59AC89 is untouched, so restore and consume its flags.
        x.jump('below','native_success')
        x.mem('80',7,'esp',0xF);x.emit('00');jump_native(0x59AC96)
        x.mark('native_success');jump_native(0x59ACA1)
    return x.finish()


SIGNATURES={0x51EE8D:'f7f1',0x51EE8F:'8b4c2414',0x51EE98:'8d4c24408bf8575253568d542460',
            0x51EEA6:'e88590feff',0x59AC84:'8bf883c40c',
            0x59AC89:'81ff96000000',0x59AC96:'0f84d7000000'}


def check_code(memory):
    for rva,sig in SIGNATURES.items():
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),
                'E_NPC_BALANCE_NATIVE_'+hex(rva))


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(admission_capacity=CAPACITY,
        scope='SINGLE_PLAYER_MANY_4_8_8_ACTIVE_BATTLE_NATIVE_150_LAYOUT',
        effect='CAP_EXTENDED_LOCAL_REQUEST_BUDGET_TO_NATIVE_CAPACITY',
        selected_extended_budget_preserved=True,
        effective_budget_override_requires_larger_input=True,
        native_priority_selection_preserved=True,forced_agent_evictions=False,
        agent_pool_expanded=False,logical_population_changed=False,
        creation_quota_changed=False,model_resources_forced_ready=False,
        fog_or_camera_modified=False,combat_or_orders_modified=False,
        native_allocation_checks_preserved=True,remote_threads_created=False,
        game_functions_called=False,actual_rendered_npcs=None,
        appearance_latency_improvement_verified=False)
    if record:
        raw=memory.read(record['data_address']+LAST_INPUT,20)
        result['last_observation']=dict(input_budget=word(raw),effective_budget=word(raw,4),
            free_agent_slots=word(raw,8),queue_capacity=word(raw,12),creation_result=word(raw,16))
    return result
