"""Optional 2000-unit XZ player-target cap for enemy physical officers.

Adds a rejection at a native target predicate call, for acquisition and
retention alike. Existing native callers clear/reselect targets themselves.
No direct actor-target writes, private worker, teleport, or strategic orders.
"""
import math
import struct
from core import require,word
from recall_bridge import Asm,R
from bridge import relative_jump
import combat_scope as scope
import bundle_support as bundle

FEATURE='ENEMY_OFFICER_PLAYER_PURSUIT_2000_TEST'
MAGIC=0x3152504F;VERSION=1;SIZE=0x1000;CODE_SIZE=0x4000
SITES={'PLAYER_TARGET_RANGE':(0x589AF4,'e8b701feff')}
COUNTERS={'predicate_visits':0x10,'enemy_officer_player_checks':0x14,
          'out_of_range_rejections':0x18,'within_range_native_checks':0x1C,
          'scope_skips':0x20,'busy_skips':0x24}
RADIUS=2000.0;RADIUS2_BITS=struct.unpack('<I',struct.pack('<f',RADIUS**2))[0]
LIMIT=0x80;ACTOR=0x140;PLAYER=0x180;SAVED=0x200


def initialize_data(raw):struct.pack_into('<I',raw,LIMIT,RADIUS2_BITS)


def build_bridge(base,data,code,auto,recall,name,*,legacy=False):
    require(name in SITES and not legacy,'E_OFFICER_PURSUIT_SITE')
    x=Asm();inc=lambda offset:x.mem('ff',0,disp=data+offset)
    # bundle_support installs a JMP at the original CALL. Recreate exactly
    # the continuation the CALL would have pushed, before saving registers.
    x.emit('68');x.dword(base+0x589AF9);x.emit('9c60')
    for off,value in ((0,MAGIC),(4,VERSION),(8,1),(0x70,auto),(0x74,recall),
                      (LIMIT,RADIUS2_BITS)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','busy')
    inc(0x10);x.set(0,disp=data+SAVED)
    x.load('eax','esp',40);x.store('eax',disp=data+SAVED+4)
    x.load('eax','esp',44);x.store('eax',disp=data+SAVED+8)
    scope.roots(x,base,data,auto,'skip')
    # Player identity is resolved each call; a nearby bodyguard or other ally
    # must not accidentally inherit the player's distance restriction.
    x.load('eax',disp=data+scope.ROOT+8);x.load('eax','eax',0x110)
    x.cmp('eax',150);x.jump('ae','skip')
    x.imul('ecx','eax',0xE0);x.load('edx',disp=data+scope.ROOT+4)
    x.rr('01','ecx','edx');x.ri(0,'ecx',0x21EF8)
    x.cmpm('ecx',disp=data+SAVED+8);x.jump('ne','skip')
    scope.physical(x,data,PLAYER,'skip',prefix='player')
    for field in (0x1C,0x20):
        x.op(7,0,disp=data+PLAYER+field);x.jump('ne','skip')
    x.load('ecx',disp=data+SAVED+4);x.sane('ecx','skip');x.load('eax','ecx',0x7C)
    scope.physical(x,data,ACTOR,'skip',prefix='officer')
    x.load('eax',disp=data+ACTOR+8);x.cmpm('eax',disp=data+SAVED+4);x.jump('ne','skip')
    scope.officer(x,data,ACTOR,'skip',allow_group_members=True)
    x.op(7,1,disp=data+ACTOR+0x20);x.jump('ne','skip')
    x.load('esi',disp=data+ACTOR+8);x.load('edi',disp=data+PLAYER+8)
    for reg in ('esi','edi'):
        for off in (0x34,0x3C):
            x.load('eax',reg,off);x.ri(4,'eax',0x7FFFFFFF)
            x.cmp('eax',0x4CBEBC20);x.jump('above','skip')
    inc(0x14)
    x.emit('89e581ec4002000083e4f0');x.store('esp','ebp',-4)
    x.mem('0fae',0,'esp');x.set(0x1F80,'ebp',-8);x.mem('0fae',2,'ebp',-8)
    x.mem('f30f10',0,'esi',0x34);x.mem('f30f5c',0,'edi',0x34);x.emit('f30f59c0')
    x.mem('f30f10',1,'esi',0x3C);x.mem('f30f5c',1,'edi',0x3C)
    x.emit('f30f59c9f30f58c1');x.mem('f30f11',0,disp=data+0x30)
    x.mem('0f2e',0,disp=data+LIMIT);x.jump('be','near')
    x.set(1,disp=data+SAVED);inc(0x18);x.jump('jmp','restore_fp')
    x.mark('near');inc(0x1C)
    x.mark('restore_fp');x.load('esp','ebp',-4);x.mem('0fae',1,'esp');x.emit('89ec')
    x.load('eax',disp=data+ACTOR);x.store('eax',disp=data+0x34)
    x.load('eax',disp=data+PLAYER);x.store('eax',disp=data+0x38)
    x.set(0,disp=data+12)
    x.op(7,1,disp=data+SAVED);x.jump('eq','reject')
    x.jump('jmp','native')
    x.mark('skip');inc(0x20);x.set(0,disp=data+12);x.jump('jmp','native')
    x.mark('busy');inc(0x24)
    x.mark('native');x.emit('619d')
    # Tail-call the original validator with exactly the native arguments and
    # the recreated return address. Its RET8 performs the original cleanup.
    x.emit(relative_jump(code+len(x.code),base+0x569CB0))
    x.mark('reject');x.emit('619db000c20800')
    return x.finish()


def check_code(memory):
    for rva,sig in ((0x569CB0,'51538b5c241055'),(0x589AEF,'8b7d085357'),
                    (0x589AF9,'84c00f84e7010000'),(0x595DD2,'e8093dffff')):
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),
                'E_OFFICER_PURSUIT_NATIVE_'+hex(rva))


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(radius_xz=RADIUS,acquisition_and_retention_capped=True,
        distance_units='NATIVE_WORLD_XZ',real_world_meters_verified=False,
        scope='ENEMY_PHYSICAL_LEADER_TO_PLAYER_ONLY',
        native_clear_and_reselection_preserved=True,direct_target_writes=False,
        troop_targets_capped=False,offscreen_orders_modified=False,
        remote_threads_created=False)
    result['last_pair']=None
    if record and result['enemy_officer_player_checks']:
        raw=memory.read(record['data_address']+0x30,12)
        d2=struct.unpack_from('<f',raw)[0]
        result['last_pair']={'officer_agent':word(raw,4),'player_agent':word(raw,8),
                            'distance_xz':math.sqrt(d2) if math.isfinite(d2) and d2>=0 else None}
    return result
