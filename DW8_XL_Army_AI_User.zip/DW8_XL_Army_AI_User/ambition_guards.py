"""Opt-in native reconstruction of the selected guards at each fresh Ambition map.

Restores the series' selected IDs before the existing native startup loop.
Native resolver and constructors keep their own validation and ordering;
no native helper is called by the hook or by the host.
"""
import struct
from core import require,word,uint
from recall_bridge import Asm,R
from bridge import relative_jump
import bundle_support as bundle

FEATURE='AMBITION_FRESH_BODYGUARDS_EACH_BATTLE'
MAGIC=0x31474241;VERSION=1;SIZE=0x1000;CODE_SIZE=0x4000
SITES={'FRESH_GUARD_STARTUP':(0x5AEE7A,'33f68974240c')}
COUNTERS={'startup_visits':0x10,'fresh_battles_prepared':0x14,'selection_ids_restored':0x18,
          'selected_guards_prepared':0x1C,'series_cache_resets':0x20,
          'scope_skips':0x24,'occupied_owner_refusals':0x28,
          'native_eligibility_refusals':0x2C,'selection_updates':0x30,'busy_skips':0x34}
LAST_ROUND,LAST_MASK,LAST_FLAGS=0x40,0x44,0x48
CAMP,ROUND,VALID,IDS=0x80,0x84,0x88,0x8C
SELECTION_RVA=0x848580
SIGNATURES={0x5AEE6D:'83e202',0x5AEE88:'8b4d0c51',0x5AEE8E:'e83db5f7ff',
            0x5AEE96:'8944241c',0x5AEE9A:'3d87040000',
            0x52A3D0:'83ec085355',0x52A406:'81fb86030000',
            0x52A41D:'e87ec0edff',0x4064A0:'8b401c3d86030000',
            0x4064B0:'0fbf844126070000',0x4064B8:'3d19040000'}


def initialize_data(raw):struct.pack_into('<3I',raw,IDS,*([0xFFFFFFFF]*3))


def validate_data(memory,record):
    raw=memory.read(record['data_address']+CAMP,24)
    camp,round_no,valid,*ids=struct.unpack('<6I',raw)
    require(valid in (0,1) and all(i==0xFFFFFFFF or i<=0x386 for i in ids),'E_AMBITION_GUARD_CACHE')
    require(not valid or (0x10000<=camp<0xFF000000 and 1<=round_no<=999),'E_AMBITION_GUARD_SERIES')


def build_bridge(base,data,code,auto,recall,name,*,pool=None):
    require(name in SITES,'E_AMBITION_GUARD_SITE');x=Asm();x.emit('9c60')
    inc=lambda key:x.mem('ff',0,disp=data+COUNTERS[key])
    for off,value in ((0,MAGIC),(4,VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,value,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','busy')
    inc('startup_visits')
    for address,value in ((auto+24,1),(auto+20,0),(recall+8,1),(recall+12,0)):
        x.op(7,value,disp=address);x.jump('ne','skip')
    x.mem('0fb7',R['eax'],disp=base+0x848530);x.cmp('eax',1);x.jump('ne','skip')
    x.load('eax',disp=base+0x6A9200);x.sane('eax','skip');x.load('ecx','eax');x.store('ecx',disp=data+LAST_FLAGS)
    # Existing native startup excludes replay/restore; never refresh mid-battle.
    x.ri(4,'ecx',0x20043E03);x.cmp('ecx',0x1000);x.jump('ne','skip')
    x.op(7,0,'eax',0x38);x.jump('ne','skip')
    x.load('ebx',disp=base+0x6A91EC);x.sane('ebx','skip')
    for off,value in ((0x590,1),(0x108,0)):
        x.op(7,value,'ebx',off);x.jump('ne','skip')
    # Prove this is the existing single-player frame, not another caller.
    x.load('eax','esp',8);x.sane('eax','skip');x.op(7,0,'eax',0xC);x.jump('ne','skip')
    x.load('esi',disp=base+0x6A91E8);x.sane('esi','skip')
    for slot in range(3):
        x.op(7,250,'ebx',0x1C4+slot*0x30);x.jump('ne','occupied')
        owner=0x4B0+(122+slot)*0x110
        x.op(7,0xFFFFFFFF,'esi',owner+0x44);x.jump('ne','occupied')
        x.op(7,0,'esi',owner+0x100);x.jump('ne','occupied')
    x.load('edi',disp=base+0x6A9398);x.sane('edi','skip')
    x.mem('0fb7',R['edx'],'edi',0x582);x.cmp('edx',1);x.jump('below','skip');x.cmp('edx',999);x.jump('above','skip')
    x.store('edx',disp=data+LAST_ROUND)
    # Preflight the complete selection/cache before modifying any game field.
    for slot in range(3):
        for cache in (False,True):
            if cache:x.load('eax',disp=data+IDS+slot*4)
            else:
                x.mem('0fbf',R['eax'],disp=base+SELECTION_RVA+slot*2)
            label=('cache_' if cache else 'selection_')+str(slot)+'_valid'
            x.cmp('eax',0xFFFFFFFF);x.jump('eq',label);x.cmp('eax',0x386);x.jump('above','skip');x.mark(label)
    x.load('esi',disp=base+0x6A9368);x.sane('esi','skip')
    x.load('ebx',disp=base+0x6A9348);x.sane('ebx','skip')
    x.op(7,1,disp=data+VALID);x.jump('ne','new_series')
    x.cmpm('edi',disp=data+CAMP);x.jump('ne','new_series')
    x.cmp('edx',1);x.jump('eq','new_series')
    x.cmpm('edx',disp=data+ROUND);x.jump('below','new_series');x.jump('jmp','cache_ready')
    x.mark('new_series');inc('series_cache_resets')
    for slot in range(3):
        x.mem('0fbf',R['eax'],disp=base+SELECTION_RVA+slot*2);x.store('eax',disp=data+IDS+slot*4)
    x.mark('cache_ready');x.store('edi',disp=data+CAMP);x.store('edx',disp=data+ROUND)
    x.set(1,disp=data+VALID);x.set(0,disp=data+LAST_MASK)
    for slot in range(3):
        x.mem('0fbf',R['eax'],disp=base+SELECTION_RVA+slot*2)
        x.cmp('eax',0xFFFFFFFF);x.jump('eq','use_cached_'+str(slot))
        x.cmpm('eax',disp=data+IDS+slot*4);x.jump('eq','use_cached_'+str(slot))
        x.store('eax',disp=data+IDS+slot*4);inc('selection_updates')
        x.mark('use_cached_'+str(slot));x.load('eax',disp=data+IDS+slot*4)
        x.cmp('eax',0xFFFFFFFF);x.jump('eq','slot_done_'+str(slot))
        # Match 4064A0's recruitment mapping check; do not manufacture an alias
        # for a missing character record or overwrite persistent camp ownership.
        x.imul('ecx','eax',0x2C);x.rr('01','ecx','esi');x.load('ecx','ecx',0x1C)
        x.cmp('ecx',0x386);x.jump('above','unavailable_'+str(slot))
        x.imul('ecx','ecx',2);x.rr('01','ecx','ebx');x.mem('0fbf',R['ecx'],'ecx',0x726)
        x.cmp('ecx',0x419);x.jump('above','unavailable_'+str(slot))
        inc('selected_guards_prepared');x.op(1,1<<slot,disp=data+LAST_MASK)
        x.mem('0fbf',R['ecx'],disp=base+SELECTION_RVA+slot*2);x.rr('39','eax','ecx')
        x.jump('eq','slot_done_'+str(slot))
        x.mem('6689',R['eax'],disp=base+SELECTION_RVA+slot*2);inc('selection_ids_restored')
        x.jump('jmp','slot_done_'+str(slot))
        x.mark('unavailable_'+str(slot));inc('native_eligibility_refusals')
        x.mark('slot_done_'+str(slot))
    inc('fresh_battles_prepared');x.jump('jmp','unlock')
    x.mark('occupied');inc('occupied_owner_refusals');x.jump('jmp','unlock')
    x.mark('skip');inc('scope_skips')
    x.mark('unlock');x.set(0,disp=data+12);x.jump('jmp','native')
    x.mark('busy');inc('busy_skips')
    x.mark('native');x.emit('619d');x.emit(bytes.fromhex(SITES[name][1]))
    x.emit(relative_jump(code+len(x.code),base+0x5AEE80));return x.finish()


def check_code(memory):
    for rva,sig in SIGNATURES.items():
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),'E_AMBITION_GUARD_NATIVE_'+hex(rva))


def changes_for_enabled(memory,record,enabled):
    """Seed private IDs when enabled during an existing series; no game writes."""
    if not enabled:return []
    if struct.unpack('<H',memory.read(memory.base+0x848530,2))[0]!=1:return []
    camp=uint(memory,memory.base+0x6A9398)
    if not 0x10000<=camp<0xFF000000:return []
    round_no=struct.unpack('<H',memory.read(camp+0x582,2))[0]
    if not 1<=round_no<=999:return []
    ids=list(struct.unpack('<3h',memory.read(memory.base+SELECTION_RVA,6)))
    require(all(-1<=v<=0x386 for v in ids),'E_AMBITION_GUARD_SELECTION')
    old=memory.read(record['data_address']+CAMP,24);values=list(struct.unpack('<6I',old))
    if values[2]==1 and values[0]==camp and values[1]<=round_no and round_no!=1:
        ids=[v if v>=0 else (values[3+i] if values[3+i]!=0xFFFFFFFF else -1) for i,v in enumerate(ids)]
    new=struct.pack('<6I',camp,round_no,1,*(v&0xFFFFFFFF for v in ids))
    return [] if old==new else [(record['data_address']+CAMP,old,new)]


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(scope='FRESH_SINGLE_PLAYER_AMBITION_GUARD_STARTUP',revives_on_next_battle=True,
        battle_invulnerability=False,native_guard_constructors_reused=True,
        guard_armies_recreated_by_existing_feature=True,full_armies_guaranteed=False,
        series_counter_difficulty_rewards_and_duel_schedule_preserved=True,
        character_recruitment_mapping_modified=False,remote_threads_created=False,game_functions_called=False,
        midbattle_respawn=False,activation_requires_next_battle=True,live_guard_return_verified=False)
    if record:
        raw=memory.read(record['data_address']+CAMP,24)
        camp,round_no,valid,*ids=struct.unpack('<6I',raw)
        result['series_cache']={'valid':bool(valid),'camp':hex(camp),'round':round_no,
                               'selected_character_ids':[-1 if i==0xFFFFFFFF else i for i in ids]}
        raw=memory.read(record['data_address']+LAST_ROUND,12)
        result['last_preparation']={'round':word(raw),'eligible_slot_mask':word(raw,4),'configuration_flags':hex(word(raw,8))}
    return result
