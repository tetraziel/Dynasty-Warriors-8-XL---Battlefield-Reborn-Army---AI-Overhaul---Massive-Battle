"""Optional personal-squad exception to the native owner map-marker filter.

Pure emitter. No game calls, actor allocation, position changes or bitmap writes.
The native TEST runs first; only its saved flags can change for a verified squad.
"""
from core import require,word
from recall_bridge import Asm,R,CONTEXT,MAGIC as RECALL_MAGIC,VERSION as RECALL_VERSION
from auto_bridge import AUTO_MAGIC,AUTO_VERSION
from family_scope import emit_family_scope
from pool_binding import resolve as resolve_pool
from bridge import relative_jump
import bundle_support as bundle

FEATURE='PERSONAL_SQUADS_MAP_MARKERS_TEST'
MAGIC=0x3850414D;VERSION=1;SIZE=0x1000;CODE_SIZE=0x4000
SITES={'PERSONAL_OWNER_MAP_FILTER':(0x5269BD,'85848ff43d0100')}
COUNTERS={'filtered_owner_checks':0x10,'personal_marker_exemptions':0x14,
          'native_filter_preserved':0x18}
FIELDS={name:0x80+i*4 for i,name in enumerate(('manager','owner','group','sequence','group_id','player_group'))}


def build_bridge(base,data,code,auto,recall,name,*,pool=None):
    # Agent and owner-bitmap storage keeps its native layout. Only logical
    # group addresses and bounds follow the explicit offline pool binding.
    p=resolve_pool(pool)
    require(name in SITES,'E_MAP_MARKER_SITE');x=Asm()
    # Execute the displaced TEST with exactly the original operands. Keep its
    # flags on our stack for every disabled, contended or out-of-scope path.
    x.emit(SITES[name][1]);x.emit('9c60')
    x.jump('eq','native') # Bitmap did not exclude this owner: nothing to fix.
    for off,val in ((0,MAGIC),(4,VERSION),(8,1),(0x70,auto),(0x74,recall)):
        x.op(7,val,disp=data+off);x.jump('ne','native')
    x.imm('eax',0);x.imm('ecx',1);x.mem('f00fb1',R['ecx'],disp=data+12);x.jump('ne','native')
    inc=lambda off:x.mem('ff',0,disp=data+off)
    def save(reg,name):x.store(reg,disp=data+FIELDS[name])
    def load(reg,name):x.load(reg,disp=data+FIELDS[name])
    def ctx(reg,name):x.cmpm(reg,disp=recall+CONTEXT[name]);x.jump('ne','skip')
    inc(0x10)
    x.load('esi','esp',4);x.cmp('esi',0);x.jump('ne','skip')
    # Only player 1's ordinary map object, single player and a running/paused
    # battle. Other map views and scenario-wide hiding remain native.
    x.load('edi','esp',0);x.cmpm('edi',disp=base+0x6A9180);x.jump('ne','skip')
    x.op(7,0,'edi');x.jump('ne','skip')
    x.mem('0fb6',R['eax'],'edi',0x11);x.cmp('eax',0);x.jump('ne','skip')
    for address,val in ((auto,AUTO_MAGIC),(auto+4,AUTO_VERSION),(auto+12,0),
                        (auto+20,0),(auto+24,1),(recall,RECALL_MAGIC),
                        (recall+4,RECALL_VERSION),(recall+8,1),(recall+12,0),(recall+16,0)):
        x.op(7,val,disp=address);x.jump('ne','skip')
    x.load('eax',disp=auto+16);x.cmp('eax',0);x.jump('eq','skip');ctx('eax','sequence');save('eax','sequence')
    x.load('ebx',disp=base+0x6A91E8);x.sane('ebx','skip');ctx('ebx','manager');save('ebx','manager')
    x.load('ecx',disp=base+0x6A91EC);x.sane('ecx','skip');ctx('ecx','players')
    x.op(7,1,'ecx',0x590);x.jump('ne','skip')
    x.load('esi','esp',4);x.cmp('esi',0);x.jump('ne','skip')
    x.cmpm('esi','ecx',0x108);x.jump('ne','skip');ctx('esi','owner');save('esi','owner')
    x.load('eax',disp=base+0x6D10BC);x.sane('eax','skip');ctx('eax','phase')
    x.load('eax','eax',0x1C784);x.cmp('eax',4);x.jump('eq','phase_ok')
    x.cmp('eax',5);x.jump('ne','skip');x.mark('phase_ok')
    x.load('edi',disp=base+0x6A91D8);x.sane('edi','skip');ctx('edi','ai')
    x.load('eax','ecx',0x110);x.cmp('eax',150);x.jump('ae','skip');ctx('eax','player_id')
    x.imul('eax','eax',0x30);x.rr('01','eax','ebx');x.ri(0,'eax',0x6B210)
    x.load('eax','eax',8);x.cmp('eax',p.group_capacity);x.jump('ae','skip');save('eax','player_group')
    x.imul('ecx','eax',0x268);x.rr('01','ecx','ebx');x.ri(0,'ecx',p.manager_groups)
    x.cmpm('eax','ecx',0x18);x.jump('ne','skip')
    x.op(7,0,'ecx',0x44);x.jump('ne','skip')
    # The native caller's EDX must resolve to an in-range self-identifying group.
    # Its owner/ordinal and exact roster position distinguish personal soldiers
    # from the main officer, reserve, guards, NPCs and unrelated infantry.
    x.load('edx','esp',20);x.sane('edx','skip');save('edx','group')
    x.load('eax','edx',0x18);x.cmp('eax',p.group_capacity);x.jump('ae','skip');save('eax','group_id')
    x.cmpm('eax',disp=data+FIELDS['player_group']);x.jump('eq','skip')
    x.imul('ecx','eax',0x268);x.rr('01','ecx','ebx');x.ri(0,'ecx',p.manager_groups)
    x.rr('39','edx','ecx');x.jump('ne','skip')
    for off,val in ((0x44,0),(0x24,30),(0x2C,30),(0x30,865)):
        x.op(7,val,'edx',off);x.jump('ne','skip')
    x.load('eax','edx',0x28);x.cmp('eax',1);x.jump('below','skip')
    x.cmp('eax',30);x.jump('above','skip')
    x.load('eax','edx',0x1C);x.cmp('eax',1);x.jump('below','skip')
    x.cmp('eax',4);x.jump('above','skip')
    x.lea('ecx','ebx',0x4B0)
    x.op(7,0,'ecx',0x38);x.jump('ne','skip')
    x.op(7,0,'ecx',0x40);x.jump('ne','skip')
    x.load('esi','ecx',0x44);ctx('esi','character')
    x.load('esi','ecx',0xF8);x.sane('esi','skip')
    # Read any roster entry only after bounding the allocation and count.
    x.load('edx','ecx',0x100);x.cmp('edx',5);x.jump('below','skip')
    x.cmp('edx',6);x.jump('above','skip')
    x.load('ecx','ecx',0xFC);x.cmp('ecx',6);x.jump('above','skip')
    x.rr('39','edx','ecx');x.jump('above','skip')
    x.mem('0fb7',R['edx'],'esi');x.cmpm('edx',disp=data+FIELDS['player_group']);x.jump('ne','skip')
    x.imul('eax','eax',2);x.rr('01','esi','eax')
    x.mem('0fb7',R['eax'],'esi');x.cmpm('eax',disp=data+FIELDS['group_id']);x.jump('ne','skip')
    emit_family_scope(x,data,{name:data+FIELDS[name] for name in ('manager','owner','group')},
                      'skip',prefix='map_family',squad_count=4,pool=p)
    # A context publication or load racing our reads must retain the native filter.
    load('eax','manager');x.cmpm('eax',disp=base+0x6A91E8);x.jump('ne','skip')
    load('eax','sequence');x.cmpm('eax',disp=auto+16);x.jump('ne','skip');ctx('eax','sequence')
    for rva,field in ((0x6A91E8,'manager'),(0x6A91D8,'ai'),(0x6A91EC,'players'),(0x6D10BC,'phase')):
        x.load('eax',disp=base+rva);ctx('eax',field)
    x.load('eax','eax',0x1C784);x.cmp('eax',4);x.jump('eq','commit_phase_ok')
    x.cmp('eax',5);x.jump('ne','skip');x.mark('commit_phase_ok')
    for address,val in ((auto+12,0),(auto+24,1),(recall+8,1),(recall+12,0)):
        x.op(7,val,disp=address);x.jump('ne','skip')
    x.op(7,0,disp=auto+20);x.jump('ne','skip')
    x.op(7,0,disp=recall+16);x.jump('ne','skip')
    inc(0x14)
    # Zero-result TEST: CF/OF/SF=0, ZF/PF=1; preserve unrelated flags and the
    # original undefined AF. GP registers, FPU and native stack are untouched.
    x.op(4,0xFFFFF73A,'esp',32);x.op(1,0x44,'esp',32)
    x.jump('jmp','unlock');x.mark('skip');inc(0x18)
    x.mark('unlock');x.set(0,disp=data+12)
    x.mark('native');x.emit('619d');x.emit(relative_jump(code+len(x.code),base+0x5269C4))
    return x.finish()


def check_code(memory):
    # Adjacent branch and owner/mask derivation prove the displaced instruction's
    # contract without comparing ASLR-dependent absolute operands.
    for rva,sig in ((0x5269AC,'8bce83e11fb801000000d3e08bcec1e905'),
                    (0x526955,'8b72448954241481fefa0000000f831b040000f64250050f8511040000'),
                    (0x5269C4,'0f87b90300008bc2e8eff3fdff')):
        require(memory.read(memory.base+rva,len(bytes.fromhex(sig)))==bytes.fromhex(sig),
                'E_MAP_MARKER_NATIVE_'+hex(rva))
    import struct
    expected=bytes.fromhex('8b1d')+struct.pack('<I',memory.base+0x6A91E8)
    require(memory.read(memory.base+0x526972,6)==expected,'E_MAP_MARKER_MANAGER_OPERAND')


def public(memory,record):
    result=bundle.public(__import__(__name__),memory,record)
    result.update(scope='FOUR_VERIFIED_PLAYER1_INFANTRY_ROSTER_SLOTS',default_enabled=False,
                  ordinary_map_filter_exception=True,world_positions_modified=False,
                  owner_bitmap_modified=False,groups_or_agents_created=0,
                  renderer_modified=False,remote_threads_created=False,
                  native_helpers_called=False,live_validated=False)
    return result
