"""NPC-only probability inputs. No unit/stat/cache writes or native calls.

The three original MOVZX instructions read the native D3 decision tier. Only
their destination register is substituted, immediately before the original game
probability calculation. D3, difficulty, tables, RNG and action checks remain
native. Importing this module does not attach to a process.
"""
from pool_binding import resolve as resolve_pool
import hashlib
import struct
from core import require,PROFILE
from bridge import relative_jump
from recall_bridge import Asm,R

MAGIC=0x38494144
VERSION=1
DATA_SIZE=0x1000
CODE_SIZE=0x4000
MAXIMUM=15
ALL_TESTS=7
SITES={
    'TEST_1':{'site_rva':0x50D011,'original':'0fb688d3000000','agent_register':'eax','output_register':'ecx'},
    'TEST_2':{'site_rva':0x51FBF7,'original':'0fb68bd3000000','agent_register':'ebx','output_register':'ecx'},
    'TEST_3':{'site_rva':0x532716,'original':'0fb6b0d3000000','agent_register':'eax','output_register':'esi'},
}
COUNTERS={'intercepts':0x10,'eligible_decisions':0x14,'boosted_decisions':0x18,
          'already_maximum':0x1C,'skipped_players':0x20,'skipped_phase':0x24,
          'skipped_identity':0x28,'allied_decisions':0x2C,'enemy_decisions':0x30,
          'single_member_group_decisions':0x34,'multi_member_group_decisions':0x38,
          'enabled_decisions':0x40,'observed_without_override':0x44}


def initial_data():
    raw=bytearray(DATA_SIZE);struct.pack_into('<4I',raw,0,MAGIC,VERSION,0,MAXIMUM)
    return bytes(raw)


def build_bridge(base,data,code,name,*,pool=None):
    p=resolve_pool(pool)
    require(name in SITES,'E_OFFENSIVE_SITE_NAME')
    spec=SITES[name];index=list(SITES).index(name);path=data+0x100+index*0x40
    x=Asm()
    inc=lambda off:x.mem('ff',0,disp=data+off)
    path_inc=lambda off:x.mem('ff',0,disp=path+off)
    def invalid(cond):x.jump(cond,'identity')
    def ptr(reg,address):x.load(reg,disp=address);x.sane(reg,'identity')
    x.emit('9c60')
    for off,value in ((0,MAGIC),(4,VERSION),(12,MAXIMUM)):
        x.op(7,value,disp=data+off);x.jump('ne','original')
    x.op(7,ALL_TESTS,disp=data+8);x.jump('above','original')
    inc(COUNTERS['intercepts']);path_inc(0)
    ptr('eax',base+0x6D10BC)
    x.op(7,4,'eax',0x1C784);x.jump('ne','phase')
    ptr('edi',base+0x6A91E8);ptr('ebx',base+0x6A91D8)
    # PUSHAD offsets from current ESP: EAX=28, EBX=16. No shared scratch.
    x.load('esi','esp',28 if spec['agent_register']=='eax' else 16)
    x.sane('esi','identity')
    x.load('eax','esi',0x7C);x.cmp('eax',150);invalid('ae')
    x.imul('ecx','eax',0xE0);x.rr('01','ecx','ebx');x.ri(0,'ecx',0x21EF8)
    x.rr('39','ecx','esi');invalid('ne')
    x.mem('f7',0,'esi',0xCC);x.dword(1);invalid('eq')
    x.mem('f7',0,'esi',0xCC);x.dword(0x08000000);x.jump('ne','player')
    x.load('edx','esi',0x80);x.sane('edx','identity')
    x.load('ecx','edx',0x74);x.cmp('ecx',p.group_capacity);invalid('ae')
    x.imul('eax','ecx',0xA0);x.rr('01','eax','ebx');x.ri(0,'eax',p.ai_groups)
    x.rr('39','eax','edx');invalid('ne')
    x.imul('eax','ecx',0x268);x.rr('01','eax','edi');x.ri(0,'eax',p.manager_groups)
    x.cmpm('ecx','eax',0x18);invalid('ne')
    x.load('ecx','eax',0x44);x.cmp('ecx',250);invalid('ae')
    x.imul('ebp','ecx',0xAC);x.rr('01','ebp','ebx')
    x.cmpm('ebp','edx',0x78);invalid('ne')
    x.imul('ebp','ecx',0x110);x.rr('01','ebp','edi');x.ri(0,'ebp',0x4B0)
    x.cmpm('ecx','ebp',0x38);invalid('ne')
    x.load('edx','ebp',0x40);x.cmp('edx',1);invalid('above')
    x.load('ecx','eax',0x24);x.cmp('ecx',0);invalid('eq')
    x.cmp('ecx',30);invalid('above')
    x.load('edi','eax',0x28);x.cmp('edi',0);invalid('eq')
    x.rr('39','edi','ecx');invalid('above')
    # Original tier is read only; the ordinary native writer caps it at 15.
    x.mem('0fb6',R['edi'],'esi',0xD3);x.cmp('edi',MAXIMUM);invalid('above')
    inc(COUNTERS['eligible_decisions']);path_inc(4)
    x.store('edi',disp=path+12)
    x.load('ebx','esi',0x7C);x.store('ebx',disp=path+16)
    x.load('ebx','eax',0x18);x.store('ebx',disp=path+20)
    x.load('ebx','eax',0x44);x.store('ebx',disp=path+24)
    x.store('edx',disp=path+28);x.store('ecx',disp=path+32)
    x.cmp('edx',0);x.jump('ne','enemy')
    inc(COUNTERS['allied_decisions']);x.jump('jmp','side_done')
    x.mark('enemy');inc(COUNTERS['enemy_decisions']);x.mark('side_done')
    x.cmp('ecx',1);x.jump('ne','multiple')
    inc(COUNTERS['single_member_group_decisions']);x.jump('jmp','kind_done')
    x.mark('multiple');inc(COUNTERS['multi_member_group_decisions']);x.mark('kind_done')
    x.mem('f7',0,disp=data+8);x.dword(1<<index);x.jump('eq','disabled')
    inc(COUNTERS['enabled_decisions']);path_inc(0x2C)
    x.cmp('edi',MAXIMUM);x.jump('eq','maximum')
    inc(COUNTERS['boosted_decisions']);path_inc(0x24);x.jump('jmp','apply')
    x.mark('maximum');inc(COUNTERS['already_maximum']);path_inc(0x28)
    x.mark('apply');x.emit('619d');x.imm(spec['output_register'],MAXIMUM)
    x.emit(relative_jump(code+len(x.code),base+spec['site_rva']+7))
    x.mark('disabled');inc(COUNTERS['observed_without_override']);x.jump('jmp','original')
    for label,counter in (('player','skipped_players'),('phase','skipped_phase'),('identity','skipped_identity')):
        x.mark(label);inc(COUNTERS[counter]);path_inc(8);x.jump('jmp','original')
    x.mark('original');x.emit('619d');x.emit(bytes.fromhex(spec['original']))
    x.emit(relative_jump(code+len(x.code),base+spec['site_rva']+7))
    result=x.finish();require(len(result)<0x1000,'E_OFFENSIVE_BRIDGE_SIZE')
    return result


def prepare(base,data,code):
    result=[]
    for index,(name,spec) in enumerate(SITES.items()):
        address=code+index*0x1000;payload=build_bridge(base,data,address,name)
        result.append({'mode':name,'site':base+spec['site_rva'],'original_hex':spec['original'],
            'replacement_hex':relative_jump(base+spec['site_rva'],address,7).hex(),
            'code_address':address,'code_size':len(payload),
            'code_sha256':hashlib.sha256(payload).hexdigest(),'installed':False})
    return result


def validate(memory,record):
    require(record.get('version')==VERSION,'E_OFFENSIVE_JOURNAL_VERSION')
    data,code=record.get('data_address',0),record.get('code_address',0)
    require(0x10000<=data<0xFFF00000-DATA_SIZE and 0x10000<=code<0xFFF00000-CODE_SIZE and
            (data+DATA_SIZE<=code or code+CODE_SIZE<=data),'E_OFFENSIVE_ALLOCATIONS')
    expected=prepare(memory.base,data,code);patches=record.get('patches',[])
    require(len(patches)==len(expected),'E_OFFENSIVE_JOURNAL_SITES')
    for saved,wanted in zip(patches,expected):
        require(all(saved.get(k)==v for k,v in wanted.items() if k!='installed'),
                'E_OFFENSIVE_JOURNAL_IDENTITY')
        actual=memory.read(saved['site'],7)
        require(actual in (bytes.fromhex(saved['original_hex']),bytes.fromhex(saved['replacement_hex'])),
                'E_OFFENSIVE_SITE_CONFLICT')
        saved['installed']=actual==bytes.fromhex(saved['replacement_hex'])
        payload=memory.read(saved['code_address'],saved['code_size'])
        require(hashlib.sha256(payload).hexdigest()==saved['code_sha256'],'E_OFFENSIVE_CODE_CHANGED')
    header=memory.read(data,16)
    require(len(header)==16 and struct.unpack('<4I',header) in
            tuple((MAGIC,VERSION,mask,MAXIMUM) for mask in range(ALL_TESTS+1)),
            'E_OFFENSIVE_DATA_HEADER')
    for rva,signature in PROFILE['offensive_ai']['code_checks'].items():
        expected_bytes=bytes.fromhex(signature)
        require(memory.read(memory.base+int(rva),len(expected_bytes))==expected_bytes,
                'E_OFFENSIVE_NATIVE_CODE_'+hex(int(rva)))


def public(memory,record):
    result={'available':True,'enabled':False,'implementation':'SCOPED_NATIVE_DECISION_INPUTS',
        'scope':'ALLIED_AND_ENEMY_NPCS','mode_filter':False,'maximum_decision_input':MAXIMUM,
        'unit_stats_modified':False,'unit_cache_modified':False,'native_d3_modified':False,
        'difficulty_modified':False,'native_action_checks_preserved':True,
        'defensive_profile_complete':False,'live_behavior_verified':False,
        'last_state':(record or {}).get('state','OFF'),'hook_installed':False,
        'enabled_tests':[],'test_mask':0,'configuration_epoch':0}
    if not record:return result
    result['hook_installed']=any(p.get('installed') for p in record.get('patches',[]))
    if 'data_address' not in record:return result
    raw=memory.read(record['data_address'],DATA_SIZE)
    require(len(raw)==DATA_SIZE and struct.unpack_from('<2I',raw)==(MAGIC,VERSION),
            'E_OFFENSIVE_DATA_HEADER')
    mask=struct.unpack_from('<I',raw,8)[0];require(0<=mask<=ALL_TESTS,'E_OFFENSIVE_TEST_MASK')
    result['test_mask']=mask;result['configuration_epoch']=struct.unpack_from('<I',raw,0x3C)[0]
    result['enabled_tests']=[name for i,name in enumerate(SITES) if mask&(1<<i)]
    result['enabled']=bool(mask and result['hook_installed'] and
        record.get('state')=='APPLIED' and all(p.get('installed') for p in record.get('patches',[])))
    result.update({name:struct.unpack_from('<I',raw,off)[0] for name,off in COUNTERS.items()})
    result['paths']={}
    for index,name in enumerate(SITES):
        at=0x100+index*0x40;v=struct.unpack_from('<12I',raw,at)
        result['paths'][name]={'enabled':bool(mask&(1<<index)),'site_rva':hex(SITES[name]['site_rva']),
            'configured_input':MAXIMUM,'counter_unit':'DECISION_INPUT_READS_AND_SUBSTITUTIONS',
            'intercepts':v[0],'eligible_decisions':v[1],'skipped':v[2],
            'last_native_input':v[3] if v[1] else None,'last_agent':v[4] if v[1] else None,
            'last_group':v[5] if v[1] else None,'last_owner':v[6] if v[1] else None,
            'last_side':v[7] if v[1] else None,'last_group_capacity':v[8] if v[1] else None,
            'boosted_decisions':v[9],'already_maximum':v[10],'enabled_decisions':v[11]}
    return result
